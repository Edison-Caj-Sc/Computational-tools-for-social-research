# =====================================================================
#  06 · FRACTIONAL REGRESSION (quasi-binomial logit, Papke & Wooldridge)
#  For: proportions between 0 and 1, including exact 0s and 1s: food share of
#  spending, vote share, attendance rate.
#  Interpretation: use the marginal effects (change in the expected proportion).
# =====================================================================

# ---------------------------------------------------------------------
# 0. SETTINGS · edit this section only
# ---------------------------------------------------------------------
file           <- NULL
outcome        <- "food_share"            # between 0 and 1 (if in %, set scale_100 = TRUE)
scale_100      <- FALSE                   # TRUE if the variable is a percentage (0-100)
predictors     <- c("log_income", "head_educ", "head_sex", "area", "hh_size")
factors        <- list(head_sex = "male", area = "urban")
extra_terms    <- NULL
manual_formula <- NULL
focus_variable <- "log_income"
use_design     <- FALSE
design         <- list(stratum = "stratum", psu = "psu", weight = "weight")
output_dir     <- "results/06_fractional_regression"

# ---------------------------------------------------------------------
# 1. Preparation
# ---------------------------------------------------------------------
source("utils.R"); install_if_missing()
out     <- prepare_output(output_dir)
formula <- build_formula(outcome, predictors, extra_terms, manual_formula)
data    <- prepare_data(load_data(file), formula_vars(formula), factors, extra = design_vars(use_design, design))
y <- all.vars(formula)[1]
if (scale_100) data[[y]] <- data[[y]] / 100
if (any(data[[y]] < 0 | data[[y]] > 1)) stop("The outcome must be between 0 and 1 (see 'scale_100').")
dsg <- if (use_design) create_design(data, design) else NULL

header("Descriptives")
desc <- data.frame(mean = mean(data[[y]]), median = median(data[[y]]),
                   pct_zeros = 100 * mean(data[[y]] == 0), pct_ones = 100 * mean(data[[y]] == 1))
print(round_df(desc, 3)); save_table(desc, "1_descriptives", out)

# ---------------------------------------------------------------------
# 2. Estimation (robust standard errors: quasi-likelihood only needs a correct mean)
# ---------------------------------------------------------------------
header("Model")
if (use_design) {
  model <- svyglm(formula, design = dsg, family = quasibinomial())
  vc <- NULL
} else {
  model <- glm(formula, data = data, family = quasibinomial())
  vc <- sandwich::vcovHC(model, type = "HC0")
}
coefs <- coef_table(model, vcov = vc)
print(round_df(coefs, 3)); save_table(coefs, "2_coefficients", out)
cat("Coefficients are on the logit scale: read their sign and use marginal effects for magnitude.\n")

# ---------------------------------------------------------------------
# 3. Fit
# ---------------------------------------------------------------------
header("Fit")
fit <- data.frame(n = nrow(data), squared_corr_obs_pred = cor(data[[y]], fitted(model))^2,
                  dispersion = summary(model)$dispersion)
print(round_df(fit, 3)); save_table(fit, "3_fit", out)

# ---------------------------------------------------------------------
# 4. Interpretation
# ---------------------------------------------------------------------
header("Average marginal effects (change in the proportion)")
ame <- marginal_effects(model, data, dsg, vcov = if (is.null(vc)) TRUE else vc)
ame$effect_pp <- 100 * ame$effect
print(round_df(ame, 4)); save_table(ame, "4_marginal_effects", out)
save_plot(prediction_plot(model, data, focus_variable, dsg, paste("Expected proportion of", y)), "4_predictions", out)
save_text(summary(model), "model_summary", out)
header(paste("Done. Results in", out))
