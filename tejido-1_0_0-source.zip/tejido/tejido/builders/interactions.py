"""Interactions: records where an actor addresses, answers, forwards or names another actor.

Social media (mentions, replies, reposts, quotes), e-mails (from → to, cc), messaging, parliamentary
debates (speaker → person named), letters, complaints. Recipients come from columns ('targets') and/or
are extracted from the text (@mentions, e-mail addresses). network: actors · hashtags · actors_hashtags"""
from __future__ import annotations

import itertools
import re
from ..utils import log

import pandas as pd

from ..graph import aggregate_edges, to_graph
from ..utils import ConfigError, as_list, require_columns
from . import register

MENTION = re.compile(r"(?<![\w@])@(\w{1,50})", re.UNICODE)
EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
HASHTAG = re.compile(r"(?<![\w#&])#(\w*[^\W\d]\w*)", re.UNICODE)


def _clean(s: pd.Series, lower: bool) -> pd.Series:
    s = s.astype("string").str.strip().str.lstrip("@")
    s = s.where(s.notna() & (s != ""), None)
    return s.str.lower() if lower else s


@register("interactions", "Who addresses whom: mentions, replies, reposts, e-mails, messages, debates")
def build(data: pd.DataFrame, opts: dict, cfg: dict):
    src = opts.get("source", opts.get("author", "author"))
    text = opts.get("text")
    lower = bool(opts.get("lowercase", True))
    network = {"users": "actors", "users_hashtags": "actors_hashtags"}.get(opts.get("network", "actors"),
                                                                       opts.get("network", "actors"))
    targets = opts.get("targets") or {}
    if isinstance(targets, (list, str)):
        targets = {c: c for c in as_list(targets)}
    for kind, col in (("reply", "reply_to"), ("repost", "repost_of"), ("quote", "quote_of")):   # old names
        if opts.get(col):
            targets.setdefault(kind, opts[col])
    kinds = opts.get("kinds", opts.get("edges"))
    extract = set(as_list(opts.get("extract")))
    if kinds is None:
        kinds = list(targets) + (["mention"] if text and "emails" not in extract else []) + \
            (["email"] if "emails" in extract else [])
    kinds = as_list(kinds)
    if "mention" in kinds and text:
        extract.add("mentions")
    time = opts.get("time")
    require_columns(data, [src, text, time] + list(targets.values()), "interactions")
    df = data.copy()
    df["_src"] = _clean(df[src], lower)
    df = df[df["_src"].notna()]
    txt = df[text].fillna("").astype(str) if text else pd.Series("", index=df.index)

    if network == "hashtags":
        rows = []
        for tags in txt.map(lambda t: sorted({h.lower() if lower else h for h in HASHTAG.findall(t)})):
            rows += [{"source": f"#{a}", "target": f"#{b}"} for a, b in itertools.combinations(tags, 2)]
        edges = aggregate_edges(pd.DataFrame(rows, columns=["source", "target"]), directed=False)
        G = to_graph(edges, directed=False)
        for n in G:
            G.nodes[n]["type"] = "hashtag"
        return G

    def part(sources, recipients, kind, times):
        return pd.DataFrame({"source": sources, "target": recipients, "kind": kind, "time": times})

    parts = []
    sep = opts.get("split")
    for kind, col in targets.items():
        if kind not in kinds:
            continue
        t = df[[col, "_src"] + ([time] if time else [])].copy()
        if sep:
            t[col] = t[col].astype("string").str.split(str(sep))
            t = t.explode(col)
        parts.append(part(t["_src"], _clean(t[col], lower), kind, t[time] if time else None))
    patterns = {"mentions": ("mention", MENTION), "emails": ("email", EMAIL)}
    for name in extract & set(patterns):
        if not text:
            raise ConfigError(f"interactions: extracting {name} needs the 'text' column")
        kind, rx = patterns[name]
        m = df.assign(_t=txt.map(rx.findall)).explode("_t").dropna(subset=["_t"])
        parts.append(part(m["_src"], _clean(m["_t"], lower), kind, m[time] if time else None))
    if network == "actors_hashtags":
        h = df.assign(_t=txt.map(HASHTAG.findall)).explode("_t").dropna(subset=["_t"])
        parts.append(part(h["_src"], "#" + _clean(h["_t"], lower), "uses_hashtag", h[time] if time else None))
    elif network != "actors":
        raise ConfigError("interactions: 'network' must be actors, hashtags or actors_hashtags")
    if not parts:
        raise ConfigError("interactions: nothing to build. Set 'targets' (recipient columns) or 'text' with 'extract'.")
    raw = pd.concat(parts, ignore_index=True).dropna(subset=["target"])
    raw = raw[raw["target"].astype(str) != ""]
    for k in raw["kind"].unique():
        raw[f"n_{k}"] = (raw["kind"] == k).astype(int)
    attrs = {c: "sum" for c in raw.columns if c.startswith("n_")}
    attrs["kind"] = "values"
    if time:
        raw["time_last"] = raw["time"]
        attrs.update({"time": "min", "time_last": "max"})
    directed = bool(opts.get("directed", network == "actors"))
    edges = aggregate_edges(raw, directed=directed, attributes=attrs).rename(columns={"kind": "relation"})
    if time:
        edges = edges.rename(columns={"time": "first_time", "time_last": "last_time"})
    edges = edges[edges["weight"] >= float(opts.get("min_interactions", 1))]

    activity = df.groupby("_src").size().rename("activity")
    nodes = activity.reset_index().rename(columns={"_src": "id"})
    for col in as_list(opts.get("node_attributes")):
        require_columns(df, col, "interactions.node_attributes")
        nodes = nodes.merge(df.groupby("_src")[col].max().rename(col), left_on="id", right_index=True, how="left")
    G = to_graph(edges, directed=directed, nodes=nodes)
    for n in G:
        G.nodes[n].setdefault("activity", 0)
        G.nodes[n]["type"] = "hashtag" if str(n).startswith("#") else "actor"
    log.info(f"interactions: {len(raw):,} interactions → {G.number_of_edges():,} ties")
    return G
