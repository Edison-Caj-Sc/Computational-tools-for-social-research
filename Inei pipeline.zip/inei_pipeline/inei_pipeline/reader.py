"""Lectura de módulos descargados (ZIP o archivos sueltos) conservando los códigos."""
from __future__ import annotations

import fnmatch
import io
import re
import tempfile
import zipfile
from pathlib import Path

import pandas as pd

from .download import module_number
from .utils import as_list, log, normalize_name

DATA_EXT = (".dta", ".sav", ".csv")


def _read_buffer(raw: bytes, name: str) -> pd.DataFrame:
    ext = Path(name).suffix.lower()
    if ext == ".dta":
        # Leemos códigos (1, 2, 3…), no etiquetas, para poder recodificar.
        return pd.read_stata(io.BytesIO(raw), convert_categoricals=False)
    if ext == ".sav":
        import pyreadstat
        with tempfile.NamedTemporaryFile(suffix=".sav", delete=False) as tmp:
            tmp.write(raw)
        try:
            df, _ = pyreadstat.read_sav(tmp.name, apply_value_formats=False)
        finally:
            Path(tmp.name).unlink(missing_ok=True)
        return df
    for enc in ("utf-8-sig", "latin-1"):
        try:
            return pd.read_csv(io.BytesIO(raw), encoding=enc, low_memory=False)
        except UnicodeDecodeError:
            continue
    raise ValueError(f"No pude leer {name}")


def _clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [normalize_name(c) for c in df.columns]
    return df.loc[:, ~df.columns.duplicated()]


def table_key(stem: str, mod: int | None = None) -> str:
    """Nombre de tabla válido como variable y estable entre años.

    'sumaria-2024' (módulo 34) -> 'm34_sumaria'; 'enaho01-2024-100' -> 'm01_enaho01_100'.
    """
    s = re.sub(r"(?<!\d)(?:19|20)\d{2}(?!\d)", "", stem.lower())
    s = re.sub(r"_+", "_", normalize_name(s)).strip("_") or "tabla"
    return f"m{mod:02d}_{s}" if mod is not None else (s if s[0].isalpha() else f"t_{s}")


def read_year(folder: Path, modules=None, exclude=None) -> dict[str, pd.DataFrame]:
    """Lee todas las tablas de datos de una carpeta de año.

    Devuelve {nombre_tabla: DataFrame}. Los ZIP se filtran por número de módulo.
    """
    wanted = {int(m) for m in as_list(modules)}
    exclude = [str(p).lower() for p in as_list(exclude)]
    tables: dict[str, pd.DataFrame] = {}
    if not folder.exists():
        return tables

    def add(name: str, raw: bytes, mod: int | None):
        tname = Path(name).stem.lower()
        if any(fnmatch.fnmatch(tname, p) or fnmatch.fnmatch(table_key(tname, mod), p) for p in exclude):
            log.info(f"  · tabla {tname} excluida por configuración")
            return
        key = table_key(tname, mod)
        if key in tables:
            k = 2
            while f"{key}_{k}" in tables:
                k += 1
            key = f"{key}_{k}"
        tables[key] = _clean(_read_buffer(raw, name))

    for path in sorted(folder.rglob("*")):
        suf = path.suffix.lower()
        if suf == ".zip":
            mod = module_number(path.stem)
            if wanted and mod not in wanted:
                continue
            with zipfile.ZipFile(path) as zf:
                for name in zf.namelist():
                    if name.lower().endswith(DATA_EXT) and not name.startswith("__MACOSX"):
                        add(name, zf.read(name), mod)
        elif suf in DATA_EXT:
            add(path.name, path.read_bytes(), None)
    return tables
