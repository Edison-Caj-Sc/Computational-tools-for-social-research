# Run this file once to install the packages used by the templates.
source("utils.R")
install_if_missing()
cat("Done: packages installed and loaded.\n")
