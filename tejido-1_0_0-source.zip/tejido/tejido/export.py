"""Stage 6 · export: tables (CSV, Excel), network files (GraphML, GEXF, JSON, Pajek, UCINET DL, adjacency
matrix), an interactive HTML view and a report (English or Spanish). Extra result tables (communities,
homophily, egos, evolution, layers, null model…) are always saved as CSV."""
from __future__ import annotations

import json
import re
import time
from html import escape as _esc
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd

from .config import resolve
from .utils import ConfigError, file_stem, log

VIS_JS = "https://cdn.jsdelivr.net/npm/vis-network@9.1.9/standalone/umd/vis-network.min.js"


def _plain(v):
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return float(v)
    if isinstance(v, (list, tuple, set, dict)):
        return json.dumps(list(v) if isinstance(v, set) else v, ensure_ascii=False)
    return v


def tables_of(G: nx.Graph) -> tuple[pd.DataFrame, pd.DataFrame]:
    nodes = pd.DataFrame([{"id": n, **{k: _plain(v) for k, v in d.items()}} for n, d in G.nodes(data=True)])
    edges = pd.DataFrame([{"source": u, "target": v, **{k: _plain(x) for k, x in d.items() if k != "distance"}}
                          for u, v, d in G.edges(data=True)])
    return nodes, edges


_XML_ILLEGAL = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\ufffe\uffff]")      # characters XML and Excel files cannot hold
_FORMULA_START = ("=", "+", "-", "@", "\t", "\r")
EXCEL_CELL_MAX = 32000


def _xml_text(v):
    return _XML_ILLEGAL.sub(" ", v) if isinstance(v, str) else v


def _json_in_script(obj) -> str:
    """JSON that can sit inside <script> whatever the data say: no '<', '>' or '&' left to close the tag or open a comment."""
    return (json.dumps(obj, ensure_ascii=False).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
            .replace("\u2028", "\\u2028").replace("\u2029", "\\u2029"))


def _sheet_table(df: pd.DataFrame) -> pd.DataFrame:
    """A table ready for Excel: no characters a workbook cannot hold, no cell longer than Excel accepts."""
    out = df.copy()
    for c in out.columns:
        if out[c].dtype == object or pd.api.types.is_string_dtype(out[c]):
            out[c] = out[c].map(lambda v: _XML_ILLEGAL.sub(" ", v)[:EXCEL_CELL_MAX] if isinstance(v, str) else v)
    out.columns = [_xml_text(str(c)) for c in out.columns]
    return out


def _texts_not_formulas(book) -> None:
    """In the workbook, a text that starts with '=' stays a text ("=SUM(A1)" is a name, not something Excel computes)."""
    for ws in book.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                if cell.data_type == "f":
                    cell.data_type = "s"


def _formula_like(tables) -> bool:
    for df in tables:
        for c in df.columns:
            if df[c].dtype == object or pd.api.types.is_string_dtype(df[c]):
                if df[c].map(lambda v: isinstance(v, str) and v.startswith("=")).any():
                    return True
    return False


def escape_formulas(df: pd.DataFrame) -> pd.DataFrame:
    """output.escape_formulas: texts that a spreadsheet would run as formulas (= + - @ at the start) get a leading
    apostrophe in the CSV files. Off by default, because it changes those texts for other programs (R, Gephi…)."""
    out = df.copy()
    for c in out.columns:
        if out[c].dtype == object or pd.api.types.is_string_dtype(out[c]):
            out[c] = out[c].map(lambda v: "'" + v if isinstance(v, str) and v.startswith(_FORMULA_START) else v)
    return out


def _clean_graph(G: nx.Graph) -> nx.Graph:
    """Plain attribute values with one type per attribute (GraphML/GEXF need consistent types), and texts
    without control characters (they come with text extracted from PDF files and XML formats refuse them)."""
    H = G.copy()
    if any(isinstance(n, str) and _XML_ILLEGAL.search(n) for n in H):
        H = nx.relabel_nodes(H, {n: _xml_text(n) for n in H}, copy=True)
    H.graph = {k: _xml_text(v) for k, v in H.graph.items() if isinstance(v, (str, int, float, bool))}
    for items in ([d for _, d in H.nodes(data=True)], [d for *_, d in H.edges(data=True)]):
        kinds: dict = {}
        for d in items:
            for k in list(d):
                v = _plain(d[k])
                if v is None or (isinstance(v, float) and not np.isfinite(v)):
                    del d[k]
                    continue
                if not isinstance(v, (str, int, float, bool)):
                    v = str(v)
                d[k] = _xml_text(v)
                kinds.setdefault(k, set()).add(bool if isinstance(v, bool) else int if isinstance(v, int)
                                               else float if isinstance(v, float) else str)
        for k, ts in kinds.items():
            if len(ts) > 1:
                cast = str if str in ts or bool in ts else float
                for d in items:
                    if k in d:
                        d[k] = cast(d[k])
    return H


def _scale(values, lo, hi):
    v = np.asarray(values, dtype=float)
    v = np.nan_to_num(v, nan=0.0)
    if v.max() == v.min():
        return np.full_like(v, (lo + hi) / 2)
    return lo + (v - v.min()) / (v.max() - v.min()) * (hi - lo)


def _tooltip(d: dict, keys) -> str:
    lines = []
    for k in keys:
        if k in d and d[k] not in (None, ""):
            v = d[k]
            lines.append(f"{k}: {round(v, 4) if isinstance(v, float) else v}")
    return "\n".join(lines)


CATEGORY_CODES = {"community", "block", "component", "core_periphery", "layer", "cluster", "type"}


def _number(v) -> bool:
    return isinstance(v, (int, float, np.integer, np.floating)) and not isinstance(v, (bool, np.bool_))


def _numeric_attr(name: str, values) -> bool:
    """Color with a gradient (not with categories) when the attribute is a measure with many values."""
    vals = [v for v in values if v is not None and not (isinstance(v, float) and np.isnan(v))]
    return name not in CATEGORY_CODES and bool(vals) and all(_number(v) for v in vals) and len(set(vals)) > 10


def _fmt(v) -> str:
    return f"{v:,.4g}" if isinstance(v, float) else str(v)


def html(G: nx.Graph, path: Path, title: str, summary: dict, opts: dict) -> None:
    """Interactive page (vis-network). opts.style holds the look chosen in the visual interface (see ui/static/style.js)."""
    size_by, color_by = opts.get("size_by", "pagerank"), opts.get("color_by", "community")
    style = opts.get("style") if isinstance(opts.get("style"), dict) else {}
    max_nodes = int(opts.get("max_nodes", 1500))
    note = ""
    if G.number_of_nodes() > max_nodes:
        key = size_by if all(size_by in d for _, d in G.nodes(data=True)) else None
        ranked = sorted(G.nodes, key=lambda n: -(G.nodes[n].get(key, 0) if key else G.degree(n)))
        G = G.subgraph(ranked[:max_nodes]).copy()
        note = f" · showing the top {max_nodes:,} nodes by {key or 'degree'}"
    nodes = list(G.nodes)
    sizes = np.nan_to_num(np.asarray([G.nodes[n].get(size_by, G.degree(n)) for n in nodes], dtype=float)) if nodes else []
    raw = [G.nodes[n].get(color_by) for n in nodes]
    numeric = _numeric_attr(color_by, raw)
    shape_by, label_by = str(style.get("shape_by") or ""), str(style.get("label_by") or "")
    keys_n = ["type", "community", "block", "core_periphery", "frequency", "documents", "activity", "size",
              "degree", "in_degree", "out_degree", "strength", "betweenness", "pagerank", "eigenvector", "closeness",
              "harmonic", "constraint", "effective_size", "brokerage", "coreness", "clustering"]

    def text(n, s):                               # (name, suffix): the page may shorten the name, never the value
        name = str(G.nodes[n].get("label", n))
        if label_by == "#size":
            return name, f" · {_fmt(float(s))}"
        x = G.nodes[n].get(label_by) if label_by else None
        return (name if x in (None, "") else _fmt(x)), ""

    vis_nodes = []
    for i, (n, s, c) in enumerate(zip(nodes, sizes, raw)):
        name, suffix = text(n, s)
        d = {"id": i, "label": name + suffix, "name": name, "suffix": suffix, "value": float(s),
             "group": (float(c) if _number(c) and not np.isnan(c) else None) if numeric else str("—" if c in (None, "") else c),
             "title": f"{G.nodes[n].get('label', n)}\n" + _tooltip(G.nodes[n], keys_n)}
        if shape_by:
            d["shape_key"] = str(G.nodes[n].get(shape_by, "—"))
        vis_nodes.append(d)
    idx = {n: i for i, n in enumerate(nodes)}
    ws = [d.get("weight", 1) for *_, d in G.edges(data=True)]
    widths = _scale(ws, .5, 6) if ws else []
    vis_edges = []
    for (u, v, d), w, raw_w in zip(G.edges(data=True), widths, ws):
        extra = {k: d[k] for k in d if k not in ("distance", "evidence") and not (k.startswith("rel_") and not d[k])}
        tip = f"{G.nodes[u].get('label', u)} — {G.nodes[v].get('label', v)}\n" + _tooltip(extra, list(extra))
        if d.get("evidence"):
            tip += "\n\nEvidence:\n" + str(d["evidence"])[:1500]
        e = {"from": idx[u], "to": idx[v], "width": float(w), "w": float(raw_w) if _number(raw_w) else 1.0, "title": tip}
        if d.get("tie_strength") in ("weak", "strong"):
            e["cls"] = d["tie_strength"]
        vis_edges.append(e)
    stats = " · ".join(f"{k.replace('_', ' ')}: {v}" for k, v in summary.items())
    data = _json_in_script({"nodes": vis_nodes, "edges": vis_edges, "directed": G.is_directed(), "numeric": numeric,
                            "color_by": str(color_by), "shape_by": shape_by})
    from importlib import resources

    from . import __author__, __version__
    static = resources.files("tejido").joinpath("ui", "static")
    style_js = static.joinpath("style.js").read_text(encoding="utf-8")
    if opts.get("offline"):                       # embed the library so the page works without internet
        js = static.joinpath("vis-network.min.js").read_text(encoding="utf-8")
        vis = "<script>" + js.replace("</script", "<\\/script") + "</script>"
    else:
        vis = f'<script src="{VIS_JS}"></script>'
    parts = {"TITLE": _esc(str(title)), "STATS": _esc(stats + note), "VERSION": _esc(__version__), "AUTHOR": _esc(__author__),
             "STYLEJS": style_js.replace("</script", "<\\/script"), "STYLE": _json_in_script(style), "DATA": data, "VIS": vis}
    # one pass: a title or a value that happens to contain "__DATA__" is never taken for a placeholder
    page = re.sub(r"__(TITLE|STATS|VERSION|AUTHOR|STYLEJS|STYLE|DATA|VIS)__", lambda m: parts[m.group(1)], HTML_TEMPLATE)
    path.write_text(page, encoding="utf-8")


TR = {"es": {
    "Summary": "Resumen", "measure": "medida", "value": "valor", "Top 10 by": "Los 10 principales por", "node": "nodo",
    "Nodes by type": "Nodos por tipo", "type": "tipo", "nodes": "nodos",
    "Communities (largest first)": "Comunidades (de mayor a menor)", "Community": "Comunidad",
    "Strongest ties": "Vínculos más fuertes", "weight": "peso", "Result tables": "Tablas de resultados",
    "rows": "filas", "file": "archivo", "Measures": "Medidas",
    "nodes_label": "nodos", "ties": "vínculos", "directed": "dirigida", "density": "densidad",
    "average_degree": "grado medio", "degree_sd": "desv. est. del grado", "max_degree": "grado máximo",
    "degree_gini": "Gini del grado", "mean_tie_weight": "peso medio de los vínculos", "components": "componentes",
    "largest_component_share": "proporción en el componente mayor", "strong_components": "componentes fuertes",
    "isolates": "aislados", "diameter": "diámetro", "radius": "radio",
    "average_path_length": "longitud media de camino", "global_efficiency": "eficiencia global",
    "average_clustering": "agrupamiento medio", "transitivity": "transitividad", "reciprocity": "reciprocidad",
    "degree_centralization": "centralización de grado", "betweenness_centralization": "centralización de intermediación",
    "closeness_centralization": "centralización de cercanía", "degree_assortativity": "asortatividad de grado",
    "bridges": "puentes", "cut_points": "puntos de corte", "connectedness": "conectividad (Krackhardt)",
    "hierarchy": "jerarquía (Krackhardt)", "algebraic_connectivity": "conectividad algebraica",
    "communities": "comunidades", "modularity": "modularidad", "type_assortativity": "asortatividad por tipo",
    "dyads_mutual": "díadas mutuas", "dyads_asymmetric": "díadas asimétricas", "dyads_null": "díadas nulas",
    "max_core": "k-núcleo máximo", "max_core_nodes": "nodos en el k-núcleo máximo", "cliques": "cliques",
    "largest_clique": "clique mayor", "blocks": "bloques", "core_size": "tamaño del núcleo",
    "core_periphery_fit": "ajuste núcleo–periferia", "small_world_sigma": "sigma de mundo pequeño",
    "egos": "egos", "mean_network_size": "tamaño medio de la red personal", "mean_ego_density": "densidad media ego",
    "mean_constraint": "restricción media", "units": "unidades", "transitions": "transiciones",
    "mobility_rate": "tasa de movilidad", "brokers": "intermediarios (agujeros estructurales)",
    "embedded_nodes": "nodos integrados (cierre)", "mean_node_constraint": "restricción media de los nodos",
    "mean_hole_share": "proporción media de agujeros", "group_holes": "agujeros entre grupos", "tie_strength_by": "fuerza del vínculo según",
    "strong_ties": "vínculos fuertes", "intermediate_ties": "vínculos intermedios", "weak_ties": "vínculos débiles", "unclassified_ties": "vínculos sin clasificar",
    "tie_strength_rule": "clasificación definida por el investigador",
    "strong_tie_share": "proporción de vínculos fuertes", "local_bridges": "puentes locales",
    "weak_share_of_local_bridges": "proporción de puentes locales que son débiles",
    "weight_overlap_correlation": "correlación peso–superposición", "stc_violations": "violaciones del cierre triádico fuerte"}}


def _t(key: str, lang: str) -> str:
    return TR.get(lang, {}).get(key, key)


def _label(key: str, lang: str) -> str:
    k = "nodes_label" if key == "nodes" else key
    return _t(k, lang) if lang != "en" and k in TR.get(lang, {}) else key.replace("_", " ")


def report(G: nx.Graph, comms, summary: dict, path: Path, title: str, lang: str = "en", tables: dict | None = None) -> None:
    t = lambda k: _t(k, lang)
    nodes, edges = tables_of(G)
    lines = [f"# {title}", "", f"## {t('Summary')}", "", f"| {t('measure')} | {t('value')} |", "|---|---|"]
    rule = lambda k, v: str(v).replace("weak", "débil").replace("strong", "fuerte") if k == "tie_strength_rule" and lang == "es" else v
    lines += [f"| {_label(k, lang)} | {rule(k, v)} |" for k, v in summary.items()]
    label = nodes["label"] if "label" in nodes else nodes["id"]
    for c in ["degree", "strength", "betweenness", "pagerank", "eigenvector", "closeness", "harmonic", "katz",
              "authority", "effective_size", "brokerage"]:
        if c in nodes and nodes[c].notna().any():
            top = nodes.assign(label=label).nlargest(10, c)[["label", c]]
            lines += ["", f"## {t('Top 10 by')} {c}", "", f"| {t('node')} | {c} |", "|---|---|"]
            lines += [f"| {r.label} | {round(getattr(r, c), 4)} |" for r in top.itertuples()]
    if "type" in nodes:
        lines += ["", f"## {t('Nodes by type')}", "", f"| {t('type')} | {t('nodes')} |", "|---|---|"]
        lines += [f"| {k} | {n} |" for k, n in nodes["type"].value_counts().items()]
    if comms:
        key = "pagerank" if "pagerank" in nodes else ("degree" if "degree" in nodes else None)
        lines += ["", f"## {t('Communities (largest first)')}", ""]
        for i, c in enumerate(comms[:15], 1):
            members = sorted(c, key=lambda n: -(G.nodes[n].get(key, 0) if key else 0))
            names = ", ".join(str(G.nodes[n].get("label", n)) for n in members[:8])
            lines.append(f"- **{t('Community')} {i}** ({len(c)} {t('nodes')}): {names}{' …' if len(c) > 8 else ''}")
    if len(edges):
        lines += ["", f"## {t('Strongest ties')}", ""]
        has_rel, has_ev = "main_relation" in edges, "evidence" in edges
        for r in edges.nlargest(15, "weight").itertuples():
            s = f"- **{G.nodes[r.source].get('label', r.source)} — {G.nodes[r.target].get('label', r.target)}** ({t('weight')} {round(r.weight, 3)}"
            s += f", {r.main_relation})" if has_rel else ")"
            if has_ev and isinstance(r.evidence, str) and r.evidence:
                s += f"\n  > {r.evidence.split(chr(10) + '---' + chr(10))[0][:300]}"
            lines.append(s)
    for name, df in (tables or {}).items():
        if df is None or not len(df):
            continue
        lines += ["", f"## {name.replace('_', ' ').capitalize()}", ""]
        show = df.head(20)
        cols = [str(c) for c in show.columns][:10]
        lines += ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
        for row in show.itertuples(index=False):
            vals = [row[i] for i in range(len(cols))]
            lines.append("| " + " | ".join(str(round(v, 4) if isinstance(v, float) else v).replace("|", "/")
                                           for v in vals) + " |")
        if len(df) > 20:
            lines.append(f"\n… {len(df)} {t('rows')} ({name}.csv)")
    from . import __url__, __version__
    made = "Informe generado con" if lang == "es" else "Report made with"
    lines += ["", "---", "", f"*{made} [Tejido]({__url__}) {__version__} · {time.strftime('%Y-%m-%d %H:%M')}*"]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_pajek(G: nx.Graph, path: Path) -> None:
    nodes = list(G)
    idx = {n: i for i, n in enumerate(nodes, 1)}
    lines = [f"*Vertices {len(nodes)}"]
    lines += [f'{i} "{str(G.nodes[n].get("label", n)).replace(chr(34), chr(39))}"' for n, i in idx.items()]
    lines.append("*Arcs" if G.is_directed() else "*Edges")
    lines += [f"{idx[u]} {idx[v]} {w:g}" for u, v, w in G.edges(data="weight", default=1)]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_ucinet(G: nx.Graph, path: Path) -> None:
    """UCINET DL, edgelist1 format with embedded labels."""
    lab = lambda n: '"' + str(G.nodes[n].get("label", n)).replace('"', "'") + '"'
    lines = [f"dl n={G.number_of_nodes()} format=edgelist1", "labels embedded:", "data:"]
    for u, v, w in G.edges(data="weight", default=1):
        lines.append(f"{lab(u)} {lab(v)} {w:g}")
        if not G.is_directed() and u != v:
            lines.append(f"{lab(v)} {lab(u)} {w:g}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


FORMATS = {"csv": "Node and tie tables (CSV)", "xlsx": "Excel workbook: nodes, ties, summary and result tables",
           "graphml": "GraphML (Gephi, Cytoscape, R igraph)", "gexf": "GEXF (Gephi)", "json": "JSON node-link",
           "pajek": "Pajek .net", "ucinet": "UCINET DL edge list", "matrix": "Adjacency matrix (CSV)",
           "html": "Interactive network view", "report": "Report (Markdown)"}


def _sheet_names(names) -> dict:
    """Excel sheet names: 31 characters at most, none of []:*?/\\, and no two alike."""
    used, out = {"summary", "nodes", "ties"}, {}
    for k in names:
        base = re.sub(r"[\[\]:*?/\\]", "_", str(k))[:31] or "table"
        name, i = base, 2
        while name.lower() in used:
            name, i = f"{base[:31 - len(str(i)) - 1]}_{i}", i + 1
        used.add(name.lower())
        out[k] = name
    return out


def export(G: nx.Graph, comms, summary: dict, cfg: dict, tables: dict | None = None, started: float | None = None) -> Path:
    out = Path(resolve(cfg, cfg["output"]["dir"]))
    try:
        out.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise ConfigError(f"The results folder {out} cannot be created: {e.strerror or e}") from e
    name = file_stem(cfg["project"])               # the project name starts every file name: keep it inside the folder
    lang = cfg["output"].get("language", "en")
    tables = {k: v for k, v in (tables or {}).items() if v is not None and len(v)}
    csv_safe = escape_formulas if cfg["output"].get("escape_formulas") else (lambda df: df)
    try:
        _write_formats(G, comms, summary, cfg, tables, out, name, lang, csv_safe)
    except PermissionError as e:                   # typically: the file is open in Excel
        raise ConfigError(f"Could not write {Path(e.filename).name if e.filename else 'a results file'} in {out}: "
                          "close it if it is open in another program (Excel, for example) and build again") from e
    if cfg["output"].get("run_record", True):
        from . import record
        try:
            record.write(out, name, cfg, summary, started)
        except OSError as e:
            log.warning(f"The run record could not be saved: {e}")
    log.info(f"Results saved in {out}")
    return out


def _write_formats(G, comms, summary, cfg, tables, out: Path, name: str, lang: str, csv_safe) -> None:
    for fmt in cfg["output"]["formats"]:
        if fmt == "csv":
            nodes, edges = tables_of(G)
            csv_safe(nodes).to_csv(out / f"{name}_nodes.csv", index=False, encoding="utf-8-sig")
            csv_safe(edges).to_csv(out / f"{name}_edges.csv", index=False, encoding="utf-8-sig")
        elif fmt == "xlsx":
            nodes, edges = tables_of(G)
            sheets = {"summary": pd.DataFrame([(k, _plain(v)) for k, v in summary.items()], columns=["measure", "value"]),
                      "nodes": nodes, "ties": edges}
            sheets.update({s: tables[k] for k, s in _sheet_names(tables).items()})
            sheets = {s: _sheet_table(df) for s, df in sheets.items()}
            try:
                xw = pd.ExcelWriter(out / f"{name}.xlsx", engine="openpyxl")
            except ImportError as e:
                raise ConfigError("Saving Excel workbooks needs the openpyxl package (pip install openpyxl); "
                                  "or remove 'xlsx' from output.formats") from e
            with xw:
                for s, df in sheets.items():
                    df.to_excel(xw, sheet_name=s, index=False)
                if _formula_like(sheets.values()):
                    _texts_not_formulas(xw.book)
        elif fmt == "graphml":
            nx.write_graphml(_clean_graph(G), out / f"{name}.graphml")
        elif fmt == "gexf":
            nx.write_gexf(_clean_graph(G), out / f"{name}.gexf")
        elif fmt == "json":
            data = nx.node_link_data(_clean_graph(G), edges="links")
            (out / f"{name}.json").write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        elif fmt == "pajek":
            write_pajek(G, out / f"{name}.net")
        elif fmt == "ucinet":
            write_ucinet(G, out / f"{name}.dl")
        elif fmt == "matrix":
            labels = [str(G.nodes[n].get("label", n)) for n in G]
            m = pd.DataFrame(nx.to_numpy_array(G, weight="weight"), index=labels, columns=labels)
            if cfg["output"].get("escape_formulas"):
                m.index = m.columns = ["'" + x if x.startswith(_FORMULA_START) else x for x in labels]
            m.to_csv(out / f"{name}_matrix.csv", encoding="utf-8-sig")
        elif fmt == "html":
            html(G, out / f"{name}.html", str(cfg["project"]), summary, cfg["output"].get("html") or {})
        elif fmt == "report":
            report(G, comms, summary, out / f"{name}_report.md", str(cfg["project"]), lang, tables)
        else:
            raise ConfigError(f"Unknown output format {fmt!r}. Options: {', '.join(FORMATS)}")
    for k, df in tables.items():
        csv_safe(df).to_csv(out / f"{name}_{file_stem(k, 'table')}.csv", index=False, encoding="utf-8-sig")


HTML_TEMPLATE = """<!doctype html>
<!-- Made with Tejido __VERSION__ (MIT), by __AUTHOR__. Includes vis-network (Apache-2.0 or MIT; see its notice in the script below) and the appearance
     module of Tejido, which credits Okabe & Ito (2008), Smith, van der Walt & Firing (2015) and Andrew (1979). -->
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="generator" content="Tejido __VERSION__">
<title>__TITLE__</title>
__VIS__
<script>__STYLEJS__</script>
<style>
:root{--bg:#f4f5f8;--fg:#1b2030;--muted:#5b6275;--panel:#ffffff;--line:#dde0e7;color-scheme:light}
@media (prefers-color-scheme:dark){:root{--bg:#111319;--fg:#e8e9ef;--muted:#a0a6b8;--panel:#181b24;--line:#2b3040;color-scheme:dark}}
*{box-sizing:border-box}body{margin:0;font:14px/1.4 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:var(--bg);color:var(--fg)}
header{padding:10px 16px;border-bottom:1px solid var(--line);background:var(--panel)}
h1{font-size:18px;margin:0 0 4px}.stats{color:var(--muted);font-size:12px}
.bar{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:8px}
input,button{font:inherit;padding:4px 8px;border:1px solid var(--line);border-radius:6px;background:var(--bg);color:var(--fg)}
.legend{font-size:12px;color:var(--muted)}.key{margin-left:10px;white-space:nowrap}
.key i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:4px;vertical-align:middle}
.ramp{display:inline-block;width:100px;height:9px;border-radius:3px;margin:0 6px;vertical-align:middle}
.made{margin-left:auto;font-size:11.5px;color:var(--muted);white-space:nowrap}
#net{height:calc(100vh - 110px);width:100%;background:var(--panel)}
div.vis-tooltip{white-space:pre-wrap;max-width:440px;font:12px/1.35 system-ui,sans-serif;background:var(--panel);color:var(--fg);border:1px solid var(--line);border-radius:6px;padding:8px}
</style></head><body>
<header><h1>__TITLE__</h1><div class="stats">__STATS__</div>
<div class="bar"><input id="q" placeholder="Search node…" list="labels"><datalist id="labels"></datalist>
<button id="go">Find</button><button id="phys">Pause layout</button><span class="legend" id="legend"></span><span class="made">Tejido __VERSION__</span></div></header>
<div id="net"></div>
<script>
const D = __DATA__, TS = TejidoStyle, ST = TS.clean(__STYLE__);
const col = TS.colors(ST, getComputedStyle(document.documentElement).getPropertyValue("--panel").trim());
if (ST.background !== "theme") document.getElementById("net").style.background = col.bg;
const pal = TS.palette(ST.palette, col.dark), stops = TS.SCALES[ST.scale], esc = s => String(s).replace(/[&<>"]/g, c => "&#" + c.charCodeAt(0) + ";");
const freq = xs => { const c = {}; xs.forEach(x => { c[x] = (c[x] || 0) + 1; }); return Object.keys(c).sort((a, b) => c[b] - c[a]); };
let cmap = {}, lo = 0, hi = 1;
if (D.numeric) { const xs = D.nodes.map(n => n.group).filter(x => x !== null); if (xs.length) { lo = Math.min(...xs); hi = Math.max(...xs); } }
else freq(D.nodes.map(n => n.group)).forEach((k, i) => { cmap[k] = pal[i] || "#9aa3b8"; });
const colorOf = n => D.numeric ? (n.group === null ? "#9aa3b8" : TS.ramp(stops, hi > lo ? (n.group - lo) / (hi - lo) : .5)) : cmap[n.group];
const smap = ST.shape_by && D.shape_by ? TS.shapeMap(D.nodes.map(n => n.shape_key)) : null;
const order = D.nodes.map((n, i) => i).sort((a, b) => D.nodes[b].value - D.nodes[a].value);
const named = new Set(ST.labels === "all" ? D.nodes.map(n => n.id) : ST.labels === "top" ? order.slice(0, Math.max(1, Math.ceil(order.length * ST.label_top / 100))) : []);
const ring = order.slice(0, ST.top_ring); ring.forEach(i => named.add(i));
const prio = [...new Set([...ring, ...order])], room = id => ring.includes(id) ? 8 : 0;
let shown = new Set(ST.labels !== "none" ? named : []);
const fixed = TS.layout(D.nodes.map(n => ({id: n.id, value: n.value, group: D.numeric ? "" : n.group})), ST), base = {};
const nodes = new vis.DataSet(D.nodes.map(n => { const c = colorOf(n); base[n.id] = c;
  const x = {id: n.id, label: (ST.label_long === "short" ? TS.shortName(n.name) : n.name) + n.suffix, value: n.value, title: n.title,
             color: TS.nodeColor(c, ST, col), font: TS.font(shown.has(n.id), ST, col)};
  if (smap) x.shape = smap[n.shape_key]; if (fixed) Object.assign(x, fixed[n.id]); return x; }));
const wk = ST.edge_width / 100;
const edges = new vis.DataSet(D.edges.map((e, i) => { const same = !D.numeric && D.nodes[e.from].group === D.nodes[e.to].group;
  const x = {id: i, from: e.from, to: e.to, width: e.width * wk, title: e.title, color: TS.edgeColor(ST, col, base[e.from], same)};
  if (e.cls === "weak") x.dashes = true;
  else if (e.cls === "strong") x.color = ST.edge_color === "neutral" ? {color: col.ink, opacity: .7} : {...x.color, opacity: .85};
  if (ST.edge_labels) x.label = String(+e.w.toFixed(3)); return x; }));
const big = D.nodes.length > 400, hier = ST.layout === "hierarchical", still = !!fixed || hier, opts = TS.options(ST, col, D.directed, big);
opts.physics = {...TS.physics(ST, big), enabled: !still};
opts.layout = hier ? TS.hierarchical(ST, D.directed) : {improvedLayout: !big && !still};
const net = new vis.Network(document.getElementById("net"), {nodes, edges}, opts);
const phys = document.getElementById("phys");
function relabel() {           // hide names that would cover a larger node or name; zooming in brings them back
  const want = ST.labels !== "none" ? named : new Set();
  const show = ST.declutter && want.size ? TS.pickLabels(TS.boxes(net, prio, id => want.has(id), room), want) : want;
  const upd = D.nodes.filter(n => show.has(n.id) !== shown.has(n.id)).map(n => ({id: n.id, font: TS.font(show.has(n.id), ST, col)}));
  shown = show; if (upd.length) nodes.update(upd);
}
let timer; const soon = () => { clearTimeout(timer); timer = setTimeout(relabel, 120); };
function settle() {           // after the forces stop: make room for the main names
  if (ST.label_adjust && (ST.layout === "force" || ST.layout === "compact") && ST.labels !== "none")
    TS.spreadNet(net, prio, TS.mainLabels(prio, named), room);
  net.fit(); soon();
}
let on = !still; phys.textContent = on ? "Pause layout" : "Resume layout";
if (on) net.once("stabilizationIterationsDone", () => {net.setOptions({physics: {enabled: false}}); on = false; phys.textContent = "Resume layout"; settle();});
else net.once("afterDrawing", () => {net.fit(); soon();});
phys.onclick = () => {on = !on; net.setOptions({physics: {enabled: on}}); phys.textContent = on ? "Pause layout" : "Resume layout"; if (!on) settle();};
for (const ev of ["zoom", "dragEnd", "animationFinished"]) net.on(ev, soon);
net.on("hoverNode", p => { if (ST.labels !== "none" && !shown.has(p.node)) nodes.update({id: p.node, font: TS.font(true, ST, col)}); });
net.on("blurNode", p => { if (!shown.has(p.node)) nodes.update({id: p.node, font: TS.font(false, ST, col)}); });
const halos = ST.halos && !D.numeric ? freq(D.nodes.map(n => n.group)).filter(k => k !== "—").slice(0, 24)
  .map(k => ({ids: D.nodes.filter(n => n.group === k).map(n => n.id), color: cmap[k], label: /^-?\\d+$/.test(k) ? D.color_by + " " + k : k})) : null;
net.on("beforeDrawing", ctx => { if (halos) TS.drawHalos(ctx, net, halos); });
net.on("afterDrawing", ctx => TS.drawRings(ctx, net, ring, col.red));
let lg = "<b>" + esc(D.color_by) + "</b> ";
lg += D.numeric ? esc(+lo.toFixed(4)) + '<i class="ramp" style="background:linear-gradient(90deg,' + stops.join(",") + ')"></i>' + esc(+hi.toFixed(4))
  : Object.entries(cmap).slice(0, 16).map(([k, c]) => '<span class="key"><i style="background:' + c + '"></i>' + esc(k) + "</span>").join("");
if (smap) lg += ' <b style="margin-left:14px">' + esc(D.shape_by) + "</b>" + Object.entries(smap).slice(0, 7).map(([k, s]) => '<span class="key">' + TS.GLYPH[s] + " " + esc(k) + "</span>").join("");
document.getElementById("legend").innerHTML = lg;
const dl = document.getElementById("labels");
D.nodes.forEach(n => {const o = document.createElement("option"); o.value = n.label; dl.appendChild(o);});
function find(){const q = document.getElementById("q").value.trim().toLowerCase(); if(!q) return;
  const hit = D.nodes.find(n => n.label.toLowerCase() === q) || D.nodes.find(n => n.label.toLowerCase().includes(q));
  if(hit){net.selectNodes([hit.id]); net.focus(hit.id,{scale:1.4,animation:true});}}
document.getElementById("go").onclick = find;
document.getElementById("q").addEventListener("keydown", e => {if(e.key === "Enter") find();});
</script></body></html>
"""
