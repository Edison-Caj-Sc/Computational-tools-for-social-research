"""Pruebas con datos sintéticos que imitan la estructura de la ENAHO (sin internet)."""
import io
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import yaml

from inei_pipeline import Pipeline, load_config
from inei_pipeline.impute import impute
from inei_pipeline.standardize import standardize

PLANTILLA = Path(__file__).parents[1] / "inei_pipeline" / "plantilla.yaml"


def _zip(path: Path, files: dict):
    with zipfile.ZipFile(path, "w") as zf:
        for name, df in files.items():
            buf = io.BytesIO()
            if name.endswith(".dta"):
                df.to_stata(buf, write_index=False, version=118)
            else:
                buf.write(df.to_csv(index=False).encode("latin-1"))
            zf.writestr(name, buf.getvalue())


def fake_enaho(root: Path, years=(2023, 2024), n=300, seed=1):
    rng = np.random.default_rng(seed)
    for y in years:
        d = root / str(y)
        d.mkdir(parents=True)
        cong = np.repeat(np.arange(5001, 5001 + n // 3), 3)[:n]
        viv = np.tile([1, 2, 3], n)[:n]
        hog = np.ones(n, dtype=int)
        m1 = pd.DataFrame({"AÑO": y, "CONGLOME": [f"{c:06d}" for c in cong], "VIVIENDA": [f"{v:03d}" for v in viv],
                           "HOGAR": [f"{h:02d}" for h in hog], "UBIGEO": rng.choice([60101, 150101, 40129], n),
                           "DOMINIO": rng.integers(1, 9, n), "ESTRATO": rng.integers(1, 9, n),
                           "RESULT": rng.choice([1, 1, 1, 2, 3], n), "FACTOR07": rng.uniform(50, 500, n)})
        _zip(d / "966-Modulo01.zip", {f"966-Modulo01/enaho01-{y}-100.csv": m1})
        ing = rng.lognormal(9.5, 0.8, n)
        ing[rng.random(n) < .08] = np.nan
        m34 = pd.DataFrame({"conglome": cong, "vivienda": viv, "hogar": hog, "mieperho": rng.integers(1, 7, n),
                            "inghog2d": ing, "ld": rng.uniform(.8, 1.1, n), "estrsocial": rng.integers(1, 6, n), "pobreza": rng.choice([1, 2, 3], n),
                            "factor07": 1.0})
        m34.loc[rng.random(n) < .05, "pobreza"] = np.nan
        p801 = {f"p801_{k}": np.where(rng.random(n) < .2, k, np.nan) for k in range(1, 6)}
        m84a = pd.DataFrame({"conglome": cong, "vivienda": viv, "hogar": hog, **p801})
        npers = 2 * n
        m84b = pd.DataFrame({"conglome": np.repeat(cong, 2), "vivienda": np.repeat(viv, 2), "hogar": 1,
                             "codinfor": np.tile([1, 2], n), "p1_01": rng.integers(1, 6, npers)})
        _zip(d / "966-Modulo34.zip", {f"966-Modulo34/sumaria-{y}.dta": m34})
        _zip(d / "966-Modulo84.zip", {f"x/enaho01-{y}-800a.dta": m84a, f"x/enaho01b-{y}-1.dta": m84b})
        m2 = pd.DataFrame({"conglome": np.repeat(cong, 2), "vivienda": np.repeat(viv, 2), "hogar": 1,
                           "codperso": np.tile([1, 2], n), "p207": rng.integers(1, 3, npers),
                           "p208a": rng.integers(0, 90, npers).astype(float)})
        m2.loc[rng.random(npers) < .05, "p208a"] = np.nan
        _zip(d / "966-Modulo02.zip", {f"966-Modulo02/enaho01-{y}-200.dta": m2})


def base_cfg(tmp):
    cfg = yaml.safe_load(PLANTILLA.read_text(encoding="utf-8"))
    cfg["datos"].update({"anios": "2023-2024", "carpeta": str(tmp / "crudos"), "descargar": False})
    cfg["exportar"].update({"carpeta": str(tmp / "out"), "formatos": ["csv", "dta", "sav"]})
    return cfg


def test_plantilla_hogar(tmp_path):
    fake_enaho(tmp_path / "crudos")
    df = Pipeline(base_cfg(tmp_path)).run()
    assert set(df["anio"]) == {2023, 2024}
    assert not df.duplicated(["anio", "conglome", "vivienda", "hogar"]).any()
    assert df["inghog2d_pc_real"].notna().all() and df["inghog2d_pc_real_imp"].sum() > 0
    assert set(df["quintil_ingreso"].dropna()) == {1, 2, 3, 4, 5}
    assert set(df["area"].dropna()) <= {"urbano", "rural"}
    assert set(df["estrato_social"]) <= {"alto", "medio_alto", "medio", "medio_bajo", "bajo"}
    assert df["n_organizaciones"].between(0, 5).all()
    assert df["ubigeo"].str.len().eq(6).all() and "cod_departamento" in df
    out = tmp_path / "out"
    for f in ["capital_social_enaho.csv", "capital_social_enaho.dta", "capital_social_enaho.sav",
              "capital_social_enaho_diccionario.csv", "capital_social_enaho_reporte_imputacion.csv",
              "capital_social_enaho_diseno_muestral.md", "capital_social_enaho_configuracion_usada.yaml"]:
        assert (out / f).exists(), f
    back = pd.read_stata(out / "capital_social_enaho.dta")
    assert len(back) == len(df)


def test_persona_con_agregacion_y_mi(tmp_path):
    fake_enaho(tmp_path / "crudos")
    cfg = base_cfg(tmp_path)
    cfg["datos"]["modulos"] = [1, 2, 34, 84]
    cfg["unir"] = {"nivel": "persona", "filtros": ["result <= 2"]}
    cfg["armonizar"] = {"conservar": ["estrato", "factor07", "p1_01"], "variables": {
        "mujer": {"reglas": [{"anios": "todos", "variable": "p207", "recodificar": {1: 0, 2: 1}}]},
        "edad": {"reglas": [{"anios": 2023, "variable": "p208a"},
                            {"anios": 2024, "expresion": "p208a + 0"}]}}}
    cfg["estandarizar"] = [{"tipo": "cortes", "variable": "edad", "cortes": [18, 65],
                            "etiquetas": ["menor", "adulto", "mayor"], "nueva": "grupo_edad"}]
    cfg["imputar"] = {"m": 3, "reglas": [{"variables": ["edad"], "metodo": "iterativo",
                                          "predictores": ["mujer", "estrato"]}]}
    bases = Pipeline(cfg).run()
    assert len(bases) == 3
    assert all(b["edad"].notna().all() for b in bases)
    assert "p1_01" in bases[0]  # módulo 85-like con codinfor renombrado a codperso
    assert (tmp_path / "out" / "capital_social_enaho_imp3.csv").exists()


def test_operaciones_e_imputaciones():
    rng = np.random.default_rng(0)
    df = pd.DataFrame({"anio": np.repeat([2023, 2024], 50), "g": np.tile(["a", "b"], 50),
                       "x": rng.normal(10, 2, 100), "y": rng.normal(5, 1, 100), "w": rng.uniform(1, 3, 100),
                       "cat": rng.choice(["p", "q", "r", "z"], 100, p=[.5, .3, .19, .01])})
    df.loc[::7, "x"] = np.nan
    df.loc[3, "x"] = 99999
    cfg = load_config({"datos": {"anios": 2023}, "diseno": {"peso": "w"}, "estandarizar": [
        {"tipo": "faltantes", "variables": ["x"], "codigos": [99999]},
        {"tipo": "escalar", "metodo": "zscore", "variables": ["y"], "por_grupo": ["anio"], "ponderado": True},
        {"tipo": "escalar", "metodo": "robusto", "variables": ["y"]},
        {"tipo": "escalar", "metodo": "minmax", "variables": ["y"]},
        {"tipo": "escalar", "metodo": "percentil", "variables": ["y"], "ponderado": True},
        {"tipo": "deflactar", "metodo": "tabla", "variables": ["y"], "indices": {2023: 100, 2024: 105},
         "anio_base": 2024},
        {"tipo": "agrupar_raras", "variable": "cat", "minimo": 0.05},
        {"tipo": "dummies", "variables": ["cat"]},
    ]})
    out = standardize(df, cfg)
    assert out["x"].isna().sum() == 16
    assert abs(out.loc[out.anio == 2024, "y_real"] - out.loc[out.anio == 2024, "y"]).max() < 1e-9
    assert np.isclose(out.loc[out.anio == 2023, "y_real"], out.loc[out.anio == 2023, "y"] * 1.05).all()
    assert out["y_minmax"].between(0, 1).all() and "z" not in set(out["cat"])
    for metodo, extra in [("media", {}), ("mediana", {"ponderado": True}), ("hotdeck", {"por_grupo": ["g"]}),
                          ("knn", {"predictores": ["y"]}), ("constante", {"valor": 0}),
                          ("interpolar", {"por_grupo": ["g"]})]:
        cfg["imputar"]["reglas"] = [{"variables": ["x"], "metodo": metodo, **extra}]
        res, rep = impute(out.copy(), cfg, 1, False)
        assert res["x"].notna().all(), metodo
        assert rep[0]["imputados"] == 16 and res["x_imp"].sum() == 16


def test_catalogo_offline():
    from inei_pipeline.download import select_catalog
    cfg = load_config({"datos": {"anios": "2023-2024", "modulos": [1, 34, 84]}})
    cat = select_catalog(cfg)
    assert all("panel" not in e["label"].lower() for e in cat)
    codes = {m["csv_code"].split("-")[1] for e in cat for y in e["years"].values()
             for p in y.values() for m in p["modules"]}
    assert codes == {"Modulo01", "Modulo34", "Modulo84"}
