#!/usr/bin/env bash
# Builds dist/tejido on macOS or Linux (needs Python only on the build machine).
set -e
python3 -m pip install --upgrade pip
python3 -m pip install -r installer/requirements-build.txt
python3 -m pip install --no-deps .
python3 -m PyInstaller tejido.spec --noconfirm
echo "Done: dist/tejido"
