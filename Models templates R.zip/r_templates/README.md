# R templates for regression models

Eight ready-to-use templates that share the same structure: **edit one settings block and run**. Each template fits the model, checks its assumptions, computes interpretable effects and saves tables and plots.

## Quick start

1. Open `r_templates.Rproj` in RStudio (so R works from this folder).
2. Run `00_install_packages.R` once.
3. Open any template and click **Source**. Without changes, it runs on simulated data.
4. To use your data, edit section **0. SETTINGS**: `file`, `outcome`, `predictors`, etc.

## Which model should I use?

| Template | Outcome | Example | Read it with |
|---|---|---|---|
| `01_linear_regression.R` | Continuous | log income, test score | Coefficients (and % if Y is in logs) |
| `02_logistic_regression.R` | Binary 0/1 (logit or probit) | poor, participates, voted | Odds ratios and marginal effects in percentage points |
| `03_poisson_regression.R` | Count | number of organizations, children | Incidence rate ratios (IRR) |
| `04_negative_binomial.R` | Overdispersed count | counts with variance above the mean | IRR, comparison with Poisson |
| `05_gamma_regression.R` | Positive, right-skewed continuous | income, spending, time | Multiplicative effects (%) |
| `06_fractional_regression.R` | Proportion between 0 and 1 | food share of spending | Marginal effects |
| `07_ordinal_logit.R` | Ordered categories | trust, Likert items | Odds ratios, probability by category |
| `08_multinomial_logit.R` | 3+ unordered categories | employment type, party | Relative risk ratios (RRR), probability by category |

## Common settings

| Setting | Purpose |
|---|---|
| `file` | `NULL` uses example data; accepts `.csv`, `.dta`, `.sav`, `.xlsx`, `.rds` |
| `outcome`, `predictors` | Model variables |
| `factors` | Categorical variables and their reference category: `list(area = "urban")` |
| `extra_terms` | Interactions or non-linear terms: `c("I(age^2)", "educ:area")` |
| `manual_formula` | Write the full formula (overrides the above) |
| `focus_variable` | Variable shown in the predictions plot |
| `use_design`, `design` | Survey-design estimation (stratum, PSU, weight) |
| `output_dir` | Where results are saved |

Template-specific settings: `link` and `threshold` (logistic), `exposure` (counts), `robust_se` (linear), `order` (ordinal), `outcome_reference` (multinomial), `scale_100` (fractional).

## Outputs

Each template writes numbered files to `output_dir`:
- CSV tables (they open cleanly in Excel): coefficients, fit, tests, marginal effects;
- PNG plots: distribution, diagnostics and predictions;
- `model_summary.txt` with R's full output.

## Survey design

With `use_design <- TRUE`, templates 01, 02, 03, 05 and 06 use `survey::svyglm`, and template 07 uses `survey::svyolr`. Standard errors then account for strata, clusters and weights.

The `survey` package does not fit negative binomial or multinomial models. Templates 04 and 08 use an **approximation** instead: normalized weights plus cluster-robust standard errors. It ignores the strata, so report it as an approximation. For the multinomial case, the `svyVGAM` package offers full design-based inference.

Datasets exported by `inei_pipeline` (in this same repository) work directly: set `file` to their path and map their variable names in `design`.

## Check that everything works

```r
source("test_templates.R")   # runs all 8 templates with and without survey design
```

## FAQ

**How do I use my own data?**
Set `file` to its path, for example `file <- "data/survey_2024.csv"`, and change `outcome`, `predictors` and `factors` to your variable names. Paths are relative to the folder of the `.Rproj` file.

**Why does the console say some cases were dropped?**
The templates use complete cases: any row with a missing value in the model variables is excluded. The message shows how many. If the loss is large, check your variables or consider imputation before modeling.

**How do I choose the reference category?**
In `factors`, write the variable and its reference: `factors <- list(area = "urban", head_sex = "male")`. Coefficients for the other categories are read against that reference. If you mistype a category, the error lists the valid ones.

**How do I add an interaction or a squared term?**
Use `extra_terms <- c("head_educ:area", "I(head_age^2)")`. For full control, write the whole formula in `manual_formula`, for example `"log_income ~ head_educ * area + head_age"`.

**My outcome is text, not 0/1. Can I use the logistic template?**
Yes. Set `success_category` to the category that should count as 1, for example `success_category <- "poor"`.

**Should I report coefficients or marginal effects?**
Coefficients (and OR, IRR or RRR) are useful for direction and significance. Marginal effects are easier to communicate because they are on the outcome's scale: percentage points, counts or units. In non-linear models, prefer marginal effects to talk about size.

**When should I turn on `use_design`?**
Whenever your data come from a complex survey (DHS, LSMS, ENAHO, labor force surveys). Ignoring strata, clusters and weights usually understates standard errors and can bias estimates.

**Why do the negative binomial and multinomial templates use an approximation with survey design?**
Because `survey` does not support those models. The approximation keeps weights and clustering but not stratification. It is common practice, but say so when you report results.

**Poisson shows overdispersion. What now?**
Use `04_negative_binomial.R`, or keep Poisson and report the robust standard errors that template 03 already saves. If there are many more zeros than expected, consider hurdle or zero-inflated models (`pscl` package).

**The proportional odds check shows changing coefficients. What now?**
If a coefficient changes sign or size markedly across cut-points, the ordinal model may be too restrictive. Compare with `08_multinomial_logit.R`, or consider a partial proportional odds model (`VGAM` or `ordinal` packages).

**My pseudo-R² is low. Is the model bad?**
Not necessarily. Pseudo-R² values are much lower than linear R² and cannot be compared with them. In logistic models, also check AUC and calibration (Hosmer-Lemeshow).

**My outcome is a percentage (0-100). Which template?**
`06_fractional_regression.R` with `scale_100 <- TRUE`.

**My income variable has zeros. Can I use the Gamma template?**
No: Gamma requires values strictly above 0. Options are excluding zeros (and saying so), modeling the zeros separately with a hurdle model, or using a Tweedie model.

**I see strange characters instead of accents.**
The files are UTF-8. In RStudio use *File → Reopen with Encoding → UTF-8*.

**A template fails after I updated R packages.**
Run `test_templates.R` to see which one. Templates were tested with R 4.3 and marginaleffects 0.18; newer versions usually work, but package APIs can change.

**How do I cite the packages?**
Run `citation("package_name")` in R, for example `citation("survey")`.

## Caveats

- The example data are **simulated**. They are for learning and testing, not for drawing conclusions.
- The templates do not replace theory: choosing variables and specification is still your job.

## Credits

The templates rely on these R packages:
- `survey` (Thomas Lumley);
- `MASS` and `nnet` (William Venables and Brian Ripley);
- `sandwich` and `lmtest` (Achim Zeileis and contributors);
- `car` (John Fox and Sanford Weisberg);
- `marginaleffects` (Vincent Arel-Bundock);
- `ggplot2`, `haven` and `readxl` (Hadley Wickham and contributors);
- `broom` (David Robinson and contributors).

Methods implemented come from:
- Papke and Wooldridge (1996), fractional regression;
- Cameron and Trivedi (1990), overdispersion test;
- Hosmer and Lemeshow, goodness-of-fit test.

## License

MIT. Author: Angel Edison Ayala Velásquez.
