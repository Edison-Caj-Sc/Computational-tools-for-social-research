"""Command line: tejido run | init | list | ui | gui | logs."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .utils import ConfigError, log

LISTS = ("builders", "steps", "measures", "groups", "formats", "sources")


def catalog(what: str) -> list[tuple[str, str]]:
    if what == "builders":
        from .builders import BUILDERS
        return [(k, d) for k, (_, d) in sorted(BUILDERS.items())]
    if what == "steps":
        from .prepare import STEPS
        return [(k, d) for k, (_, d) in sorted(STEPS.items())]
    if what == "measures":
        from .analyze import NODE_MEASURES
        return sorted(NODE_MEASURES.items())
    if what == "groups":
        from .groups import GROUPS
        return sorted(GROUPS.items()) + [("communities", "louvain | greedy | label_propagation | girvan_newman | attribute | none")]
    if what == "formats":
        from .export import FORMATS
        return list(FORMATS.items())
    from .io import CONNECTORS
    return [(k, d) for k, (d, _) in sorted(CONNECTORS.items())]


def main(argv=None):
    from . import __version__
    from .utils import safe_console
    safe_console()
    p = argparse.ArgumentParser(prog="tejido", description="Turn (almost) any data into a network.")
    from . import __author__, __license__
    p.add_argument("--version", action="version",
                   version=f"tejido {__version__} · © 2026 {__author__} · {__license__} license")
    p.add_argument("-v", "--verbose", action="store_true", help="Show more detail while running")
    p.add_argument("-q", "--quiet", action="store_true", help="Show only warnings and errors")
    p.add_argument("--log-file", default=None, metavar="FILE", help="Also write the activity log to this file")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("run", help="Read, prepare, build, filter, analyze and export as a YAML file describes")
    s.add_argument("config")
    s = sub.add_parser("init", help="Copy the example configurations and data to a folder")
    s.add_argument("folder", nargs="?", default="tejido_examples")
    s = sub.add_parser("list", help="List builders, prepare steps, measures, groups, formats or sources")
    s.add_argument("what", nargs="?", choices=LISTS + ("all",), default="all")
    sub.add_parser("builders", help="List the network builders (same as 'list builders')")
    s = sub.add_parser("ui", help="Open the visual interface in your web browser")
    s.add_argument("--workspace", default=None, help="Folder for uploads and results (default: ~/tejido_workspace)")
    s.add_argument("--port", type=int, default=0)
    s.add_argument("--no-browser", action="store_true")
    sub.add_parser("gui", help="Open the simple desktop window")
    s = sub.add_parser("logs", help="Show where the activity log of the visual interface is, and its last lines")
    s.add_argument("--workspace", default=None, help="Workspace of the interface (default: ~/tejido_workspace)")
    s.add_argument("--lines", type=int, default=40)
    a = p.parse_args(argv)
    import logging

    from . import logs
    logs.setup(file=a.log_file, level=logging.DEBUG if a.verbose else logging.WARNING if a.quiet else logging.INFO)
    if a.log_file:
        logs.session_start(f"command line: {a.cmd}")
    try:
        if a.cmd == "run":
            from .pipeline import run
            run(a.config)
        elif a.cmd == "init":
            from .gui import copy_examples
            dest = copy_examples(Path(a.folder))
            print(f"Examples copied to {dest}. Try:  tejido run {dest / 'documents.yaml'}")
        elif a.cmd in ("list", "builders"):
            for what in (LISTS if getattr(a, "what", "builders") == "all" else (getattr(a, "what", "builders"),)):
                print(f"\n{what.upper()}")
                for name, desc in catalog(what):
                    print(f"  {name:<18} {desc}")
        elif a.cmd == "ui":
            from .ui.server import main as ui
            ui(a.workspace, a.port, not a.no_browser)
        elif a.cmd == "gui":
            from .gui import main as gui
            gui()
        elif a.cmd == "logs":
            path = logs.log_file((Path(a.workspace) if a.workspace else Path.home() / "tejido_workspace") / "logs")
            print(f"Activity log: {path}" + ("" if path.is_file() else "  (nothing recorded yet)"))
            text = logs.tail(path, a.lines)
            if text:
                print(text)
    except ConfigError as e:
        log.error(str(e))
        sys.exit(1)
    except KeyboardInterrupt:
        log.warning("Stopped by the user")
        sys.exit(130)
    except Exception:                                 # the trace goes to the log; the screen gets one line
        log.exception("Unexpected error") if a.verbose or a.log_file else log.error(
            "Unexpected error (run again with --verbose to see the details)", exc_info=False)
        if not (a.verbose or a.log_file):
            import traceback
            log.error(traceback.format_exc(limit=-1).strip().splitlines()[-1])
        sys.exit(2)


if __name__ == "__main__":
    main()
