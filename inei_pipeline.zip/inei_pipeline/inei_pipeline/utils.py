"""Funciones auxiliares compartidas por todo el paquete."""
from __future__ import annotations

import fnmatch
import logging
import re
import unicodedata

import numpy as np
import pandas as pd

log = logging.getLogger("inei_pipeline")
if not log.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
    log.addHandler(_h)
    log.setLevel(logging.INFO)


class ConfigError(ValueError):
    """Error en el archivo de configuración, con mensaje para el usuario."""


def as_list(x) -> list:
    if x is None:
        return []
    return list(x) if isinstance(x, (list, tuple, set)) else [x]


def parse_years(spec) -> list[int] | None:
    """Convierte '2015-2024', 2020, [2019, 2021] o 'todos' en lista de años.

    Devuelve None cuando significa «todos los años».
    """
    if spec is None or (isinstance(spec, str) and spec.strip().lower() in ("todos", "*", "")):
        return None
    years: list[int] = []
    for item in as_list(spec):
        s = str(item).strip()
        m = re.fullmatch(r"(\d{4})\s*-\s*(\d{4})", s)
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            years.extend(range(min(a, b), max(a, b) + 1))
        elif re.fullmatch(r"\d{4}", s):
            years.append(int(s))
        else:
            raise ConfigError(f"No entiendo la especificación de años: {item!r}. "
                              "Usa 2020, '2015-2024', [2019, 2021] o 'todos'.")
    return sorted(set(years))


def year_matches(year: int, spec) -> bool:
    years = parse_years(spec)
    return years is None or int(year) in years


def normalize_name(col: str) -> str:
    """Minúsculas, sin tildes ni símbolos. 'AÑO' / 'aÑo' -> 'anio'."""
    low = str(col).strip().lower()
    if re.fullmatch(r"a[^\x00-\x7f]{1,2}o", low):
        return "anio"
    s = unicodedata.normalize("NFKD", low).encode("ascii", "ignore").decode()
    s = re.sub(r"[^0-9a-z_]+", "_", s).strip("_")
    return s or "col"


def expand_columns(df: pd.DataFrame, patterns, required: bool = False) -> list[str]:
    """Expande nombres o comodines ('p801_*', '*') a columnas existentes."""
    pats = as_list(patterns)
    if pats == ["*"]:
        return list(df.columns)
    out: list[str] = []
    for p in pats:
        p = str(p).lower()
        if any(c in p for c in "*?["):
            hits = fnmatch.filter(df.columns, p)
        else:
            hits = [p] if p in df.columns else []
        if not hits and required:
            raise ConfigError(f"La variable o patrón {p!r} no existe en los datos.")
        out.extend(h for h in hits if h not in out)
    return out


def weighted_quantile(values, q, weights=None) -> float:
    v = pd.to_numeric(pd.Series(values), errors="coerce").to_numpy(float)
    w = np.ones_like(v) if weights is None else pd.to_numeric(pd.Series(weights), errors="coerce").to_numpy(float)
    ok = ~np.isnan(v) & ~np.isnan(w) & (w > 0)
    v, w = v[ok], w[ok]
    if v.size == 0:
        return np.nan
    idx = np.argsort(v)
    v, w = v[idx], w[idx]
    cw = np.cumsum(w) - 0.5 * w
    return float(np.interp(q * w.sum(), cw, v))


def weighted_mean(values, weights=None) -> float:
    v = pd.to_numeric(pd.Series(values), errors="coerce").to_numpy(float)
    w = np.ones_like(v) if weights is None else pd.to_numeric(pd.Series(weights), errors="coerce").to_numpy(float)
    ok = ~np.isnan(v) & ~np.isnan(w)
    return float(np.average(v[ok], weights=w[ok])) if ok.any() and w[ok].sum() > 0 else np.nan


def weighted_mode(values, weights=None):
    s = pd.Series(values).reset_index(drop=True)
    w = pd.Series(1.0, index=s.index) if weights is None else pd.Series(weights).reset_index(drop=True)
    ok = s.notna() & w.notna()
    if not ok.any():
        return np.nan
    return w[ok].groupby(s[ok]).sum().idxmax()


def map_values(s: pd.Series, mapping: dict, others: str = "nan") -> pd.Series:
    """Recodifica con un diccionario. Si las claves son números, compara como números.

    others: 'nan' (valores no listados quedan faltantes), 'conservar' (se mantienen)
    o cualquier otro texto/valor (se asigna ese valor).
    """
    numeric_keys = all(_is_number(k) for k in mapping)
    if numeric_keys:
        src = pd.to_numeric(s, errors="coerce")
        mp = {float(k): v for k, v in mapping.items()}
    else:
        src = s.astype("string").str.strip()
        mp = {str(k): v for k, v in mapping.items()}
    out = src.map(mp).astype(object)
    unmapped = s.notna() & ~src.isin(list(mp))
    mode = str(others).lower()
    if mode in ("conservar", "mantener", "keep"):
        out[unmapped] = s[unmapped].astype(object)
    elif mode not in ("nan", "faltante", "na"):
        out[unmapped] = others
    return tidy(out)


def _is_number(x) -> bool:
    if isinstance(x, bool):
        return False
    try:
        float(x)
        return True
    except (TypeError, ValueError):
        return False


def tidy(s: pd.Series) -> pd.Series:
    """Deja un tipo limpio: numérico si todos los valores son números."""
    num = pd.to_numeric(s, errors="coerce")
    if num.notna().sum() == s.notna().sum():
        return num
    out = s.astype(object)
    return out.where(s.notna(), np.nan)


def weights_of(df: pd.DataFrame, cfg: dict, use: bool):
    """Serie de pesos del diseño muestral, solo si se pidió ponderar."""
    if not use:
        return None
    w = (cfg.get("diseno") or {}).get("peso")
    if not w or w not in df.columns:
        raise ConfigError("Pediste 'ponderado: true' pero 'diseno.peso' no está definido "
                          "o esa variable no existe en los datos.")
    return pd.to_numeric(df[w], errors="coerce")


def groups(df: pd.DataFrame, by) -> list:
    """Lista de índices por grupo (o un solo grupo con todo)."""
    by = [b for b in as_list(by)]
    missing = [b for b in by if b not in df.columns]
    if missing:
        raise ConfigError(f"Las variables de agrupación {missing} no existen en los datos.")
    if not by:
        return [df.index]
    key = by[0] if len(by) == 1 else by
    return list(df.groupby(key, dropna=False).groups.values())
