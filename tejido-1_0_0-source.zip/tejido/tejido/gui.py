"""Simple desktop window for people who do not use the command line.

Opens when the executable is double-clicked (or with `tejido gui`)."""
from __future__ import annotations

import logging
import os
import queue
import subprocess
import sys
import threading
from pathlib import Path

from . import __author__, __version__
from .utils import ConfigError, log


def open_path(path) -> None:
    """Opens a file or folder with the system's default application."""
    path = str(Path(path).resolve())                         # an absolute path can never be read as an option
    if not os.path.exists(path):
        raise ConfigError(f"{path} does not exist")
    if sys.platform.startswith("win"):
        os.startfile(path)                                   # noqa: S606
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


class _QueueHandler(logging.Handler):
    def __init__(self, q):
        super().__init__()
        self.q = q
        self.setFormatter(logging.Formatter("%(message)s"))

    def emit(self, record):
        self.q.put(self.format(record))


class App:
    def __init__(self, root):
        import tkinter as tk
        from tkinter import ttk
        from tkinter.scrolledtext import ScrolledText

        self.tk, self.root = tk, root
        root.title(f"Tejido {__version__} · data to networks · © {__author__}")
        root.geometry("820x560")
        root.minsize(640, 420)
        self.config_path = tk.StringVar()
        self.result = None
        self.q: queue.Queue = queue.Queue()
        self.handler = _QueueHandler(self.q)
        log.addHandler(self.handler)

        frm = ttk.Frame(root, padding=12)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text="Configuration file (.yaml)").grid(row=0, column=0, sticky="w")
        ttk.Entry(frm, textvariable=self.config_path).grid(row=1, column=0, columnspan=3, sticky="ew", pady=(2, 8))
        ttk.Button(frm, text="Browse…", command=self.browse).grid(row=1, column=3, padx=(6, 0), pady=(2, 8))

        bar = ttk.Frame(frm)
        bar.grid(row=2, column=0, columnspan=4, sticky="w", pady=(0, 8))
        ttk.Button(bar, text="Create examples…", command=self.make_examples).pack(side="left")
        ttk.Button(bar, text="Edit configuration", command=self.edit).pack(side="left", padx=6)
        self.run_btn = ttk.Button(bar, text="▶ Run", command=self.start)
        self.run_btn.pack(side="left")
        self.folder_btn = ttk.Button(bar, text="Open results folder", command=self.open_folder, state="disabled")
        self.folder_btn.pack(side="left", padx=6)
        self.html_btn = ttk.Button(bar, text="Open network", command=self.open_html, state="disabled")
        self.html_btn.pack(side="left")

        self.out = ScrolledText(frm, height=20, wrap="word", font=("Consolas", 10) if sys.platform.startswith("win")
                                else ("Menlo", 11) if sys.platform == "darwin" else ("DejaVu Sans Mono", 10))
        self.out.grid(row=3, column=0, columnspan=4, sticky="nsew")
        frm.columnconfigure(0, weight=1)
        frm.rowconfigure(3, weight=1)
        self.write("1) Click 'Create examples…' to try it, or 'Browse…' to choose your configuration.\n"
                   "2) Click 'Run'. 3) Open the results folder or the interactive network.\n")
        root.after(150, self.poll)

    # ------------------------------------------------------------------ helpers
    def write(self, text: str) -> None:
        self.out.insert("end", text if text.endswith("\n") else text + "\n")
        self.out.see("end")

    def poll(self):
        while not self.q.empty():
            self.write(self.q.get_nowait())
        self.root.after(150, self.poll)

    def browse(self):
        from tkinter import filedialog
        p = filedialog.askopenfilename(title="Choose a configuration", filetypes=[("YAML", "*.yaml *.yml"), ("All", "*.*")])
        if p:
            self.config_path.set(p)

    def make_examples(self):
        from tkinter import filedialog, messagebox
        parent = filedialog.askdirectory(title="Where should the examples folder be created?")
        if not parent:
            return
        dest = Path(parent) / "tejido_examples"
        try:
            copy_examples(dest)
        except ConfigError as e:
            messagebox.showerror("Tejido", str(e))
            return
        self.config_path.set(str(dest / "documents.yaml"))
        self.write(f"Examples copied to {dest}. Selected documents.yaml; click Run.")

    def edit(self):
        p = self.config_path.get().strip()
        if p and Path(p).exists():
            open_path(p)

    def open_folder(self):
        if self.result and self.result.output_dir:
            open_path(self.result.output_dir)

    def open_html(self):
        if self.result and self.result.output_dir:
            pages = sorted(Path(self.result.output_dir).glob("*.html"))
            if pages:
                open_path(pages[0])

    # ------------------------------------------------------------------ running
    def run_now(self):
        """Runs the configuration in the current thread; returns the result or None."""
        from .pipeline import run
        p = self.config_path.get().strip()
        if not p:
            self.q.put("Choose a configuration file first.")
            return None
        self.result = None                                   # never show the results of an earlier run as new
        try:
            self.result = run(p)
            self.q.put(f"\n✔ Done. Results in: {self.result.output_dir}\n")
        except ConfigError as e:
            self.q.put(f"\n✖ Configuration problem: {e}\n")
        except Exception as e:                               # show any error instead of crashing
            log.exception("Unexpected error while running a configuration")
            self.q.put(f"\n✖ Unexpected error: {type(e).__name__}: {e}\n")
        return self.result

    def start(self):
        self.run_btn.config(state="disabled")
        self.write(f"\n— Running {self.config_path.get()} —")

        def work():
            res = self.run_now()
            self.root.after(0, lambda: self.finish(res))
        threading.Thread(target=work, daemon=True).start()

    def finish(self, res):
        self.run_btn.config(state="normal")
        state = "normal" if res and res.output_dir else "disabled"
        self.folder_btn.config(state=state)
        self.html_btn.config(state=state)


def copy_examples(dest: Path) -> Path:
    import shutil
    from importlib import resources
    if dest.exists():
        raise ConfigError(f"{dest} already exists; choose another folder.")
    src = resources.files("tejido").joinpath("examples")
    with resources.as_file(src) as path:
        shutil.copytree(path, dest, ignore=shutil.ignore_patterns("__pycache__", "results"))
    return dest


def main():
    try:
        import tkinter as tk
    except ImportError:
        print("The graphical interface needs tkinter. Use the command line instead: tejido --help")
        sys.exit(1)
    root = tk.Tk()
    App(root)
    root.mainloop()
