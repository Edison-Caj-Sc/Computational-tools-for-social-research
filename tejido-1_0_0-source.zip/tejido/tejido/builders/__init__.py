"""Stage 3 · build: each builder turns a dataset into a network, named by what defines a tie.

ties          direct relations (edge list, adjacency list, adjacency matrix)
affiliation   shared membership in groups, events or documents (two-mode data)
similarity    alike profiles: cases or variables, any metric, geographic proximity
text          entities, terms or documents that appear together in texts
interactions  records of who addresses whom (posts, e-mails, messages, debates)
ego           personal networks from surveys (name and position generators)
transitions   sequences of states (trajectories, mobility, processes)

A builder may also leave extra results in G.graph["summary"] and G.graph["tables"]."""
from __future__ import annotations

BUILDERS: dict = {}


def register(name: str, description: str):
    def deco(fn):
        BUILDERS[name] = (fn, description)
        return fn
    return deco


def get(name: str):
    from ..config import BUILDER_ALIASES
    from ..utils import ConfigError
    name = BUILDER_ALIASES.get(name, (name, {}))[0]
    if name not in BUILDERS:
        raise ConfigError(f"Unknown builder {name!r}. Options: {sorted(BUILDERS)}")
    return BUILDERS[name][0]


from . import affiliation, ego, interactions, similarity, text, ties, transitions  # noqa: E402,F401
