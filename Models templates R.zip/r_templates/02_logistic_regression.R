# =====================================================================
#  02 · LOGISTIC REGRESSION (and PROBIT)
#  For: binary outcomes (0/1): poverty, participation, voting.
#  Interpretation: odds ratio (OR) > 1 raises the probability; < 1 lowers it.
#  To communicate results, prefer marginal effects (percentage points).
# =====================================================================

# ---------------------------------------------------------------------
# 0. SETTINGS · edit this section only
# ---------------------------------------------------------------------
file             <- NULL
outcome          <- "poor"                # must be 0/1 (or two categories; see 'success_category')
success_category <- NULL                  # if Y is text, the category coded as 1 (e.g. "poor")
predictors       <- c("head_educ", "head_age", "head_sex", "area", "hh_size")
factors          <- list(head_sex = "male", area = "urban")
extra_terms      <- NULL
manual_formula   <- NULL
link             <- "logit"               # "logit" (odds ratios) or "probit"
focus_variable   <- "head_educ"
threshold        <- NULL                  # classification cut-off; NULL = observed share of 1s
use_design       <- FALSE
design           <- list(stratum = "stratum", psu = "psu", weight = "weight")
output_dir       <- "results/02_logistic_regression"

# ---------------------------------------------------------------------
# 1. Preparation
# ---------------------------------------------------------------------
source("utils.R"); install_if_missing()
out     <- prepare_output(output_dir)
formula <- build_formula(outcome, predictors, extra_terms, manual_formula)
data    <- prepare_data(load_data(file), formula_vars(formula), factors, extra = design_vars(use_design, design))
y <- all.vars(formula)[1]
if (!is.null(success_category)) data[[y]] <- as.integer(data[[y]] == success_category)
if (!all(data[[y]] %in% c(0, 1))) stop("The outcome must be 0/1. Use 'success_category' if it is text.")
dsg <- if (use_design) create_design(data, design) else NULL

header("Outcome distribution")
print(prop.table(table(data[[y]])))
if (use_design) print(svymean(as.formula(paste0("~", y)), dsg))
if (min(table(data[[y]])) < 10 * length(attr(terms(formula), "term.labels")))
  warning("Few cases in the rarest category for this many predictors (10 events per variable rule).")

# ---------------------------------------------------------------------
# 2. Estimation
# ---------------------------------------------------------------------
header("Model")
fam   <- if (use_design) quasibinomial(link = link) else binomial(link = link)
model <- if (use_design) svyglm(formula, design = dsg, family = fam) else glm(formula, data = data, family = fam)
print(summary(model))
coefs <- coef_table(model, exponentiate = link == "logit")
if (link == "logit") names(coefs) <- sub("^exp_", "or_", names(coefs))
print(round_df(coefs, 3)); save_table(coefs, "2_coefficients", out)

# ---------------------------------------------------------------------
# 3. Fit
# ---------------------------------------------------------------------
header("Model fit")
p_hat <- fitted(model); obs <- data[[y]]
auc <- function(p, o) {                    # area under the ROC curve (Mann-Whitney)
  r <- rank(p); n1 <- sum(o == 1); n0 <- sum(o == 0)
  (sum(r[o == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}
if (use_design) {
  fit <- data.frame(n = nrow(data), pseudo_r2_nagelkerke = psrsq(model, method = "Nagelkerke"),
                    auc_unweighted = auc(p_hat, obs))
  print(global_test(model))
} else {
  null <- update(model, . ~ 1)
  lr <- 2 * as.numeric(logLik(model) - logLik(null))
  fit <- data.frame(n = nobs(model), pseudo_r2_mcfadden = 1 - as.numeric(logLik(model) / logLik(null)),
                    auc = auc(p_hat, obs), AIC = AIC(model), BIC = BIC(model),
                    lr_chi2 = lr, lr_p = pchisq(lr, df = length(coef(model)) - 1, lower.tail = FALSE))
  # Hosmer-Lemeshow on deciles of the predicted probability
  groups <- cut(p_hat, unique(quantile(p_hat, 0:10 / 10)), include.lowest = TRUE)
  o1 <- tapply(obs, groups, sum); e1 <- tapply(p_hat, groups, sum); ng <- tapply(obs, groups, length)
  hl <- sum((o1 - e1)^2 / (e1 * (1 - e1 / ng)))
  fit$hosmer_lemeshow_p <- pchisq(hl, df = nlevels(groups) - 2, lower.tail = FALSE)
}
print(round_df(fit, 3)); save_table(fit, "3_fit", out)
cat("AUC: 0.5 = chance · 0.7-0.8 acceptable · > 0.8 good.",
    if (!use_design) "Hosmer-Lemeshow p < 0.05 suggests poor fit.", "\n")

cut_off <- if (is.null(threshold)) mean(obs) else threshold
cm <- table(observed = obs, predicted = as.integer(p_hat >= cut_off))
print(cm)
metrics <- data.frame(threshold = cut_off, accuracy = sum(diag(cm)) / sum(cm),
                      sensitivity = cm["1", "1"] / sum(cm["1", ]),
                      specificity = cm["0", "0"] / sum(cm["0", ]))
print(round_df(metrics, 3)); save_table(metrics, "3_classification", out)

# ---------------------------------------------------------------------
# 4. Interpretation: marginal effects (percentage points) and predictions
# ---------------------------------------------------------------------
header("Average marginal effects (change in probability)")
ame <- marginal_effects(model, data, dsg)
ame$effect_pp <- 100 * ame$effect
print(round_df(ame, 4)); save_table(ame, "4_marginal_effects", out)
save_plot(prediction_plot(model, data, focus_variable, dsg, paste("Predicted probability of", y)) +
            labs(y = "Probability"), "4_predictions", out)
save_text(summary(model), "model_summary", out)
header(paste("Done. Results in", out))
