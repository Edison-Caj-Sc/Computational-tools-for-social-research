"""Lectura y validación del archivo de configuración (YAML)."""
from __future__ import annotations

import copy
from importlib import resources
from pathlib import Path

import yaml

from .utils import ConfigError, as_list, parse_years

DEFAULTS: dict = {
    "proyecto": "mi_proyecto",
    "datos": {
        "encuesta": "enaho",          # alias de inei-microdatos (enaho, endes, enapres...)
        "etiqueta": None,             # nombre exacto de la encuesta, si el alias es ambiguo
        "anios": None,                # obligatorio
        "periodo": "anual",           # texto que debe contener el período (anual, trimestre 1...)
        "modulos": None,              # lista de números de módulo; None = todos
        "carpeta": "datos/crudos",
        "descargar": True,
        "formato": "STATA",           # STATA, SPSS o CSV (con respaldo automático)
        "hilos": 4,
    },
    "llaves": {
        "vivienda": ["conglome", "vivienda"],
        "hogar": ["conglome", "vivienda", "hogar"],
        "persona": ["conglome", "vivienda", "hogar", "codperso"],
    },
    "unir": {
        "nivel": "hogar",             # hogar | persona | vivienda
        "tabla_base": None,           # patrón del nombre de la tabla base (opcional)
        "duplicados": "primero",      # primero | sufijo
        "renombrar": {"codinfor": "codperso"},  # se aplica solo si el destino no existe
        "excluir_tablas": [],
        "agregar": {},                # var: [funciones] para resumir personas a hogar
        "filtros": [],                # expresiones con nombres originales
    },
    "armonizar": {
        "conservar": [],
        "variables": {},
    },
    "diseno": {"estrato": "estrato", "conglomerado": "conglome", "peso": "factor07"},
    "estandarizar": [],
    "imputar": {"m": 1, "semilla": 2026, "banderas": True, "reglas": []},
    "exportar": {
        "carpeta": "datos/procesados",
        "nombre": None,
        "formatos": ["csv"],
        "variables": None,            # None = todas
    },
}


def _merge(base: dict, new: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (new or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict) and k not in ("variables", "renombrar", "agregar"):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(source) -> dict:
    """Acepta una ruta a YAML o un diccionario y devuelve la configuración completa."""
    if isinstance(source, (str, Path)):
        path = Path(source)
        if not path.exists():
            raise ConfigError(f"No encuentro el archivo de configuración: {path}")
        with open(path, encoding="utf-8") as f:
            user = yaml.safe_load(f) or {}
        base_dir = path.parent
    else:
        user, base_dir = dict(source), Path.cwd()
    cfg = _merge(DEFAULTS, user)
    cfg["_base_dir"] = str(base_dir)
    validate(cfg)
    return cfg


def validate(cfg: dict) -> None:
    d = cfg["datos"]
    if not d.get("anios"):
        raise ConfigError("Falta 'datos.anios' (por ejemplo: '2015-2024').")
    cfg["_anios"] = parse_years(d["anios"])
    if cfg["unir"]["nivel"] not in ("hogar", "persona", "vivienda"):
        raise ConfigError("'unir.nivel' debe ser 'hogar', 'persona' o 'vivienda'.")
    if cfg["unir"]["duplicados"] not in ("primero", "sufijo"):
        raise ConfigError("'unir.duplicados' debe ser 'primero' o 'sufijo'.")
    for name, spec in (cfg["armonizar"].get("variables") or {}).items():
        if not isinstance(spec, dict) or not spec.get("reglas"):
            raise ConfigError(f"La variable armonizada {name!r} necesita una lista 'reglas'.")
    if not isinstance(cfg["estandarizar"], list):
        raise ConfigError("'estandarizar' debe ser una lista de operaciones (cada una con 'tipo').")
    for op in cfg["estandarizar"]:
        if "tipo" not in op:
            raise ConfigError(f"Operación de estandarización sin 'tipo': {op}")
    m = int(cfg["imputar"].get("m", 1))
    if m < 1:
        raise ConfigError("'imputar.m' debe ser 1 o más.")
    cfg["exportar"]["formatos"] = [f.lower() for f in as_list(cfg["exportar"]["formatos"])]
    cfg["exportar"]["nombre"] = cfg["exportar"]["nombre"] or cfg["proyecto"]


def resolve(cfg: dict, path: str) -> Path:
    """Rutas relativas se interpretan respecto del archivo de configuración."""
    p = Path(path)
    return p if p.is_absolute() else Path(cfg.get("_base_dir", ".")) / p


def write_template(dest: str | Path) -> Path:
    dest = Path(dest)
    if dest.exists():
        raise ConfigError(f"{dest} ya existe; no lo sobrescribo.")
    text = resources.files("inei_pipeline").joinpath("plantilla.yaml").read_text(encoding="utf-8")
    dest.write_text(text, encoding="utf-8")
    return dest
