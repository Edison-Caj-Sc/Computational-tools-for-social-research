"""Similarity networks: nodes linked when their profiles look alike.

nodes: rows     cases linked (countries by indicators, municipalities by census data, respondents by attitudes)
nodes: columns  variables linked (correlation or partial-correlation networks of survey items, indicators)
metric: cosine · correlation · spearman · partial_correlation · euclidean · jaccard · gower (mixed data)
        · geographic (latitude/longitude → proximity)
sparsify: knn · threshold · top_percent · backbone · mst · radius (km, geographic) · none"""
from __future__ import annotations

import fnmatch

import numpy as np
import pandas as pd

from ..graph import to_graph
from ..io import worldbank_wide
from ..utils import ConfigError, as_list, log, require_columns
from . import register

METRICS = {"cosine", "correlation", "spearman", "partial_correlation", "euclidean", "jaccard", "gower", "geographic"}
SPARSIFY = {"knn", "threshold", "top_percent", "backbone", "mst", "radius", "none"}


def _feature_cols(data, opts, entity, numeric):
    pats = as_list(opts.get("features"))
    if pats:
        cols = [c for c in data.columns if any(fnmatch.fnmatch(str(c), str(p)) for p in pats) and c != entity]
        require_columns(data, [p for p in pats if not any(ch in str(p) for ch in "*?[")], "similarity.features")
        return cols
    base = data.select_dtypes("number") if numeric else data
    return [c for c in base.columns if c not in (entity, opts.get("label"))]


def prepare_matrix(data: pd.DataFrame, opts: dict, numeric: bool = True) -> tuple[pd.DataFrame, pd.Series]:
    fmt = opts.get("format", "wide")
    if fmt == "worldbank":
        X = worldbank_wide(data, opts).set_index("country_code")
        labels = X.pop("country")
    elif fmt == "long":
        e, f, v = opts.get("entity"), opts.get("feature"), opts.get("value")
        require_columns(data, [e, f, v], "similarity (long)")
        X = data.pivot_table(index=e, columns=f, values=v, aggfunc="mean")
        labels = pd.Series(X.index.astype(str), index=X.index)
    elif fmt == "wide":
        e = opts.get("entity")
        require_columns(data, [e, opts.get("label")], "similarity (wide)")
        cols = _feature_cols(data, opts, e, numeric)
        if not cols:
            raise ConfigError("similarity: no feature columns (set 'features' or use numeric columns)")
        base = data.drop_duplicates(e) if e else data.reset_index(drop=True)
        idx = base[e].astype(str) if e else pd.Index([f"row{i + 1}" for i in range(len(base))])
        X = base.set_index(idx)[cols]
        lab = opts.get("label")
        labels = pd.Series(base[lab].to_numpy() if lab else X.index, index=X.index)
    else:
        raise ConfigError("similarity: 'format' must be 'wide', 'long' or 'worldbank'")
    if numeric:
        X = X.apply(pd.to_numeric, errors="coerce")
    X.index = X.index.astype(str)
    labels.index = labels.index.astype(str)

    miss = opts.get("missing") or {}
    max_f, max_e = float(miss.get("max_feature_missing", .3)), float(miss.get("max_entity_missing", .3))
    X = X.loc[:, X.isna().mean() <= max_f]
    X = X.loc[X.isna().mean(axis=1) <= max_e]
    impute = miss.get("impute", "median")
    if not numeric:                                    # mixed data (gower): Gower handles scales itself
        return X, labels.reindex(X.index)
    if impute in ("mean", "median"):
        X = X.fillna(getattr(X, impute)())
    X = X.dropna()
    if X.shape[0] < 3 or X.shape[1] < 1:
        raise ConfigError(f"similarity: only {X.shape[0]} entities × {X.shape[1]} features left after "
                          "handling missing values. Relax 'missing' or choose other features.")
    for col in as_list((opts.get("transform") or {}).get("log")):
        if col in X:
            X[col] = np.log1p(X[col].clip(lower=0))
    scale = (opts.get("transform") or {}).get("scale", "zscore")
    if scale == "zscore":
        X = (X - X.mean()) / X.std(ddof=0).replace(0, 1)
    elif scale == "minmax":
        X = (X - X.min()) / (X.max() - X.min()).replace(0, 1)
    elif scale == "rank":
        X = X.rank(pct=True)
    log.info(f"similarity: {X.shape[0]} entities × {X.shape[1]} features")
    return X, labels.reindex(X.index)


def similarity_matrix(X: np.ndarray, metric: str) -> np.ndarray:
    if metric == "cosine":
        norm = np.linalg.norm(X, axis=1, keepdims=True)
        Z = X / np.where(norm == 0, 1, norm)
        S = Z @ Z.T
    elif metric in ("correlation", "spearman", "partial_correlation"):
        Z = pd.DataFrame(X).rank(axis=1).to_numpy() if metric == "spearman" else X
        S = np.corrcoef(Z)
        if metric == "partial_correlation":           # association net of all the others
            P = np.linalg.pinv(np.nan_to_num(S))
            d = np.sqrt(np.abs(np.diag(P)))
            S = -P / np.outer(np.where(d == 0, 1, d), np.where(d == 0, 1, d))
    elif metric == "euclidean":
        sq = (X ** 2).sum(axis=1)
        D = np.sqrt(np.maximum(sq[:, None] + sq[None, :] - 2 * X @ X.T, 0))
        S = 1 / (1 + D)
    elif metric == "jaccard":
        Bm = X > 0
        inter = Bm.astype(float) @ Bm.T.astype(float)
        cnt = Bm.sum(axis=1)
        union = cnt[:, None] + cnt[None, :] - inter
        S = np.divide(inter, union, out=np.zeros_like(inter), where=union > 0)
    else:
        raise ConfigError(f"'metric' must be one of {sorted(METRICS)}")
    S = np.nan_to_num(S)
    np.fill_diagonal(S, 0)
    return S


def gower_matrix(X: pd.DataFrame) -> np.ndarray:
    """Gower similarity for mixed numeric and categorical columns (missing values are skipped)."""
    n = len(X)
    total, count = np.zeros((n, n)), np.zeros((n, n))
    for c in X.columns:
        col = X[c]
        num = pd.to_numeric(col, errors="coerce")
        ok = col.notna().to_numpy()
        if num.notna().sum() >= .8 * col.notna().sum() and col.notna().any():
            v = num.to_numpy(float)
            rng = np.nanmax(v) - np.nanmin(v)
            s = 1 - np.abs(v[:, None] - v[None, :]) / (rng if rng > 0 else 1)
            ok = ~np.isnan(v)
        else:
            v = col.astype(str).to_numpy()
            s = (v[:, None] == v[None, :]).astype(float)
        both = ok[:, None] & ok[None, :]
        total += np.where(both, np.nan_to_num(s), 0)
        count += both
    S = np.divide(total, count, out=np.zeros_like(total), where=count > 0)
    np.fill_diagonal(S, 0)
    return S


def haversine_km(lat, lon) -> np.ndarray:
    la, lo = np.radians(lat), np.radians(lon)
    a = np.sin((la[:, None] - la[None, :]) / 2) ** 2 + \
        np.cos(la[:, None]) * np.cos(la[None, :]) * np.sin((lo[:, None] - lo[None, :]) / 2) ** 2
    return 6371.0088 * 2 * np.arcsin(np.sqrt(np.clip(a, 0, 1)))


def disparity_backbone(S: np.ndarray, alpha: float) -> np.ndarray:
    """Disparity filter (Serrano, Boguñá & Vespignani 2009): keeps statistically salient ties."""
    W = np.where(S > 0, S, 0)
    k = (W > 0).sum(axis=1)
    s = W.sum(axis=1)
    P = np.divide(W, s[:, None], out=np.zeros_like(W), where=s[:, None] > 0)
    A = (1 - P) ** (np.maximum(k, 1) - 1)[:, None]
    keep = ((A < alpha) & (W > 0)) & (k[:, None] > 1)
    return keep | keep.T


def sparsify(S: np.ndarray, spec: dict, D: np.ndarray | None = None) -> np.ndarray:
    method = spec.get("method", "radius" if D is not None and spec.get("km") else "knn")
    if method not in SPARSIFY:
        raise ConfigError(f"sparsify.method must be one of {sorted(SPARSIFY)}")
    n = S.shape[0]
    if method == "knn":
        k = min(int(spec.get("k", 5)), n - 1)
        idx = np.argsort(-S, axis=1)[:, :k]
        K = np.zeros_like(S, dtype=bool)
        K[np.repeat(np.arange(n), k), idx.ravel()] = True
        keep = (K & K.T) if spec.get("mutual") else (K | K.T)
    elif method == "threshold":
        keep = S >= float(spec.get("threshold", .7))
    elif method == "top_percent":
        iu = np.triu_indices(n, 1)
        cut = np.percentile(S[iu], 100 - float(spec.get("percent", 5)))
        keep = S >= cut
    elif method == "backbone":
        keep = disparity_backbone(S, float(spec.get("alpha", .05)))
    elif method == "mst":                              # maximum spanning tree: the strongest skeleton
        import networkx as nx
        iu = np.triu_indices(n, 1)
        G = nx.Graph()
        G.add_weighted_edges_from((a, b, w) for a, b, w in zip(*iu, S[iu]) if w > 0)
        keep = np.zeros_like(S, dtype=bool)
        for a, b in nx.maximum_spanning_tree(G).edges:
            keep[a, b] = keep[b, a] = True
    elif method == "radius":
        if D is None:
            raise ConfigError("sparsify.method radius needs metric: geographic")
        keep = D <= float(spec.get("km", 50))
    else:
        keep = np.ones_like(S, dtype=bool)
    return keep & (S > 0)


@register("similarity", "Alike profiles: cases or variables linked by similarity, correlation or proximity")
def build(data: pd.DataFrame, opts: dict, cfg: dict):
    metric = opts.get("metric", "cosine")
    if metric not in METRICS:
        raise ConfigError(f"'metric' must be one of {sorted(METRICS)}")
    D = None
    if metric == "geographic":
        coords = as_list(opts.get("coordinates", ["latitude", "longitude"]))
        e = opts.get("entity")
        require_columns(data, coords + [e, opts.get("label")], "similarity (geographic)")
        df = data.dropna(subset=coords).drop_duplicates(e) if e else data.dropna(subset=coords)
        X = df.set_index(df[e].astype(str) if e else df.index.astype(str))[coords].apply(pd.to_numeric, errors="coerce")
        labels = pd.Series(df[opts["label"]].to_numpy() if opts.get("label") else X.index, index=X.index)
        D = haversine_km(X.iloc[:, 0].to_numpy(float), X.iloc[:, 1].to_numpy(float))
        S = 1 / (1 + D)
        np.fill_diagonal(S, 0)
    else:
        X, labels = prepare_matrix(data, opts, numeric=metric != "gower")
        if opts.get("nodes", "rows") in ("columns", "variables"):
            X = X.T
            labels = pd.Series(X.index.astype(str), index=X.index.astype(str))
            X.index = X.index.astype(str)
            log.info(f"similarity: nodes are the {len(X)} variables")
        if X.shape[0] > 4000:
            log.warning(f"similarity: {X.shape[0]:,} nodes need a large n × n matrix; this may be slow")
        S = gower_matrix(X) if metric == "gower" else similarity_matrix(X.to_numpy(float), metric)
    sign = np.sign(S)
    if opts.get("signed") or opts.get("absolute"):     # negative associations count as strong ties too
        S = np.abs(S)
    keep = sparsify(S, opts.get("sparsify") or {}, D)
    iu = np.triu_indices(len(S), 1)
    sel = keep[iu]
    ids = np.array(X.index)
    edges = pd.DataFrame({"source": ids[iu[0][sel]], "target": ids[iu[1][sel]], "weight": S[iu][sel]})
    if opts.get("signed") or opts.get("absolute"):
        edges["sign"] = sign[iu][sel].astype(int)
    if D is not None:
        edges["distance_km"] = D[iu][sel].round(2)
    nodes = pd.DataFrame({"id": ids, "label": labels.reindex(ids).to_numpy(), "keep_isolated": True})
    e = opts.get("entity")
    if e and opts.get("format", "wide") == "wide" and opts.get("nodes", "rows") == "rows":
        for col in as_list(opts.get("node_attributes")):
            require_columns(data, col, "similarity.node_attributes")
            attr = data.drop_duplicates(e).set_index(e)[col]
            attr.index = attr.index.astype(str)
            nodes[col] = nodes["id"].map(attr)
    return to_graph(edges, directed=False, nodes=nodes)
