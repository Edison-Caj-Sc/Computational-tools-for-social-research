"""Texts → networks of what appears together (entities, terms) or of documents that share them.

What is detected (entities: …): your own list with aliases (gazetteer), organization-name patterns
(Spanish/English), acronym definitions such as "Ministerio de Salud (MINSA)", named entities with spaCy
(people, places, organizations), key terms (semantic networks), #hashtags and @mentions.
mode: entities (co-occurrence in a sentence, paragraph, window or document) · documents (linked by shared
entities) · bipartite (document–entity). Ties keep evidence snippets and relation types from keyword
dictionaries (default ones for coordination, agreement, funding, oversight, conflict, technical support).
""" 
from __future__ import annotations

import itertools
import re
from collections import Counter, defaultdict

import pandas as pd

from ..config import resolve
from ..graph import to_graph
from ..io import read_table
from ..utils import ConfigError, as_list, fold, log, require_columns
from . import register

UP = "A-ZÁÉÍÓÚÑÜ"
TOKEN = rf"(?:[{UP}][\w'’\-]*|[{UP}]{{2,}}|\d+)"

KEYWORDS = {
    "es": {
        "national_government": ["Ministerio", "Presidencia", "Congreso", "Poder Ejecutivo", "Poder Judicial",
                                "Superintendencia", "Organismo", "Contraloría", "Defensoría", "Fiscalía",
                                "Policía", "Tribunal", "Corte", "Autoridad", "Servicio", "Agencia", "Instituto",
                                "Programa", "Proyecto", "Secretaría", "Oficina", "Consejo", "Comisión", "Fondo",
                                "Registro", "Jurado"],
        "regional_government": ["Gobierno Regional", "Dirección Regional", "Gerencia Regional", "Consejo Regional"],
        "local_government": ["Municipalidad", "Gobierno Local", "Gerencia Municipal"],
        "civil_society": ["Asociación", "Federación", "Confederación", "Sindicato", "Cooperativa", "Comité",
                          "Frente", "Coordinadora", "Central", "Red", "Fundación", "Mesa", "Ronda", "Junta",
                          "Comunidad Campesina", "Colectivo", "Movimiento", "Plataforma"],
        "private": ["Empresa", "Corporación", "Compañía", "Cámara", "Sociedad", "Banco", "Minera", "Grupo"],
        "academia": ["Universidad", "Centro", "Observatorio", "Colegio"],
        "international": ["Organización", "Naciones Unidas", "Unión Europea", "Cooperación"],
        "other": ["Dirección", "Gerencia", "Unidad", "Entidad"],
    },
    "en": {
        "government": ["Ministry", "Department", "Agency", "Office", "Bureau", "Council", "Commission",
                       "Authority", "Secretariat", "Court", "Parliament", "Congress", "Senate", "Government",
                       "Service", "Administration", "Directorate", "Municipality", "City of"],
        "civil_society": ["Association", "Federation", "Union", "Committee", "Coalition", "Network",
                          "Foundation", "Movement", "Alliance", "Cooperative"],
        "private": ["Company", "Corporation", "Bank", "Group", "Chamber"],
        "academia": ["University", "Institute", "Center", "Centre", "College"],
        "international": ["Organization", "Organisation", "United Nations", "Fund", "Programme", "Program"],
    },
}
CONNECTORS = {"es": r"(?:de|del|de la|de las|de los|la|las|los|el|y|e|para|en|al|a|sobre|contra)",
              "en": r"(?:of|for|the|and|on|in|to|&)"}
STOP_START = {"es": {"el", "la", "los", "las", "un", "una", "este", "esta", "dicho", "dicha"},
              "en": {"the", "a", "an", "this", "that"}}
DEFAULT_RELATIONS = {
    "es": {"coordination": ["coordin", "articul", "mesa de trabajo", "comité", "conjunt", "concert"],
           "agreement": ["convenio", "acuerdo", "memorando", "acta", "compromiso"],
           "funding": ["financ", "transfer", "presupuest", "fondos", "cofinanc", "donación"],
           "oversight": ["supervis", "fiscaliz", "control", "sanci", "audit"],
           "conflict": ["conflict", "protest", "denunci", "rechaz", "paro", "demanda"],
           "technical_support": ["asistencia técnica", "capacitación", "asesor", "acompañamiento"]},
    "en": {"coordination": ["coordinat", "joint", "partner", "collaborat", "working group"],
           "agreement": ["agreement", "memorandum", "mou", "accord", "contract"],
           "funding": ["fund", "grant", "financ", "budget", "transfer", "loan"],
           "oversight": ["oversee", "oversight", "audit", "regulat", "supervis", "monitor"],
           "conflict": ["conflict", "protest", "dispute", "lawsuit", "complain"],
           "technical_support": ["technical assistance", "training", "capacity building", "advis"]},
}
STOPWORDS = {
    "es": set("""a al algo algun alguna algunas alguno algunos ante antes aqui asi aun bajo bien cada casi como con
    contra cual cuales cuando de del desde donde dos e el ella ellas ellos en entre era eran es esa esas ese eso
    esos esta estaba estado estan estar estas este esto estos fue fueron ha habia han hasta hay la las le les lo
    los mas me mi mientras muy nada ni no nos nuestra nuestro o os otra otras otro otros para pero poco por porque
    que quien se segun ser si sido sin sobre solo son su sus tambien tan tanto te tiene tienen todo todos tras tu
    un una uno unos usted y ya yo dicho dicha asimismo dentro donde durante mediante cual cuya cuyo ademas debe
    deben puede pueden hace hacer cabe toda todas mismo misma mismos parte vez veces tal tales sea sean""".split()),
    "en": set("""a about above after again against all am an and any are as at be because been before being below
    between both but by can could did do does doing down during each few for from further had has have having he
    her here hers him his how i if in into is it its itself just me more most my no nor not now of off on once only
    or other our out over own same she should so some such than that the their them then there these they this
    those through to too under until up very was we were what when where which while who whom why will with would
    you your also may must shall within without upon per via""".split()),
}
ABBREV = r"\b(?:Sr|Sra|Dr|Dra|Ing|Lic|Art|Arts|Inc|No|Nº|N°|art|núm|pág|Mr|Mrs|Ms|Prof|St|etc|vs|Av|Jr|Mg|Abog)\."


# ---------------------------------------------------------------------------
# Segmentation
# ---------------------------------------------------------------------------

def split_units(text: str, unit: str, window: int = 2) -> list[str]:
    text = text.replace("\r", "")
    if unit == "document":
        return [text]
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    if unit == "paragraph":
        return paragraphs
    sentences = []
    for p in paragraphs:
        p = re.sub(ABBREV, lambda m: m.group(0).replace(".", "§"), re.sub(r"\s*\n\s*", " ", p))
        sentences += [s.replace("§", ".").strip() for s in re.split(rf"(?<=[.!?;])\s+(?=[{UP}¿¡\"“(\d])", p) if s.strip()]
    if unit == "sentence":
        return sentences
    if unit == "window":
        return [" ".join(sentences[i:i + window]) for i in range(max(1, len(sentences) - window + 1))]
    raise ConfigError("text: 'unit' must be sentence, paragraph, window or document")


# ---------------------------------------------------------------------------
# Entity recognition
# ---------------------------------------------------------------------------

class EntityFinder:
    def __init__(self, opts: dict, cfg: dict, lang: str):
        self.lang = lang
        self.alias: dict[str, str] = {}           # folded alias -> canonical
        self.types: dict[str, str] = {}
        self.exclude = {fold(x) for x in as_list(opts.get("exclude"))}
        self.use_patterns = bool(opts.get("patterns", True)) and lang in KEYWORDS
        if opts.get("patterns", True) and lang not in KEYWORDS:
            log.info(f"text: no organization patterns for language {lang!r}; using the other detectors")
        terms = opts.get("terms") or False
        self.terms = ({} if terms is True else dict(terms)) if terms else None
        if self.terms is not None:
            self.stop = {fold(w) for w in STOPWORDS.get(lang, set()) | set(as_list(self.terms.get("stopwords")))}
            self.min_len = int(self.terms.get("min_length", 3))
        self.hashtags, self.mentions = bool(opts.get("hashtags")), bool(opts.get("mentions"))
        self.use_acronyms = bool(opts.get("acronyms", True))
        if opts.get("gazetteer"):
            self._load_gazetteer(resolve(cfg, opts["gazetteer"]))
        kw = KEYWORDS.get(lang, {"organization": ["\uffff"]})
        self.kw_type = {fold(k): t for t, ks in kw.items() for k in ks}
        kw_alt = "|".join(sorted((re.escape(k) for ks in kw.values() for k in ks), key=len, reverse=True))
        conn = CONNECTORS.get(lang, CONNECTORS["en"])
        self.kw_re = re.compile(rf"(?:{kw_alt})\b")
        self.org_re = re.compile(rf"\b(?:{kw_alt})\b(?:\s+(?:{conn}\s+)*{TOKEN})*")
        self.pre_re = re.compile(rf"\b(?:{TOKEN}\s+){{1,4}}(?:{kw_alt})\b") if lang == "en" else None
        self.and_re = re.compile(r"\s+(?:y|e|and|&)\s+(?:(?:la|el|los|las|the)\s+)?")
        self.word_re = re.compile(r"[^\W\d_]+(?:[-'’][^\W\d_]+)*", re.UNICODE)
        self.acr_re = re.compile(rf"([{UP}][^()]{{3,120}}?)\s*\(\s*([{UP}][{UP}A-Za-z0-9\-]{{1,14}})\s*\)")
        self._alias_re = None
        self.spacy = None
        if opts.get("spacy"):
            try:
                import spacy
                self.spacy = spacy.load(opts["spacy"])
                self.spacy_labels = set(as_list(opts.get("spacy_labels", ["ORG"])))
            except Exception as e:
                raise ConfigError(f"Could not load spaCy model {opts['spacy']!r}: {e}. "
                                  f"Install with: python -m spacy download {opts['spacy']}") from e

    def _load_gazetteer(self, path):
        g = read_table(path)
        require_columns(g, "name", "gazetteer")
        for d in g.to_dict("records"):
            name = str(d["name"]).strip()
            for a in [name] + [x.strip() for x in str(d.get("aliases") or "").split("|") if x.strip()]:
                self.alias[fold(a)] = name
            if d.get("type") and pd.notna(d.get("type")):
                self.types[name] = str(d["type"])
        log.info(f"text: gazetteer with {len(g)} entities and {len(self.alias)} names/aliases")

    def learn_acronyms(self, texts):
        """'Autoridad Nacional del Agua (ANA)' → ANA is an alias of the full name."""
        if not self.use_acronyms:
            return
        n = 0
        for t in texts:
            for m in self.acr_re.finditer(t):
                full, acr = m.group(1), m.group(2)
                names = []
                if self.use_patterns:
                    for rx in filter(None, (self.org_re, self.pre_re)):
                        for x in rx.finditer(full):
                            names += self._split_and(x.group(0))
                ends = [n for n in names if full.rstrip().endswith(n) and len(n.split()) >= 2]
                cand = max(ends, key=len) if ends else None
                if cand is None:
                    canon = self.alias.get(fold(full.strip()))
                    if canon is None:
                        continue
                    cand = canon
                canon = self.alias.get(fold(cand), self._clean(cand))
                if fold(acr) not in self.alias:
                    self.alias[fold(acr)] = canon
                    self.alias.setdefault(fold(canon), canon)
                    n += 1
        if n:
            log.info(f"text: learned {n} acronym(s) from definitions like 'Full Name (ACR)'")

    def _split_and(self, s: str) -> list[str]:
        """Splits 'A and B' only when B is an organization by itself (it contains a keyword)."""
        pieces, start = [], 0
        for m in self.and_re.finditer(s):
            following = self.and_re.split(s[m.end():])[0]
            if self.kw_re.search(following) or fold(following) in self.alias:
                pieces.append(s[start:m.start()])
                start = m.end()
        return pieces + [s[start:]]

    def _clean(self, name: str) -> str:
        name = re.sub(rf"\s+(?:{CONNECTORS.get(self.lang, CONNECTORS['en'])})$", "", name.strip(" ,.;:"))
        return re.sub(r"\s+", " ", name)

    def find_terms(self, text: str) -> set[str]:
        words = [w.lower() for w in self.word_re.findall(text)]
        ok = [len(w) >= self.min_len and fold(w) not in self.stop for w in words]
        found = {w for w, k in zip(words, ok) if k}
        if self.terms.get("bigrams"):
            found |= {f"{a} {b}" for (a, ka), (b, kb) in zip(zip(words, ok), zip(words[1:], ok[1:])) if ka and kb}
        for w in found:
            self.types[w] = "term"
        return found

    def entity_type(self, name: str) -> str:
        if name in self.types:
            return self.types[name]
        m = self.kw_re.search(name)
        return self.kw_type.get(fold(m.group(0)), "organization") if m else "organization"

    def find(self, text: str) -> set[str]:
        found = set()
        if self.alias:                                 # gazetteer, aliases and acronyms
            if self._alias_re is None:
                alt = "|".join(re.escape(a) for a in sorted(self.alias, key=len, reverse=True) if a)
                self._alias_re = re.compile(rf"(?<![a-z0-9])(?:{alt})(?![a-z0-9])")
            found |= {self.alias[m.group(0)] for m in self._alias_re.finditer(fold(text))}
        if self.use_patterns:
            hits = [m.group(0) for m in self.org_re.finditer(text)]
            if self.pre_re:
                hits += [m.group(0) for m in self.pre_re.finditer(text)]
            for h in hits:
                for part in self._split_and(h):
                    part = self._clean(part)
                    if len(part.split()) < 2 or fold(part.split()[0]) in STOP_START[self.lang]:
                        continue                         # "el Ministerio" alone is too generic
                    found.add(self.alias.get(fold(part), part))
        if self.spacy is not None:
            for ent in self.spacy(text).ents:
                if ent.label_ in self.spacy_labels:
                    name = self._clean(ent.text)
                    found.add(self.alias.get(fold(name), name))
        if self.hashtags:
            for h in re.findall(r"(?<![\w#&])#(\w*[^\W\d]\w*)", text):
                found.add("#" + h.lower())
                self.types["#" + h.lower()] = "hashtag"
        if self.mentions:
            for m in re.findall(r"(?<![\w@])@(\w{1,50})", text):
                found.add("@" + m.lower())
                self.types["@" + m.lower()] = "mention"
        # drop names contained in a longer name found in the same unit
        folded = {f: fold(f) for f in found}
        found = {f for f in found if not any(f != g and folded[f] in folded[g] and len(folded[g]) > len(folded[f])
                                             and folded[f] not in self.alias for g in found)}
        if self.terms is not None:
            found |= self.find_terms(text)
        return {f for f in found if fold(f) not in self.exclude}


# ---------------------------------------------------------------------------
# Builder
# ---------------------------------------------------------------------------

@register("text", "Texts: entities or terms that appear together, or documents that share them, with evidence")
def build(data: pd.DataFrame, opts: dict, cfg: dict):
    tcol, idcol = opts.get("text_column", "text"), opts.get("id_column", "doc_id")
    require_columns(data, tcol, "text")
    if idcol not in data.columns:
        data = data.assign(**{idcol: [f"doc{i + 1}" for i in range(len(data))]})
    lang = opts.get("language", "es")
    ent_opts = opts.get("entities") or {}
    finder = EntityFinder(ent_opts, cfg, lang)
    texts = data[tcol].fillna("").astype(str).tolist()
    finder.learn_acronyms(texts)

    rel = opts.get("relations", "default")
    relations = DEFAULT_RELATIONS.get(lang, {}) if rel == "default" else (rel if isinstance(rel, dict) else {})
    relations = {k: [fold(w) for w in as_list(v)] for k, v in relations.items()}
    n_evidence = int(opts.get("evidence", 3))
    unit = opts.get("unit", "sentence")

    units = []                                      # (doc, text, entities)
    for doc, text in zip(data[idcol].astype(str), texts):
        for u in split_units(text, unit, int(opts.get("window", 2))):
            ents = finder.find(u)
            if ents:
                units.append((doc, u, ents))
    freq = Counter(e for _, _, ents in units for e in ents)
    min_f = int(ent_opts.get("min_frequency", 1))
    keep = {e for e, c in freq.items() if c >= min_f}
    terms = {e for e in keep if finder.types.get(e) == "term"}
    max_terms = int((finder.terms or {}).get("max_terms", 150))
    if len(terms) > max_terms:                      # semantic networks: the most frequent terms only
        keep -= set(sorted(terms, key=lambda e: (-freq[e], e))[max_terms:])
    if not keep:
        raise ConfigError("text: no entities found. Add a gazetteer, enable 'terms', check 'language', "
                          "or lower 'min_frequency'.")
    docs_of = defaultdict(set)
    for doc, _, ents in units:
        for e in ents & keep:
            docs_of[e].add(doc)
    nodes = pd.DataFrame([{"id": e, "type": finder.entity_type(e), "frequency": freq[e],
                           "documents": len(docs_of[e]), "keep_isolated": True} for e in keep])
    mode = opts.get("mode", "entities")
    if mode in ("documents", "bipartite"):
        return _document_network(data, idcol, units, keep, nodes, mode, opts)
    if mode != "entities":
        raise ConfigError("text: 'mode' must be entities, documents or bipartite")

    pairs = defaultdict(lambda: {"weight": 0, "docs": set(), "evidence": [], **{f"rel_{k}": 0 for k in relations}})
    for doc, u, ents in units:
        ents = sorted(e for e in ents if e in keep)
        fu = fold(u)
        rel_hits = [k for k, words in relations.items() if any(w in fu for w in words)]
        for a, b in itertools.combinations(ents, 2):
            p = pairs[(a, b)]
            p["weight"] += 1
            p["docs"].add(doc)
            for k in rel_hits:
                p[f"rel_{k}"] += 1
            if len(p["evidence"]) < n_evidence:
                snippet = u if len(u) <= 400 else u[:397] + "…"
                p["evidence"].append(f"[{doc}] {snippet}")
    min_co = float(opts.get("min_cooccurrence", 1))
    rows = []
    for (a, b), p in pairs.items():
        if p["weight"] < min_co:
            continue
        rels = {k: v for k, v in p.items() if k.startswith("rel_")}
        top = max(rels, key=rels.get) if rels and max(rels.values()) > 0 else None
        found = [k[4:] for k, v in rels.items() if v > 0]
        rows.append({"source": a, "target": b, "weight": float(p["weight"]), "documents": len(p["docs"]),
                     **rels, "main_relation": top[4:] if top else "co-mention",
                     "relation": "|".join(sorted(found)) or "co-mention",
                     "evidence": "\n---\n".join(p["evidence"])})
    edges = pd.DataFrame(rows, columns=["source", "target", "weight", "documents", "main_relation", "relation",
                                        "evidence"] + [f"rel_{k}" for k in relations])
    log.info(f"text: {len(data)} document(s), {len(units):,} units with entities, "
             f"{len(keep):,} entities, {len(edges):,} ties")
    return to_graph(edges, directed=False, nodes=nodes)


def _document_network(data, idcol, units, keep, ent_nodes, mode, opts):
    """Documents linked by the entities they share (or the document–entity bipartite network)."""
    from .affiliation import incidence, project
    rows = [(doc, e) for doc, _, ents in units for e in ents & keep]
    pairs = pd.DataFrame(rows, columns=["doc", "entity"])
    meta = [c for c in data.columns if c not in ("text", "path", opts.get("text_column", "text"))]
    docs = data[meta].drop_duplicates(idcol).rename(columns={idcol: "id"})
    docs["id"] = docs["id"].astype(str)
    if mode == "bipartite":
        edges = pairs.value_counts().rename("weight").reset_index().rename(columns={"doc": "source", "entity": "target"})
        dn = docs.assign(type="document", bipartite=0, keep_isolated=True)
        nodes = pd.concat([dn, ent_nodes.assign(bipartite=1)], ignore_index=True)
        log.info(f"text: {len(dn)} documents × {len(ent_nodes)} entities → {len(edges):,} ties")
        return to_graph(edges, directed=False, nodes=nodes)
    B, _, doc_labels = incidence(pairs["entity"], pairs["doc"])           # entity × document
    edges, freq = project(B, doc_labels, opts.get("weighting", "count"), float(opts.get("min_cooccurrence", 1)))
    shared = defaultdict(list)
    for doc, grp in pairs.drop_duplicates().groupby("doc"):
        shared[doc] = set(grp["entity"])
    edges["shared"] = ["; ".join(sorted(shared[a] & shared[b])[:15]) for a, b in zip(edges["source"], edges["target"])]
    nodes = docs.merge(freq.rename("entities").rename_axis("id").reset_index(), on="id", how="left")
    nodes = nodes.assign(type="document", keep_isolated=True)
    log.info(f"text: {len(nodes)} documents linked by shared entities → {len(edges):,} ties")
    return to_graph(edges, directed=False, nodes=nodes)
