# Third-party components / Componentes de terceros

Tejido is MIT licensed (see `LICENSE`). It is built on, and the standalone executable and installer contain, the
components below, each under its own license. The full license texts travel with the program in
`tejido/ui/static/` (`THIRD-PARTY-LICENSES.txt`, `LICENSE-vis-network.txt`, `LICENSE-fonts.txt`, `LICENSE-xlrd.txt`)
and the installer copies them next to `tejido.exe`. Regenerate the first file with `python tools/third_party_licenses.py`
on the machine that builds the executable.

| Component | Used for | License |
|---|---|---|
| [vis-network](https://visjs.github.io/vis-network/) (vis.js community) | drawing the network (bundled, unmodified) | Apache-2.0 or MIT |
| [Instrument Sans](https://github.com/Instrument/instrument-sans), [Newsreader](https://github.com/productiontype/Newsreader) | interface typefaces (bundled, unmodified) | SIL OFL 1.1 |
| [NetworkX](https://networkx.org) | graphs, many measures, community detection | BSD-3-Clause |
| [pandas](https://pandas.pydata.org), [NumPy](https://numpy.org), [SciPy](https://scipy.org) | tables and numerics (NumPy and SciPy bundle OpenBLAS and the GCC runtime; see their texts) | BSD-3-Clause (NumPy also lists 0BSD, MIT, Zlib, CC0-1.0) |
| [PyYAML](https://pyyaml.org) | configuration files | MIT |
| [pypdf](https://github.com/py-pdf/pypdf) | reading PDF | BSD-3-Clause |
| [python-docx](https://github.com/python-openxml/python-docx), [lxml](https://lxml.de) | reading Word | MIT; BSD-3-Clause |
| [openpyxl](https://openpyxl.readthedocs.io), et_xmlfile, [xlrd](https://github.com/python-excel/xlrd) | reading Excel (.xlsx and .xls) | MIT; MIT; BSD |
| [pyreadstat](https://github.com/Roche/pyreadstat) | reading SPSS, Stata and SAS (bundles ReadStat, MIT) | Apache-2.0 |
| python-dateutil, tzdata, narwhals, typing_extensions | dependencies of the above | Apache-2.0 or BSD-3-Clause; Apache-2.0; MIT; PSF-2.0 |
| Python 3.12 and Tcl/Tk | runtime and launcher window inside the executable | PSF-2.0; Tcl/Tk License |
| [PyInstaller](https://pyinstaller.org) | builds the executable | GPL-2.0-or-later with the bootloader exception: the executables it produces may be distributed under any license |
| [NSIS](https://nsis.sourceforge.io) | builds the Windows installer | zlib/libpng |

Optional, not bundled: [spaCy](https://spacy.io) (MIT).

Methods, palettes and algorithms are credited in the *Credits and methods* section of `README.md` and in the header of
`tejido/ui/static/style.js`. Program and file-format names (Pajek, UCINET, GEXF/Gephi, SPSS, Excel, World Bank, CEPALSTAT…)
belong to their owners and are used only to say what Tejido reads or writes; no code from those programs is included.
