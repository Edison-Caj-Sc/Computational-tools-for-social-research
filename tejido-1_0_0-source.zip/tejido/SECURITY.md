# Security / Seguridad

Tejido 1.0 · Copyright (c) 2026 Angel Edison Ayala Velásquez · MIT License

Tejido runs on your own computer. It does not send your data anywhere: the only internet connections are the
downloads you ask for (World Bank indicators, or a table given as a web address).

## How the program protects you

**Configuration files.** A YAML configuration may come from someone else. Expressions in `prepare.filter`,
`prepare.compute` and `builder.filter` are checked before pandas evaluates them (`tejido/safe_expr.py`): only
column names, numbers, texts, comparisons, arithmetic, `and`/`or`/`not`, lists, a short list of column methods and
mathematical functions are accepted. `@variables`, imports, attributes of Python objects and file access are
refused. YAML is read with `safe_load`, which creates no Python objects.

**Visual interface** (`tejido/ui/server.py`):

| Protection | Against |
|---|---|
| Listens only on `127.0.0.1` | Other computers on the network |
| The page opens only from a one-time launch address; the browser then keeps an `HttpOnly; SameSite=Strict` session cookie | Other programs or users of the same computer that find the port |
| A random 256-bit key in a header on every `/api` call; never in addresses | Keys left in the browser history |
| `Host`, `Origin` and `Sec-Fetch-Site` are checked | Websites that try to talk to the interface; DNS rebinding |
| Content-Security-Policy without inline or remote scripts; `X-Frame-Options: DENY` | Data that tries to run code in the interface; framing |
| Result pages open in a sandbox | A page built from someone else's data using your session |
| Uploads: size limit (`TEJIDO_MAX_UPLOAD_MB`, 1024 by default) and only the kinds of file the program reads | Filling the disk; executables in the workspace |
| Results, uploads and downloads stay inside the workspace folder; only folders can be opened from the interface | Writing elsewhere on the disk; running a received file |
| Downloads: http(s) only, `TEJIDO_MAX_DOWNLOAD_MB` (300); ZIP files: at most 200 tables and `TEJIDO_MAX_UNZIP_MB` (1024) unzipped | `file://` tricks; ZIP bombs |
| Refused requests are written to the activity log | Attempts going unnoticed |

**Result files.** Interactive pages escape every value taken from the data. Excel workbooks keep texts that start
with `=` as texts, not formulas. CSV files are written as they are, because R, Gephi and other programs need the
exact values; if you share them with people who open them in a spreadsheet, set `output.escape_formulas: true`
to prefix such texts with an apostrophe.

## Logs and privacy

The activity log (`logs/tejido.log` in the workspace, or `--log-file`) records sessions, builds, files received,
errors and refused requests. It never records the contents of your data; session keys are masked. Each run also
saves `<project>_run.json` with the versions, settings and SHA-256 fingerprints of its input files (no data).
Remove these files if the names of your files or folders are themselves confidential.

## Executables

The Windows, macOS and Linux executables are built by the public GitHub Actions workflow of the repository from
this source code. They are not code-signed yet, so Windows SmartScreen and macOS Gatekeeper may warn the first time.
Download them only from the repository's Releases page.

## Reporting a vulnerability

Please do not open a public issue. Write to the author through the contact given on the GitHub profile
[Edison-Caj-Sc](https://github.com/Edison-Caj-Sc) with the version (`tejido --version`), your system and the steps
to reproduce it. You will get an answer within 14 days, and the fix will credit you if you wish.

---

**Resumen en español.** Tejido funciona solo en tu computadora y no envía tus datos a ningún lugar. Las
expresiones de los archivos de configuración se verifican antes de evaluarlas, para que un archivo recibido de
otra persona no pueda ejecutar comandos. La interfaz solo se abre desde la dirección que entrega el propio
programa, comprueba una clave aleatoria en cada solicitud, rechaza peticiones de otros sitios web y guarda todo
dentro de la carpeta de trabajo. El registro de actividad (`logs/tejido.log`) nunca guarda el contenido de tus
datos. Para informar de una vulnerabilidad, escribe al autor por el contacto de su perfil de GitHub, no en un
issue público.
