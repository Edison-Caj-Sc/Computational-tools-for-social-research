"""Whole-network statistics: size and cohesion, distances, centralization, connectivity and
vulnerability, hierarchy, homophily, dyads and triads, degree distribution, rich club and comparison
with random networks (null models, small-world sigma)."""
from __future__ import annotations

import networkx as nx
import numpy as np
import pandas as pd

from .analyze import BIG, is_weighted, undirected_simple
from .utils import ConfigError, as_list, log, slug


def _r(x, d=4):
    return round(float(x), d) if x is not None and np.isfinite(x) else None


def gini(x) -> float:
    x = np.sort(np.asarray(x, dtype=float))
    n = len(x)
    return float((2 * np.arange(1, n + 1) - n - 1) @ x / (n * x.sum())) if n and x.sum() > 0 else 0.0


def freeman(values, n: int, kind: str) -> float | None:
    """Freeman centralization (0 = all equal, 1 = star)."""
    v = np.asarray(list(values), dtype=float)
    if n < 3 or not len(v):
        return None
    diff = (v.max() - v).sum()
    denom = {"degree": (n - 1) * (n - 2), "betweenness": n - 1, "closeness": (n - 1) * (n - 2) / (2 * n - 3)}[kind]
    return diff / denom


def distances(G: nx.Graph, seed: int, exact_up_to: int = 5000) -> dict:
    """One pass of shortest paths (in C): diameter, radius and mean path length of the largest component,
    and global efficiency over all pairs. Above 'exact_up_to' nodes they are estimated from 1,000 sources."""
    from .analyze import distance_rows
    U = undirected_simple(G) if G.is_directed() else G
    N = U.number_of_nodes()
    if N < 2 or U.number_of_edges() == 0:
        return {}
    nodes = list(U)
    lcc = max(nx.connected_components(U), key=len)
    in_lcc = np.array([v in lcc for v in nodes])
    sources = None
    if N > exact_up_to:
        sources = np.sort(np.random.default_rng(seed).choice(N, 1000, replace=False))
    ecc, total, pairs, inv, rows_seen = [], 0.0, 0, 0.0, 0
    for ind, D in distance_rows(U, False, nodes=nodes, sources=sources):
        with np.errstate(divide="ignore"):
            inv += np.where(np.isfinite(D) & (D > 0), 1 / D, 0).sum()
        rows_seen += len(ind)
        for i, row in zip(ind, D):
            if in_lcc[i] and len(lcc) > 1:
                fin = row[in_lcc]
                ecc.append(fin.max())
                total += fin.sum()
                pairs += len(fin) - 1
    out = {"global_efficiency": _r(inv / (rows_seen * (N - 1)))}
    if ecc:
        out.update({"diameter": int(max(ecc)), "average_path_length": _r(total / pairs if pairs else 0, 3)})
        if sources is None:
            out["radius"] = int(min(ecc))
    if sources is not None:
        out["distances_note"] = "estimated from 1,000 sampled nodes (diameter is a lower bound)"
    return out


def krackhardt(G: nx.Graph) -> dict:
    """Krackhardt (1994): connectedness (reachable pairs) and, for directed networks, hierarchy
    (share of the unordered pairs linked by reach in at least one direction that are not mutually reachable)."""
    n = G.number_of_nodes()
    if n < 2 or n > BIG:
        return {}
    U = undirected_simple(G) if G.is_directed() else G
    sizes = [len(c) for c in nx.connected_components(U)]
    out = {"connectedness": _r(sum(s * (s - 1) for s in sizes) / (n * (n - 1)))}
    if G.is_directed():
        reach = mutual = 0
        R = {v: nx.descendants(G, v) for v in G}
        for v, ds in R.items():
            reach += len(ds)
            mutual += sum(1 for w in ds if v in R[w])
        pairs = reach - mutual / 2                     # unordered pairs with reach in at least one direction
        out["hierarchy"] = _r(1 - (mutual / 2) / pairs) if pairs else 0
    return out


def homophily(G: nx.Graph, attrs) -> tuple[dict, pd.DataFrame | None]:
    """Assortativity, E-I index (Krackhardt & Stern) and Coleman's index for node attributes."""
    U = undirected_simple(G) if G.is_directed() else G
    summary, rows = {}, []
    m = U.number_of_edges()
    for a in as_list(attrs):
        vals = {n: d.get(a) for n, d in U.nodes(data=True) if d.get(a) is not None}
        if len(vals) < 2:
            log.warning(f"homophily: attribute {a!r} not found on nodes")
            continue
        numeric = all(isinstance(v, (int, float, np.number)) and not isinstance(v, bool) for v in vals.values()) \
            and len(set(vals.values())) > 10
        try:
            f = nx.numeric_assortativity_coefficient if numeric else nx.attribute_assortativity_coefficient
            H = U.subgraph(vals)
            summary[f"assortativity_{slug(a)}"] = _r(f(H, a))
        except Exception:
            pass
        if numeric or not m:
            continue
        internal = sum(1 for u, v in U.edges if u in vals and v in vals and str(vals[u]) == str(vals[v]))
        external = sum(1 for u, v in U.edges if u in vals and v in vals and str(vals[u]) != str(vals[v]))
        summary[f"ei_index_{slug(a)}"] = _r((external - internal) / (external + internal)) if internal + external else None
        groups = pd.Series({n: str(v) for n, v in vals.items()})
        share = groups.value_counts(normalize=True)
        for g, w in share.items():                      # ties seen from the members' side: an internal tie
            members = set(groups[groups == g].index)    # counts once for each of its two members
            ties = [(u, v) for u, v in U.edges if u in vals and v in vals and (u in members or v in members)]
            if not ties:
                continue
            inside = sum(1 for u, v in ties if u in members and v in members)
            outside = len(ties) - inside
            s = 2 * inside / (2 * inside + outside)
            coleman = (s - w) / (1 - w) if s >= w and w < 1 else (s - w) / w
            rows.append({"attribute": a, "group": g, "nodes": len(members), "share_of_nodes": _r(w),
                         "ties": len(ties), "internal_ties": inside, "share_internal": _r(s),
                         "ei_index": _r((outside - 2 * inside) / (outside + 2 * inside)), "coleman": _r(coleman)})
    return summary, (pd.DataFrame(rows) if rows else None)


def rich_club(G: nx.Graph) -> pd.DataFrame | None:
    U = nx.Graph(undirected_simple(G) if G.is_directed() else G)
    U.remove_edges_from(nx.selfloop_edges(U))
    if U.number_of_edges() < 3:
        return None
    rc = nx.rich_club_coefficient(U, normalized=False)
    return pd.DataFrame({"degree_above": list(rc), "rich_club": [round(v, 4) for v in rc.values()],
                         "nodes": [sum(1 for _, d in U.degree() if d > k) for k in rc]})


def _simple(G: nx.Graph) -> nx.Graph:
    """Ties as present or absent: no weights, no self-loops (the structure the null models randomize)."""
    S = nx.DiGraph() if G.is_directed() else nx.Graph()
    S.add_nodes_from(G)
    S.add_edges_from((u, v) for u, v in G.edges if u != v)
    return S


def rewire(S: nx.Graph, seed: int, swaps: float = 10) -> nx.Graph:
    """Degree-preserving randomization: swaps ends of ties (keeping in- and out-degrees in directed networks) without
    creating multiple ties or self-loops. When few swaps are possible (dense or tiny networks) it keeps those it made."""
    H = S.copy()
    nswap = max(1, int(swaps * H.number_of_edges()))
    try:
        if H.is_directed():
            nx.directed_edge_swap(H, nswap=nswap, max_tries=100 * nswap, seed=seed)
        else:
            nx.double_edge_swap(H, nswap=nswap, max_tries=100 * nswap, seed=seed)
    except (nx.NetworkXError, nx.NetworkXAlgorithmError):
        pass
    return H


def null_model(G: nx.Graph, comms, spec, seed: int) -> tuple[dict, pd.DataFrame]:
    """Observed vs random networks with the same size (erdos_renyi) or the same degrees (configuration: the observed
    ties rewired, with no multiple ties or self-loops). Ties are taken as present or absent in both."""
    spec = spec if isinstance(spec, dict) else {}
    model, reps = spec.get("model", "configuration"), int(spec.get("n", 50))
    if model not in ("configuration", "erdos_renyi"):
        raise ConfigError("null_model.model must be configuration or erdos_renyi")
    rng = np.random.default_rng(seed)
    directed = G.is_directed()
    obs_graph = _simple(G)
    n, m = obs_graph.number_of_nodes(), obs_graph.number_of_edges()
    with_paths = n <= 2000

    def stats(H):
        U = nx.Graph(H.to_undirected()) if H.is_directed() else H
        s = {"transitivity": nx.transitivity(U), "average_clustering": nx.average_clustering(U)}
        if with_paths and U.number_of_edges():
            L = U.subgraph(max(nx.connected_components(U), key=len))
            s["average_path_length"] = nx.average_shortest_path_length(L) if L.number_of_nodes() > 1 else 0
        if H.is_directed() and H.number_of_edges():
            s["reciprocity"] = nx.reciprocity(H)
        if U.number_of_edges():
            s["modularity"] = nx.community.modularity(U, nx.community.louvain_communities(U, weight=None, seed=seed),
                                                      weight=None)
        return s

    obs = stats(obs_graph)
    sims = []
    for i in range(reps):
        s = int(rng.integers(1 << 31))
        if model == "erdos_renyi":
            H = nx.gnm_random_graph(n, m, seed=s, directed=directed)
        else:
            H = rewire(obs_graph, s, float(spec.get("swaps", 10)))
        sims.append(stats(H))
    rows, summary = [], {}
    for k, v in obs.items():
        x = np.array([s[k] for s in sims if k in s], dtype=float)
        if not len(x):
            continue
        mu, sd = x.mean(), x.std(ddof=1) if len(x) > 1 else 0
        z = (v - mu) / sd if sd > 0 else None
        p = (np.sum(np.abs(x - mu) >= abs(v - mu)) + 1) / (len(x) + 1)
        rows.append({"measure": k, "observed": _r(v), "random_mean": _r(mu), "random_sd": _r(sd),
                     "z": _r(z, 3) if z is not None else None, "p_value": _r(p, 3)})
        if z is not None:
            summary[f"{k}_z"] = _r(z, 3)
    t = pd.DataFrame(rows).set_index("measure") if rows else pd.DataFrame()
    if {"average_clustering", "average_path_length"} <= set(t.index):
        c, l = t.loc["average_clustering"], t.loc["average_path_length"]
        if c["random_mean"] and l["observed"] and l["random_mean"]:
            summary["small_world_sigma"] = _r((c["observed"] / c["random_mean"]) / (l["observed"] / l["random_mean"]), 3)
    log.info(f"null model: {reps} {model} networks compared")
    return summary, t.reset_index()


def network_statistics(G: nx.Graph, comms, a: dict, seed: int) -> tuple[dict, dict]:
    n, m, directed = G.number_of_nodes(), G.number_of_edges(), G.is_directed()
    U = undirected_simple(G) if directed else G
    comps = list(nx.weakly_connected_components(G) if directed else nx.connected_components(G))
    deg = np.array([d for _, d in G.degree()], dtype=float)
    w = np.array([x for *_, x in G.edges(data="weight", default=1)], dtype=float)
    s = {"nodes": n, "ties": m, "directed": directed, "density": _r(nx.density(G)),
         "average_degree": _r(2 * m / n if not directed else m / n, 3) if n else 0,
         "degree_sd": _r(deg.std(), 3), "max_degree": int(deg.max()) if n else 0, "degree_gini": _r(gini(deg)),
         "mean_tie_weight": _r(w.mean(), 3) if m else None,
         "components": len(comps), "largest_component_share": _r(max(map(len, comps)) / n, 3) if n else 0}
    if directed:
        s["strong_components"] = nx.number_strongly_connected_components(G)
    s["isolates"] = nx.number_of_isolates(G)
    s.update(distances(G, seed))
    S = nx.Graph(U)
    S.remove_edges_from(nx.selfloop_edges(S))
    s["average_clustering"] = _r(nx.average_clustering(S))
    s["transitivity"] = _r(nx.transitivity(S))
    if directed:
        s["reciprocity"] = _r(nx.reciprocity(G)) if m else 0
    s["degree_centralization"] = _r(freeman(dict(U.degree()).values(), n, "degree"))
    dist = a.get("distance") or "auto"
    steps = dist == "steps" or (dist == "auto" and not is_weighted(G))
    for k in ("betweenness", "closeness"):
        if k == "betweenness" and not a.get("normalized", True):
            continue                                   # Freeman's formula needs normalized betweenness
        if k == "closeness" and not (steps and not directed and len(comps) == 1):
            continue                                   # its maximum (the star) holds for steps in connected undirected networks
        vals = [d[k] for _, d in G.nodes(data=True) if k in d]
        if len(vals) == n:
            s[f"{k}_centralization"] = _r(freeman(vals, n, k))
    try:
        with np.errstate(all="ignore"):
            s["degree_assortativity"] = _r(nx.degree_assortativity_coefficient(U)) if m > 1 else None
    except Exception:
        pass
    s["bridges"] = sum(1 for _ in nx.bridges(S))
    s["cut_points"] = sum(1 for _ in nx.articulation_points(S))
    s.update(krackhardt(G))
    if 2 < n <= BIG and m:
        L = S.subgraph(max(nx.connected_components(S), key=len))
        if L.number_of_nodes() > 2:
            try:
                s["algebraic_connectivity"] = _r(nx.algebraic_connectivity(L, weight=None, seed=seed))
            except Exception:
                pass
    if comms:
        s["communities"] = len(comms)
        s["modularity"] = _r(nx.community.modularity(U, comms, weight="weight"))
    tables = {}
    attrs = as_list(a.get("attributes"))
    types = {d.get("type") for _, d in G.nodes(data=True)} - {None}
    if 1 < len(types) <= 20:
        try:
            s["type_assortativity"] = _r(nx.attribute_assortativity_coefficient(U, "type"))
        except Exception:
            pass
    if attrs:
        hs, ht = homophily(G, attrs)
        s.update(hs)
        if ht is not None:
            tables["homophily"] = ht
    if directed:
        dyads = n * (n - 1) / 2
        mutual = sum(1 for u, v in G.edges if u != v and G.has_edge(v, u)) / 2
        asym = sum(1 for u, v in G.edges if u != v) - 2 * mutual
        s.update({"dyads_mutual": int(mutual), "dyads_asymmetric": int(asym),
                  "dyads_null": int(dyads - mutual - asym)})
        if n <= BIG:
            D = nx.DiGraph()
            D.add_nodes_from(G)
            D.add_edges_from((u, v) for u, v in G.edges if u != v)
            tc = (getattr(nx, "triadic_census", None) or getattr(nx, "triad_census"))(D)
            if tc:
                tables["triad_census"] = pd.DataFrame({"triad": list(tc), "count": list(tc.values())})
    dd = pd.Series(deg.astype(int)).value_counts().sort_index()
    tables["degree_distribution"] = pd.DataFrame({"degree": dd.index, "nodes": dd.values,
                                                  "share": (dd.values / n).round(4)})
    rc = rich_club(G) if n <= BIG else None
    if rc is not None:
        tables["rich_club"] = rc
    if a.get("null_model"):
        ns, nt = null_model(G, comms, a["null_model"], seed)
        s.update(ns)
        tables["null_model"] = nt
    return {k: v for k, v in s.items() if v is not None}, tables
