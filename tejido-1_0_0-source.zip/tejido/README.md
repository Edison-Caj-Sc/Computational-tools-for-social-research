# Tejido

**Turn (almost) any data into a network, and read it like a social scientist.**

![License: MIT](https://img.shields.io/badge/license-MIT-blue) ![Python 3.9+](https://img.shields.io/badge/python-3.9%2B-blue) ![Windows · macOS · Linux](https://img.shields.io/badge/platforms-Windows%20%C2%B7%20macOS%20%C2%B7%20Linux-lightgrey) ![Interface: English · Español](https://img.shields.io/badge/interface-English%20%C2%B7%20Espa%C3%B1ol-5c6bc0)

Tejido builds networks from the data social researchers actually have: edge lists and matrices, memberships, survey items, indicator tables, documents, social media or e-mail records, personal-network surveys and life trajectories. It computes the measures of social network analysis, shows the network in an interactive view and writes a report. Use it from a visual interface in English or Spanish, from the command line, or from Python. Every decision (what a tie is, what is filtered, what is measured) is saved in a small YAML file, so an analysis can be reviewed, shared and repeated.

```
read → prepare → build → filter → analyze → export        (+ layers and time)
```

![Tejido's network view: organizations co-mentioned in five simulated documents, colored by community](docs/img/network.png)
<sub>Organizations and people mentioned in the same answer across ten simulated interviews about small businesses in Cajamarca, Peru. Colors are communities; rings mark the three largest nodes.</sub>

**[Download](https://github.com/Edison-Caj-Sc/Computational-tools-for-social-research/releases)** · [Get started](#get-started) · [What it can build](#what-it-can-build) · [Visual interface](#visual-interface) · [Configuration](#the-configuration-file) · [FAQ](#faq) · [How to cite](#how-to-cite)

## Highlights

- **Seven ways to build a network**, named by what a tie means: a recorded relation, a shared group or event, being alike, appearing together in a text, addressing someone, a respondent naming a contact, or moving from one state to another.
- **Ties from texts come with evidence.** Read PDF, Word, TXT or HTML documents: organizations, people and places mentioned together become ties, and each tie keeps the snippets that support it and the kinds of relation its words suggest (agreement, funding, oversight, conflict… or your own dictionary).
- **Measures and models for social research**: centrality, communities, structural holes and brokerage, strong and weak ties and local bridges, homophily, core–periphery, blockmodels (CONCOR, structural and generalized blockmodeling, stochastic blockmodels), exponential random graph models (ERGM) validated against R's statnet, comparison with random networks, layers with QAP, change over time, and personal-network measures of social capital.
- **Indicator data as they come**: World Bank, CEPAL, OECD, IMF, Eurostat, Our World in Data or INEI tables, wide or long, with titles, notes and missing-value marks, become similarity networks between countries, regions or districts.
- **No coding needed**: a visual interface walks you through seven stages, and ten one-click examples show each kind of network. The same settings also run from the command line.
- **Pictures you can publish**: shapes, palettes, labels, ties, layout and background are customizable, labels do not overlap, and the network downloads as a PNG or as an interactive page that works offline.
- **Open formats**: CSV, Excel, GraphML, GEXF, JSON, Pajek, UCINET and matrices, plus a report in English or Spanish.
- **Your data stay with you**: everything runs on your computer and nothing is uploaded.

## Get started

**Download (no Python needed).** From [Releases](https://github.com/Edison-Caj-Sc/Computational-tools-for-social-research/releases): the Windows installer (`tejido-X_Y_Z-instalador-windows.exe`) installs Tejido for your user, with shortcuts and without administrator rights; `tejido-windows.exe` runs without installing; `tejido-macos` and `tejido-linux` are for other systems (make them executable with `chmod +x`). Double-click and the interface opens in your browser. The executables are not code-signed, so Windows may show "Windows protected your PC" (choose *More info → Run anyway*) and macOS may ask you to open the file from its context menu.

**With Python 3.9 or later.**

```bash
git clone https://github.com/Edison-Caj-Sc/Computational-tools-for-social-research
cd Computational-tools-for-social-research
py -m pip install "./tejido[all]"      # use python3 -m pip on macOS and Linux
tejido ui                               # opens the visual interface
```

**Your first network.** Open an example from the start page and click **Build network**, or bring your own data: choose a table or documents (stage 1), pick what a tie means (stage 3) and click **Build network**. Click a node or a tie to see its details, use *Customize* to change the look and *Image* to save a PNG.

| ![Start page with the seven stages and the examples](docs/img/start.png) | ![A tie built from documents, with its relation types and supporting text](docs/img/evidence.png) | ![The appearance panel](docs/img/customize.png) |
|---|---|---|
| Seven stages on the left; ten examples on the start page. | A tie from documents: weight, relation types and the text that supports it. | *Customize*: shapes, palettes, labels, ties, layout and background. |

## What it can build

Builders are named by **what defines a tie**, not by where the data comes from.

| Builder | A tie means… | Typical data |
|---|---|---|
| `ties` | a relation recorded explicitly | edge lists, contact lists in one cell, adjacency matrices: flows, friendships, citations, trade, migration |
| `affiliation` | sharing a group, event or context | codes in interview segments, co-authors, directors on boards, people in organizations, users and hashtags |
| `similarity` | being alike or close | countries by indicators, municipalities by census data, survey items (networks of variables), places by distance |
| `text` | appearing together in a text, or sharing entities | organizations, people, places or key terms in documents; documents linked by what they mention |
| `interactions` | addressing someone | mentions, replies, reposts, e-mails (to/cc), messages, debates |
| `ego` | a respondent naming a contact | surveys with name generators and position generators (social capital) |
| `transitions` | moving from one state to another | occupational mobility, migration, school trajectories, steps of a process |

Old names keep working: `edgelist` and `matrix` → `ties`, `cooccurrence` → `affiliation`, `social` → `interactions`, `worldbank_csv` / `worldbank_api` inputs.

## Install

Requires Python 3.9+. From a clone of the repository (or the unzipped source):

```bash
py -m pip install ./tejido                 # core (use python3 -m pip on macOS and Linux)
py -m pip install "./tejido[documents]"    # + PDF and Word documents
py -m pip install "./tejido[formats]"      # + Excel (.xlsx, .xls), SPSS, Stata, SAS and Parquet
py -m pip install "./tejido[all]"          # everything above
py -m pip install "./tejido[nlp]"          # optional: spaCy, to find people and places in texts
```

If the `tejido` command is not recognized, use `py -m tejido` with the same arguments.

## Visual interface

Prefer clicking to writing YAML? Run `tejido ui` (or double-click the executable). A page opens in your web browser, in Spanish or English (switch at the top). On the left, the seven stages are threaded on one line that fills as you configure them; open any stage to change it:

1. **Data**: choose **Table** or **Documents**. A table can be any file or, under *Table source*, **indicator data**: countries, regions or other units × years from the World Bank, CEPAL, OECD, IMF, INEI or any similar source, in almost any layout (recognized automatically; *Adjust how the data are recognized* fixes what it gets wrong), or World Bank indicators downloaded online. Drop a folder of documents (optionally with a table of document details) or give a path or web address.
2. **Prepare**: add steps (filter rows, recode, compute, split cells, reshape, join a table…) and preview the prepared data. Later stages list the prepared columns.
3. **Build the network**: pick what a tie means (only the types that fit your data are enabled) and fill in the form. A table of node attributes can be added for any type.
4. **Filter**, 5. **Analyze** (measures grouped by family, with explanations; distance, communities, groups and positions, homophily, brokerage, group centrality, null models), 6. **Layers and time**, 7. **Save results** (files, report language, interactive page).

Click **Build network** and explore the results in the same page:
- **Network**: color and size by any measure (numeric measures as a gradient), find a node, hide weak ties, and click a node to highlight its neighborhood or a tie to see its details (with the supporting text for documents). **Customize** opens the appearance panel and **Image** downloads the network as a PNG (see below).
- **Summary**: whole-network statistics grouped by topic, each with a short explanation.
- **Nodes** and **Ties**: sortable tables, downloadable as CSV.
- **Groups**: communities, group centrality, blocks and cliques.
- **Tables**: every result table (personal networks, homophily, layers, mobility table…).
- **Over time**: a chart of any measure by period.
- **Files** and **Log**.

**Appearance of the network.** *Customize* changes the look without rebuilding the network:
- *Quick style*: Sober, Poster, Print (black and white), Color-blind friendly, Night.
- *Nodes*: shape (circle, square, triangle, diamond, star, hexagon, inverted triangle) or shape by an attribute; palette for groups (Tejido, Andean textile, Okabe–Ito, Earth, Pastel, Grays) and scale for numbers (Indigo, Viridis, Heat, diverging); size range, border, opacity, shadow, and a ring around the largest nodes.
- *Labels*: all, only the largest, on hover or none; name, name and value, or any attribute; long names in several lines, one line or shortened; size and a halo for readability. Names that would cover a larger node or name are hidden and come back when zooming in (hovering always shows a name).
- *Ties*: gray, ink, color of the origin, blend of both ends, or group color inside groups; opacity, width, straight or curved, arrow size, weights as labels.
- *Arrangement and background*: forces, compact forces, circle, rings (largest in the center), one circle per group, levels; spacing; when the layout stops, nodes move apart just enough for the main names to fit; background; shaded areas around groups.
- *Image*: resolution (1×–4×), legend and title in the PNG.

The look is remembered on the computer, saved with the settings (`output.html.style`) and used by the interactive page of the results.

**Save settings** writes the configuration as YAML for the command line; **Open settings** loads one back, including options the forms do not show. The ten examples open with one click from the start page.

The interface runs only on your computer: a small local server at `127.0.0.1` that other computers cannot reach. Uploaded files and results are kept in a workspace folder (`~/tejido_workspace` by default; change it with `tejido ui --workspace PATH`). The program opens the page with a one-time launch address; the bare address (`http://127.0.0.1:<port>/`) shows nothing, so other programs or users of the same computer cannot use your session. `tejido ui --no-browser` prints the launch address to paste in a browser.

**About** (top right, or the owner's name at the bottom) shows the version, the author, how to cite, the license and where the workspace and the activity log are. The footer shows that everything runs on this computer and opens the workspace folder.

## Logs and run records

- **Activity log**: `logs/tejido.log` in the workspace (five rotating files of 1 MB at most). It records sessions, builds, files received, errors with their traceback and refused requests; never the contents of your data, and session keys are masked. Open it from the footer of the interface (*Activity log*), with `tejido logs`, or from the control window. On the command line, `--log-file FILE` writes it too, `--verbose` shows more detail and `--quiet` only warnings and errors.
- **Run record**: every run saves `<project>_run.json` next to its results: Tejido and library versions, date and duration, the configuration used, each input file with its size and SHA-256 fingerprint, the size of the network and the files written. With it a result can be traced back to its data and repeated. Turn it off with `output.run_record: false`.

See [`SECURITY.md`](SECURITY.md) for how the program protects your computer and your data.

## Standalone executable (no Python needed)

`tejido.exe` (Windows) and the macOS/Linux versions bundle Python and every library in one file.

- **Double-click** it to open the visual interface in your browser, plus a small window with *Open interface*, *Workspace folder*, *Activity log* and *Quit Tejido* buttons. Closing that window stops the program.
- **From a terminal**, it works like the command line: `tejido.exe run config.yaml`, `tejido.exe init examples`, `tejido.exe builders`.

**Getting the executables.** The repository includes a GitHub Actions workflow (`.github/workflows/build-tejido.yml`) that builds them on GitHub's Windows, macOS and Linux machines. You do not need Python for this.
1. Go to the **Actions** tab, choose **Build tejido executables** and click **Run workflow**. When it finishes (about 10 minutes), download `tejido-Windows` from the run's *Artifacts*: it holds `tejido-windows.exe` and the installer `tejido-X_Y_Z-instalador-windows.exe`.
2. Or publish a release: create a tag such as `tejido-v1.0.0` (*Releases → Draft a new release → Choose a tag*). The executables are attached to the release automatically.

**Building on your own computer** (needs Python only on that computer): run `build_windows.bat` on Windows or `./build_unix.sh` on macOS/Linux. The file appears in `dist/`; on Windows, if [NSIS](https://nsis.sourceforge.io) is installed, the installer is built too.

**New version checklist**: change the version in `pyproject.toml`, `tejido/__init__.py`, `installer/tejido.nsi` (`VERSION`, `OutFile`, `VIProductVersion`) and `installer/version_info.txt`, update the citation below, and add the changes to `CHANGELOG.md`. `tests/test_release.py` checks that these agree.

The executable is about 75 MB. It includes PDF, Word, Excel and SPSS readers, but not spaCy or Parquet support; for those, use the Python package.

## Quick start

```bash
tejido init my_examples                        # copies 10 example configurations and their data
tejido run my_examples/documents.yaml          # organizations in (fictional) government documents
tejido run my_examples/personal_networks.yaml  # personal networks and social capital from a survey
tejido run my_examples/trajectories.yaml       # occupational mobility
tejido run my_examples/survey_items.yaml       # network of attitudes (partial correlations)
tejido run my_examples/social_evolution.yaml   # interactions over time and by kind (layers)
tejido list                                    # builders, prepare steps, measures, groups, formats, sources
tejido ui                                      # visual interface in the browser
```

| Example | Builder | Shows |
|---|---|---|
| `documents` | text | entities, evidence, brokerage roles, core–periphery, relation types as layers (QAP) |
| `social_media` | interactions | mentions, replies, reposts; hubs and reciprocity |
| `social_evolution` | interactions | one network per quarter (`time`) and interaction kinds as layers |
| `qualitative_codes` | affiliation | code co-occurrence, homophily by theme, cliques |
| `indicators` (or `worldbank_csv`), `worldbank_api` | similarity | Indicator data (units × years) reshaped by a `prepare` step |
| `personal_networks` | ego | size, density, constraint, composition, homophily, position generator |
| `trajectories` | transitions | mobility network, transition probabilities, mobility table |
| `survey_items` | similarity | variables as nodes, partial correlations, communities of items |
| `districts` | similarity | geographic proximity, `bin` step, homophily by poverty level |

All example data are fictional or simulated.

## The configuration file

```yaml
project: my_network
input:    {type: table, path: data/file.csv}       # table | documents | api | none
prepare:  [ ... ]                                  # optional cleaning and reshaping steps
builder:  {type: ties, source: from, target: to}   # how ties are defined
nodes:    {path: data/attributes.csv, id: id}      # optional node attributes for any builder
filters:  {min_weight: 2, largest_component: true}
analysis: {centrality: [degree, betweenness, closeness], communities: louvain}
layers:   {by: relation}                           # optional: multiplex analysis
time:     {column: date, every: year}              # optional: one network per period
output:   {dir: results, language: es, formats: [csv, xlsx, html, report]}
```

Relative paths are read from the folder of the YAML file.

### 1 · read (`input`)

- `table`: CSV, TSV, Excel (`sheet`), Stata, SPSS, Parquet, JSON or JSONL. `path` can be a file, a folder, a pattern (`data/*.csv`) or a URL. Several files are stacked with a `source_file` column.
- `documents`: TXT, Markdown, HTML, PDF and Word files in a folder. `metadata: docs.csv` adds columns (date, author, type…) by `doc_id` (the file name without extension).
- `api`: online sources (`tejido list sources`). Now: `source: worldbank` with `indicators`, `countries`, `years`.
- `preset: indicators` (also `type: indicators`; `preset: worldbank` is the same) reads **indicator data**, described below.

#### Indicator data (World Bank or similar, tidy or not)

Tables of units (countries, regions, provinces…) × indicators × years are recognized in four layouts:

| layout | looks like | typical source |
|---|---|---|
| `years_wide` | unit, [indicator], 2015, 2016, … | World Bank CSV and DataBank, IMF WEO, INEI tables |
| `long` | unit, [indicator], year, value | CEPALSTAT, OECD, Eurostat, ILOSTAT |
| `indicators_wide` | unit, year, gdp, life_expectancy, … | Our World in Data, your own panel |
| `units_wide` | year, Peru, Chile, … (one indicator) | report tables |

It copes with untidy files: titles and notes above the header and footnotes below, several Excel sheets (it takes the one with data), separators `,` `;` tab or `|`, decimal commas and thousands separators (`1.234,5`, `1 234,5`, `1,234.5`), missing-value marks (`..`, `-`, `n.d.`, `:`, `n/a`), flags next to values (`12,3 a/`, `4.5 p`), years written as `2015 [YR2015]`, `YR2015`, `2020 P/` or dates, and extra columns that split a series (sex, area…) or give its units, which are added to the indicator's name. A file with a single indicator takes its name from the title above the table (`Cuadro 7.1: Producto bruto interno…`) or from the file name. Aggregates (world, regions, income groups, continents, totals, averages) are marked and excluded later.

When something is recognized wrongly, say it in `input` (column names as in the file): `layout`, `unit`, `unit_code`, `indicator`, `indicator_code`, `year`, `value`, `header_row` (1 = first row), `indicator_name`, `sheet`, `missing` (more marks of missing values). In the interface, a table that clearly holds indicator data switches to *Indicator data* by itself; choose *Any table* to read it as an ordinary table. Ordinary tables with a title above the header or notes below are also read.

### 2 · prepare

A list of steps applied in order:

```yaml
prepare:
  - filter: "year >= 2015 and region == 'Cajamarca'"
  - recode: {sex: {1: man, 2: woman}}
  - compute: {income_pc: "income / members"}
  - split: {authors: ";"}                      # several values in one cell → one row each
  - to_long: {id: [person], columns: ["q_*"]}
  - merge: {path: regions.csv, on: district}
  - bin: {column: age, bins: [0, 30, 60, 120], labels: [young, adult, older], into: age_group}
```

Other steps: `select`, `drop`, `rename`, `dropna`, `fillna`, `to_wide`, `datetime`, `deduplicate`, `sample`, `clean_text` and `worldbank` (World Bank long data → one row per country).

Expressions in `filter`, `compute` and `builder.filter` may use column names (between backticks when they have spaces: `` `tipo de relación` == 'convenio' ``), numbers, texts in quotes, comparisons, arithmetic, `and` / `or` / `not`, `in [...]`, column methods (`.isin([...])`, `.isna()`, `.notna()`, `.between(a, b)`, `.fillna(x)`, `.round()`, `.str.contains('…')`, `.str.lower()`, `.str.len()`, `.dt.year`…) and mathematical functions (`log`, `sqrt`, `abs`, `exp`…). Anything else (variables with `@`, imports, other functions) is refused, so a configuration received from someone else cannot run commands on your computer.

### 3 · build (`builder`)

**`ties`** · `format: edgelist | adjacency_list | matrix`
- `source`, `target` (or `targets` + `sep` for adjacency lists), `weight`, `directed`, `self_loops`.
- `relation`: a column with the kind of tie; ties keep `relation` and one `n_<kind>` count per kind (use it for `layers`).
- Matrices: first column = row labels; `threshold`. Undirected (`directed: false`): a symmetric matrix gives each pair once; a non-symmetric one is combined with `symmetrize: sum | max | min | mean` (default `sum`).
- Undirected lists: `both_directions: auto | once | add`. A tie listed as A→B and B→A counts once when every row has its mirror (`auto`) or always (`once`); with `add` the rows are separate records whose weights add up.

**`affiliation`** · two-mode data
- `format: long` with `group` and `member` (optionally `split`, `value`), or `format: wide` with `members: ["code_*"]`.
- `mode: members | groups | bipartite`.
- `weighting: count | jaccard | cosine | newman | association | overlap`; `min_cooccurrence`.
- `member_attributes`, `group_attributes`.

**`similarity`**
- `nodes: rows` (cases) or `columns` (variables: networks of indicators or survey items).
- `format: wide` (`entity`, `label`, `features`), `long` (`entity`, `feature`, `value`) or `worldbank`.
- `metric`: `cosine`, `correlation`, `spearman`, `partial_correlation`, `euclidean`, `jaccard`, `gower` (mixed numeric and categorical data) or `geographic` (`coordinates: [lat, lon]` → distance in km).
- `missing` (`max_feature_missing`, `max_entity_missing`, `impute`), `transform` (`log`, `scale: zscore | minmax | rank | none`).
- `absolute: true` keeps strong negative associations as ties (with `sign`).
- `sparsify`: `knn` (`k`, `mutual`), `threshold`, `top_percent`, `backbone` (`alpha`), `mst` (maximum spanning tree), `radius` (`km`) or `none`.

**`text`**
- `language: es | en` (other languages: gazetteer, terms and spaCy), `unit: sentence | paragraph | window | document`.
- `entities`: `gazetteer` (CSV with `name`, `aliases`, `type`), `patterns` (organization names), `acronyms`, `spacy` + `spacy_labels`, `terms` (key terms → semantic networks: `max_terms`, `min_length`, `bigrams`, `stopwords`), `hashtags`, `mentions`, `min_frequency`, `exclude`.
- `mode: entities | documents | bipartite`.
- `relations: default` or your own dictionary `{funding: [financ, transfer], conflict: [protest]}`; `evidence` snippets per tie.

**`interactions`**
- `source` (who acts) and `targets` (`{reply: reply_to, to: recipients, cc: copy}`), `split` for several recipients in a cell.
- `text` + `extract: [mentions, emails]`; `kinds` to keep some kinds only.
- `network: actors | hashtags | actors_hashtags`, `directed`, `time`, `node_attributes`, `min_interactions`.

**`ego`**
- `format: wide`: `ego`, `alters` (name-generator columns), `alter_attributes` (`{sex: "alter{i}_sex"}`), `weights` (`"alter{i}_closeness"`), `alter_ties` (`"tie_{i}_{j}"`).
- `format: long`: `ego`, `alter`, `alter_attributes`, `weight`, `alter_ties: {path, ego, alter_a, alter_b}`.
- `ego_attributes` (`{sex: sex}`) for homophily; `positions: {prestige: {knows_doctor: 78, …}}` for a position generator; `shared_alters: true` when alter names identify the same person across respondents.
- Result table `egos`: size, alter ties, density, components, isolates, effective size, efficiency, constraint, mean tie strength; per attribute: IQV heterogeneity, composition shares, mean/sd, same-as-ego share, E-I index; positions: extensity, upper reachability, range, mean prestige.

**`transitions`**
- `format: long` (`unit`, `order`, `state`) or `wide` (`unit`, `states: [s2019, s2020, …]`).
- `weight: count | probability | units`, `collapse_repeats`, `self_loops`, `lag`, `min_transitions`.
- Nodes: frequency, stays, entries and exits (moves from and to other states), starts and ends (trajectories that begin or end there), stay rate. Summary: mobility rate. Table: `transition_matrix`.

### 4 · filter (`filters`)

`min_weight`, `max_weight`, `keep_edges: {relation: [funding]}`, `backbone: {alpha: 0.05}` (disparity filter for any weighted network), `keep_nodes` / `drop_nodes` (`{type: [ngo]}` or a list of names), `ego: {nodes: [Ana], radius: 2}`, `min_degree`, `k_core`, `remove_isolates`, `top_nodes`, `largest_component`.

### 5 · analyze (`analysis`)

**Node measures** (`centrality: [...]` or `all`; default `[degree, betweenness, closeness, pagerank]`):

| Measure | What it captures |
|---|---|
| `degree`, `strength` | number and weight of ties (in/out when directed) |
| `betweenness`, `edge_betweenness` | lying on shortest paths: brokers and bridging ties |
| `ego_betweenness` | betweenness inside the node's own neighborhood (Everett & Borgatti): local brokerage |
| `flow_betweenness` | current-flow (random-walk) betweenness: counts all paths, not only the shortest |
| `closeness`, `harmonic`, `eccentricity` | reach and distance to the others (directed networks: from the others, plus `out_closeness` and `out_harmonic`) |
| `information` | information centrality (Stephenson & Zelen): closeness over all paths |
| `eigenvector`, `katz`, `pagerank`, `hubs` | ties to important nodes; hub and authority scores |
| `laplacian`, `subgraph` | structural importance (energy drop, closed walks) |
| `voterank` | best spreaders for diffusion |
| `coreness`, `clustering`, `neighbor_degree`, `reciprocity` | cohesion around the node |
| `constraint`, `effective_size` | Burt's structural holes (and efficiency); see also `structural_holes` below |
| `brokerage` | Gould–Fernandez roles (coordinator, itinerant, gatekeeper, representative, liaison) by `analysis.brokerage: attribute` |
| `cut_points` | nodes whose removal disconnects the network |

**Paths**: `distance` sets how path length is measured for betweenness and closeness: `auto` (inverse weight when ties have different weights, otherwise steps), `steps`, `inverse_weight` (strong ties are short), `weight` (the weight is already a distance or cost) or the name of a tie attribute such as `distance_km`. `betweenness_sample` is `auto` (exact up to 1,000 nodes), `exact` or a number of sampled nodes; `normalized: false` gives raw path counts. `group_centrality: community` (or a node attribute) adds a table with group degree, betweenness and closeness (Everett & Borgatti).

**Groups**: `communities: louvain | greedy | label_propagation | girvan_newman | attribute | none` (+ `resolution`, `community_attribute`), with a `communities` table (size, density, conductance, E-I index). `groups: [kcore, cliques, equivalence, core_periphery]` (or `all`): k-cores, maximal cliques, structural-equivalence blocks with the block image matrix (`blocks: k`) and Borgatti–Everett core–periphery.

**Whole network** (always): size, density, degree distribution (sd, Gini, table), components (weak/strong), isolates, diameter, radius, mean path length, global efficiency, clustering and transitivity, reciprocity, Freeman centralization (degree, betweenness, closeness), degree assortativity, bridges and cut points, Krackhardt connectedness and hierarchy, algebraic connectivity, modularity, dyad and triad census (directed) and rich-club coefficients.

**Structural holes** (`structural_holes: {groups: community}` or a node attribute; `broker_share`, `hole_ratio`), following Burt (1992):
- each node gets its holes (pairs of contacts who are not tied to each other), share of holes, constraint, effective size, efficiency, hierarchy, groups spanned and a role: broker, intermediate, embedded (closure), pendant or isolate;
- the `brokers` table ranks the nodes that span the most holes;
- the `structural_holes` table lists pairs of groups with fewer ties between them than expected from their ties overall, together with the nodes that connect them.

**Strong and weak ties** (`tie_strength: {by: auto}`), following Granovetter (1973):
- `by` sets what strength means: `weight`, `overlap` (shared contacts), a tie attribute (closeness, frequency of contact) or `auto`/`composite`, which averages the ranks of weight, reciprocity, overlap and multiplexity;
- ties are classified as strong and weak (`levels: 3` adds intermediate; `threshold` uses a fixed value, e.g. 3 = very close);
- the researcher can set the classification: `weak_values: [1, 2]` or `weak_values: [acquaintance, neighbor]` (values of the `by` attribute that count as weak; the rest are strong), `strong_values` (with `weak_values`, the rest are intermediate), or the limits `weak_max` (weak up to this value) and `threshold` (strong from this value; between both, intermediate). These take precedence over the quantile `cut` (default 0.5); ties without a value are left *unclassified*;
- each tie also gets its neighborhood overlap and whether it is a local bridge (with its span);
- each node gets its strong and weak ties and its violations of strong triadic closure (the "forbidden triad");
- the summary tests the weak-ties argument: the share of local bridges that are weak and the correlation of weight and overlap.

In the interactive views, weak ties are drawn dashed and local bridges can be highlighted.

**Homophily** (`attributes: [sex, sector]`): assortativity, E-I index and a `homophily` table with Coleman's index and the E-I index per group (both from the members' side: an internal tie counts once for each of its two members).

**Null models** (`null_model: {model: configuration | erdos_renyi, n: 100}`; `configuration` rewires the observed ties keeping every degree, with no multiple ties or self-loops; `swaps`: rewirings per tie, default 10): observed vs random networks, with ties taken as present or absent (clustering, transitivity, path length, modularity, reciprocity) with z-scores and p-values, and the small-world sigma.

Large networks: betweenness is sampled above 1,000 nodes, path statistics are estimated above 5,000 nodes, and the most expensive group analyses are skipped above 3,000 nodes (the log says so).

### Layers (`layers`)

`layers: {by: relation, qap: 200}` treats each value of a tie attribute (relation type, interaction kind) as a layer: statistics per layer, overlap (Jaccard) and correlation between layers with QAP permutation p-values, and per node the number of layers and degree in each.

### Time (`time`)

`time: {column: date, every: year | quarter | month | week | day | 5, cumulative: false, export_snapshots: false}` builds the same network for each period from the rows of that period. Tables: `evolution` (measures per period, tie persistence, new and lost ties and nodes) and `node_evolution` (node measures per period).

### 6 · export (`output`)

`formats`: `csv`, `xlsx` (one workbook with all tables), `graphml`, `gexf`, `json`, `pajek`, `ucinet` (DL), `matrix`, `html` and `report` (Markdown; `language: en | es`). Result tables (`egos`, `communities`, `homophily`, `layers`, `evolution`, `null_model`, `block_image`…) are always saved as CSV. HTML options: `size_by`, `color_by` (numeric measures are colored with a gradient), `max_nodes`, `offline` and `style`, the look chosen in the visual interface (for example `style: {palette: andean, shape_by: type, halos: true, curve: curved}`; the keys are listed in `tejido/ui/static/style.js`).

## Python

```python
import tejido

result = tejido.run("documents.yaml")          # all stages
result.graph, result.summary, result.tables    # networkx graph, statistics, result tables

df = tejido.read({"input": {"type": "table", "path": "ties.csv"}, "builder": {"type": "ties"}})
df = tejido.prepare(df, [{"filter": "year >= 2020"}])
G = tejido.build(df, "ties", source="from", target="to", weight="amount")
G = tejido.filter(G, largest_component=True)
G, communities, summary, tables = tejido.analyze(G, centrality="all", groups=["core_periphery"])
```

## FAQ

**Is a co-occurrence in a document a real relationship?**
Not necessarily. Two organizations mentioned in the same sentence may cooperate, compete, or simply appear in a list. That is why each tie keeps evidence snippets and relation keywords. Read the evidence, use `unit: sentence` for tighter ties, and treat the network as a map to guide close reading, not as proof.

**The text builder misses or splits organization names. What can I do?**
Add a gazetteer with the names and aliases you care about; it always takes priority. Use `exclude` for false positives and `min_frequency` to drop rare noise. For other kinds of entities (people, places), install spaCy and set `entities.spacy`.

**Can it read scanned PDFs?**
Only if they contain a text layer. Scanned images need OCR first, for example with `ocrmypdf`. Documents without extractable text are reported in the log.

**Which builder should I use for my data?**
Ask what a tie means in your data:
- a row says "A relates to B" → `ties`;
- things belong to the same group, event or unit → `affiliation`;
- cases or variables are alike, or places are close → `similarity`;
- free text → `text`;
- someone addresses someone (posts, e-mails, messages) → `interactions`;
- respondents name their contacts → `ego`;
- units move between states over time → `transitions`.

**How do I choose `k` or the threshold in similarity networks?**
There is no single right value, and results depend on it. Start with `knn` and `k` between 3 and 5 so every node has neighbors. Then check that your main conclusions hold with other values, or use `backbone`, which keeps only statistically salient ties.

**Why are aggregates excluded?**
Rows like "World", "High income", "Latin America & Caribbean", "América Latina y el Caribe" or "Total" are not countries; they would look similar to many countries and distort the network. Set `exclude_aggregates: false` to keep them.

**Is the World Bank example file real data?**
No. `worldbank_format_SIMULATED.csv` has the World Bank layout but simulated values. Use `worldbank_api.yaml` or download real files from data.worldbank.org.

**Are the example documents, posts and interviews real?**
No. They are fictional and only meant to show how the tool works.

**My network is a hairball. How do I simplify it?**
Use `filters`: `min_weight`, `min_degree`, `top_nodes` or `largest_component`. For similarity networks, lower `k` or use `backbone`. In the HTML view, `max_nodes` limits what is drawn.

**Which centrality should I report?**
- `degree` / `strength`: how many or how strong the ties are;
- `betweenness`, `constraint`, `effective_size`, `brokerage`: brokerage and structural holes;
- `pagerank` / `eigenvector` / `katz`: being tied to well-connected actors;
- `closeness` / `harmonic`: overall reach (use `harmonic` when the network is disconnected);
- `voterank`: good starting points for diffusion.

Choose the one that matches your theoretical question.

**Are the network statistics significant?**
Descriptive statistics depend on size and density. Use `null_model` to compare clustering, path length and modularity with random networks of the same size or degrees, and `layers.qap` to test whether two kinds of ties overlap more than chance.

**Can I use it with data from `inei_pipeline` or the R templates in this repository?**
Yes. Any CSV, DTA or SAV file works as a `table` input, and `prepare` steps can recode and reshape it. Network measures exported in `*_nodes.csv` can then be merged into your survey data and used in the R regression templates.

**Windows says the app is unrecognized and won't run it. Is it safe?**
The executable is not digitally signed, so SmartScreen warns about any new app. If you downloaded it from your own repository, click *More info → Run anyway*. Some antivirus programs also flag PyInstaller executables by mistake; building it yourself with `build_windows.bat` avoids that doubt. On macOS, right-click → *Open* the first time.

**The executable takes a few seconds to start. Why?**
It unpacks Python and its libraries to a temporary folder each time it starts. Analyses run at normal speed after that.

**Does the visual interface send my data anywhere?**
No. It is served from your own computer (`127.0.0.1`), opens only from the program's launch address and checks a random key on every request, so other computers, websites and users of the same computer cannot use it. The only internet connections are the downloads you request (World Bank, or a table given as a web address). Interactive pages saved from the interface include the drawing library, so they also work offline.

**Where are the files I uploaded and the results?**
In the workspace folder shown on the start page (`tejido_workspace` in your user folder). Each project's results are in `results/<project name>`. The **Files** tab and the **Open results folder** button take you there.

**How do I add a new kind of network?**
Write a function `build(data, opts, cfg)` that returns a networkx graph in a new file in `tejido/builders/`, decorate it with `@register("name", "description")`, and import it in `builders/__init__.py`. Extra results go in `G.graph["summary"]` (dict) and `G.graph["tables"]` (DataFrames). New prepare steps use `@step` in `prepare.py`, and new online sources go in `io.CONNECTORS`. To show it in the visual interface, describe its fields in `tejido/ui/schema.py`.

## Blockmodels and exponential random graph models

**Blockmodels** find positions (roles): sets of nodes tied in similar ways to the rest. Choose a method in *Analyze → Blockmodel*:

```yaml
analysis:
  blockmodel: {method: generalized, blocks: 3, equivalence: regular}   # concor | structural | generalized | sbm
```

- `concor`: CONCOR, iterated correlations of tie profiles.
- `structural`: structural equivalence by hierarchical clustering.
- `generalized`: generalized blockmodeling, a direct search for the partition whose blocks best match ideal blocks (null/complete for structural equivalence, null/regular for regular equivalence).
- `sbm`: stochastic blockmodel fitted by maximum likelihood; without `blocks`, the number is chosen by ICL.

Every node gets its `block` (color the network by it). The *Groups* tab shows the members, the block image (densities), the ideal block types with their inconsistencies, and the adjacency matrix ordered by block.

**Exponential random graph models (ERGM)** estimate which local patterns make ties more likely, all at once (*Analyze → Exponential random graph model*):

```yaml
analysis:
  ergm:
    terms: [edges, mutual, gwesp(0.5), nodematch(group), nodecov(age)]
    method: auto        # mple | mcmle | auto (MCMC maximum likelihood up to 150 nodes)
    gof: true           # degrees, shared partners and distances of simulated networks
```

Terms use the names of the R package `ergm`: `edges`, `mutual`, `triangles`, `ttriple`, `isolates`, `gwesp(decay)`, `gwdegree(decay)`, `gwidegree(decay)`, `gwodegree(decay)`, `nodematch(attr)`, `nodefactor(attr)`, `nodecov(attr)`, `absdiff(attr)`, `nodeicov(attr)`, `nodeocov(attr)`. The *Model* tab shows each coefficient with its significance and what it means, and goodness-of-fit charts.

**Validation.** The ERGM statistics and pseudo-likelihood estimates match `ergm` 4.12.0 (statnet) to six decimals on Padgett's Florentine marriages and Sampson's monks; MCMC estimates agree within simulation error. Generalized-blockmodeling inconsistencies match `blockmodeling` 1.1.8 exactly for the same partition, and the search reaches its best solution in 11 of 12 test cases. These comparisons are in `tests/test_models.py`.

**Limits.** Ties are binary (weights are ignored). MCMC estimation is meant for networks up to about 500 nodes, and blockmodels up to 1,500. Models with `triangles` are often degenerate; prefer `gwesp`.

## Known limitations

- A co-occurrence in a text is not necessarily a relationship: read the evidence of each tie (see the FAQ).
- PDF files need a text layer (scans need OCR first), and paragraph breaks may be lost when reading them; for interviews, prefer Word or TXT, or use `unit: sentence`.
- Without a gazetteer, the text builder finds organizations by their names (Ministry…, Association…, Company…); people and places need a gazetteer or spaCy.
- Very large networks: the interactive views draw the most connected nodes (up to 3,000 in the interface and 1,500 in the exported page by default); all nodes are in the saved files.
- The executables are not code-signed, and the macOS and Linux builds are new: please report any problem.

## Roadmap

Ideas for future versions: an INEI connector, entity resolution across spelling variants, relation extraction with language models, directed ties from verbs ("A funds B"), valued blockmodels, ERGM for weighted ties and OCR integration.

## Contributing and feedback

Questions, bugs and ideas are welcome as [issues](https://github.com/Edison-Caj-Sc/Computational-tools-for-social-research/issues). For a bug, include your system, the version (`tejido --version`), the message in the *Log* tab, the last lines of the activity log (`tejido logs`) and, if possible, a small example with fictional data. Pull requests should keep the tests passing (`py -m pytest tests`) and add a test for new behavior.

## How to cite

Ayala Velásquez, A. E. (2026). *Tejido* (Version 1.0.0) [Computer software]. https://github.com/Edison-Caj-Sc/Computational-tools-for-social-research

```bibtex
@software{ayala_velasquez_tejido_2026,
  author  = {Ayala Velásquez, Angel Edison},
  title   = {Tejido: turn (almost) any data into a network},
  year    = {2026},
  version = {1.0.0},
  url     = {https://github.com/Edison-Caj-Sc/Computational-tools-for-social-research}
}
```

Please also cite the methods you report (see below) and the sources of your data.

## Credits and methods

Tejido stands on the work of others. Thank you to everyone below. Where an algorithm is used, the code names its source; algorithms are implemented from the published descriptions, and the libraries are used as published.

**Libraries** (licenses and texts: `THIRD_PARTY_NOTICES.md` and `tejido/ui/static/`)
- [NetworkX](https://networkx.org) (Hagberg, Schult & Swart 2008) for graphs and many measures: betweenness, closeness, harmonic, eigenvector, Katz, PageRank, HITS and information centrality, k-cores, clustering, assortativity, rich-club coefficients, and Louvain and other community detection. Its documentation gives the original reference of each.
- pandas, NumPy, SciPy and PyYAML; pypdf, python-docx, lxml, openpyxl, xlrd and pyreadstat to read files; optionally spaCy.
- [vis-network](https://visjs.github.io/vis-network/) (vis.js community, Apache-2.0 or MIT) for drawing, bundled unmodified in `tejido/ui/static/`.
- The typefaces [Instrument Sans](https://github.com/Instrument/instrument-sans) and [Newsreader](https://github.com/productiontype/Newsreader), SIL Open Font License 1.1, bundled unmodified so the interface looks the same on every computer and works offline.
- PyInstaller, the Python and Tcl/Tk runtimes (standalone executable) and NSIS (Windows installer).

**Methods**
- Communities (Louvain): Blondel, Guillaume, Lambiotte & Lefebvre (2008), *Journal of Statistical Mechanics*, P10008.
- Disparity-filter backbone: Serrano, Boguñá & Vespignani (2009), *PNAS* 106(16), 6483–6488.
- Collaboration weighting: Newman (2001), *Physical Review E* 64, 016132.
- Structural holes, constraint, effective size and efficiency: Burt (1992), *Structural Holes*, Harvard University Press.
- Strong and weak ties, local bridges and the forbidden triad: Granovetter (1973), *American Journal of Sociology* 78(6), 1360–1380; neighborhood overlap: Onnela et al. (2007), *PNAS* 104(18), 7332–7336.
- Brokerage roles: Gould & Fernandez (1989), *Sociological Methodology* 19, 89–126.
- Core–periphery: Borgatti & Everett (1999), *Social Networks* 21(4), 375–395. Group centrality: Everett & Borgatti (1999), *Journal of Mathematical Sociology* 23(3), 181–201. Ego betweenness: Everett & Borgatti (2005), *Social Networks* 27(1), 31–38.
- Laplacian centrality: Qi, Fuller, Wu, Wu & Zhang (2012), *Information Sciences* 194, 240–253.
- Centralization: Freeman (1978), *Social Networks* 1(3), 215–239. Connectedness and hierarchy: Krackhardt (1994), in Carley & Prietula (eds.), *Computational Organization Theory*, Erlbaum, 89–111.
- Homophily: E–I index, Krackhardt & Stern (1988), *Social Psychology Quarterly* 51(2), 123–140; Coleman's index, Coleman (1958), *Human Organization* 17(4), 28–36; assortativity, Newman (2002), *Physical Review Letters* 89, 208701. Heterogeneity (IQV): Mueller & Schuessler (1961), *Statistical Reasoning in Sociology*, Houghton Mifflin.
- Small-world sigma: Humphries & Gurney (2008), *PLoS ONE* 3(4), e0002051.
- Layer correlation with QAP permutations: Hubert & Schultz (1976), *British Journal of Mathematical and Statistical Psychology* 29(2), 190–241; Krackhardt (1987), *Social Networks* 9(2), 171–186.
- Position generator: Lin & Dumin (1986), *Social Networks* 8(4), 365–385.
- Mixed-data similarity (Gower): Gower (1971), *Biometrics* 27(4), 857–871.
- CONCOR: Breiger, Boorman & Arabie (1975), *Journal of Mathematical Psychology* 12(3), 328–383.
- Generalized blockmodeling: Batagelj, Ferligoj & Doreian (1992), *Social Networks* 14(1–2), 63–90; Batagelj, Doreian & Ferligoj (1992), *Social Networks* 14(1–2), 121–135; Batagelj, Ferligoj & Doreian (1999), *Informatica* 23, 501–506 (block inconsistencies); Doreian, Batagelj & Ferligoj (2005), *Generalized Blockmodeling*, Cambridge University Press.
- Stochastic blockmodel: Holland, Laskey & Leinhardt (1983), *Social Networks* 5(2), 109–137; choice of the number of blocks by ICL: Daudin, Picard & Robin (2008), *Statistics and Computing* 18(2), 173–183.
- ERGM terms and estimation: Strauss & Ikeda (1990), *JASA* 85(409), 204–212 (pseudo-likelihood); Geyer & Thompson (1992), *JRSS B* 54(3), 657–699, and Hunter & Handcock (2006), *JCGS* 15(3), 565–583 (Monte Carlo MLE); Snijders, Pattison, Robins & Handcock (2006), *Sociological Methodology* 36, 99–153, and Hunter (2007), *Social Networks* 29(2), 216–230 (geometrically weighted terms); Morris, Handcock & Hunter (2008), *Journal of Statistical Software* 24(4) (terms and tie/no-tie sampling); Hummel, Hunter & Handcock (2012), *JCGS* 21(4), 920–939 (step length); Hunter, Goodreau & Handcock (2008), *JASA* 103(481), 248–258 (goodness of fit). Term names follow the R package ergm: Hunter, Handcock, Butts, Goodreau & Morris (2008), *Journal of Statistical Software* 24(3).
- Validation software (not included): the R packages `ergm` (statnet) and `blockmodeling` (Žiberna).
- Force-directed layout: vis-network's `forceAtlas2Based` solver, after Jacomy, Venturini, Heymann & Bastian (2014), *PLoS ONE* 9(6), e98679.

**Appearance**
- Color-blind palette: Okabe & Ito (2008), *Color Universal Design (CUD)*, https://jfly.uni-koeln.de/color/.
- Viridis scale: Smith, van der Walt & Firing (2015), the matplotlib colormap, CC0.
- Convex hulls for group areas: Andrew (1979), *Information Processing Letters* 9(5), 216–219 (monotone chain).
- The other palettes, presets, layouts (circle, rings, one circle per group), label selection and node separation were written for Tejido using standard techniques; no third-party code was copied.

**Data and formats.** World Bank data come from the World Development Indicators API; cite the World Bank when you use them. Tejido writes Pajek, UCINET and GEXF (Gephi) files and reads files from several statistical agencies; those names belong to their owners and no code from those programs is included. The bundled examples and test files use fictional or simulated data, except two classic networks used to validate the models: Padgett's Florentine marriages (Padgett & Ansell 1993, *AJS* 98(6), 1259–1319; as distributed with NetworkX) and Sampson's monastery (Sampson 1968, PhD dissertation, Cornell University; `tests/data/sampson_*.csv`, as distributed with the R package ergm).

## License

MIT (see [`LICENSE`](LICENSE)). Copyright (c) 2026 Angel Edison Ayala Velásquez, author and owner of Tejido. Third-party components keep their own licenses: [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md).
