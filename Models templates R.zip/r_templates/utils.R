# =====================================================================
#  utils.R · helper functions shared by all templates
#  You do not need to edit this file.
# =====================================================================

PACKAGES <- c("survey", "MASS", "nnet", "sandwich", "lmtest", "car",
              "ggplot2", "broom", "marginaleffects", "haven", "readxl")

install_if_missing <- function(packages = PACKAGES) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) {
    message("Installing missing packages: ", paste(missing, collapse = ", "))
    install.packages(missing, repos = "https://cloud.r-project.org")
  }
  invisible(suppressPackageStartupMessages(lapply(packages, library, character.only = TRUE)))
}

header <- function(text) {
  cat("\n", strrep("=", 70), "\n ", text, "\n", strrep("=", 70), "\n", sep = "")
}

# ---------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------

load_data <- function(file = NULL) {
  if (is.null(file)) {
    message("Using simulated example data (set 'file' to use your own data).")
    return(example_data())
  }
  if (!file.exists(file)) stop("File not found: ", file)
  ext <- tolower(tools::file_ext(file))
  d <- switch(ext,
    csv  = utils::read.csv(file, encoding = "UTF-8", fileEncoding = "UTF-8-BOM", stringsAsFactors = FALSE),
    dta  = haven::zap_labels(haven::read_dta(file)),
    sav  = haven::zap_labels(haven::read_sav(file)),
    xlsx = , xls = as.data.frame(readxl::read_excel(file)),
    rds  = readRDS(file),
    stop("Unsupported format: .", ext, " (use csv, dta, sav, xlsx or rds)")
  )
  as.data.frame(d)
}

#' Simulated data with the structure of a household survey (not real data).
example_data <- function(n = 3000, seed = 2026) {
  set.seed(seed)
  k <- n / 20
  psu     <- rep(seq_len(k), each = 20)
  stratum <- rep(sample(1:8, k, TRUE, prob = c(.2, .15, .1, .1, .15, .1, .1, .1)), each = 20)
  area    <- ifelse(stratum <= 5, "urban", "rural")
  rural   <- as.integer(area == "rural")
  u       <- rep(rnorm(k, 0, .25), each = 20)                       # cluster effect
  head_sex <- sample(c("male", "female"), n, TRUE, prob = c(.72, .28))
  female  <- as.integer(head_sex == "female")
  head_age  <- round(pmin(pmax(rnorm(n, 48, 14), 18), 95))
  head_educ <- round(pmin(pmax(rnorm(n, 11 - 4 * rural, 3.5), 0), 18))
  hh_size <- pmax(1, rpois(n, 3.3 + .6 * rural))
  log_income <- 5.7 + .08 * head_educ + .012 * head_age - .15 * female - .35 * rural + u + rnorm(n, 0, .6)
  income  <- round(exp(log_income), 1)
  mu_org  <- exp(-.6 + .05 * head_educ + .3 * rural + .1 * hh_size + u)
  n_organizations <- rnbinom(n, size = 1.2, mu = mu_org)
  mu_food <- plogis(.8 - .5 * (log_income - 6.5) + .3 * rural)
  food_share <- round(rbeta(n, mu_food * 20, (1 - mu_food) * 20), 3)
  latent_trust <- .05 * head_educ + .4 * (n_organizations > 0) - .3 * rural + rlogis(n)
  trust <- cut(latent_trust, c(-Inf, -.3, .8, 2, Inf), labels = c("none", "little", "some", "a_lot"))
  util <- cbind(formal_employee = -2.5 + .25 * head_educ - 1.2 * rural,
                informal_employee = 0,
                self_employed = -1 + .02 * head_age - .4 * female + .3 * rural)
  pr <- exp(util) / rowSums(exp(util))
  occupation <- colnames(util)[apply(pr, 1, function(p) sample(3, 1, prob = p))]
  d <- data.frame(psu, stratum, weight = round(runif(n, 60, 140) * (1 + .5 * rural), 1),
                  area, head_sex, head_age, head_educ, hh_size, income, log_income = round(log_income, 4),
                  poor = as.integer(income < 450), n_organizations,
                  org_member = as.integer(n_organizations > 0), food_share,
                  trust = as.character(trust), occupation, stringsAsFactors = FALSE)
  d$log_income[sample(n, 60)] <- NA      # some missing values, as in real data
  d
}

#' Keeps complete cases, converts factors and sets reference categories.
prepare_data <- function(data, variables, factors = list(), ordered = list(), extra = character()) {
  variables <- unique(c(variables, extra))
  missing <- setdiff(variables, names(data))
  if (length(missing)) stop("These variables are not in the data: ", paste(missing, collapse = ", "))
  d <- data[, variables, drop = FALSE]
  n0 <- nrow(d)
  d <- d[stats::complete.cases(d), , drop = FALSE]
  if (n0 - nrow(d) > 0)
    message(sprintf("Dropping %d of %d cases (%.1f %%) because of missing values.",
                    n0 - nrow(d), n0, 100 * (n0 - nrow(d)) / n0))
  for (v in names(factors)) {
    if (!v %in% names(d)) next
    d[[v]] <- factor(d[[v]])
    ref <- factors[[v]]
    if (!is.null(ref) && !is.na(ref)) {
      if (!ref %in% levels(d[[v]]))
        stop(sprintf("Reference '%s' is not a category of '%s'. Categories: %s",
                     ref, v, paste(levels(d[[v]]), collapse = ", ")))
      d[[v]] <- stats::relevel(d[[v]], ref = as.character(ref))
    }
  }
  for (v in names(ordered)) d[[v]] <- factor(d[[v]], levels = ordered[[v]], ordered = TRUE)
  if (any(vapply(names(ordered), function(v) anyNA(d[[v]]), logical(1))))
    stop("Some values are not listed in 'order'. Check the categories.")
  d
}

build_formula <- function(outcome, predictors, extra = NULL, manual = NULL) {
  f <- if (!is.null(manual)) stats::as.formula(manual) else
    stats::reformulate(c(predictors, extra), response = outcome)
  environment(f) <- parent.frame()          # script variables are visible from the formula
  f
}

formula_vars <- function(formula) all.vars(formula)

# ---------------------------------------------------------------------
# Survey design
# ---------------------------------------------------------------------

create_design <- function(data, d) {
  options(survey.lonely.psu = "adjust")
  survey::svydesign(ids = stats::as.formula(paste0("~", d$psu)),
                    strata = stats::as.formula(paste0("~", d$stratum)),
                    weights = stats::as.formula(paste0("~", d$weight)),
                    data = data, nest = TRUE)
}

design_vars <- function(use, d) if (isTRUE(use)) unlist(d[c("stratum", "psu", "weight")]) else character()

design_weights <- function(design) if (is.null(design)) NULL else as.numeric(stats::weights(design))

# ---------------------------------------------------------------------
# Tables and tests
# ---------------------------------------------------------------------

stars <- function(p) ifelse(p < .001, "***", ifelse(p < .01, "**", ifelse(p < .05, "*", ifelse(p < .1, ".", ""))))

#' Coefficient table. With 'exponentiate' it adds OR, IRR or multiplicative effects.
coef_table <- function(model, exponentiate = FALSE, vcov = NULL, level = .95) {
  if (!is.null(vcov)) {
    ct <- lmtest::coeftest(model, vcov. = vcov)
    ci <- lmtest::coefci(model, vcov. = vcov, level = level)
    tab <- data.frame(term = rownames(ct), estimate = ct[, 1], se = ct[, 2],
                      statistic = ct[, 3], p = ct[, 4], ci_low = ci[, 1], ci_high = ci[, 2])
  } else {
    t <- broom::tidy(model, conf.int = TRUE, conf.level = level)
    tab <- data.frame(term = t$term, estimate = t$estimate, se = t$std.error,
                      statistic = t$statistic, p = t$p.value, ci_low = t$conf.low, ci_high = t$conf.high)
  }
  if (exponentiate) {
    tab$exp_estimate <- exp(tab$estimate)
    tab$exp_ci_low <- exp(tab$ci_low)
    tab$exp_ci_high <- exp(tab$ci_high)
    tab$pct_change <- 100 * (tab$exp_estimate - 1)
  }
  tab$signif <- stars(tab$p)
  rownames(tab) <- NULL
  tab
}

#' Average marginal effects (AME), weighted when a survey design is used.
marginal_effects <- function(model, data, design = NULL, weights = NULL, ...) {
  args <- list(model, newdata = data, ...)
  w <- if (!is.null(weights)) weights else design_weights(design)
  if (!is.null(w)) args$wts <- w
  am <- suppressWarnings(do.call(marginaleffects::avg_slopes, args))
  out <- as.data.frame(am)
  keep <- intersect(c("group", "term", "contrast", "estimate", "std.error", "p.value", "conf.low", "conf.high"),
                    names(out))
  out <- out[, keep]
  names(out) <- c(group = "category", term = "term", contrast = "contrast", estimate = "effect",
                  std.error = "se", p.value = "p", conf.low = "ci_low", conf.high = "ci_high")[keep]
  out$signif <- stars(out$p)
  out
}

#' Joint Wald test of all terms (survey models).
global_test <- function(model) {
  terms <- attr(stats::terms(model), "term.labels")
  survey::regTermTest(model, stats::reformulate(terms), method = "Wald")
}

#' R² weighted by the design weights.
weighted_r2 <- function(model, design) {
  w <- stats::weights(design); y <- stats::model.response(stats::model.frame(model))
  1 - sum(w * (y - stats::fitted(model))^2) / sum(w * (y - stats::weighted.mean(y, w))^2)
}

#' Cluster-robust covariance for nnet::multinom (not supported by sandwich).
vcov_cluster_multinom <- function(model, data, formula, cluster, weights = NULL) {
  X <- stats::model.matrix(formula, data = data)
  P <- stats::fitted(model)
  Y <- stats::model.matrix(~ y - 1, data.frame(y = data[[all.vars(formula)[1]]]))
  w <- if (is.null(weights)) rep(1, nrow(X)) else weights
  S <- do.call(cbind, lapply(2:ncol(P), function(j) (Y[, j] - P[, j]) * w * X))
  U <- rowsum(S, cluster)
  G <- nrow(U)
  B <- stats::vcov(model)
  V <- B %*% (crossprod(U) * G / (G - 1)) %*% B
  dimnames(V) <- dimnames(B)
  V
}

compare_models <- function(...) {
  ms <- list(...)
  data.frame(model = names(ms),
             n = vapply(ms, stats::nobs, numeric(1)),
             logLik = vapply(ms, function(m) as.numeric(stats::logLik(m)), numeric(1)),
             AIC = vapply(ms, stats::AIC, numeric(1)),
             BIC = vapply(ms, stats::BIC, numeric(1)), row.names = NULL)
}

round_df <- function(df, digits = 4) {
  df[] <- lapply(df, function(x) if (is.numeric(x)) round(x, digits) else x)
  df
}

# ---------------------------------------------------------------------
# Outputs
# ---------------------------------------------------------------------

prepare_output <- function(folder) {
  dir.create(folder, recursive = TRUE, showWarnings = FALSE)
  folder
}

save_table <- function(table, name, folder) {
  path <- file.path(folder, paste0(name, ".csv"))
  con <- file(path, open = "w", encoding = "UTF-8")
  on.exit(close(con))
  cat("\ufeff", file = con)                       # BOM so Excel reads accents correctly
  utils::write.csv(round_df(table), con, row.names = FALSE)
  message("Saved: ", path)
  invisible(path)
}

save_plot <- function(plot, name, folder, width = 7, height = 5) {
  path <- file.path(folder, paste0(name, ".png"))
  ggplot2::ggsave(path, plot, width = width, height = height, dpi = 300)
  message("Saved: ", path)
  invisible(path)
}

save_text <- function(expr, name, folder) {
  path <- file.path(folder, paste0(name, ".txt"))
  utils::capture.output(expr, file = path)
  message("Saved: ", path)
  invisible(path)
}

#' Conditional predictions: other variables are held at their mean or mode,
#' so no weights are needed.
prediction_plot <- function(model, data, focus, design = NULL, title = NULL, ...) {
  p <- suppressWarnings(marginaleffects::plot_predictions(model, condition = focus, newdata = data, ...))
  p + ggplot2::labs(title = title, x = focus[1], y = "Predicted value") + ggplot2::theme_minimal(base_size = 12)
}
