"""Layers (multiplex networks): each kind of tie (relation type, interaction kind…) as a layer.

layers: {by: relation, qap: 200}
→ per-layer statistics, overlap (Jaccard) and correlation between layers with QAP permutation p-values,
and node attributes 'layers' (number of layers where a node has ties) and degree per layer."""
from __future__ import annotations

import itertools

import networkx as nx
import numpy as np
import pandas as pd

from .utils import ConfigError, log, slug, split_values


def layer_edges(G: nx.Graph, by: str) -> dict:
    layers = {}
    for u, v, d in G.edges(data=True):
        if u == v:
            continue
        for val in split_values(d.get(by)):
            layers.setdefault(val, set()).add((u, v) if G.is_directed() else tuple(sorted((u, v), key=str)))
    return layers


def analyze_layers(G: nx.Graph, spec: dict, seed: int = 2026) -> dict:
    by = spec.get("by", "relation")
    L = layer_edges(G, by)
    if len(L) < 2:
        raise ConfigError(f"layers: ties need an attribute {by!r} with 2+ values (found {len(L)})")
    if len(L) > 20:
        keep = sorted(L, key=lambda k: -len(L[k]))[:20]
        log.warning(f"layers: {len(L)} values of {by!r}; using the 20 largest")
        L = {k: L[k] for k in keep}
    n = G.number_of_nodes()
    directed = G.is_directed()
    dyads = n * (n - 1) if directed else n * (n - 1) / 2
    rows = []
    for name, E in L.items():
        H = nx.DiGraph(list(E)) if directed else nx.Graph(list(E))
        U = H.to_undirected() if directed else H
        rows.append({"layer": name, "ties": len(E), "nodes": H.number_of_nodes(),
                     "density": round(len(E) / dyads, 5) if dyads else 0,
                     "components": nx.number_connected_components(U),
                     "transitivity": round(nx.transitivity(nx.Graph(U)), 4),
                     **({"reciprocity": round(nx.reciprocity(H), 4)} if directed else {})})
    reps = int(spec.get("qap", 200))
    rng = np.random.default_rng(seed)
    nodes = list(G)
    pairs = []
    for a, b in itertools.combinations(L, 2):
        Ea, Eb = L[a], L[b]
        inter = len(Ea & Eb)

        def corr(k, na=len(Ea), nb=len(Eb)):
            num = dyads * k - na * nb
            den = np.sqrt(na * (dyads - na) * nb * (dyads - nb))
            return num / den if den > 0 else 0.0
        r = corr(inter)
        p = None
        if reps:                                       # QAP: permute node labels of one layer
            ge = 0
            for _ in range(reps):
                perm = {nodes[i]: nodes[j] for i, j in enumerate(rng.permutation(len(nodes)))}
                Eb_p = {(perm[u], perm[v]) if directed else tuple(sorted((perm[u], perm[v]), key=str)) for u, v in Eb}
                ge += corr(len(Ea & Eb_p)) >= r
            p = round((ge + 1) / (reps + 1), 4)
        pairs.append({"layer_a": a, "layer_b": b, "shared_ties": inter,
                      "jaccard": round(inter / len(Ea | Eb), 4) if Ea | Eb else 0,
                      "correlation": round(r, 4), "qap_p_value": p})
    deg = {x: {} for x in G}
    for name, E in L.items():
        for u, v in E:
            for x in (u, v):
                deg[x][name] = deg[x].get(name, 0) + 1
    for x, d in deg.items():
        G.nodes[x]["layers"] = len(d)
        if len(L) <= 10:
            for name in L:
                G.nodes[x][f"degree_{slug(name, 25)}"] = d.get(name, 0)
    log.info(f"layers: {len(L)} layers by {by!r}" + (f", QAP with {reps} permutations" if reps else ""))
    return {"layers": pd.DataFrame(rows), "layer_overlap": pd.DataFrame(pairs)}
