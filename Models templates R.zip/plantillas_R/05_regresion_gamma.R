# =====================================================================
#  05 · REGRESIÓN GAMMA (enlace logarítmico)
#  Para: variables continuas positivas y asimétricas (ingreso, gasto, tiempo, montos).
#  Ventaja frente a MCO con log(Y): modela la media de Y en su escala original y
#  acepta varianzas que crecen con la media.
#  Interpretación: exp(b) es un efecto multiplicativo. exp(b) = 1,08 → Y es 8 % mayor.
# =====================================================================

# ---------------------------------------------------------------------
# 0. CONFIGURACIÓN · edita solo esta sección
# ---------------------------------------------------------------------
archivo        <- NULL
dependiente    <- "ingreso"               # estrictamente mayor que 0
predictores    <- c("educ_jefe", "edad_jefe", "sexo_jefe", "area", "mieperho")
factores       <- list(sexo_jefe = "hombre", area = "urbano")
terminos_extra <- NULL
formula_manual <- NULL
enlace         <- "log"                   # "log" (recomendado), "identity" o "inverse"
variable_foco  <- "educ_jefe"
usar_diseno    <- FALSE
diseno         <- list(estrato = "estrato", conglomerado = "conglome", peso = "factor07")
carpeta_salida <- "resultados/05_regresion_gamma"

# ---------------------------------------------------------------------
# 1. Preparación
# ---------------------------------------------------------------------
source("utilidades.R"); instalar_si_falta()
salida  <- preparar_salida(carpeta_salida)
formula <- construir_formula(dependiente, predictores, terminos_extra, formula_manual)
datos   <- preparar_datos(cargar_datos(archivo), variables_formula(formula), factores,
                          extra = vars_diseno(usar_diseno, diseno))
y <- all.vars(formula)[1]
if (any(datos[[y]] <= 0)) {
  n0 <- sum(datos[[y]] <= 0)
  stop(sprintf("Gamma exige Y > 0 y hay %d valores <= 0. Exclúyelos o usa otro modelo (p. ej. Tweedie o hurdle).", n0))
}
dis <- if (usar_diseno) crear_diseno(datos, diseno) else NULL

encabezado("Descriptivos")
desc <- data.frame(media = mean(datos[[y]]), mediana = median(datos[[y]]), de = sd(datos[[y]]),
                   asimetria = mean((datos[[y]] - mean(datos[[y]]))^3) / sd(datos[[y]])^3)
print(redondear(desc, 2)); guardar_tabla(desc, "1_descriptivos", salida)
g <- ggplot(datos, aes(.data[[y]])) + geom_histogram(bins = 50, fill = "steelblue", colour = "white") +
  theme_minimal() + labs(title = paste("Distribución de", y))
guardar_grafico(g, "1_distribucion_dependiente", salida)

# ---------------------------------------------------------------------
# 2. Estimación
# ---------------------------------------------------------------------
encabezado("Modelo")
fam <- Gamma(link = enlace)
modelo <- if (usar_diseno) svyglm(formula, design = dis, family = fam) else
  glm(formula, data = datos, family = fam, control = glm.control(maxit = 100))
print(summary(modelo))
coefs <- tabla_coeficientes(modelo, exponenciar = enlace == "log")
print(redondear(coefs, 3)); guardar_tabla(coefs, "2_coeficientes", salida)

# ---------------------------------------------------------------------
# 3. Ajuste y diagnósticos
# ---------------------------------------------------------------------
encabezado("Ajuste")
disp <- summary(modelo)$dispersion
ajuste <- data.frame(n = nrow(datos), dispersion = disp, cv_implicito = sqrt(disp),
                     correlacion_obs_pred2 = cor(datos[[y]], fitted(modelo))^2)
if (!usar_diseno) { ajuste$AIC <- AIC(modelo); ajuste$BIC <- BIC(modelo) }
print(redondear(ajuste, 3)); guardar_tabla(ajuste, "3_ajuste", salida)
diag <- data.frame(ajustado = fitted(modelo), residuo = residuals(modelo, type = "deviance"))
g <- ggplot(diag, aes(log(ajustado), residuo)) + geom_point(alpha = .3) +
  geom_smooth(se = FALSE, colour = "red", method = "loess", formula = y ~ x) + theme_minimal() +
  labs(title = "Residuos de devianza vs. valores ajustados",
       subtitle = "Una curva plana alrededor de 0 indica buena especificación", x = "log(valor ajustado)")
guardar_grafico(g, "3_residuos", salida)

# ---------------------------------------------------------------------
# 4. Interpretación
# ---------------------------------------------------------------------
encabezado("Efectos marginales promedio (en unidades de Y)")
ame <- efectos_marginales(modelo, datos, dis)
print(redondear(ame, 3)); guardar_tabla(ame, "4_efectos_marginales", salida)
guardar_grafico(grafico_predicciones(modelo, datos, variable_foco, dis, paste("Valor esperado de", y)),
                "4_predicciones", salida)
guardar_texto(summary(modelo), "resumen_modelo", salida)
encabezado(paste("Listo. Resultados en", salida))
