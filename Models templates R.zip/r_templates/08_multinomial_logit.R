# =====================================================================
#  08 · MULTINOMIAL LOGIT
#  For: outcomes with 3+ unordered categories: employment type, party voted for,
#  religion, mode of transport.
#  Interpretation: relative risk ratio (RRR) of each category versus the reference.
#  To communicate, use marginal effects by category.
#  Assumption: independence of irrelevant alternatives (IIA).
# =====================================================================

# ---------------------------------------------------------------------
# 0. SETTINGS · edit this section only
# ---------------------------------------------------------------------
file              <- NULL
outcome           <- "occupation"
outcome_reference <- "informal_employee"  # comparison category of the outcome
predictors        <- c("head_educ", "head_age", "head_sex", "area")
factors           <- list(head_sex = "male", area = "urban")
extra_terms       <- NULL
manual_formula    <- NULL
focus_variable    <- "head_educ"
use_design        <- FALSE                # see the note in section 2
design            <- list(stratum = "stratum", psu = "psu", weight = "weight")
output_dir        <- "results/08_multinomial_logit"

# ---------------------------------------------------------------------
# 1. Preparation
# ---------------------------------------------------------------------
source("utils.R"); install_if_missing()
out     <- prepare_output(output_dir)
formula <- build_formula(outcome, predictors, extra_terms, manual_formula)
y <- all.vars(formula)[1]
data    <- prepare_data(load_data(file), formula_vars(formula),
                        c(factors, setNames(list(outcome_reference), y)), extra = design_vars(use_design, design))
if (nlevels(data[[y]]) < 3) stop("The outcome has fewer than 3 categories: use 02_logistic_regression.R")

header("Outcome distribution")
print(round(prop.table(table(data[[y]])), 3))

# ---------------------------------------------------------------------
# 2. Estimation
#    With 'use_design = TRUE' the template uses normalized weights and cluster-robust
#    standard errors (an approximation). For full design-based inference see svyVGAM.
# ---------------------------------------------------------------------
header("Model")
if (use_design) {
  data$.w <- data[[design$weight]] / mean(data[[design$weight]])
  model <- nnet::multinom(formula, data = data, weights = .w, trace = FALSE, Hess = TRUE)
  vc <- vcov_cluster_multinom(model, data, formula, data[[design$psu]], data$.w)
  message("Design approximation: normalized weights + cluster-robust standard errors.")
} else {
  model <- nnet::multinom(formula, data = data, trace = FALSE, Hess = TRUE)
  vc <- vcov(model)
}
b  <- coef(model)
se <- matrix(sqrt(diag(vc)), nrow = nrow(b), byrow = TRUE, dimnames = dimnames(b))
tab <- do.call(rbind, lapply(rownames(b), function(k) {
  z <- b[k, ] / se[k, ]
  data.frame(category = k, term = colnames(b), estimate = b[k, ], se = se[k, ], z = z,
             p = 2 * pnorm(-abs(z)), rrr = exp(b[k, ]),
             rrr_ci_low = exp(b[k, ] - qnorm(.975) * se[k, ]),
             rrr_ci_high = exp(b[k, ] + qnorm(.975) * se[k, ]))
}))
tab$signif <- stars(tab$p); rownames(tab) <- NULL
cat("Each row compares the listed category with the reference:", outcome_reference, "\n")
print(round_df(tab, 3)); save_table(tab, "2_coefficients", out)

# ---------------------------------------------------------------------
# 3. Fit
# ---------------------------------------------------------------------
header("Fit")
null <- nnet::multinom(update(formula, . ~ 1), data = data, trace = FALSE,
                       weights = if (use_design) .w else NULL)
lr <- 2 * as.numeric(logLik(model) - logLik(null))
fit <- data.frame(n = nrow(data), AIC = AIC(model), BIC = BIC(model),
                  pseudo_r2_mcfadden = 1 - as.numeric(logLik(model) / logLik(null)),
                  lr_chi2 = lr, lr_p = pchisq(lr, df = length(b) - nrow(b), lower.tail = FALSE))
fit$accuracy <- mean(predict(model) == data[[y]])
fit$accuracy_baseline <- max(prop.table(table(data[[y]])))
print(round_df(fit, 3)); save_table(fit, "3_fit", out)
cat("IIA: if adding or removing a category would change the other choices, the assumption is doubtful;\n",
    "then consider nested logit or multinomial probit.\n")

# ---------------------------------------------------------------------
# 4. Interpretation: marginal effects on the probability of each category
# ---------------------------------------------------------------------
header("Average marginal effects by category")
ame <- marginal_effects(model, data, NULL, weights = if (use_design) data$.w else NULL, type = "probs")
ame$effect_pp <- 100 * ame$effect
print(round_df(ame, 4)); save_table(ame, "4_marginal_effects", out)
g <- prediction_plot(model, data, c(focus_variable, "group"), NULL, paste("Probability of each category of", y),
                     type = "probs") + labs(y = "Probability", colour = y, fill = y)
save_plot(g, "4_predictions", out)
save_text(summary(model), "model_summary", out)
header(paste("Done. Results in", out))
