"""tejido: turn (almost) any data into a network.

Stages: read → prepare → build → filter → analyze → export. Use run(config) for all of them.

Copyright (c) 2026 Angel Edison Ayala Velásquez. MIT License (see LICENSE)."""
__version__ = "1.0.0"
__author__ = "Angel Edison Ayala Velásquez"
__copyright__ = "Copyright (c) 2026 Angel Edison Ayala Velásquez"
__license__ = "MIT"
__url__ = "https://github.com/Edison-Caj-Sc/Computational-tools-for-social-research"

from .pipeline import Result, analyze, build, filter, prepare, read, run  # noqa: E402,F401,A004

__all__ = ["read", "prepare", "build", "filter", "analyze", "run", "Result", "__version__", "__author__"]
