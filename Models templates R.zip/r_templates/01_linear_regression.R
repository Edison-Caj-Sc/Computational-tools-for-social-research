# =====================================================================
#  01 · LINEAR REGRESSION (OLS)
#  For: continuous outcomes (log income, scores, indices).
#  Interpretation: change in Y for a one-unit change in X, holding the rest constant.
#  If Y is in logs: 100 × (exp(b) − 1) = percentage change in Y.
# =====================================================================

# ---------------------------------------------------------------------
# 0. SETTINGS · edit this section only
# ---------------------------------------------------------------------
file           <- NULL                    # NULL = example data; or "data/my_data.csv" (.csv .dta .sav .xlsx .rds)
outcome        <- "log_income"
predictors     <- c("head_educ", "head_age", "head_sex", "area", "hh_size")
factors        <- list(head_sex = "male", area = "urban")   # variable = reference category
extra_terms    <- NULL                    # e.g. c("I(head_age^2)", "head_educ:head_sex")
manual_formula <- NULL                    # e.g. "log_income ~ head_educ * area" (overrides the above)
focus_variable <- "head_educ"             # for the predictions plot
use_design     <- FALSE                   # TRUE = survey-design estimation (DHS, LSMS, ENAHO…)
design         <- list(stratum = "stratum", psu = "psu", weight = "weight")
robust_se      <- "HC3"                   # without design: "HC0".."HC3", "cluster" or NULL (classical)
output_dir     <- "results/01_linear_regression"

# ---------------------------------------------------------------------
# 1. Preparation
# ---------------------------------------------------------------------
source("utils.R"); install_if_missing()
out     <- prepare_output(output_dir)
formula <- build_formula(outcome, predictors, extra_terms, manual_formula)
data    <- prepare_data(load_data(file), formula_vars(formula), factors,
                        extra = c(design_vars(use_design, design),
                                  if (identical(robust_se, "cluster")) design$psu))
dsg     <- if (use_design) create_design(data, design) else NULL
y       <- all.vars(formula)[1]

header("Outcome descriptives")
print(summary(data[[y]]))
g <- ggplot(data, aes(.data[[y]])) + geom_histogram(bins = 40, fill = "steelblue", colour = "white") +
  theme_minimal() + labs(title = paste("Distribution of", y))
save_plot(g, "1_outcome_distribution", out)

# ---------------------------------------------------------------------
# 2. Estimation
# ---------------------------------------------------------------------
header("Model")
if (use_design) {
  model <- svyglm(formula, design = dsg, family = gaussian())
  vc <- NULL                               # the design already gives correct standard errors
} else {
  model <- lm(formula, data = data)
  vc <- if (is.null(robust_se)) NULL else if (robust_se == "cluster")
    sandwich::vcovCL(model, cluster = data[[design$psu]]) else
    sandwich::vcovHC(model, type = robust_se)
}
print(summary(model))
coefs <- coef_table(model, vcov = vc)
coefs$pct_change_if_log_y <- 100 * (exp(coefs$estimate) - 1)   # only meaningful if Y is in logs
print(round_df(coefs, 3))
save_table(coefs, "2_coefficients", out)

# ---------------------------------------------------------------------
# 3. Fit and assumptions
# ---------------------------------------------------------------------
header("Fit and diagnostics")
if (use_design) {
  fit <- data.frame(n = nrow(data), weighted_r2 = weighted_r2(model, dsg))
  print(round_df(fit, 3)); save_table(fit, "3_fit", out)
  print(global_test(model))
} else {
  s <- summary(model)
  fit <- data.frame(n = nobs(model), r2 = s$r.squared, adj_r2 = s$adj.r.squared,
                    AIC = AIC(model), BIC = BIC(model))
  print(round_df(fit, 3)); save_table(fit, "3_fit", out)

  bp <- lmtest::bptest(model); reset <- lmtest::resettest(model)
  tests <- data.frame(test = c("Breusch-Pagan (heteroskedasticity)", "RESET (functional form)"),
                      statistic = c(bp$statistic, reset$statistic), p = c(bp$p.value, reset$p.value))
  tests$reading <- ifelse(tests$p < .05, "Problem detected (p < 0.05)", "No evidence of a problem")
  print(round_df(tests, 4)); save_table(tests, "3_tests", out)

  if (length(attr(terms(model), "term.labels")) > 1) {
    v <- car::vif(model)
    v <- if (is.matrix(v)) data.frame(term = rownames(v), vif = v[, ncol(v)]^2) else
      data.frame(term = names(v), vif = v)
    v$reading <- ifelse(v$vif > 5, "High collinearity (> 5)", "Acceptable")
    print(round_df(v, 2)); save_table(v, "3_vif", out)
  }
  png(file.path(out, "3_diagnostic_plots.png"), width = 2400, height = 2400, res = 300)
  par(mfrow = c(2, 2)); plot(model); dev.off()
  cook <- cooks.distance(model)
  cat("Influential observations (Cook > 4/n):", sum(cook > 4 / nobs(model)), "\n")
}

# ---------------------------------------------------------------------
# 4. Interpretation: marginal effects and predictions
# ---------------------------------------------------------------------
header("Average marginal effects")
ame <- marginal_effects(model, data, dsg, vcov = if (is.null(vc)) TRUE else vc)
print(round_df(ame, 4)); save_table(ame, "4_marginal_effects", out)
save_plot(prediction_plot(model, data, focus_variable, dsg, paste("Predicted", y)), "4_predictions", out)
save_text(summary(model), "model_summary", out)
header(paste("Done. Results in", out))
