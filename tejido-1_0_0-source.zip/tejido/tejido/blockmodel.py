"""Blockmodels: positions (roles) of nodes that are tied in similar ways.

  analysis:
    blockmodel: {method: concor | structural | generalized | sbm, blocks: 4, equivalence: structural | regular, restarts: 20}

Methods
- concor: CONCOR, repeated correlation of tie profiles until they split in two, again and again
  (Breiger, Boorman & Arabie 1975).
- structural: structural equivalence, hierarchical clustering (average linkage) of the correlations between tie profiles
  (Wasserman & Faust 1994, ch. 9).
- generalized: generalized blockmodeling, the partition is searched directly so that blocks look like ideal blocks:
  null or complete for structural equivalence, null or regular for regular equivalence (Batagelj, Ferligoj & Doreian 1992;
  Batagelj, Doreian & Ferligoj 1992; Doreian, Batagelj & Ferligoj 2005). Block inconsistencies as in Batagelj, Ferligoj &
  Doreian (1999): null = ties present, complete = ties missing, regular = |R|(|S| - covered columns) + |S|(|R| - covered rows).
  Search: relocation of single nodes with random restarts.
- sbm: stochastic blockmodel, tie probabilities depend only on the blocks of the two nodes (Holland, Laskey & Leinhardt 1983),
  fitted by maximum likelihood with the same relocation search; without a number of blocks, it is chosen by the integrated
  classification likelihood, ICL (Daudin, Picard & Robin 2008).

Ties are taken as present or absent (weights are ignored). Every method writes the node attribute `block` and the tables
`blocks` (members), `block_image` (density of ties within and between blocks) and, for generalized blockmodeling,
`block_types` (ideal block of each cell and its inconsistencies). The summary reports `blockmodel_r2`, the squared
correlation between the ties and the densities of their blocks, comparable across methods.
"""
from __future__ import annotations

import math

import networkx as nx
import numpy as np
import pandas as pd

from .utils import ConfigError, log

METHODS = {"concor": "CONCOR: repeated correlations of tie profiles (structural equivalence)",
           "structural": "Structural equivalence by hierarchical clustering of tie profiles",
           "generalized": "Generalized blockmodeling: partition that best fits ideal blocks",
           "sbm": "Stochastic blockmodel: tie probabilities between blocks, fitted by maximum likelihood"}
LIMIT = 1500          # nodes; the search is quadratic in the number of nodes


def _adjacency(G: nx.Graph):
    nodes = list(G)
    A = (nx.to_numpy_array(G, nodelist=nodes, weight=None) > 0).astype(float)
    np.fill_diagonal(A, 0)
    return nodes, A


def _onehot(labels, k):
    H = np.zeros((len(labels), k))
    H[np.arange(len(labels)), labels] = 1
    return H


def _counts(A, labels, k):
    """Ties T[r, s] from block r to block s, block sizes and ordered pairs of distinct nodes N[r, s]."""
    H = _onehot(labels, k)
    s = H.sum(0)
    return H.T @ A @ H, s, np.outer(s, s) - np.diag(s)


# ---------------------------------------------------------------- objectives (smaller is better)
def _structural_errors(T, s):
    N = np.outer(s, s) - np.diag(s)
    return float(np.minimum(T, N - T).sum())


def _regular_errors(A, labels, k, out=None, inn=None):
    """Inconsistency with null or regular blocks (Batagelj, Ferligoj & Doreian 1999)."""
    H = _onehot(labels, k)
    out = A @ H if out is None else out            # ties from each node to each block
    inn = A.T @ H if inn is None else inn          # ties to each node from each block
    s = H.sum(0)
    T = H.T @ out
    rows = H.T @ (out > 0)                         # rows[r, t]: nodes of r with a tie to t
    cols = (H.T @ (inn > 0)).T                     # cols[r, t]: nodes of t with a tie from r
    reg = s[:, None] * (s[None, :] - cols) + s[None, :] * (s[:, None] - rows)
    return float(np.minimum(T, reg).sum()), T, reg


def _sbm_loglik(T, s, directed):
    N = np.outer(s, s) - np.diag(s)
    if directed:
        E, M = T.ravel(), N.ravel()
    else:
        iu, d = np.triu_indices(len(s)), np.eye(len(s), dtype=bool)
        E, M = np.where(d, T / 2, T)[iu], np.where(d, N / 2, N)[iu]
    p = np.divide(E, M, out=np.zeros_like(E, dtype=float), where=M > 0)
    with np.errstate(divide="ignore", invalid="ignore"):
        ll = np.where(E > 0, E * np.log(np.where(p > 0, p, 1)), 0) + np.where(M - E > 0, (M - E) * np.log(np.where(p < 1, 1 - p, 1)), 0)
    return float(ll.sum())


def _icl(ll, s, n, directed):
    k = len(s)
    params = k * k if directed else k * (k + 1) / 2
    pairs = n * (n - 1) if directed else n * (n - 1) / 2
    membership = sum(x * math.log(x / n) for x in s if x > 0)
    return ll + membership - params / 2 * math.log(max(pairs, 2)) - (k - 1) / 2 * math.log(n)


# ---------------------------------------------------------------- relocation search
def _shift(T, o, i, a, b):
    """Ties between blocks after one node with ties o (to blocks) and i (from blocks) moves from a to b."""
    T = T.copy()
    T[a, :] -= o; T[b, :] += o; T[:, a] -= i; T[:, b] += i
    return T


def _relocate(A, k, labels, kind, rng, directed, max_rounds=60, exchanges=True):
    """Transfers (one node to another block) and exchanges (two nodes swap blocks) while the objective improves,
    as in the relocation algorithm of generalized blockmodeling (Doreian, Batagelj & Ferligoj 2005)."""
    n = len(A)
    H = _onehot(labels, k)
    out, inn = A @ H, A.T @ H
    T, s = H.T @ out, H.sum(0)

    def value(T, s, labels, out, inn):
        if kind == "structural":
            return _structural_errors(T, s)
        if kind == "regular":
            return _regular_errors(A, labels, k, out, inn)[0]
        return -_sbm_loglik(T, s, directed)

    def moved(out, inn, v, a, b):
        o, i = out.copy(), inn.copy()
        o[:, a] -= A[:, v]; o[:, b] += A[:, v]; i[:, a] -= A[v, :]; i[:, b] += A[v, :]
        return o, i

    best = value(T, s, labels, out, inn)
    for _ in range(max_rounds):
        improved = False
        for v in rng.permutation(n):                              # transfers
            a = labels[v]
            if s[a] <= 1:
                continue
            choice = None
            for b in range(k):
                if b == a:
                    continue
                T2, s2 = _shift(T, out[v], inn[v], a, b), s.copy()
                s2[a] -= 1; s2[b] += 1
                if kind == "regular":
                    l2 = labels.copy(); l2[v] = b
                    val = value(T2, s2, l2, *moved(out, inn, v, a, b))
                else:
                    val = value(T2, s2, None, None, None)
                if val < best - 1e-9 and (choice is None or val < choice[0]):
                    choice = (val, b, T2, s2)
            if choice:
                best, b, T, s = choice
                labels[v] = b
                out, inn = moved(out, inn, v, a, b)
                improved = True
        if not improved and exchanges:                            # exchanges
            for v in rng.permutation(n):
                a = labels[v]
                for u in np.where(labels != a)[0]:
                    b = labels[u]
                    T1 = _shift(T, out[v], inn[v], a, b)
                    ou, iu = out[u].copy(), inn[u].copy()
                    ou[a] -= A[u, v]; ou[b] += A[u, v]; iu[a] -= A[v, u]; iu[b] += A[v, u]
                    T2 = _shift(T1, ou, iu, b, a)
                    if kind == "regular":
                        l2 = labels.copy(); l2[v], l2[u] = b, a
                        o2, i2 = moved(*moved(out, inn, v, a, b), u, b, a)
                        val = value(T2, s, l2, o2, i2)
                    else:
                        val = value(T2, s, None, None, None)
                    if val < best - 1e-9:
                        best, T = val, T2
                        out, inn = moved(*moved(out, inn, v, a, b), u, b, a)
                        labels[v], labels[u] = b, a
                        improved = True
                        break
        if not improved:
            break
    return labels, best


def _search(A, k, kind, restarts, seed, directed, start=None, polish=10):
    """Many fast starts (transfers only), then the best few polished with exchanges too.
    start: one labeling or a list of labelings tried before the random ones."""
    rng = np.random.default_rng(seed)
    n, found = len(A), []
    given = [] if start is None else (start if isinstance(start, list) else [start])
    starts = [np.asarray(x) % k for x in given] + [None] * restarts
    for init in starts:
        if init is None:
            init = rng.integers(k, size=n)
            init[rng.permutation(n)[:k]] = np.arange(k)          # no empty block
        labels, val = _relocate(A, k, np.array(init), kind, rng, directed, exchanges=False)
        found.append((val, labels.copy()))
    found.sort(key=lambda x: x[0])
    best = None
    for val, labels in found[:polish]:
        lab, v2 = _relocate(A, k, labels.copy(), kind, rng, directed, exchanges=n <= 400)
        if best is None or v2 < best[1] - 1e-9:
            best = (lab, v2)
    return best


# ---------------------------------------------------------------- indirect methods
def _profiles(A, directed):
    return np.hstack([A, A.T]) if directed else A


def _structural_labels(A, k, directed):
    from scipy.cluster.hierarchy import fcluster, linkage
    P = _profiles(A, directed)
    P = P - P.mean(axis=1, keepdims=True)
    norm = np.linalg.norm(P, axis=1)
    R = (P @ P.T) / np.outer(np.where(norm == 0, 1, norm), np.where(norm == 0, 1, norm))
    D = np.clip(1 - R, 0, 2)
    iu = np.triu_indices(len(A), 1)
    return fcluster(linkage(D[iu], method="average"), t=k, criterion="maxclust") - 1


def _concor_split(P, idx, max_iter=100):
    X = P[idx]
    if len(idx) < 2:
        return None
    C = np.corrcoef(X)
    if not np.isfinite(C).all():
        return None
    for _ in range(max_iter):
        if np.all(np.abs(np.abs(C) - 1) < 1e-6):
            break
        C = np.corrcoef(C)
        if not np.isfinite(C).all():
            return None
    side = C[0] > 0
    if side.all() or not side.any():
        return None
    return idx[side], idx[~side]


def _concor_labels(A, k, directed):
    P = _profiles(A, directed)
    isolated = np.where(P.sum(1) == 0)[0]
    active = np.where(P.sum(1) > 0)[0]
    blocks, stuck = ([active] if len(active) else []), set()
    while len(blocks) + (1 if len(isolated) else 0) < k:
        cand = [i for i, b in enumerate(blocks) if i not in stuck and len(b) > 1]
        if not cand:
            break
        i = max(cand, key=lambda j: len(blocks[j]))
        split = _concor_split(P, blocks[i])
        if split is None:
            stuck.add(i)
            continue
        blocks[i] = split[0]
        blocks.append(split[1])
        stuck = set()
    labels = np.zeros(len(A), dtype=int)
    for b, members in enumerate(blocks):
        labels[members] = b
    if len(isolated):
        labels[isolated] = len(blocks)
    return labels


# ---------------------------------------------------------------- results
def _relabel(labels):
    """Blocks numbered 0.. by size (largest first)."""
    sizes = pd.Series(labels).value_counts()
    order = {b: i for i, b in enumerate(sorted(sizes.index, key=lambda b: (-sizes[b], b)))}
    return np.array([order[b] for b in labels])


def _r2(A, labels, k):
    T, s, N = _counts(A, labels, k)
    dens = np.divide(T, N, out=np.zeros_like(T), where=N > 0)
    off = ~np.eye(len(A), dtype=bool)
    x, y = A[off], dens[labels][:, labels][off]
    if x.std() == 0 or y.std() == 0:
        return 0.0
    return float(np.corrcoef(x, y)[0, 1] ** 2)


def _tables(G, nodes, A, labels, k, types=None):
    T, s, N = _counts(A, labels, k)
    dens = np.divide(T, N, out=np.zeros_like(T), where=N > 0)
    names = [f"block {b + 1}" for b in range(k)]
    image = pd.DataFrame(np.round(dens, 4), index=names, columns=names)
    image.insert(0, "nodes", s.astype(int))
    deg = dict(G.degree())
    rows = []
    for b in range(k):
        members = [nodes[i] for i in np.where(labels == b)[0]]
        members.sort(key=lambda m: -deg.get(m, 0))
        rows.append({"block": names[b], "nodes": len(members), "density_within": round(float(dens[b, b]), 4),
                     "ties_out": int(T[b].sum() - T[b, b]), "ties_in": int(T[:, b].sum() - T[b, b]),
                     "members": ", ".join(str(G.nodes[m].get("label", m)) for m in members[:15])
                                + (" …" if len(members) > 15 else "")})
    tables = {"blocks": pd.DataFrame(rows), "block_image": image.reset_index().rename(columns={"index": "block"})}
    if types is not None:
        tables["block_types"] = types
    return tables


def _types_table(A, labels, k, equivalence):
    T, s, N = _counts(A, labels, k)
    if equivalence == "regular":
        reg = _regular_errors(A, labels, k)[2]
        alt, name = reg, "regular"
    else:
        alt, name = N - T, "complete"
    names = [f"block {b + 1}" for b in range(k)]
    cells = pd.DataFrame(index=names, columns=names, dtype=object)
    for r in range(k):
        for c in range(k):
            null_err, other = int(T[r, c]), int(alt[r, c])
            cells.iloc[r, c] = f"null ({null_err})" if null_err <= other else f"{name} ({other})"
    return cells.reset_index().rename(columns={"index": "block"})


def blockmodel(G: nx.Graph, spec, seed: int = 2026) -> tuple[dict, dict]:
    spec = spec if isinstance(spec, dict) else {"method": spec}
    method = str(spec.get("method", "concor")).lower()
    if method in ("none", "", "false"):
        return {}, {}
    if method not in METHODS:
        raise ConfigError(f"analysis.blockmodel.method must be one of {sorted(METHODS)}")
    equivalence = str(spec.get("equivalence", "structural")).lower()
    if equivalence not in ("structural", "regular"):
        raise ConfigError("analysis.blockmodel.equivalence must be structural or regular")
    nodes, A = _adjacency(G)
    n, directed = len(nodes), G.is_directed()
    if n < 3 or A.sum() == 0:
        log.warning("blockmodel: needs at least 3 nodes and one tie")
        return {}, {}
    if n > LIMIT:
        log.warning(f"blockmodel: skipped for {n:,} nodes (limit {LIMIT:,}); filter the network first")
        return {}, {}
    blocks = spec.get("blocks")
    blocks = None if blocks in (None, "", "auto") else int(blocks)
    if blocks is not None and not 1 <= blocks <= n:
        raise ConfigError("analysis.blockmodel.blocks must be between 1 and the number of nodes")
    restarts = int(spec.get("restarts", max(20, min(500, 10000 // n))))
    summary, types = {"blockmodel_method": method}, None
    if method == "concor":
        k = blocks or 4
        labels = _concor_labels(A, k, directed)
    elif method == "structural":
        k = blocks or min(max(2, round(n ** .5 / 2)), 8)
        labels = _structural_labels(A, k, directed)
    elif method == "generalized":
        k = blocks or 3
        kind = "regular" if equivalence == "regular" else "structural"
        # informed starts: random partitions often sit on a plateau where every block is null and no single move helps
        deg = A.sum(0) + A.sum(1)
        by_degree = np.empty(n, dtype=int)
        by_degree[np.argsort(-deg, kind="stable")] = np.minimum(np.arange(n) * k // n, k - 1)
        sbm_start, _ = _search(A, k, "sbm", 3, seed, directed, _structural_labels(A, k, directed), polish=1)
        starts = [_structural_labels(A, k, directed), _concor_labels(A, k, directed), by_degree, sbm_start]
        labels, err = _search(A, k, kind, restarts, seed, directed, starts)
        labels = _relabel(labels)
        types = _types_table(A, labels, k, equivalence)
        cells = n * (n - 1)
        summary.update({"blockmodel_equivalence": equivalence, "blockmodel_errors": int(round(err)),
                        "blockmodel_fit": round(1 - err / cells, 4)})
    else:                                                    # sbm
        sbm_restarts = int(spec.get("restarts", max(4, min(12, 600 // n))))
        candidates = [blocks] if blocks else range(1, min(8, max(1, n // 3)) + 1)
        best, worse = None, 0
        for k in candidates:
            if k == 1:
                lab = np.zeros(n, dtype=int)
            else:
                lab, _ = _search(A, k, "sbm", sbm_restarts, seed + k, directed, _structural_labels(A, k, directed), polish=2)
            T, s, _ = _counts(A, lab, k)
            ll = _sbm_loglik(T, s, directed)
            icl = _icl(ll, s[s > 0], n, directed)
            if best is None or blocks or icl > best[2]:
                best, worse = (lab, ll, icl, k), 0
            else:
                worse += 1
                if worse >= 2:                               # ICL fell twice in a row: more blocks will not help
                    break
        labels, ll, icl, k = best
        summary.update({"sbm_loglik": round(ll, 3), "sbm_icl": round(icl, 3)})
    labels = _relabel(labels)
    k = int(labels.max()) + 1
    nx.set_node_attributes(G, {node: int(b) + 1 for node, b in zip(nodes, labels)}, "block")
    summary.update({"blocks": k, "blockmodel_r2": round(_r2(A, labels, k), 4)})
    if method == "generalized":
        types = _types_table(A, labels, k, equivalence)
    return summary, _tables(G, nodes, A, labels, k, types)
