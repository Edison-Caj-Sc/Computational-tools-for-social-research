"""Stage 1 · read: tables (files or URLs), documents and online sources (connectors)."""
from __future__ import annotations

import atexit
import glob
import html
import json
import os
import re
import shutil
import urllib.parse
import urllib.request
from pathlib import Path

import pandas as pd

from .utils import ConfigError, as_list, log

TABLE_EXT = {".csv", ".tsv", ".txt", ".xlsx", ".xls", ".dta", ".sav", ".parquet", ".json", ".jsonl"}
DOC_EXT = {".txt", ".md", ".html", ".htm", ".pdf", ".docx"}


def _limit_mb(name: str, default: int) -> int:
    """Size limits can be changed with environment variables (megabytes)."""
    try:
        return max(1, int(os.environ.get(name, default)))
    except ValueError:
        return default


_TEMP: list[Path] = []                    # downloads and unzipped files, removed when the program ends


def temp_folder(prefix: str = "tejido_") -> Path:
    import tempfile
    d = Path(tempfile.mkdtemp(prefix=prefix))
    _TEMP.append(d)
    return d


@atexit.register
def _clean_temp() -> None:
    for d in _TEMP:
        shutil.rmtree(d, ignore_errors=True)
    _TEMP.clear()


def _open_url(url: str, timeout: int):
    """Opens http(s) addresses only (never file:// or other schemes), identifying the program."""
    from . import __version__
    parts = urllib.parse.urlparse(url)
    if parts.scheme not in ("http", "https") or not parts.netloc:
        raise ConfigError(f"Only http:// and https:// addresses can be downloaded (got {url!r})")
    req = urllib.request.Request(url, headers={"User-Agent": f"tejido/{__version__}"})
    return urllib.request.urlopen(req, timeout=timeout)   # noqa: S310 - scheme checked above


def _download(url: str) -> Path:
    """Downloads a URL to a temporary file that keeps its extension (up to TEJIDO_MAX_DOWNLOAD_MB, 300 by default)."""
    limit = _limit_mb("TEJIDO_MAX_DOWNLOAD_MB", 300) * 1024 * 1024
    suffix = Path(urllib.parse.urlparse(url).path).suffix.lower()
    name = "download" + (suffix if re.fullmatch(r"\.[a-z0-9]{1,8}", suffix) else ".csv")
    target = temp_folder("tejido_dl_") / name
    try:
        with _open_url(url, 120) as r, open(target, "wb") as fh:
            done = 0
            while chunk := r.read(1 << 20):
                done += len(chunk)
                if done > limit:
                    raise ConfigError(f"{url} is larger than {limit // 1024 // 1024} MB; download it and choose the file")
                fh.write(chunk)
    except ConfigError:
        raise
    except Exception as e:
        raise ConfigError(f"Could not download {url}: {e}") from e
    log.info(f"Downloaded {url} ({done:,} bytes)")
    return target


def _expand(path, exts) -> list[Path]:
    if str(path).startswith(("http://", "https://")):
        return [_download(str(path))]
    p = Path(path)
    if p.is_dir():
        files = [f for f in sorted(p.rglob("*")) if f.suffix.lower() in exts]
    elif any(c in str(path) for c in "*?["):
        files = [Path(f) for f in sorted(glob.glob(str(path), recursive=True))]
    else:
        files = [p]
    missing = [f for f in files if not f.exists()]
    if not files or missing:
        raise ConfigError(f"No input files found at {path}")
    return files


# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------

def _sniff_sep(f: Path, encoding: str) -> str:
    """Column separator among comma, semicolon, tab and bar (comma when unclear, e.g. a single column)."""
    import csv
    with open(f, encoding=encoding, newline="") as fh:
        sample = fh.read(65536)
    try:
        return csv.Sniffer().sniff(sample, delimiters=",;\t|").delimiter
    except csv.Error:
        return ","


def _read_untidy(f: Path, encoding: str) -> pd.DataFrame:
    """A CSV with title rows above the header or notes below it: finds the header and keeps the table."""
    from .panel import _frame, _grids, _numeric_share, to_numbers
    _, rows, dec = _grids(f, {"encoding": encoding})[0]
    df, h = _frame(rows)
    for c in df.columns:
        if _numeric_share(df[c]) >= 0.9:
            v = to_numbers(df[c], dec)[0]
            df[c] = v.astype("Int64") if v.notna().any() and (v.dropna() % 1 == 0).all() else v
    log.info(f"{f.name}: header found in row {h}; title and note rows skipped")
    return df


COMMA_NUMBER = r"[-+]?(?:\d{1,3}(?:\.\d{3})+|\d+)(?:,\d+)?"


def _decimal_comma(df: pd.DataFrame) -> pd.DataFrame:
    """Semicolon files: columns pandas left as text because of thousands dots (1.234,5) become numbers."""
    from .panel import to_numbers
    for c in df.columns:
        if pd.api.types.is_numeric_dtype(df[c]):
            continue
        v = df[c].dropna().astype(str).str.strip()
        v = v[v != ""]
        if len(v) and v.str.fullmatch(COMMA_NUMBER).all() and v.str.contains(r"[.,]").any():
            x = to_numbers(df[c], ",")[0]
            df[c] = x.astype("Int64") if (x.dropna() % 1 == 0).all() else x
    return df


def _text_encodings(f: Path, encoding=None) -> list[str]:
    """Encodings to try for a text file: the one asked for, or the one its first bytes announce, then the usual ones."""
    if encoding:
        return [encoding]
    with open(f, "rb") as fh:
        head = fh.read(4)
    if head.startswith((b"\xff\xfe", b"\xfe\xff")):        # "Unicode text" saved by Excel
        return ["utf-16"]
    return ["utf-8-sig", "latin-1"]


def _read_one(f: Path, sheet=None, encoding=None) -> pd.DataFrame:
    ext = f.suffix.lower()
    if f.stat().st_size == 0:
        raise ConfigError(f"{f.name}: the file is empty")
    if ext in (".csv", ".txt", ".tsv"):
        for enc in _text_encodings(f, encoding):
            try:
                sep = "\t" if ext == ".tsv" else _sniff_sep(f, enc)
                # semicolon-separated files (Excel in Spanish and other locales) use the decimal comma
                try:
                    df = pd.read_csv(f, sep=sep, engine="python", encoding=enc, decimal="," if sep == ";" else ".")
                    return _decimal_comma(df) if sep == ";" else df
                except pd.errors.EmptyDataError as e:
                    raise ConfigError(f"{f.name}: the file has no columns") from e
                except pd.errors.ParserError:            # titles or notes around the table
                    return _read_untidy(f, enc)
            except (UnicodeDecodeError, UnicodeError):
                continue
            except LookupError as e:
                raise ConfigError(f"{f.name}: unknown encoding {enc!r} (try utf-8 or latin-1)") from e
        raise ConfigError(f"{f.name}: could not be read with encoding {encoding!r}; leave 'encoding' empty to detect it")
    if ext == ".xls":
        try:
            return pd.read_excel(f, sheet_name=sheet or 0)
        except ImportError as e:
            raise ConfigError(f"{f.name}: reading old Excel files (.xls) needs the xlrd package (pip install xlrd); "
                              "or save it as .xlsx or CSV") from e
    if ext in (".xlsx", ".xlsm"):
        return pd.read_excel(f, sheet_name=sheet or 0)
    if ext == ".dta":
        return pd.read_stata(f, convert_categoricals=False)
    if ext == ".sav":
        try:
            import pyreadstat
        except ImportError as e:
            raise ConfigError(f"{f.name}: reading SPSS files needs the pyreadstat package (pip install pyreadstat)") from e
        return pyreadstat.read_sav(str(f))[0]
    if ext == ".parquet":
        return pd.read_parquet(f)
    if ext == ".jsonl":
        return pd.read_json(f, lines=True)
    if ext == ".json":
        data = json.loads(f.read_text(encoding="utf-8-sig"))
        if isinstance(data, dict):                     # {"data": [...]} or one record
            lists = [v for v in data.values() if isinstance(v, list) and v and all(isinstance(x, dict) for x in v)]
            data = lists[0] if len(lists) == 1 else [data]
        if not isinstance(data, list) or not all(isinstance(x, dict) for x in data):
            raise ConfigError(f"{f.name}: the JSON file must be a list of records, like [{{\"a\": 1}}, {{\"a\": 2}}]")
        return pd.json_normalize(data)
    raise ConfigError(f"Unsupported table format: {f.name}")


def read_table(path, sheet=None, encoding=None) -> pd.DataFrame:
    frames = []
    files = _expand(path, TABLE_EXT)
    for f in files:
        try:
            df = _read_one(f, sheet, encoding)
        except ConfigError:
            raise
        except ImportError as e:
            raise ConfigError(f"{f.name}: a package needed for this format is not installed ({e})") from e
        except Exception as e:                         # damaged file, or its name says a format it is not
            msg = str(e).strip().splitlines()[0][:200] if str(e).strip() else type(e).__name__
            raise ConfigError(f"{f.name}: the file could not be read as a table; it may be damaged, protected with a "
                              f"password or not in the format its name says ({msg})") from e
        if isinstance(df, dict):                       # sheet given as a list
            df = pd.concat(df.values(), ignore_index=True)
        if len(files) > 1:
            df = df.assign(source_file=f.name)
        frames.append(df)
    out = pd.concat(frames, ignore_index=True)
    log.info(f"Read {len(out):,} rows × {out.shape[1]} columns from {len(files)} file(s)")
    return out


# ---------------------------------------------------------------------------
# Documents
# ---------------------------------------------------------------------------

def _read_pdf(f: Path) -> str:
    try:
        from pypdf import PdfReader
    except ImportError as e:
        raise ConfigError("Reading PDF requires pypdf: pip install pypdf") from e
    return "\n\n".join((page.extract_text() or "") for page in PdfReader(str(f)).pages)


def _read_docx(f: Path) -> str:
    try:
        import docx
    except ImportError as e:
        raise ConfigError("Reading DOCX requires python-docx: pip install python-docx") from e
    return "\n\n".join(p.text for p in docx.Document(str(f)).paragraphs)


def _read_html(f: Path) -> str:
    raw = f.read_text(encoding="utf-8", errors="ignore")
    raw = re.sub(r"(?is)<(script|style).*?</\1>", " ", raw)
    raw = re.sub(r"(?i)</?(p|div|br|h\d|li|tr)[^>]*>", "\n\n", raw)
    return html.unescape(re.sub(r"<[^>]+>", " ", raw))


def read_documents(path) -> pd.DataFrame:
    rows = []
    for f in _expand(path, DOC_EXT):
        ext = f.suffix.lower()
        if ext == ".pdf":
            text = _read_pdf(f)
        elif ext == ".docx":
            text = _read_docx(f)
        elif ext in (".html", ".htm"):
            text = _read_html(f)
        else:
            text = f.read_text(encoding="utf-8", errors="ignore")
        rows.append({"doc_id": f.stem, "path": str(f), "text": text})
    df = pd.DataFrame(rows)
    empty = df["text"].str.strip().eq("")
    if empty.any():
        log.warning(f"{int(empty.sum())} document(s) have no extractable text (scanned PDFs need OCR)")
    log.info(f"Read {len(df)} document(s)")
    return df


# ---------------------------------------------------------------------------
# World Bank
# ---------------------------------------------------------------------------

WB_COLUMNS = ["country", "country_code", "indicator", "indicator_code", "year", "value"]


def read_worldbank_csv(path) -> pd.DataFrame:
    """World Bank downloads and similar indicator data (see panel.py, which recognizes many layouts)."""
    from .panel import read_indicators
    return read_indicators(path)


def _get_json(url: str):
    with _open_url(url, 60) as r:
        return json.loads(r.read(64 * 1024 * 1024).decode("utf-8"))


# World Bank aggregates (regions, income and lending groups) present in its downloads.
WB_AGGREGATES = set("""AFE AFW ARB CEB CSS EAP EAR EAS ECA ECS EMU EUU FCS HIC HPC IBD IBT IDA IDB IDX INX LAC
LCN LDC LIC LMC LMY LTE MEA MIC MNA NAC OED OSS PRE PSS PST SAS SSA SSF SST TEA TEC TLA TMN TSA TSS UMC WLD""".split())


def _years(spec, available):
    """latest | 2020 | 2015-2020 | 2015:2020 | [2015, 2018] → the years to use (None: the latest of each unit)."""
    if spec in (None, "", "latest"):
        return None
    try:
        if isinstance(spec, (list, tuple, set)):
            return sorted({int(y) for y in spec})
        s = str(spec).strip().lower()
        if s == "latest":
            return None
        m = re.fullmatch(r"(\d{4})\s*[-:–]\s*(\d{4})", s)
        if m:
            a, b = sorted(int(x) for x in m.groups())
            return [y for y in available if a <= y <= b]
        return sorted({int(float(x)) for x in re.split(r"[,;\s]+", s) if x})
    except (TypeError, ValueError) as e:
        raise ConfigError(f"'year' must be latest, a year (2020), a range (2015-2020) or a list of years; got {spec!r}") from e


def worldbank_wide(data: pd.DataFrame, opts: dict) -> pd.DataFrame:
    """Long World Bank data → one row per country: country_code, country, one column per indicator
    (or per year when features_from: years)."""
    from .utils import require_columns
    require_columns(data, ["country", "country_code", "indicator_code", "year", "value"], "World Bank data")
    df = data.copy()
    extra = {str(x) for x in as_list(opts.get("exclude"))}
    drop = df["country_code"].isin(WB_AGGREGATES | extra) | df["country"].astype(str).isin(extra)
    if opts.get("exclude_aggregates", True):
        if "is_aggregate" in df:
            drop |= df["is_aggregate"].fillna(False).astype(bool)
        n = df["country_code"].nunique()
        df = df[~drop]
        log.info(f"Indicator data: {n - df['country_code'].nunique()} aggregates (world, regions, income groups…) excluded")
    elif extra:
        df = df[~(df["country_code"].isin(extra) | df["country"].astype(str).isin(extra))]
    if as_list(opts.get("indicators")):
        df = df[df["indicator_code"].isin(as_list(opts["indicators"]))]
    names = df.groupby("country_code")["country"].first()
    by_years = opts.get("features_from", "indicators") == "years"
    if not by_years and df["indicator_code"].nunique() == 1 and df["year"].nunique() > 1:
        log.info("Indicator data: only one indicator, so units are compared by its values over the years")
        by_years = True
    if by_years:                                                     # trajectories of one indicator
        yrs = _years(opts.get("year", "latest"), sorted(int(y) for y in df["year"].dropna().unique()))
        if yrs is not None and len(yrs) > 1:
            df = df[df["year"].isin(yrs)]
        if df["indicator_code"].nunique() != 1:
            raise ConfigError("features_from: years needs exactly one indicator (use 'indicators')")
        X = df.pivot_table(index="country_code", columns="year", values="value")
    else:
        yrs = _years(opts.get("year", "latest"), sorted(int(y) for y in df["year"].dropna().unique()))
        if yrs is None:                                                  # latest available per country
            df = df.sort_values("year").groupby(["country_code", "indicator_code"]).tail(1)
        else:
            df = df[df["year"].isin(yrs)]
        X = df.pivot_table(index="country_code", columns="indicator_code", values="value", aggfunc="mean")
    X.columns = [str(c) for c in X.columns]
    X.insert(0, "country", names.reindex(X.index))
    return X.reset_index()


def worldbank_aggregates() -> set[str]:
    """ISO3 codes the World Bank API marks as aggregates (regions, income groups…)."""
    data = _get_json("https://api.worldbank.org/v2/country?format=json&per_page=500")
    return {c["id"] for c in data[1] if c.get("region", {}).get("value") == "Aggregates"}


def read_worldbank_api(indicators, countries="all", years="2015:2023") -> pd.DataFrame:
    """Downloads indicators from the World Bank API v2 (requires internet)."""
    if not as_list(indicators):
        raise ConfigError("World Bank: write at least one indicator code (e.g. NY.GDP.PCAP.KD)")
    rows = []
    where = ";".join(str(c).strip() for c in as_list(countries) if str(c).strip()).replace(",", ";").replace(" ", "") or "all"
    if not re.fullmatch(r"[A-Za-z0-9;]+", where):
        raise ConfigError(f"World Bank: countries must be 'all' or ISO codes separated by ';' (PER;BOL;ECU); got {countries!r}")
    years = str(years or "2015:2023").strip().replace("-", ":").replace("–", ":")
    if not re.fullmatch(r"\d{4}(:\d{4})?", years):
        raise ConfigError(f"World Bank: years must be like 2020 or 2015:2023; got {years!r}")
    for code in as_list(indicators):
        code = str(code).strip()
        if not re.fullmatch(r"[A-Za-z0-9._\-]+", code):
            raise ConfigError(f"World Bank: {code!r} is not an indicator code (they look like NY.GDP.PCAP.KD)")
        page, pages = 1, 1
        while page <= pages:
            q = urllib.parse.urlencode({"format": "json", "per_page": 20000, "date": years, "page": page})
            url = f"https://api.worldbank.org/v2/country/{where}/indicator/{code}?{q}"
            try:
                answer = _get_json(url)
            except Exception as e:
                raise ConfigError(f"World Bank: could not download {code}; check the internet connection ({e})") from e
            if not isinstance(answer, list) or len(answer) < 2 or not isinstance(answer[0], dict):
                detail = ""
                try:
                    detail = ": " + answer[0]["message"][0]["value"]
                except Exception:
                    pass
                raise ConfigError(f"World Bank: indicator {code!r} or countries {where!r} not recognized{detail}")
            meta, data = answer[0], answer[1]
            pages = int(meta.get("pages", 1) or 1)
            for d in data or []:
                rows.append({"country": d["country"]["value"], "country_code": d.get("countryiso3code") or d["country"]["id"],
                             "indicator": d["indicator"]["value"], "indicator_code": d["indicator"]["id"],
                             "year": int(d["date"]), "value": d["value"]})
            page += 1
        log.info(f"World Bank: downloaded {code}")
    return pd.DataFrame(rows, columns=WB_COLUMNS).dropna(subset=["value"])


# ---------------------------------------------------------------------------
# Connectors (online sources) and the read stage
# ---------------------------------------------------------------------------

def _worldbank_connector(i: dict) -> pd.DataFrame:
    return read_worldbank_api(i.get("indicators"), i.get("countries", "all"), i.get("years", "2015:2023"))


CONNECTORS = {"worldbank": ("World Bank indicators API (indicators, countries, years)", _worldbank_connector)}


def read(cfg: dict) -> pd.DataFrame:
    """input.type: table | documents | api | none. Paths may be files, folders, patterns or URLs."""
    from .config import resolve
    i = cfg["input"]
    kind = i.get("type", "table")
    if kind == "none":
        return pd.DataFrame()
    if kind == "api":
        src = i.get("source")
        if src not in CONNECTORS:
            raise ConfigError(f"'input.source' must be one of {sorted(CONNECTORS)}")
        return CONNECTORS[src][1](i)
    if not i.get("path"):
        raise ConfigError("Missing 'input.path'")
    path = resolve(cfg, i["path"])
    if kind == "documents":
        docs = read_documents(path)
        if i.get("metadata"):                       # table with doc_id + date, author, type…
            meta = read_table(resolve(cfg, i["metadata"]))
            if "doc_id" not in meta.columns:
                raise ConfigError("input.metadata needs a 'doc_id' column (file name without extension)")
            meta["doc_id"] = meta["doc_id"].astype(str)
            docs = docs.merge(meta, on="doc_id", how="left")
        return docs
    if i.get("preset") in ("worldbank", "indicators"):       # indicator data: units × years, any layout
        from .panel import read_indicators
        return read_indicators(path, i)
    return read_table(path, i.get("sheet"), i.get("encoding"))
