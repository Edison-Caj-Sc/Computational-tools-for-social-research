"""Turning edge and node tables into networkx graphs."""
from __future__ import annotations

import networkx as nx
import pandas as pd

AGG = {"sum": "sum", "mean": "mean", "min": "min", "max": "max", "first": "first", "last": "last",
       "count": "count", "nunique": "nunique"}


def _missing(v) -> bool:
    try:
        return bool(pd.isna(v))
    except (TypeError, ValueError):                     # lists and other containers are values
        return False


def _values(s: pd.Series) -> str:
    return "|".join(sorted({str(v) for v in s.dropna()}))


def aggregate_edges(df: pd.DataFrame, directed: bool, weight: str | None = None,
                    attributes: dict | None = None) -> pd.DataFrame:
    """Collapses repeated source-target pairs. weight = sum of 'weight' column or number of rows."""
    df = df.dropna(subset=["source", "target"]).copy()
    df["source"], df["target"] = df["source"].astype(str), df["target"].astype(str)
    if not directed:                      # A-B and B-A are the same tie
        a, b = df["source"].where(df["source"] <= df["target"], df["target"]), \
               df["target"].where(df["source"] <= df["target"], df["source"])
        df["source"], df["target"] = a, b
    df["_w"] = pd.to_numeric(df[weight], errors="coerce").fillna(0) if weight else 1.0
    g = df.groupby(["source", "target"], sort=False)
    out = g["_w"].sum().rename("weight").to_frame()
    for col, how in (attributes or {}).items():
        out[col] = g[col].agg(_values) if how == "values" else g[col].agg(AGG.get(how, how))
    return out.reset_index()


def to_graph(edges: pd.DataFrame, directed: bool, nodes: pd.DataFrame | None = None,
             self_loops: bool = False) -> nx.Graph:
    G = nx.DiGraph() if directed else nx.Graph()
    if not self_loops:
        edges = edges[edges["source"] != edges["target"]]
    attrs = [c for c in edges.columns if c not in ("source", "target")]
    # to_dict keeps the column names as they are ("tipo de relación", "2020", "class"); itertuples renames them
    for d in edges.to_dict("records"):
        G.add_edge(d["source"], d["target"], **{str(k): d[k] for k in attrs})
    if nodes is not None and len(nodes):
        for d in nodes.to_dict("records"):
            nid = str(d.pop("id"))
            keep = bool(d.pop("keep_isolated", False))
            if nid in G or keep:
                G.add_node(nid, **{str(k): v for k, v in d.items() if not _missing(v)})
    for n in G.nodes:
        G.nodes[n].setdefault("label", n)
    return G


def add_relation_counts(df: pd.DataFrame, column: str, max_types: int = 30) -> dict:
    """Adds n_<type> count columns from a relation-type column; returns the aggregation spec."""
    from .utils import log, slug
    kinds = df[column].dropna().astype(str).unique().tolist()
    if len(kinds) > max_types:
        log.warning(f"'{column}' has {len(kinds)} relation types; only per-type counts for the first {max_types}")
        kinds = kinds[:max_types]
    for k in kinds:
        df[f"n_{slug(k)}"] = (df[column].astype(str) == k).astype(int)
    return {f"n_{slug(k)}": "sum" for k in kinds}


def attach_nodes(G: nx.Graph, table: pd.DataFrame, id_col: str = "id", columns=None) -> None:
    """Copies node attributes from a table (only for nodes already in the network)."""
    from .utils import as_list, require_columns
    require_columns(table, id_col, "nodes")
    cols = as_list(columns) or [c for c in table.columns if c != id_col]
    t = table.drop_duplicates(id_col).set_index(table.drop_duplicates(id_col)[id_col].astype(str))[cols]
    for n in G.nodes:
        if str(n) in t.index:
            for k, v in t.loc[str(n)].items():
                if pd.notna(v):
                    G.nodes[n][k] = v.item() if hasattr(v, "item") else v
