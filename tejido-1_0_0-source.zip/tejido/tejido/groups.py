"""Groups and positions: communities, k-cores, cliques, structural equivalence (blockmodels) and
core–periphery structure."""
from __future__ import annotations

import networkx as nx
import numpy as np
import pandas as pd

from .analyze import BIG, COMMUNITIES, undirected_simple
from .utils import ConfigError, as_list, log

GROUPS = {"kcore": "k-core decomposition (largest core)",
          "cliques": "Maximal cliques of 3+ nodes (cohesive subgroups)",
          "equivalence": "Structural equivalence: blocks of nodes with similar ties + block image matrix",
          "core_periphery": "Borgatti–Everett core–periphery: continuous coreness and core/periphery split"}


def communities(G: nx.Graph, method, resolution: float, seed: int, attribute=None) -> list[set]:
    if method not in COMMUNITIES:
        raise ConfigError(f"'communities' must be one of {sorted(c for c in COMMUNITIES if c)}")
    if method in ("none", None) or G.number_of_edges() == 0:
        return []
    U = undirected_simple(G) if G.is_directed() else G
    if method == "louvain":
        comms = nx.community.louvain_communities(U, weight="weight", resolution=resolution, seed=seed)
    elif method == "greedy":
        comms = nx.community.greedy_modularity_communities(U, weight="weight", resolution=resolution)
    elif method == "label_propagation":
        comms = nx.community.asyn_lpa_communities(U, weight="weight", seed=seed)
    elif method == "girvan_newman":                    # divisive; keeps the split with the best modularity
        if U.number_of_nodes() > 400:
            raise ConfigError("girvan_newman is slow; use it for networks of up to 400 nodes (or louvain)")
        best, best_q = [set(U)], -1
        for i, part in enumerate(nx.community.girvan_newman(U)):
            q = nx.community.modularity(U, part, weight="weight")
            if q > best_q:
                best, best_q = part, q
            if i > 60:
                break
        comms = best
    else:                                              # groups defined by a node attribute
        if not attribute:
            raise ConfigError("communities: attribute needs 'analysis.community_attribute'")
        by = {}
        for n, d in G.nodes(data=True):
            by.setdefault(str(d.get(attribute, "—")), set()).add(n)
        comms = by.values()
    comms = sorted((set(c) for c in comms), key=len, reverse=True)
    for i, c in enumerate(comms, 1):
        for n in c:
            G.nodes[n]["community"] = i
    return comms


def community_table(G: nx.Graph, comms) -> pd.DataFrame:
    """Size, internal density, external ties, conductance and E-I index of each community (from the members' side:
    an internal tie counts once for each of its two members)."""
    U = undirected_simple(G) if G.is_directed() else G
    vol_total = 2 * U.number_of_edges()
    rows = []
    for i, c in enumerate(comms, 1):
        internal = U.subgraph(c).number_of_edges()
        external = sum(1 for u in c for v in U[u] if v not in c)
        vol = sum(U.degree(u) for u in c)
        n = len(c)
        top = sorted(c, key=lambda x: -U.degree(x))[:8]
        rows.append({"community": i, "size": n, "internal_ties": internal, "external_ties": external,
                     "density": round(2 * internal / (n * (n - 1)), 4) if n > 1 else 0,
                     "conductance": round(external / min(vol, vol_total - vol), 4) if min(vol, vol_total - vol) > 0 else 0,
                     "ei_index": round((external - 2 * internal) / (external + 2 * internal), 4) if external + internal else 0,
                     "main_members": "; ".join(str(G.nodes[x].get("label", x)) for x in top)})
    return pd.DataFrame(rows)


def cliques(G: nx.Graph, limit: int = 200_000):
    U = nx.Graph(undirected_simple(G) if G.is_directed() else G)
    U.remove_edges_from(nx.selfloop_edges(U))
    found = []
    for i, c in enumerate(nx.find_cliques(U)):
        if len(c) >= 3:
            found.append(c)
        if i >= limit:
            log.warning(f"cliques: stopped after {limit:,} cliques")
            break
    count = {n: 0 for n in G}
    for c in found:
        for n in c:
            count[n] += 1
    nx.set_node_attributes(G, count, "cliques")
    found.sort(key=len, reverse=True)
    table = pd.DataFrame([{"clique": i, "size": len(c), "members": "; ".join(str(G.nodes[x].get("label", x)) for x in c)}
                          for i, c in enumerate(found[:200], 1)])
    return {"cliques": len(found), "largest_clique": len(found[0]) if found else 0}, table


def equivalence(G: nx.Graph, k: int | None):
    """Structural equivalence: nodes with similar ties to the same others, grouped by hierarchical clustering
    of their tie profiles; plus the block image (density between blocks). See blockmodel.py for other methods."""
    from .blockmodel import blockmodel
    summary, tables = blockmodel(G, {"method": "structural", "blocks": k})
    return {"blocks": summary.get("blocks", 0)}, tables.get("block_image")


def core_periphery(G: nx.Graph):
    """Borgatti & Everett (1999): continuous coreness (leading eigenvector of the symmetrized adjacency)
    and the core size whose ideal pattern (core–core ties, no periphery–periphery ties) fits best."""
    U = undirected_simple(G) if G.is_directed() else G
    nodes = list(U)
    A = (nx.to_numpy_array(U, nodelist=nodes, weight=None) > 0).astype(float)
    np.fill_diagonal(A, 0)
    vals, vecs = np.linalg.eigh(A)
    c = np.abs(vecs[:, -1])
    c = c / c.max() if c.max() > 0 else c
    order = np.argsort(-c)
    S = A[np.ix_(order, order)]
    n = len(nodes)
    C = S.cumsum(0).cumsum(1)
    total, best, best_s = S.sum(), -2.0, 1
    for s in range(1, n):
        cc = C[s - 1, s - 1]                          # ties inside the core (counted twice)
        pp = total - 2 * C[s - 1, -1] + cc            # ties inside the periphery
        n_cc, n_pp = s * (s - 1), (n - s) * (n - s - 1)
        N = n_cc + n_pp
        if N == 0 or n_cc == 0:
            continue
        x_mean = (cc + pp) / N                        # correlation of observed with ideal (1 in core block)
        i_mean = n_cc / N
        cov = cc / N - x_mean * i_mean
        sx = np.sqrt(max(x_mean - x_mean ** 2, 0))
        si = np.sqrt(i_mean - i_mean ** 2)
        r = cov / (sx * si) if sx > 0 and si > 0 else -2
        if r > best:
            best, best_s = r, s
    core = {nodes[i] for i in order[:best_s]}
    nx.set_node_attributes(G, {nodes[i]: round(float(c[i]), 6) for i in range(n)}, "coreness_cp")
    nx.set_node_attributes(G, {x: ("core" if x in core else "periphery") for x in nodes}, "core_periphery")
    return {"core_size": len(core), "core_periphery_fit": round(float(best), 4)}


def analyze_groups(G: nx.Graph, a: dict, seed: int):
    summary, tables = {}, {}
    comms = communities(G, a.get("communities"), float(a.get("resolution", 1.0)), seed,
                        a.get("community_attribute"))
    if comms:
        tables["communities"] = community_table(G, comms)
    which = set(as_list(a.get("groups")))
    if "all" in which:
        which = set(GROUPS)
    unknown = which - set(GROUPS)
    if unknown:
        raise ConfigError(f"Unknown analysis.groups {sorted(unknown)}. Options: {sorted(GROUPS)}")
    if "equivalence" in which and a.get("blockmodel"):
        log.info("groups: equivalence skipped; analysis.blockmodel gives the blocks")
        which.discard("equivalence")
    n = G.number_of_nodes()
    if "kcore" in which:
        U = nx.Graph(undirected_simple(G) if G.is_directed() else G)
        U.remove_edges_from(nx.selfloop_edges(U))
        core = nx.core_number(U)
        nx.set_node_attributes(G, core, "coreness")
        kmax = max(core.values()) if core else 0
        summary.update({"max_core": kmax, "max_core_nodes": sum(1 for v in core.values() if v == kmax)})
    for name, fn in (("cliques", lambda: cliques(G)), ("equivalence", lambda: equivalence(G, a.get("blocks"))),
                     ("core_periphery", lambda: (core_periphery(G), None))):
        if name not in which:
            continue
        if n > BIG:
            log.warning(f"{name}: skipped for {n:,} nodes (limit {BIG:,})")
            continue
        s, t = fn()
        summary.update(s)
        if t is not None:
            tables["block_image" if name == "equivalence" else name] = t
    return comms, summary, tables
