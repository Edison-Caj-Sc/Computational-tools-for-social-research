"""Corrections of 0.8.1: one test per fixed measure or behavior."""
import networkx as nx
import numpy as np
import pandas as pd
import pytest

from tejido import build, run
from tejido.analyze import node_measures
from tejido.filters import backbone
from tejido.groups import community_table
from tejido.io import read_table
from tejido.network import homophily, krackhardt, network_statistics, null_model, rewire, _simple

OUT = {"formats": []}


def test_krackhardt_hierarchy_counts_unordered_pairs():
    D = nx.DiGraph([("A", "B"), ("B", "C"), ("C", "A"), ("C", "D")])
    assert krackhardt(D)["hierarchy"] == 0.5             # 3 one-way pairs out of 6 reachable pairs
    assert krackhardt(nx.DiGraph([("a", "b"), ("b", "c")]))["hierarchy"] == 1


def test_coleman_and_group_ei_are_zero_under_random_mixing():
    R = nx.gnp_random_graph(400, 0.05, seed=1)
    for n in R:
        R.nodes[n]["g"] = "a" if n < 200 else "b"
    _, t = homophily(R, ["g"])
    assert t["coleman"].abs().max() < 0.06 and t["ei_index"].abs().max() < 0.06   # was about 0.3
    _, t = homophily(nx.Graph([(0, 1), (2, 3)]), [])        # no attributes: nothing to report
    assert t is None


def test_community_ei_from_the_members_side():
    G = nx.Graph([(1, 2), (2, 3), (3, 4)])
    t = community_table(G, [{1, 2}, {3, 4}])
    assert t.loc[0, "ei_index"] == round((1 - 2) / (1 + 2), 4)   # 1 internal tie (seen twice), 1 external


def test_closeness_centralization_only_where_freeman_holds():
    star = nx.star_graph(4)
    node_measures(star, ["closeness"], 1, {})
    s, _ = network_statistics(star, [], {}, 1)
    assert s["closeness_centralization"] == 1
    W = nx.Graph()
    W.add_weighted_edges_from([("a", "b", 5), ("a", "c", 5), ("a", "d", 5), ("d", "e", 1)])
    node_measures(W, ["closeness"], 1, {})
    assert "closeness_centralization" not in network_statistics(W, [], {}, 1)[0]
    D = nx.DiGraph([(i, 0) for i in range(1, 4)])
    node_measures(D, ["closeness"], 1, {})
    assert "closeness_centralization" not in network_statistics(D, [], {}, 1)[0]


def test_directed_harmonic_is_inward_like_closeness():
    D = nx.DiGraph([("a", "b"), ("a", "c"), ("a", "d"), ("b", "c")])
    node_measures(D, ["harmonic", "closeness"], 1, {})
    ref = nx.harmonic_centrality(D)
    for n in D:
        assert D.nodes[n]["harmonic"] == pytest.approx(ref[n] / 3, abs=1e-6)
    assert D.nodes["a"]["harmonic"] == 0 and D.nodes["a"]["out_harmonic"] == 1


def test_average_clustering_is_unweighted():
    K = nx.karate_club_graph()
    s, _ = network_statistics(K, [], {}, 1)
    assert s["average_clustering"] == round(nx.average_clustering(K), 4)


@pytest.mark.parametrize("directed", [False, True])
def test_rewiring_keeps_degrees_and_ties(directed):
    G = nx.gnm_random_graph(40, 120, seed=3, directed=directed)
    H = rewire(_simple(G), 7)
    assert H.number_of_edges() == G.number_of_edges() and nx.number_of_selfloops(H) == 0
    if directed:
        assert dict(H.in_degree()) == dict(G.in_degree()) and dict(H.out_degree()) == dict(G.out_degree())
    else:
        assert dict(H.degree()) == dict(G.degree())
    assert set(H.edges) != set(G.edges)


def test_null_model_compares_like_with_like():
    K = nx.karate_club_graph()                     # weighted: modularity must be unweighted on both sides
    _, t = null_model(K, [], {"model": "configuration", "n": 10}, 1)
    obs = t.set_index("measure")["observed"]
    assert obs["average_clustering"] == round(nx.average_clustering(K), 4)
    U = nx.Graph(K.edges())
    q = nx.community.modularity(U, nx.community.louvain_communities(U, seed=1))
    assert obs["modularity"] == round(q, 4)


def test_undirected_matrix_and_mirrored_lists_count_each_tie_once():
    sym = pd.DataFrame({"id": ["A", "B", "C"], "A": [0, 1, 0], "B": [1, 0, 3], "C": [0, 3, 0]})
    G = build(sym, "matrix", directed=False)
    assert G["A"]["B"]["weight"] == 1 and G["B"]["C"]["weight"] == 3
    assert not build(sym, "matrix", directed=False, threshold=2).has_edge("A", "B")
    asym = pd.DataFrame({"id": ["A", "B"], "A": [0, 2], "B": [1, 0]})
    assert build(asym, "matrix", directed=False, symmetrize="max")["A"]["B"]["weight"] == 2
    mirrored = pd.DataFrame({"source": ["A", "B", "B", "C"], "target": ["B", "A", "C", "B"], "w": [2, 2, 5, 5]})
    G = build(mirrored, "ties", directed=False, weight="w")
    assert G["A"]["B"]["weight"] == 2 and G["B"]["C"]["weight"] == 5
    assert build(mirrored, "ties", directed=False, weight="w", both_directions="add")["A"]["B"]["weight"] == 4
    records = pd.DataFrame({"source": ["A", "B", "A"], "target": ["B", "A", "C"]})   # not a mirror: records add up
    assert build(records, "ties", directed=False)["A"]["B"]["weight"] == 2
    assert build(records, "ties", directed=False, both_directions="once")["A"]["B"]["weight"] == 1


def test_time_does_not_refit_ergm_or_blockmodel():
    rng = np.random.default_rng(0)
    el = pd.DataFrame({"source": rng.integers(0, 20, 80).astype(str), "target": rng.integers(0, 20, 80).astype(str),
                       "t": rng.choice([2020, 2021], 80)})
    r = run({"builder": {"type": "ties"}, "analysis": {"ergm": {"terms": ["edges"], "gof": False},
                                                      "blockmodel": {"method": "concor"}},
             "time": {"column": "t"}, "output": OUT}, el)
    assert "ergm_terms" in r.summary and "blocks" in r.summary
    assert not [c for c in r.tables["evolution"].columns if c.startswith(("ergm", "block"))]


def test_blockmodel_replaces_equivalence():
    rng = np.random.default_rng(1)
    el = pd.DataFrame({"source": rng.integers(0, 25, 90).astype(str), "target": rng.integers(0, 25, 90).astype(str)})
    r = run({"builder": {"type": "ties"}, "analysis": {"groups": ["equivalence"], "blocks": 2,
                                                      "blockmodel": {"method": "concor", "blocks": 4}}, "output": OUT}, el)
    assert r.summary["blocks"] == len({d["block"] for _, d in r.graph.nodes(data=True)})


def test_only_self_loops_does_not_crash():
    r = run({"builder": {"type": "ties", "self_loops": True}, "analysis": {"group_centrality": "community"},
             "output": OUT}, pd.DataFrame({"source": ["a", "b"], "target": ["a", "b"]}))
    assert r.graph.number_of_nodes() == 2


def test_html_page_escapes_title_and_statistics(tmp_path):
    run({"project": "R&D", "builder": {"type": "ties"}, "output": {"dir": str(tmp_path), "formats": ["html"]}},
        pd.DataFrame({"source": ["x", "y"], "target": ["y", "z"]}))        # a name that is valid on Windows too
    page = (tmp_path / "R&D.html").read_text(encoding="utf-8")
    assert "<title>R&amp;D</title>" in page and "<h1>R&amp;D</h1>" in page


def test_semicolon_csv_with_thousands_dots(tmp_path):
    f = tmp_path / "t.csv"
    f.write_text("code;value;share\n060101;1.234,5;0,5\n060102;4;1,25\n", encoding="utf-8")
    df = read_table(f)
    assert df["value"].tolist() == [1234.5, 4.0] and df["share"].tolist() == [0.5, 1.25]


def test_directed_backbone_uses_out_and_in_strength():
    D = nx.DiGraph()
    D.add_weighted_edges_from([("a", "b", 10), ("a", "c", 1), ("a", "d", 1), ("a", "e", 1)])
    D.add_weighted_edges_from((f"x{i}", "a", 10) for i in range(10))
    assert backbone(D, 0.05).has_edge("a", "b")            # salient among a's outgoing ties


def test_transitions_entries_exits_starts_ends():
    df = pd.DataFrame({"u": [1, 1, 1, 2, 2], "t": [1, 2, 3, 1, 2], "s": ["A", "B", "B", "A", "C"]})
    G = build(df, "transitions", unit="u", order="t", state="s")
    b, a = G.nodes["B"], G.nodes["A"]
    assert (b["entries"], b["exits"], b["stays"], b["starts"], b["ends"]) == (1, 0, 1, 0, 1)
    assert (a["entries"], a["exits"], a["starts"], a["ends"]) == (0, 2, 2, 0)
