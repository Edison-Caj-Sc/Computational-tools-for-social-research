# Cambios

## 1.0.0 — versión oficial

Primera versión estable. Los archivos de configuración de 0.8 siguen funcionando sin cambios, con dos excepciones
documentadas abajo (expresiones de `filter`/`compute` y carpeta de resultados en la interfaz).

**Seguridad**
- **Expresiones verificadas**: `prepare.filter`, `prepare.compute` y `builder.filter` aceptan solo columnas, números, textos, comparaciones, aritmética, `and/or/not`, listas, métodos de columna y funciones matemáticas (`tejido/safe_expr.py`). Antes, un archivo de configuración recibido de otra persona podía ejecutar comandos en la computadora (por ejemplo con `@pd.io.common.os.system(...)`). Las columnas con espacios se escriben entre acentos graves: `` `tipo de relación` ``.
- **Sesión de la interfaz**: la página solo se abre desde la dirección de arranque que entrega el programa; luego el navegador guarda una cookie `HttpOnly; SameSite=Strict`. La dirección sola ya no muestra la página ni la clave. La clave viaja en una cabecera, nunca en las direcciones.
- **Servidor**: se comprueban `Host` (con puerto), `Origin` y `Sec-Fetch-Site`; política de seguridad de contenido sin scripts en línea; `X-Frame-Options`, `Referrer-Policy`, `nosniff`; las páginas de resultados se abren aisladas (sandbox); límites de tamaño para subidas (1 GB) y peticiones; solo se aceptan los tipos de archivo que el programa lee; solo se pueden abrir carpetas; los resultados de la interfaz quedan siempre dentro de la carpeta de trabajo.
- **Descargas y ZIP**: solo direcciones http(s), con límite de tamaño (300 MB); los ZIP, con un máximo de 200 tablas y 1 GB descomprimido. Los archivos temporales se borran al cerrar.
- **Archivos de resultados**: la página interactiva escapa todos los valores (un proyecto o un nodo llamado `__DATA__` ya no rompe la página); en Excel, los textos que empiezan con `=` se quedan como textos; nueva opción `output.escape_formulas` para los CSV; el nombre del proyecto ya no puede escribir fuera de la carpeta de resultados.
- Nuevo `SECURITY.md`.

**Registros**
- **Registro de actividad** (`logs/tejido.log` en la carpeta de trabajo; rotativo, 5 × 1 MB): sesiones, construcciones, archivos recibidos, errores con su traza y solicitudes rechazadas; nunca el contenido de los datos, y las claves se enmascaran. Se ve desde la interfaz (*Registro de actividad*), con `tejido logs` o desde la ventana de control.
- **Registro de ejecución**: cada resultado trae `<proyecto>_run.json` con la versión, las bibliotecas, la configuración, las huellas SHA-256 de los archivos de entrada y los archivos escritos (`output.run_record: false` lo desactiva).
- Línea de comandos: `--verbose`, `--quiet`, `--log-file ARCHIVO` y `tejido logs`. Los errores inesperados quedan en el registro antes de que el programa se detenga.

**Interfaz**
- **Aspecto renovado, de aplicación de trabajo**: barra superior en índigo oscuro con iconos en los botones; una sola familia tipográfica (la serif queda para la evidencia textual y la cita); etapas como pasos numerados sobre una línea de avance; los tipos de red como lista de opciones; el *Resumen* como hoja de medidas (rótulo sobre valor); ejemplos, archivos y tablas en paneles con filas; índigo para la acción principal (la cochinilla queda para la marca y los avisos); barra de estado más compacta. Sin cambios en el funcionamiento ni en los textos. Capturas del README actualizadas.
- Pie de página con el titular (© 2026 Angel Edison Ayala Velásquez), la licencia, la carpeta de trabajo y el registro de actividad.
- Diálogo *Acerca de*: autor y titular, cita lista para copiar, licencia, componentes de terceros y datos de la instalación.
- La barra de la red queda fija sobre el gráfico (antes flotaba y tapaba nodos); estado con color, barra de progreso y segundos; al recargar la página se retoma la construcción en curso o su resultado; Ctrl+Enter construye y Esc cierra paneles; la pestaña *Archivos* explica qué es cada archivo.
- La pestaña «Registro» pasa a llamarse «Mensajes», para no confundirla con el registro de actividad.
- Ventana de control en español o inglés, con botones para la carpeta de trabajo y el registro, y el titular.
- El ejecutable de Windows y el instalador muestran autor, versión y derechos de autor en sus propiedades, y llevan el icono de Tejido (`installer/tejido.ico`, generado con `tools/make_icon.py`).
- La ventana de control sigue el idioma de Windows (el de sus menús), como la interfaz sigue el del navegador.

**Correcciones**
- Columnas con espacios, tildes o que empiezan con número («tipo de relación», «2020»): daban `KeyError` en los atributos de vínculos y los atributos de nodos se renombraban en silencio a `_1`, `_2`.
- Afiliación sin ninguna coincidencia entre miembros: error interno de scipy.
- Años `2015:2020` (el formato que la propia interfaz propone para el Banco Mundial) o listas de años: error.
- Archivos vacíos, dañados, con contraseña o con una extensión que no es la suya: ahora un mensaje claro con el nombre del archivo. CSV en UTF-16 («Texto Unicode» de Excel): se leían como basura. JSON con `{"data": [...]}`: error.
- Banco Mundial: varios países separados por comas, códigos mal escritos y respuestas de error de la API.
- La barra de estado insertaba como HTML los mensajes de error, que pueden contener nombres de columnas del archivo.
- GraphML: un carácter de control en un texto (frecuente en texto extraído de PDF) detenía la exportación.
- Un paso de `prepare` mal escrito daba un error interno; ahora dice qué paso es y qué forma espera.
- Si un archivo de resultados está abierto en Excel, el mensaje lo dice. Las hojas de Excel ya no pueden repetir nombre.
- Ventana simple (`tejido gui`): tras un error mostraba los resultados de la ejecución anterior.
- Los ejemplos copiados a la carpeta de trabajo se renuevan cuando cambia la versión.
- Traducciones duplicadas en la interfaz.
- Instalador: el nombre del titular salía mal codificado («VelÃ¡squez») en sus propiedades y en *Agregar o quitar programas*; `tejido.nsi` se guarda ahora en UTF-8 con BOM.
- Ejecutable: el registro de ejecución no encontraba las versiones de las bibliotecas; `tejido --version` podía detenerse en consolas sin «©» o «á»; `tejido ui` no mostraba la dirección de arranque hasta cerrarse cuando la salida iba a un archivo.

**Compilación**
- Versiones fijadas en `installer/requirements-build.txt`: las bibliotecas con que pasan las pruebas y herramientas de compilación publicadas al menos dos semanas antes. Las usan `build_windows.bat`, `build_unix.sh` y GitHub Actions, que además corre las pruebas antes de compilar.

**Cambios que pueden afectar configuraciones existentes**
- Las expresiones con `@variable` o funciones de Python ya no se aceptan (ver arriba).
- En la interfaz, `output.dir` debe quedar dentro de la carpeta de trabajo; si no, los resultados van a `results/<proyecto>`. En la línea de comandos no cambia.

## 0.8.1 — correcciones de medidas

- **Jerarquía de Krackhardt**: se calcula sobre pares no ordenados; antes se subestimaba (en A→B→C→A más C→D daba 0,33 en lugar de 0,5).
- **Índice de Coleman y E-I por grupo** (tabla `homophily`) y **E-I de cada comunidad** (tabla `communities`): se cuentan desde los miembros, de modo que un vínculo interno cuenta para cada uno de sus dos extremos. Antes, con mezcla aleatoria, daban alrededor de ±0,3 en lugar de 0. Los vínculos con un nodo sin valor del atributo ya no entran en el cálculo.
- **Centralización de cercanía**: solo se informa donde la fórmula de Freeman es válida (redes no dirigidas, conexas y con distancias en pasos); con distancias ponderadas podía superar 1.
- **Cercanía armónica en redes dirigidas**: ahora mide la cercanía desde los demás, como `closeness`, y se añade `out_harmonic`.
- **Modelo nulo de configuración**: las redes aleatorias se obtienen recableando los vínculos observados, con los mismos grados (de entrada y de salida en redes dirigidas) y sin vínculos múltiples ni bucles; antes perdían vínculos y los z quedaban inflados. Las redes observada y aleatorias se comparan sin pesos, también la modularidad. Nueva opción `swaps`.
- **Agrupamiento medio** del resumen: sin pesos, como dice su explicación y como en el modelo nulo.
- **Matrices y listas en redes no dirigidas**: una matriz simétrica ya no duplica los pesos (y `threshold` se aplica al peso real); una no simétrica se combina con `symmetrize` (`sum` por defecto, `max`, `min`, `mean`). En listas, un vínculo escrito en ambos sentidos cuenta una vez cuando toda la lista está duplicada así (`both_directions: auto | once | add`).
- **Tiempo**: el ERGM y los modelos de bloques se estiman solo para la red completa, no en cada periodo.
- **Equivalencia y modelo de bloques a la vez**: si se pide `blockmodel`, `groups: equivalence` se omite, para que el resumen y los bloques de los nodos coincidan.
- **Redes degeneradas**: la centralidad de grupo ya no detiene el análisis (por ejemplo, con solo bucles).
- **Transiciones**: `entries` y `exits` cuentan ahora los movimientos desde y hacia otros estados; las trayectorias que empiezan o terminan en un estado pasan a `starts` y `ends`.
- **Filtro de columna vertebral en redes dirigidas**: usa la fuerza de salida del origen y la de entrada del destino.
- **CSV con punto y coma**: los números con punto de miles («1.234,5») se leen como números.
- **Página interactiva**: el título y el resumen se escapan como texto.
- 17 pruebas nuevas (`tests/test_corrections.py`).

## 0.8.0 — modelos de bloques y redes exponenciales

- **Modelos de bloques** (*Analizar → Modelo de bloques*, `analysis.blockmodel`): posiciones y roles de los nodos con cuatro métodos.
  - **CONCOR**: correlaciones iteradas de los perfiles de vínculos (Breiger, Boorman y Arabie 1975).
  - **Equivalencia estructural** por agrupamiento jerárquico.
  - **Blockmodeling generalizado** con bloques ideales nulos/completos (equivalencia estructural) o nulos/regulares (equivalencia regular), con búsqueda directa por transferencias e intercambios y varios inicios (Doreian, Batagelj y Ferligoj 2005).
  - **Modelo estocástico de bloques**, ajustado por máxima verosimilitud; sin número de bloques, se elige por ICL.
  - Cada nodo recibe su bloque (se puede colorear la red por bloque). Las tablas muestran los miembros, la imagen de densidades y, en el generalizado, el tipo de bloque ideal con sus inconsistencias. *Grupos* muestra la matriz de adyacencia ordenada por bloques.
- **Modelos exponenciales de grafos aleatorios (ERGM)** (*Analizar → Modelo exponencial*, `analysis.ergm`):
  - Términos con los nombres del paquete `ergm` de R: edges, mutual, triangles, ttriple, isolates, gwesp, gwdegree, gwidegree, gwodegree, nodematch, nodefactor, nodecov, absdiff, nodeicov y nodeocov.
  - Estimación por pseudoverosimilitud o por máxima verosimilitud con MCMC.
  - Bondad de ajuste comparando grados, socios compartidos y distancias con redes simuladas.
  - Nueva pestaña *Modelo* con los coeficientes, su significancia, qué significa cada término y los gráficos de bondad de ajuste.
- **Validado contra R**:
  - **ERGM:** los estadísticos y las estimaciones por pseudoverosimilitud coinciden con `ergm` 4.12.0 (statnet), hasta la sexta decimal, en las redes florentina y de Sampson. Las estimaciones por MCMC coinciden dentro del error de simulación.
  - **Blockmodeling:** las inconsistencias coinciden exactamente con `blockmodeling` 1.1.8 para la misma partición, y la búsqueda alcanza su mejor solución en 11 de 12 casos (en el otro queda a 1 inconsistencia).

## 0.7.1 — redes menos aglomeradas

- **Créditos y licencias**: se añade `LICENSE` (MIT), `THIRD_PARTY_NOTICES.md` y los textos de licencia de las bibliotecas incluidas en el ejecutable (`THIRD-PARTY-LICENSES.txt`); el instalador los copia junto al programa y muestra la licencia. El README acredita ahora los métodos, paletas y algoritmos usados.
- **Nombres que no se tapan**: si un nombre cubriría a un nodo o a un nombre más importante, se oculta, y reaparece al acercarse; al pasar el ratón sobre un nodo se ve siempre su nombre. Se puede desactivar en *Personalizar → Nombres → Ocultar nombres que se superponen*.
- **Espacio para los nombres**: al terminar el acomodo (o al pausarlo), los nodos se apartan lo justo para que quepan los nombres principales. Opción *Apartar nodos para que quepan los nombres*, en *Distribución y fondo*.
- **Nombres largos**: en varias líneas (nueva opción inicial), en una sola línea o abreviados («Cámara de Comercio…»); el nombre completo aparece al pasar el ratón.
- **Tamaños más parejos**: los nombres van de 10 a 18 px y no crecen más al acercarse; los nodos más grandes pasan de 38 a 30 px y las fuerzas evitan que se monten.
- **Áreas de los grupos**: no se dibuja el área de un grupo que está disperso entre otros (por ejemplo, tipos de actor repartidos por toda la red); las comunidades se siguen sombreando.
- El halo detrás de los nombres viene activado.
- Todo lo anterior también en la página interactiva de los resultados.

## 0.7.0 — la red, a tu gusto

- **Personalizar** (nuevo botón en *Red*): un panel para cambiar el aspecto de la red sin volver a construirla.
  - **Estilo rápido**: Sobrio, Póster, Impresión (blanco y negro), Apto para daltonismo y Noche.
  - **Nodos**: siete formas (círculo, cuadrado, triángulo, rombo, estrella, hexágono, triángulo invertido) o una forma según un atributo (por ejemplo, núcleo y periferia); seis paletas (Tejido, Textil andino, Okabe–Ito, Tierra, Pastel, Grises); tamaño mínimo y máximo, borde, opacidad, sombra y un anillo en los nodos más grandes.
  - **Nombres**: todos, solo los más grandes o al pasar el ratón; el texto puede ser el nombre, el nombre con su valor o cualquier atributo; tamaño y halo para leerlos sobre los vínculos.
  - **Vínculos**: gris, tinta, color del origen, mezcla de ambos extremos o color del grupo dentro de cada grupo; opacidad, grosor, trazo recto o curvo, tamaño de las flechas y peso visible.
  - **Distribución y fondo**: fuerzas, fuerzas compactas, círculo, anillos (los más grandes al centro), un círculo por grupo y niveles (jerarquía); separación; fondo como la interfaz, blanco, papel u oscuro.
- **Nuevos elementos visuales**: áreas sombreadas alrededor de cada grupo, con su nombre; color por medidas numéricas con degradado (índigo, viridis, calor, divergente) y su barra en la leyenda; leyenda de formas, de anillos y de la medida del tamaño.
- **Imagen**: descarga la red como PNG (de 1× a 4×), con leyenda y título si se desea.
- **El aspecto se conserva**: se recuerda en la computadora, se guarda en la configuración (`output.html.style`) y lo usa también la página interactiva de los resultados.
- Cambiar el color, el tamaño o el estilo ya no reacomoda la red; *Encuadrar* deja libre el espacio de los paneles abiertos.
- Página interactiva: los atributos numéricos (intermediación, PageRank…) se colorean con degradado en lugar de una categoría por valor.
- `build_windows.bat` incluye xlrd (archivos .xls) y arma el instalador si NSIS está instalado; el workflow de GitHub también genera el instalador de Windows.

## 0.6.1 — archivos del Banco Mundial en Excel y ZIP

- **Excel antiguo (.xls)**: el programa ya lee los archivos .xls (Excel 97-2003), como los que el Banco Mundial descarga en «Excel»; antes daban error. Se incluye la biblioteca xlrd.
- **ZIP**: también se puede subir el .zip que el Banco Mundial descarga en «CSV»; se usa la tabla de datos y se ignoran las de metadatos.
- **Un solo indicador**: cuando el archivo trae un indicador, los países se comparan por sus valores a lo largo de los años (antes se comparaba un único número y la red no tenía sentido).
- **Agregados**: «Países Bajos» ya no se confunde con un agregado; se reconocen más nombres de agregados del Banco Mundial en español (BIRF, AIF, Estados pequeños, África al sur del Sahara, situaciones de fragilidad…).

## 0.6.0 — interfaz rediseñada

- **Diseño más sobrio y legible**: nueva tipografía incluida en el programa (Instrument Sans para la interfaz y Newsreader para títulos y cifras), así se ve igual en cualquier computadora y sin internet; controles de altura uniforme, foco visible y colores revisados en modo claro y oscuro.
- **Etapas**: cada etapa muestra su resumen debajo del título; el hilo de la izquierda se teje (índigo) hasta la última etapa lista.
- **Inicio**: los ejemplos aparecen como un catálogo con el tipo de red de cada uno.
- **Red**: la barra de herramientas queda agrupada; los detalles de un nodo o vínculo se abren en un panel flotante que se cierra, así el gráfico usa todo el ancho; los colores de la red siguen el tema claro u oscuro.
- **Resumen**: las medidas se leen como una hoja de resultados; tablas con encabezado fijo y filas resaltadas.
- Correcciones: ya no aparece el texto «null» en Tablas ni en los detalles de un vínculo sin texto; «1 medida» en singular; al actualizar el programa el navegador ya no usa archivos guardados de la versión anterior.

## 0.5.0 — datos de indicadores de cualquier fuente

- **Datos de indicadores, no solo del Banco Mundial.** Tejido reconoce tablas de unidades (países, regiones, departamentos…) × indicadores × años de cualquier fuente: Banco Mundial (CSV, DataBank, Excel), CEPALSTAT, OCDE, FMI, Eurostat, Our World in Data, INEI o tablas propias. Acepta cuatro formatos: una columna por año, una fila por valor, una columna por indicador y una columna por unidad.
- **Archivos desordenados.** Encuentra el encabezado aunque haya títulos encima y notas debajo, elige la hoja de Excel con datos, entiende coma decimal y separadores de miles, marcas de faltantes (`..`, `-`, `n.d.`), marcas junto a los valores (`12,3 a/`), años como `2015 [YR2015]` o `2020 P/`, y columnas que dividen una serie (sexo, área…) o indican su unidad. Si el archivo tiene un solo indicador, toma su nombre del título del cuadro.
- **Agregados por nombre.** Mundo, regiones, grupos de ingreso, continentes, totales y promedios se detectan también por su nombre (en español e inglés), no solo por los códigos del Banco Mundial.
- **Interfaz.** En *Tabla → Origen de la tabla*, la opción *Datos de indicadores* reemplaza a *Archivo del Banco Mundial*. Una tabla que claramente es de indicadores cambia sola a esa opción, y *Cualquier tabla* la devuelve a tabla común sin perder el archivo. La vista previa explica qué se reconoció; *Ajustar cómo se reconocen los datos* permite corregirlo (formato, columnas, fila de encabezados, nombre del indicador, marcas de faltantes).
- **Tablas comunes con títulos o notas** también se leen.
- Nuevo ejemplo: *Países (datos de indicadores desordenados)*, con datos simulados en formato de exportación de CEPALSTAT.
- Las configuraciones anteriores (`worldbank_csv`, `preset: worldbank`) siguen funcionando y dan los mismos resultados.

## 0.4.2 — corrección de errores

- **CSV con punto y coma**: los archivos separados por `;` (Excel en español) ahora leen la coma decimal: `1500,5` es un número y no texto.
- **CSV de una sola columna**: ya no se parte el encabezado en columnas falsas (el separador se busca solo entre coma, punto y coma, tabulación y barra).
- **Excel antiguo (.xls)**: mensaje claro para guardarlo como .xlsx o CSV, en lugar de un error técnico.
- **Banco Mundial en línea**: la vista previa descargaba sin los códigos de indicador y mostraba 0 filas sin aviso; ahora descarga los indicadores y muestra el error real si no hay conexión. Sin indicadores, se avisa.
- **Red en pantalla**: "Ocultar vínculos débiles" ahora oculta los vínculos clasificados como débiles; el deslizador pasa a llamarse "Ocultar vínculos de bajo peso" y usa el rango real de pesos (antes forzaba 1 como mínimo o máximo).
- **Fuerza del vínculo**: ya no falla cuando la red solo tiene vínculos de un nodo consigo mismo.
- **Interfaz**: la etiqueta "Filas (casos)" ya no se reemplazaba por "Filas"; el servidor deja de mostrar errores cuando el navegador cierra o recarga la página a mitad de una respuesta.

## 0.4.1

- El investigador define qué valores son vínculos débiles (`weak_values`, `strong_values`, `weak_max`, `threshold`, `cut`).
- El Banco Mundial pasa a ser un origen dentro de **Tabla** (archivo CSV, reconocido automáticamente, o descarga en línea).
