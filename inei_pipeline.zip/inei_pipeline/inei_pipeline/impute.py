"""Imputación de datos faltantes con varias estrategias y registro transparente.

Nunca se pierde el dato original: con 'banderas: true' se crea <var>_imp (1 = imputado).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .utils import (ConfigError, as_list, expand_columns, groups, log, weighted_mean,
                    weighted_mode, weighted_quantile, weights_of)

METHODS = {"media", "mediana", "moda", "constante", "hotdeck", "knn", "iterativo", "interpolar"}


def _fill_stat(df, cols, rule, cfg, stat):
    w = weights_of(df, cfg, bool(rule.get("ponderado")))
    for c in cols:
        if stat in ("media", "mediana") and not pd.api.types.is_numeric_dtype(df[c]):
            raise ConfigError(f"No puedo usar '{stat}' con {c!r}, que no es numérica. Usa 'moda' o 'hotdeck'.")

        def compute(idx):
            v, ww = df.loc[idx, c], None if w is None else w.loc[idx]
            if stat == "media":
                return weighted_mean(v, ww)
            if stat == "mediana":
                return weighted_quantile(v, .5, ww)
            return weighted_mode(v, ww)

        overall = compute(df.index)
        for idx in groups(df, rule.get("por_grupo")):
            miss = idx[df.loc[idx, c].isna().to_numpy()]
            if len(miss):
                val = compute(idx)
                df.loc[miss, c] = overall if pd.isna(val) else val
    return df


def _hotdeck(df, cols, rule, cfg, rng):
    """Copia el valor de un donante al azar del mismo grupo (probabilidad ∝ peso si ponderado)."""
    w = weights_of(df, cfg, bool(rule.get("ponderado")))
    for c in cols:
        for idx in groups(df, rule.get("por_grupo")):
            vals = df.loc[idx, c]
            miss, donors = vals.index[vals.isna()], vals.dropna()
            if not len(miss):
                continue
            if donors.empty:
                donors = df[c].dropna()
                log.warning(f"  · hotdeck {c}: un grupo no tenía donantes; se usaron donantes de toda la base")
            p = None
            if w is not None:
                pw = w.loc[donors.index].fillna(0).to_numpy(float)
                p = pw / pw.sum() if pw.sum() > 0 else None
            df.loc[miss, c] = rng.choice(donors.to_numpy(), size=len(miss), replace=True, p=p)
    return df


def _numeric_matrix(df, cols, rule):
    preds = [p for p in expand_columns(df, rule.get("predictores")) if p not in cols]
    allc = cols + preds
    X = df[allc].apply(pd.to_numeric, errors="coerce")
    bad = [c for c in allc if X[c].notna().sum() == 0 and df[c].notna().sum() > 0]
    if bad:
        raise ConfigError(f"knn/iterativo requieren variables numéricas; revisa {bad} (crea dummies antes).")
    return X, preds


def _knn(df, cols, rule):
    from sklearn.impute import KNNImputer
    X, _ = _numeric_matrix(df, cols, rule)
    mu, sd = X.mean(), X.std().replace(0, 1)
    Z = KNNImputer(n_neighbors=int(rule.get("vecinos", 5))).fit_transform((X - mu) / sd)
    filled = pd.DataFrame(Z, index=X.index, columns=X.columns) * sd + mu
    for c in cols:
        df[c] = df[c].where(df[c].notna(), filled[c])
    return df


def _iterative(df, cols, rule, seed, stochastic):
    from sklearn.experimental import enable_iterative_imputer  # noqa: F401
    from sklearn.impute import IterativeImputer
    X, _ = _numeric_matrix(df, cols, rule)
    imp = IterativeImputer(max_iter=int(rule.get("max_iter", 10)), random_state=seed,
                           sample_posterior=stochastic)
    filled = pd.DataFrame(imp.fit_transform(X), index=X.index, columns=X.columns)
    for c in cols:
        df[c] = df[c].where(df[c].notna(), filled[c])
    return df


def _interpolate(df, cols, rule):
    """Interpolación lineal dentro de grupo ordenado (útil en paneles o series)."""
    orden = rule.get("ordenar_por", "anio")
    for c in cols:
        for idx in groups(df, rule.get("por_grupo")):
            sub = df.loc[idx].sort_values(orden)
            df.loc[sub.index, c] = pd.to_numeric(sub[c], errors="coerce").interpolate(limit_direction="both")
    return df


def impute(df: pd.DataFrame, cfg: dict, seed: int, stochastic: bool) -> tuple[pd.DataFrame, list[dict]]:
    icfg = cfg["imputar"]
    rng = np.random.default_rng(seed)
    report = []
    for rule in icfg.get("reglas") or []:
        metodo = rule.get("metodo")
        if metodo not in METHODS:
            raise ConfigError(f"Método de imputación desconocido {metodo!r}. Opciones: {sorted(METHODS)}")
        cols = expand_columns(df, rule.get("variables"), required=True)
        before = {c: int(df[c].isna().sum()) for c in cols}
        if icfg.get("banderas", True):
            for c in cols:
                if before[c] and f"{c}_imp" not in df.columns:
                    df[f"{c}_imp"] = df[c].isna().astype(int)
        if metodo in ("media", "mediana", "moda"):
            df = _fill_stat(df, cols, rule, cfg, metodo)
        elif metodo == "constante":
            for c in cols:
                df[c] = df[c].fillna(rule.get("valor", 0))
        elif metodo == "hotdeck":
            df = _hotdeck(df, cols, rule, cfg, rng)
        elif metodo == "knn":
            df = _knn(df, cols, rule)
        elif metodo == "iterativo":
            df = _iterative(df, cols, rule, seed, stochastic)
        else:
            df = _interpolate(df, cols, rule)
        for c in cols:
            after = int(df[c].isna().sum())
            report.append({"variable": c, "metodo": metodo, "por_grupo": ",".join(as_list(rule.get("por_grupo"))),
                           "faltantes_antes": before[c], "imputados": before[c] - after,
                           "faltantes_despues": after, "pct_imputado": round(100 * (before[c] - after) / len(df), 2)})
            log.info(f"  · {c}: {before[c] - after:,} valores imputados con {metodo}")
    return df, report


def impute_all(df: pd.DataFrame, cfg: dict) -> tuple[list[pd.DataFrame], list[dict]]:
    """Devuelve m bases imputadas (m > 1 = imputación múltiple)."""
    icfg = cfg["imputar"]
    if not icfg.get("reglas"):
        return [df], []
    m, seed = int(icfg.get("m", 1)), int(icfg.get("semilla", 2026))
    out, report = [], []
    for k in range(m):
        if m > 1:
            log.info(f"Imputación {k + 1} de {m}")
        d, r = impute(df.copy(), cfg, seed + k, stochastic=m > 1)
        out.append(d)
        report.extend({**x, "imputacion": k + 1} for x in r)
    return out, report
