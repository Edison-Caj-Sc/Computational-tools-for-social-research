"""Stage 4 · filter: keep the part of the network you want to analyze.

min_weight / max_weight · keep_edges {attribute: [values]} · backbone {alpha} (disparity filter for any
weighted network) · keep_nodes / drop_nodes {attribute: [values]} or a list of names · ego {nodes, radius}
· min_degree · k_core · remove_isolates · top_nodes · largest_component"""
from __future__ import annotations

import networkx as nx

from .utils import ConfigError, as_list, log, split_values


def _match(value, allowed: set) -> bool:
    return bool({str(v) for v in split_values(value)} & allowed) if value is not None else False


def _node_ids(G, names) -> list:
    """Node ids from ids or labels (case-insensitive)."""
    names = [str(x) for x in as_list(names)]
    by_label = {str(d.get("label", n)).lower(): n for n, d in G.nodes(data=True)}
    out = [n for n in G if str(n) in names]
    out += [by_label[x.lower()] for x in names if x.lower() in by_label and by_label[x.lower()] not in out]
    return out


def _node_rule(G, spec, keep: bool) -> list:
    if isinstance(spec, dict):
        sel = [n for n, d in G.nodes(data=True)
               if any(_match(d.get(attr), {str(v) for v in as_list(vals)}) for attr, vals in spec.items())]
    else:
        sel = _node_ids(G, spec)
    return [n for n in G if n not in sel] if keep else sel


def backbone(G: nx.Graph, alpha: float) -> nx.Graph:
    """Disparity filter (Serrano, Boguñá & Vespignani 2009) for any weighted network. A tie stays when it is salient
    for either end; in directed networks, among the outgoing ties of its source or the incoming ties of its target."""
    H = G.copy()
    if G.is_directed():
        ends = ((dict(G.out_degree(weight="weight")), dict(G.out_degree())),
                (dict(G.in_degree(weight="weight")), dict(G.in_degree())))
    else:
        ends = ((dict(G.degree(weight="weight")), dict(G.degree())),) * 2
    drop = []
    for u, v, w in G.edges(data="weight", default=1):
        w = float(w or 0)
        keep = False
        for x, (s, k) in zip((u, v), ends):
            if k[x] > 1 and s[x] > 0:
                p = w / s[x]
                keep |= (1 - p) ** (k[x] - 1) < alpha
        if not keep:
            drop.append((u, v))
    H.remove_edges_from(drop)
    return H


def apply_filters(G: nx.Graph, f: dict) -> nx.Graph:
    G = G.copy()
    f = f or {}
    n0, m0 = G.number_of_nodes(), G.number_of_edges()
    if f.get("min_weight") is not None:
        G.remove_edges_from([(u, v) for u, v, w in G.edges(data="weight", default=1) if w < float(f["min_weight"])])
    if f.get("max_weight") is not None:
        G.remove_edges_from([(u, v) for u, v, w in G.edges(data="weight", default=1) if w > float(f["max_weight"])])
    if f.get("keep_edges"):
        spec = f["keep_edges"]
        G.remove_edges_from([(u, v) for u, v, d in G.edges(data=True)
                             if not any(_match(d.get(a), {str(x) for x in as_list(vals)}) for a, vals in spec.items())])
    if f.get("backbone"):
        b = f["backbone"]
        G = backbone(G, float(b.get("alpha", .05) if isinstance(b, dict) else (.05 if b is True else b)))
    if f.get("keep_nodes"):
        G.remove_nodes_from(_node_rule(G, f["keep_nodes"], keep=True))
    if f.get("drop_nodes"):
        G.remove_nodes_from(_node_rule(G, f["drop_nodes"], keep=False))
    if f.get("ego"):
        e = f["ego"] if isinstance(f["ego"], dict) else {"nodes": f["ego"]}
        centers = _node_ids(G, e.get("nodes"))
        if not centers:
            raise ConfigError(f"filters.ego: none of {as_list(e.get('nodes'))} is in the network")
        U = G.to_undirected(as_view=True) if G.is_directed() else G
        keep = set()
        for c in centers:
            keep |= set(nx.single_source_shortest_path_length(U, c, cutoff=int(e.get("radius", 1))))
        G = G.subgraph(keep).copy()
    if f.get("min_degree") is not None:
        G.remove_nodes_from([n for n, d in G.degree() if d < int(f["min_degree"])])
    if f.get("k_core"):
        U = nx.Graph(G.to_undirected()) if G.is_directed() else nx.Graph(G)
        U.remove_edges_from(nx.selfloop_edges(U))
        G = G.subgraph(nx.k_core(U, int(f["k_core"])).nodes).copy()
    if f.get("remove_isolates", True):
        G.remove_nodes_from(list(nx.isolates(G)))
    if f.get("top_nodes"):
        top = sorted(G.degree(weight="weight"), key=lambda x: -x[1])[: int(f["top_nodes"])]
        G = G.subgraph([n for n, _ in top]).copy()
    if f.get("largest_component") and G.number_of_nodes():
        comps = nx.weakly_connected_components(G) if G.is_directed() else nx.connected_components(G)
        G = G.subgraph(max(comps, key=len)).copy()
    if (G.number_of_nodes(), G.number_of_edges()) != (n0, m0):
        log.info(f"Filters: {n0:,} → {G.number_of_nodes():,} nodes, {m0:,} → {G.number_of_edges():,} ties")
    if G.number_of_nodes() == 0:
        raise ConfigError("The network is empty after filtering. Relax 'filters'.")
    return G
