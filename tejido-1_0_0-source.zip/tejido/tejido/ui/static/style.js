/* Tejido network appearance: palettes, color scales, shapes, presets, static layouts and canvas decorations
   (group areas, rings). Shared by the visual interface and the exported interactive page. MIT, see LICENSE.
   Credits: "okabe" palette after Okabe & Ito (2008), Color Universal Design, https://jfly.uni-koeln.de/color/ ;
   "viridis" scale after Smith, van der Walt & Firing (2015), matplotlib colormap, CC0 ; convex hull by the monotone-chain
   algorithm of Andrew (1979), Information Processing Letters 9(5) ; drawing and the force layout come from vis-network
   (Apache-2.0 or MIT), after ForceAtlas2 (Jacomy et al. 2014). Other palettes, layouts, label selection and node
   separation were written for Tejido with standard techniques. */
(function (root) {
"use strict";
const TEJIDO = ["#283c7a", "#a61e44", "#c08f12", "#3f8f7a", "#7a4fa0", "#d0743c", "#4f86c6", "#8c6d3f", "#c1508f",
                "#5c8a3a", "#9aa3b8", "#6b2d3c", "#2f9fb3", "#e0a96d", "#55607a", "#b9a03a"];
const PALETTES = {
  tejido: TEJIDO,
  andean: ["#b5272d", "#e3a72f", "#2a6f97", "#3c8d5a", "#7b3f8c", "#e0662f", "#1f3b57", "#c2185b", "#8c6d3f", "#4fa3a5", "#d4b483", "#5e3023"],
  okabe: ["#0072b2", "#e69f00", "#009e73", "#d55e00", "#cc79a7", "#56b4e9", "#f0e442", "#7f7f7f"],
  earth: ["#7a5c3e", "#a8763e", "#5f7d4a", "#3e6e74", "#9c4a3c", "#c9a227", "#6d5a7b", "#8f8f6a", "#b07d62", "#4f5d75"],
  pastel: ["#8fa8e0", "#f4a3b5", "#e9c46a", "#9fd6c2", "#c3a6e0", "#f7b98c", "#a7c7e7", "#d9c6a5", "#b8d8a0", "#e6a0c4"],
  gray: ["#1b2030", "#6b7183", "#a3a8b6", "#3d4457", "#8a90a3", "#c9ccd5"]};
const SCALES = {indigo: ["#dfe4f3", "#8193cf", "#283c7a"], viridis: ["#440154", "#3b528b", "#21918c", "#5ec962", "#fde725"],
  heat: ["#fde3c3", "#f59e72", "#d2475b", "#7a1f5c"], diverging: ["#283c7a", "#d9dbe6", "#a61e44"], gray: ["#e2e4ea", "#1b2030"]};
const SHAPES = ["dot", "square", "triangle", "diamond", "star", "hexagon", "triangleDown"];
const GLYPH = {dot: "●", square: "■", triangle: "▲", diamond: "◆", star: "★", hexagon: "⬢", triangleDown: "▼"};
const BACKGROUNDS = {white: "#ffffff", paper: "#f6f1e7", dark: "#14161d"};
const SMOOTH = {straight: false, curved: {type: "curvedCW", roundness: 0.18}, smooth: {type: "continuous", roundness: 0.5}};
const DEFAULTS = {palette: "tejido", scale: "indigo", shape: "dot", shape_by: "", size_min: 6, size_max: 30, border: 1,
  border_color: "darker", node_opacity: 100, shadow: false, top_ring: 0,
  labels: "all", label_top: 20, label_by: "", label_size: 100, label_halo: true, label_long: "wrap", declutter: true, label_adjust: true,
  edge_color: "neutral", edge_opacity: 45, edge_width: 100, curve: "straight", arrow_size: 50, edge_labels: false,
  layout: "force", spacing: 110, background: "theme", halos: false, png_scale: 2, png_legend: true, png_title: false};
const OPTIONS = {palette: Object.keys(PALETTES), scale: Object.keys(SCALES), shape: SHAPES, border_color: ["darker", "background", "ink"],
  labels: ["all", "top", "hover", "none"], label_long: ["full", "wrap", "short"], edge_color: ["neutral", "ink", "source", "gradient", "group"], curve: Object.keys(SMOOTH),
  layout: ["force", "compact", "circle", "rings", "groups", "hierarchical"], background: ["theme", "white", "paper", "dark"]};
const RANGES = {size_min: [2, 30, 1], size_max: [10, 90, 1], border: [0, 6, 0.5], node_opacity: [20, 100, 5], top_ring: [0, 20, 1],
  label_top: [5, 50, 5], label_size: [60, 200, 10], edge_opacity: [5, 100, 5], edge_width: [20, 300, 10], arrow_size: [0, 150, 10],
  spacing: [40, 300, 10], png_scale: [1, 4, 1]};
const PRESETS = {
  sober: {},
  poster: {border: 2, border_color: "background", shadow: true, curve: "curved", edge_color: "source", edge_opacity: 55,
           label_halo: true, halos: true, size_max: 40},
  print: {palette: "gray", scale: "gray", border: 1.5, border_color: "ink", edge_color: "ink", edge_opacity: 55, background: "white", label_halo: true},
  accessible: {palette: "okabe", scale: "viridis", border: 1.5, label_halo: true, label_size: 115},
  night: {palette: "pastel", scale: "viridis", background: "dark", edge_color: "gradient", edge_opacity: 40, shadow: true, label_halo: true, curve: "smooth"}};
// A preset changes the look, not what the picture shows.
const PRESET_KEEPS = ["shape_by", "label_by", "labels", "label_top", "label_long", "declutter", "label_adjust", "top_ring", "edge_labels",
  "layout", "spacing", "png_scale", "png_legend", "png_title"];

function clean(s) {                      // defaults + only known keys, valid options and numbers in range
  const out = {...DEFAULTS};
  if (!s || typeof s !== "object") return out;
  for (const [k, d] of Object.entries(DEFAULTS)) {
    let v = s[k];
    if (v === undefined || v === null) continue;
    if (typeof d === "number") { v = Number(v); if (!Number.isFinite(v)) continue; const r = RANGES[k]; if (r) v = Math.min(r[1], Math.max(r[0], v)); }
    else if (typeof d === "boolean") v = v === true || v === "true";
    else { v = String(v); if (OPTIONS[k] && !OPTIONS[k].includes(v)) continue; }
    out[k] = v;
  }
  if (out.size_max < out.size_min) out.size_max = out.size_min;
  return out;
}
function diff(s) { const c = clean(s); return Object.fromEntries(Object.entries(c).filter(([k, v]) => v !== DEFAULTS[k])); }
function preset(name, cur) {
  const keep = Object.fromEntries(PRESET_KEEPS.map(k => [k, (cur || {})[k]]).filter(([, v]) => v !== undefined));
  return clean({...DEFAULTS, ...(PRESETS[name] || {}), ...keep});
}

const hex = c => { c = String(c).trim().replace("#", ""); if (c.length === 3) c = [...c].map(x => x + x).join("");
  return [0, 2, 4].map(i => parseInt(c.slice(i, i + 2), 16) || 0); };
const toHex = rgb => "#" + rgb.map(v => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, "0")).join("");
const mix = (a, b, t) => { const x = hex(a), y = hex(b); return toHex(x.map((v, i) => v + (y[i] - v) * t)); };
const alpha = (c, a) => toHex(hex(c)) + Math.round(Math.max(0, Math.min(1, a)) * 255).toString(16).padStart(2, "0");
const isDark = c => { const [r, g, b] = hex(c); return 0.299 * r + 0.587 * g + 0.114 * b < 128; };
function ramp(stops, t) {
  t = Math.max(0, Math.min(1, Number.isFinite(t) ? t : 0.5));
  const k = t * (stops.length - 1), i = Math.min(Math.floor(k), stops.length - 2);
  return mix(stops[i], stops[i + 1], k - i);
}
function palette(name, dark) {              // the Tejido palette follows light or dark backgrounds
  const p = PALETTES[name] || TEJIDO;
  return name === "tejido" && dark ? ["#9fb1ee", "#ec6f8d", ...p.slice(2)] : p;
}
function colors(st, themeBg) {               // background, ink and accents for a style
  const bg = st.background === "theme" ? (themeBg || "#ffffff") : BACKGROUNDS[st.background];
  const dark = isDark(bg);
  return {bg, dark, ink: dark ? "#e8e9ef" : "#1b2030", muted: dark ? "#a0a6b8" : "#5b6275", neutral: "#8a90a6", red: dark ? "#ec6f8d" : "#a61e44"};
}
function nodeColor(c, st, col) {
  const fill = st.node_opacity < 100 ? alpha(c, st.node_opacity / 100) : c;
  const border = st.border_color === "background" ? col.bg : st.border_color === "ink" ? col.ink : mix(c, col.dark ? "#ffffff" : "#000000", 0.3);
  return {background: fill, border, highlight: {background: fill, border: col.ink}, hover: {background: fill, border: col.ink}};
}
function dimColor(c, st, col) {
  const n = nodeColor(c, st, col), f = x => alpha(x, 0.18);
  return {background: f(c), border: f(n.border), highlight: n.highlight, hover: n.hover};
}
function font(show, st, col, faded) {
  if (!show) return {color: "rgba(0,0,0,0)", strokeWidth: 0};
  return {color: faded ? alpha(col.ink, 0.3) : col.ink, strokeWidth: st.label_halo && !faded ? 4 : 0, strokeColor: col.bg};
}
function shortName(text, max = 26) {        // "Cámara de Comercio y Producción de Cajamarca" → "Cámara de Comercio…"
  const s = String(text);
  if (s.length <= max) return s;
  let cut = s.slice(0, max - 1), sp = cut.lastIndexOf(" ");
  if (sp > max * 0.45) cut = cut.slice(0, sp);
  cut = cut.replace(/(?:\s+(?:de|del|la|las|los|el|y|e|en|para|a|al|of|the|and|for|in))+\s*$/i, "").replace(/[\s,.;:–-]+$/, "");
  return cut + "…";
}
function shapeMap(values) {                  // most frequent value first → circle, then square, triangle…
  const counts = {}; values.forEach(v => { counts[v] = (counts[v] || 0) + 1; });
  return Object.fromEntries(Object.keys(counts).sort((a, b) => counts[b] - counts[a]).map((k, i) => [k, SHAPES[i % SHAPES.length]]));
}
function options(st, col, directed, big) {    // vis-network options for a style (physics and layout are set by the caller)
  const k = st.label_size / 100;
  return {
    nodes: {shape: st.shape, borderWidth: st.border, borderWidthSelected: st.border + 1.5,
            shadow: st.shadow ? {enabled: true, color: col.dark ? "rgba(0,0,0,.65)" : "rgba(27,32,48,.28)", size: 9, x: 0, y: 2} : false,
            // names grow less than nodes and never above 18 px on screen: zooming in makes room between them
            scaling: {min: st.size_min, max: st.size_max, label: {enabled: true, min: 10 * k, max: 18 * k, maxVisible: 18 * k, drawThreshold: 5}},
            widthConstraint: st.label_long === "wrap" ? {maximum: Math.round(150 * k)} : false,
            font: {face: "Instrument Sans, system-ui, sans-serif", color: col.ink}},
    edges: {smooth: SMOOTH[st.curve], selectionWidth: 1.5, arrows: {to: {enabled: !!directed, scaleFactor: st.arrow_size / 100}},
            font: {size: 10 * k, color: col.muted, strokeWidth: 3, strokeColor: col.bg, align: "middle", face: "Instrument Sans, system-ui, sans-serif"}},
    interaction: {hover: true, tooltipDelay: 150, hideEdgesOnDrag: true}};
}
function physics(st, big) {
  const it = {iterations: big ? 150 : 300};
  if (st.layout === "compact") return {solver: "barnesHut", barnesHut: {gravitationalConstant: -2500, centralGravity: 0.8, springLength: st.spacing * 0.6, avoidOverlap: 0.5}, stabilization: it};
  return {solver: "forceAtlas2Based", forceAtlas2Based: {gravitationalConstant: -50, springLength: st.spacing, avoidOverlap: 0.5}, stabilization: it};
}
function hierarchical(st, directed) {
  return {hierarchical: {direction: "UD", sortMethod: directed ? "directed" : "hubsize", levelSeparation: st.spacing * 1.3, nodeSpacing: st.spacing}};
}
function edgeColor(st, col, fromColor, sameGroup) {
  const op = st.edge_opacity / 100;
  switch (st.edge_color) {
    case "ink": return {color: col.ink, opacity: op};
    case "source": return {color: fromColor, opacity: op};
    case "gradient": return st.border_color === "darker" ? {inherit: "both", opacity: op} : {color: fromColor, opacity: op};  // vis blends border colors
    case "group": return sameGroup ? {color: fromColor, opacity: Math.min(1, op + 0.25)} : {color: col.neutral, opacity: op * 0.45};
    default: return {color: col.neutral, opacity: op};
  }
}

function groupsOf(nodes) {
  const m = new Map();
  nodes.forEach(d => { const k = d.group == null ? "" : String(d.group); if (!m.has(k)) m.set(k, []); m.get(k).push(d); });
  return [...m.entries()].map(([name, members]) => ({name, members: members.sort((a, b) => b.value - a.value)}))
    .sort((a, b) => b.members.length - a.members.length);
}
function layout(nodes, st) {                 // fixed positions for circle, rings and one-circle-per-group; null for the others
  const L = st.layout, sp = st.spacing, out = {};
  if (!["circle", "rings", "groups"].includes(L) || !nodes.length) return null;
  const circle = (list, cx, cy, r, start) => list.forEach((d, i) => {
    const a = (start ?? -Math.PI / 2) + 2 * Math.PI * i / list.length; out[d.id] = {x: cx + r * Math.cos(a), y: cy + r * Math.sin(a)}; });
  if (L === "circle") {
    circle(groupsOf(nodes).flatMap(g => g.members), 0, 0, Math.max(120, nodes.length * sp * 0.8 / (2 * Math.PI)));
  } else if (L === "rings") {                // the largest in the center, then concentric rings
    const list = [...nodes].sort((a, b) => b.value - a.value), gap = sp;
    for (let i = 0, k = 0; i < list.length; k++) {
      const cap = k === 0 ? 1 : Math.max(6, Math.floor(2 * Math.PI * k * gap / (sp * 0.8)));
      circle(list.slice(i, i + cap), 0, 0, k * gap, -Math.PI / 2 + k * 0.37); i += cap;
    }
  } else {                                   // each group in its own circle, packed in rows
    const gs = groupsOf(nodes).map(g => ({...g, r: g.members.length === 1 ? 0 : Math.max(sp * 0.35, g.members.length * sp * 0.8 / (2 * Math.PI))}));
    const cell = g => 2 * g.r + sp * 0.9, W = Math.sqrt(gs.reduce((a, g) => a + cell(g) ** 2, 0)) * 1.15;
    let x = 0, y = 0, rowH = 0;
    gs.forEach(g => {
      const c = cell(g); if (x > 0 && x + c > W) { x = 0; y += rowH; rowH = 0; }
      const cx = x + c / 2, cy = y + c / 2, m = g.members;
      if (m.length > 5) { out[m[0].id] = {x: cx, y: cy}; circle(m.slice(1), cx, cy, g.r); } else circle(m, cx, cy, g.r);
      x += c; rowH = Math.max(rowH, c);
    });
  }
  const ps = Object.values(out), mx = ps.reduce((a, p) => a + p.x, 0) / ps.length, my = ps.reduce((a, p) => a + p.y, 0) / ps.length;
  ps.forEach(p => { p.x -= mx; p.y -= my; });
  return out;
}

/* ---- fewer crowded names ----
   Boxes are in network units: node circle of radius r at (x, y) and, below it, its name (w × h), as vis-network draws it. */
const GAP = 3;
function boxes(net, ids, wantLabel, grow) {
  const body = net.body.nodes, scale = net.getScale(), out = [];
  for (const id of ids) {
    const n = body[id]; if (!n || n.options.hidden) continue;
    const L = n.labelModule, s = L && L.size, thr = ((n.options.scaling || {}).label || {}).drawThreshold || 5;
    const drawn = wantLabel(id) && s && s.width > 0 && L.fontOptions.size * scale >= thr;
    out.push({id, x: n.x, y: n.y, r: (n.options.size || 10) + (grow ? grow(id) : 0), w: drawn ? s.width : 0, h: drawn ? s.height : 0});
  }
  return out;
}
function pickLabels(items, want, pad = 2) {   // items by priority: a name is shown if it does not cover a name or node shown before
  const placed = [], show = new Set();
  const hit = b => placed.some(p => b.l < p.r && p.l < b.r && b.t < p.b && p.t < b.b);
  for (const it of items) {
    if (want.has(it.id) && it.w > 0) {
      const b = {l: it.x - it.w / 2 - pad, r: it.x + it.w / 2 + pad, t: it.y + it.r + GAP - pad, b: it.y + it.r + GAP + it.h + pad};
      if (!hit(b)) { placed.push(b); show.add(it.id); }
    }
    placed.push({l: it.x - it.r, r: it.x + it.r, t: it.y - it.r, b: it.y + it.r});
  }
  return show;
}
function spread(items, pad = 6, iterations = 80) {   // moves nodes apart until node + name boxes do not overlap (label adjust)
  const B = items.map(it => ({it, w: Math.max(2 * it.r, it.w), h: 2 * it.r + (it.w > 0 ? GAP + it.h : 0), cy: it.w > 0 ? (GAP + it.h) / 2 : 0}));
  for (let k = 0; k < iterations; k++) {
    let moved = 0;
    B.sort((a, b) => (a.it.x - a.w / 2) - (b.it.x - b.w / 2));
    for (let i = 0; i < B.length; i++) {
      const a = B[i], right = a.it.x + a.w / 2 + pad;
      for (let j = i + 1; j < B.length; j++) {
        const b = B[j]; if (b.it.x - b.w / 2 > right) break;
        const ay = a.it.y + a.cy, by = b.it.y + b.cy;
        const ox = (a.w + b.w) / 2 + pad - Math.abs(a.it.x - b.it.x), oy = (a.h + b.h) / 2 + pad - Math.abs(ay - by);
        if (ox <= 0 || oy <= 0) continue;
        moved++;
        if (ox < oy) { const d = (ox / 2 + 0.01) * (a.it.x <= b.it.x ? 1 : -1); a.it.x -= d; b.it.x += d; }
        else { const d = (oy / 2 + 0.01) * (ay <= by ? 1 : -1); a.it.y -= d; b.it.y += d; }
      }
    }
    if (!moved) break;
  }
  return items;
}
function mainLabels(order, named) {          // room is made for the names of the largest nodes only; zooming in shows the rest
  const ids = order.filter(id => named.has(id)), k = Math.max(15, Math.round(ids.length * 0.25));
  const top = new Set(ids.slice(0, k)); return id => top.has(id);
}
function spreadNet(net, ids, wantLabel, grow) {
  const items = boxes(net, ids, wantLabel, grow), before = items.map(it => [it.x, it.y]);
  spread(items);
  items.forEach((it, i) => { if (it.x !== before[i][0] || it.y !== before[i][1]) net.moveNode(it.id, it.x, it.y); });
}

function hull(pts) {                         // convex hull (monotone chain)
  const p = [...pts].sort((a, b) => a.x - b.x || a.y - b.y);
  if (p.length < 3) return p;
  const cross = (o, a, b) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x), lo = [], up = [];
  for (const q of p) { while (lo.length >= 2 && cross(lo[lo.length - 2], lo[lo.length - 1], q) <= 0) lo.pop(); lo.push(q); }
  for (const q of p.reverse()) { while (up.length >= 2 && cross(up[up.length - 2], up[up.length - 1], q) <= 0) up.pop(); up.push(q); }
  return lo.slice(0, -1).concat(up.slice(0, -1));
}
function inside(poly, p) {                    // point in convex polygon
  let sign = 0;
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length], c = (b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x);
    if (c !== 0) { if (sign && Math.sign(c) !== sign) return false; sign = Math.sign(c); }
  }
  return true;
}
function drawHalos(ctx, net, groups) {       // groups: [{ids, color, label}] → soft area around each group
  const pos = net.getPositions(), body = net.body.nodes, owner = new Map();
  groups.forEach((g, k) => g.ids.forEach(id => owner.set(String(id), k)));
  for (const [k, g] of groups.entries()) {
    const centers = g.ids.map(id => pos[id] && body[id] && !body[id].options.hidden &&
      {x: pos[id].x, y: pos[id].y, r: (body[id].options.size || 10) + 14}).filter(Boolean);
    if (!centers.length) continue;
    const ring = [];
    hull(centers).forEach(p => { for (let i = 0; i < 16; i++) { const a = i * Math.PI / 8; ring.push({x: p.x + p.r * Math.cos(a), y: p.y + p.r * Math.sin(a)}); } });
    const poly = hull(ring);
    // a group scattered among others is not an area: skip it when it encloses other groups' nodes, at least half as many as its own
    let others = 0;
    for (const [id, p] of Object.entries(pos)) if (owner.get(id) !== k && inside(poly, p)) others++;
    if (others * 2 >= centers.length && others > 0) continue;
    ctx.save(); ctx.beginPath();
    poly.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)); ctx.closePath();
    ctx.fillStyle = alpha(g.color, 0.12); ctx.fill();
    ctx.lineWidth = 1.5; ctx.strokeStyle = alpha(g.color, 0.5); ctx.stroke();
    if (g.label) {
      const top = poly.reduce((a, p) => p.y < a.y ? p : a);
      ctx.font = "600 14px Instrument Sans, system-ui, sans-serif"; ctx.textAlign = "center"; ctx.fillStyle = alpha(g.color, 0.95);
      ctx.fillText(g.label, top.x, top.y - 7);
    }
    ctx.restore();
  }
}
function drawRings(ctx, net, ids, color) {   // a ring around highlighted nodes
  if (!ids || !ids.length) return;
  const pos = net.getPositions(ids), body = net.body.nodes;
  ctx.save(); ctx.strokeStyle = color; ctx.lineWidth = 2.5;
  ids.forEach(id => { const p = pos[id], b = body[id]; if (!p || !b || b.options.hidden) return;
    ctx.beginPath(); ctx.arc(p.x, p.y, (b.options.size || 10) + 6, 0, 2 * Math.PI); ctx.stroke(); });
  ctx.restore();
}

root.TejidoStyle = {PALETTES, SCALES, SHAPES, GLYPH, BACKGROUNDS, DEFAULTS, OPTIONS, RANGES, PRESETS, clean, diff, preset,
  mix, alpha, ramp, isDark, palette, colors, nodeColor, dimColor, font, shortName, shapeMap, options, physics, hierarchical, edgeColor,
  layout, boxes, pickLabels, spread, mainLabels, spreadNet, hull, drawHalos, drawRings};
})(typeof window !== "undefined" ? window : globalThis);
