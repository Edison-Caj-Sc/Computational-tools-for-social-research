"""Stage 2 · prepare: reshape and clean the data before building the network.

'prepare' is a list of steps applied in order; each step is a one-key mapping, e.g.
  prepare:
    - filter: "year >= 2015 and region == 'Cajamarca'"
    - recode: {sex: {1: man, 2: woman}}
    - split: {authors: ";"}
Run 'tejido list steps' to see them all."""
from __future__ import annotations

import fnmatch

import pandas as pd

from .utils import ConfigError, as_list, log, require_columns

STEPS: dict = {}


def step(name: str, description: str):
    def deco(fn):
        STEPS[name] = (fn, description)
        return fn
    return deco


def _cols(df, spec) -> list:
    """Column names or patterns ('q_*') → existing columns."""
    out = []
    for p in as_list(spec):
        hits = [c for c in df.columns if fnmatch.fnmatch(str(c), str(p))] if any(ch in str(p) for ch in "*?[") else [p]
        out += [h for h in hits if h not in out]
    require_columns(df, out, "prepare")
    return out


@step("filter", "Keep rows matching an expression: \"year >= 2015 and region == 'Lima'\"")
def _filter(df, arg, cfg):
    from .safe_expr import query
    return query(df, arg, "prepare.filter")


@step("select", "Keep only these columns (names or patterns like 'q_*')")
def _select(df, arg, cfg):
    return df[_cols(df, arg)]


@step("drop", "Remove these columns")
def _drop(df, arg, cfg):
    return df.drop(columns=_cols(df, arg))


@step("rename", "Rename columns: {old: new}")
def _rename(df, arg, cfg):
    require_columns(df, list(arg), "prepare.rename")
    return df.rename(columns=arg)


@step("recode", "Replace values: {column: {old: new}}; unlisted values stay")
def _recode(df, arg, cfg):
    df = df.copy()
    for col, mapping in arg.items():
        require_columns(df, col, "prepare.recode")
        m = {**{str(k): v for k, v in mapping.items()}, **mapping}
        df[col] = df[col].map(lambda v, m=m: m.get(v, m.get(str(v), v)) if pd.notna(v) else v)
    return df


@step("compute", "New columns from expressions: {income_pc: \"income / members\"}")
def _compute(df, arg, cfg):
    from .safe_expr import evaluate
    df = df.copy()
    for col, expr in arg.items():
        df[str(col)] = evaluate(df, expr, "prepare.compute")
    return df


@step("dropna", "Drop rows with missing values (in these columns, or in any column if true)")
def _dropna(df, arg, cfg):
    return df.dropna() if arg is True else df.dropna(subset=_cols(df, arg))


@step("fillna", "Fill missing values: {column: value}")
def _fillna(df, arg, cfg):
    require_columns(df, list(arg), "prepare.fillna")
    return df.fillna(arg)


@step("split", "Several values in one cell → one row each: {authors: \";\"}")
def _split(df, arg, cfg):
    for col, sep in arg.items():
        require_columns(df, col, "prepare.split")
        df = df.assign(**{col: df[col].astype("string").str.split(str(sep))}).explode(col)
        df[col] = df[col].str.strip()
        df = df[df[col].notna() & (df[col] != "")]
    return df.reset_index(drop=True)


@step("to_long", "Wide → long: {id: [person], columns: ['q_*'], name: variable, value: value}")
def _to_long(df, arg, cfg):
    ids = _cols(df, arg.get("id"))
    vals = _cols(df, arg.get("columns")) if arg.get("columns") else [c for c in df.columns if c not in ids]
    return df.melt(id_vars=ids, value_vars=vals, var_name=arg.get("name", "variable"),
                   value_name=arg.get("value", "value"))


@step("to_wide", "Long → wide: {index: [country], columns: indicator, values: value, agg: mean}")
def _to_wide(df, arg, cfg):
    require_columns(df, as_list(arg.get("index")) + [arg.get("columns"), arg.get("values")], "prepare.to_wide")
    out = df.pivot_table(index=as_list(arg["index"]), columns=arg["columns"], values=arg["values"],
                         aggfunc=arg.get("agg", "mean"))
    out.columns = [str(c) for c in out.columns]
    return out.reset_index()


@step("merge", "Join another table: {path: regions.csv, on: district, how: left}")
def _merge(df, arg, cfg):
    from .config import resolve
    from .io import read_table
    other = read_table(resolve(cfg or {}, arg["path"]), arg.get("sheet"))
    on = as_list(arg.get("on"))
    require_columns(df, on, "prepare.merge (this table)")
    require_columns(other, on, "prepare.merge (other table)")
    return df.merge(other, on=on, how=arg.get("how", "left"))


@step("bin", "Numbers → categories: {column: age, bins: [0, 30, 60, 120], labels: [young, adult, older], into: age_group}")
def _bin(df, arg, cfg):
    col = arg["column"]
    require_columns(df, col, "prepare.bin")
    bins = arg.get("bins", 4)
    x = pd.to_numeric(df[col], errors="coerce")
    cut = pd.qcut(x, bins, labels=arg.get("labels"), duplicates="drop") if arg.get("quantiles") else \
        pd.cut(x, bins, labels=arg.get("labels"), include_lowest=True)
    return df.assign(**{arg.get("into", col): cut.astype("string")})


@step("datetime", "Parse dates: {date: \"%d/%m/%Y\"} (null = guess the format)")
def _datetime(df, arg, cfg):
    df = df.copy()
    for col, fmt in (arg.items() if isinstance(arg, dict) else ((c, None) for c in as_list(arg))):
        require_columns(df, col, "prepare.datetime")
        df[col] = pd.to_datetime(df[col], format=fmt, errors="coerce")
    return df


@step("deduplicate", "Drop repeated rows (considering these columns, or all if true)")
def _dedup(df, arg, cfg):
    return df.drop_duplicates() if arg is True else df.drop_duplicates(subset=_cols(df, arg))


@step("sample", "Random sample: 500 rows, or {n: 500, seed: 1}, or {fraction: 0.1}")
def _sample(df, arg, cfg):
    a = arg if isinstance(arg, dict) else {"n": arg}
    if a.get("fraction"):
        return df.sample(frac=float(a["fraction"]), random_state=a.get("seed", 2026))
    return df.sample(n=min(int(a["n"]), len(df)), random_state=a.get("seed", 2026))


@step("clean_text", "Trim spaces and optionally lowercase: {columns: [name], lowercase: true}")
def _clean_text(df, arg, cfg):
    a = arg if isinstance(arg, dict) else {"columns": arg}
    df = df.copy()
    for c in _cols(df, a.get("columns")):
        s = df[c].astype("string").str.strip().str.replace(r"\s+", " ", regex=True)
        df[c] = s.str.lower() if a.get("lowercase") else s
    return df


@step("worldbank", "Indicator data (World Bank or similar) → one row per unit: {year: latest, indicators: [...]}")
def _worldbank(df, arg, cfg):
    from .io import worldbank_wide
    return worldbank_wide(df, arg if isinstance(arg, dict) else {})


def prepare(df: pd.DataFrame, steps, cfg: dict | None = None) -> pd.DataFrame:
    for i, s in enumerate(as_list(steps), 1):
        if not isinstance(s, dict) or len(s) != 1:
            raise ConfigError(f"prepare step {i} must be a one-key mapping like '- filter: \"x > 0\"'")
        name, arg = next(iter(s.items()))
        if name not in STEPS:
            raise ConfigError(f"Unknown prepare step {name!r}. Options: {sorted(STEPS)}")
        n0 = len(df)
        try:
            df = STEPS[name][0](df, arg, cfg)
        except ConfigError:
            raise
        except Exception as e:                       # a wrong shape of the step (text where a mapping goes…)
            raise ConfigError(f"prepare step {i} ({name}): {type(e).__name__}: {e}. "
                              f"Expected: {STEPS[name][1]}") from e
        log.info(f"prepare · {name}: {n0:,} → {len(df):,} rows, {df.shape[1]} columns")
    return df
