# Ejecuta este archivo una sola vez para instalar los paquetes que usan las plantillas.
source("utilidades.R")
instalar_si_falta()
cat("Listo: paquetes instalados y cargados.\n")
