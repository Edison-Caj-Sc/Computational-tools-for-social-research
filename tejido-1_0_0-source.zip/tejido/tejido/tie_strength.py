"""Strong and weak ties (Granovetter 1973).

analysis:
  tie_strength:
    by: auto        # auto | weight | overlap | composite | <tie attribute> (e.g. closeness, frequency)
    components: [weight, overlap, reciprocity, multiplexity]   # for composite (auto uses those that vary)
    levels: 2       # 2: strong / weak · 3: strong / intermediate / weak
    cut: 0.5        # quantile of the index that separates weak from strong (levels: 2)
    threshold: 3    # optional: strong when the raw value of 'by' reaches it (e.g. closeness 3 = very close)
    weak_max: 2     # optional: weak when the raw value of 'by' is at most this (with threshold: values between are intermediate)
    weak_values: [1, 2]        # optional: the values of 'by' the researcher classifies as weak (numbers or labels,
                               # e.g. [conocido, vecino]); the rest are strong
    strong_values: [4, 5]      # optional: the values classified as strong; with weak_values, the rest are intermediate

Values set by the researcher (weak_values / strong_values, then weak_max / threshold) take precedence over the
quantile cut. With by: auto or composite, weak_max and threshold refer to the 0–1 strength index. Ties without a
value of 'by' are left 'unclassified'.

Each tie gets: overlap (share of shared neighbors, Onnela et al. 2007), local_bridge and span
(Granovetter's bridges), tie_strength_index (0–1) and tie_strength (strong / weak).
Nodes get the number of strong and weak ties and violations of strong triadic closure (two strong
ties to people who are not tied: Granovetter's "forbidden triad"). The summary tests the weak-ties
argument: the share of local bridges that are weak and the correlation of tie weight and overlap."""
from __future__ import annotations

import itertools

import networkx as nx
import numpy as np
import pandas as pd

from .utils import ConfigError, as_list, log, split_values


def nonempty(v) -> bool:
    return v is not None and v != "" and v != []

COMPONENTS = ("weight", "overlap", "reciprocity", "multiplexity")


def _key(u, v):
    return (u, v) if str(u) <= str(v) else (v, u)


def overlap_and_bridges(U: nx.Graph) -> tuple[dict, dict]:
    """Neighborhood overlap of each tie and local bridges with their span (inf = bridge)."""
    adj = {v: set(U[v]) - {v} for v in U}
    ov = {}
    for u, v in U.edges:
        if u == v:
            continue
        common = len(adj[u] & adj[v])
        denom = (len(adj[u]) - 1) + (len(adj[v]) - 1) - common
        ov[_key(u, v)] = common / denom if denom > 0 else 0.0
    S = nx.Graph(U)
    S.remove_edges_from(nx.selfloop_edges(S))
    span = {}
    if S.number_of_edges() <= 200_000:
        span = {_key(u, v): s for u, v, s in nx.local_bridges(S, with_span=True)}
    else:
        log.warning("tie_strength: too many ties to compute local bridges; skipped")
    return ov, span


def _norm(x):
    """Comparable form of a value: numbers as float ('2' == 2 == 2.0), text trimmed and lowercased."""
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return None
    try:
        f = float(x)
        return None if np.isnan(f) else f
    except (TypeError, ValueError):
        t = str(x).strip().lower()
        return t or None


def _num(x):
    return None if x is None or x == "" else float(x)


def _manual(raw: pd.Series, spec: dict):
    """Classes from the values the researcher set, or None when none were set."""
    weak_v = {_norm(v) for v in as_list(spec.get("weak_values"))} - {None}
    strong_v = {_norm(v) for v in as_list(spec.get("strong_values"))} - {None}
    lo, hi = _num(spec.get("weak_max")), _num(spec.get("threshold"))
    if weak_v or strong_v:
        def f(x):
            x = _norm(x)
            if x is None:
                return "unclassified"
            if x in weak_v:
                return "weak"
            if x in strong_v or not strong_v:
                return "strong"
            return "intermediate" if weak_v else "weak"
        return raw.map(f).to_numpy()
    if lo is None and hi is None:
        return None
    if lo is not None and hi is not None and lo >= hi:
        raise ConfigError("tie_strength: weak_max must be below threshold")
    num = pd.to_numeric(raw, errors="coerce")
    def g(x):
        if pd.isna(x):
            return "unclassified"
        if lo is not None and x <= lo:
            return "weak"
        if hi is not None and x >= hi:
            return "strong"
        return "intermediate" if lo is not None and hi is not None else ("strong" if hi is None else "weak")
    return num.map(g).to_numpy()


def _rank(x: pd.Series) -> pd.Series:
    return x.rank(pct=True, method="average") if x.nunique() > 1 else pd.Series(np.nan, index=x.index)


def tie_strength(G: nx.Graph, spec) -> tuple[dict, dict]:
    spec = spec if isinstance(spec, dict) else {}
    if spec.get("enabled") is False or G.number_of_edges() == 0:
        return {}, {}
    from .analyze import undirected_simple
    U = undirected_simple(G) if G.is_directed() else G
    ov, span = overlap_and_bridges(U)
    rows = []
    for u, v, d in G.edges(data=True):
        if u == v:
            continue
        k = _key(u, v)
        rows.append({"u": u, "v": v, "weight": float(d.get("weight", 1) or 0), "overlap": ov.get(k, 0.0),
                     "reciprocity": float(G.has_edge(v, u)) if G.is_directed() else np.nan,
                     "multiplexity": float(len(split_values(d.get("relation")))) if d.get("relation") is not None else np.nan,
                     "local_bridge": int(k in span), "span": span.get(k)})
    if not rows:                            # only self-loops
        return {}, {}
    E = pd.DataFrame(rows)
    by = spec.get("by", "auto")
    manual_set = any(nonempty(spec.get(k)) for k in ("weak_values", "strong_values", "weak_max", "threshold"))
    if by in ("auto", "composite"):
        comps = [c for c in as_list(spec.get("components")) or COMPONENTS if c in COMPONENTS]
        ranks = pd.DataFrame({c: _rank(E[c]) for c in comps if E[c].notna().any()})
        ranks = ranks.dropna(axis=1, how="all")
        if ranks.empty:
            log.warning("tie_strength: ties do not differ in weight, overlap, reciprocity or multiplexity")
            return {}, {}
        used = list(ranks.columns)
        E["idx"] = ranks.mean(axis=1)
        raw = None
    else:
        if by in COMPONENTS:
            raw = E[by]
        else:
            vals = [d.get(by) for u, v, d in G.edges(data=True) if u != v]
            if all(x is None for x in vals):
                raise ConfigError(f"tie_strength.by: ties have no attribute {by!r}")
            raw = pd.Series(vals, index=E.index, dtype=object)
        num = pd.to_numeric(raw, errors="coerce")
        if not manual_set and num.nunique() < 2:
            log.warning(f"tie_strength: {by} has fewer than two numeric values; set weak_values to classify its values")
            return {}, {}
        used = [by]
        E["idx"] = num.rank(pct=True, method="average") if num.nunique() > 1 else np.nan
    levels = int(spec.get("levels", 2))
    if manual_set and raw is None and (as_list(spec.get("weak_values")) or as_list(spec.get("strong_values"))):
        log.warning("tie_strength: weak_values and strong_values need a tie attribute in 'by'; using weak_max/threshold on the index")
        spec = {k: v for k, v in spec.items() if k not in ("weak_values", "strong_values")}
    if manual_set and raw is None:
        for k in ("weak_max", "threshold"):
            if nonempty(spec.get(k)) and not 0 <= float(spec[k]) <= 1:
                log.warning(f"tie_strength.{k}: with by: auto or composite it refers to the 0–1 index; ignored")
                spec = {**spec, k: None}
    cls = _manual(raw if raw is not None else E["idx"], spec) if manual_set else None
    if cls is not None:
        if E["idx"].isna().all():           # labels only: index from the classes
            E["idx"] = pd.Series(cls).map({"weak": 0.0, "intermediate": 0.5, "strong": 1.0}).to_numpy()
        n_un = int((cls == "unclassified").sum())
        if n_un:
            log.warning(f"tie_strength: {n_un:,} ties have no value of {'+'.join(used)} and are left unclassified")
    elif levels == 3:
        lo, hi = E["idx"].quantile([1 / 3, 2 / 3])
        top = (E["idx"] > hi) | ((E["idx"] == hi) & (hi > lo))
        cls = np.where(top, "strong", np.where(E["idx"] <= lo, "weak", "intermediate"))
    else:                                   # ties exactly at the cut count as strong unless the cut is the minimum
        cut = E["idx"].quantile(float(spec.get("cut", .5)))
        top = (E["idx"] > cut) | ((E["idx"] == cut) & (cut > E["idx"].min()))
        cls = np.where(top, "strong", "weak")
    if raw is not None and not manual_set:  # ties without a value of 'by' are not classified
        cls = np.where(E["idx"].isna(), "unclassified", cls)
    E["cls"] = cls
    if (E["cls"] == "intermediate").any():
        levels = 3
    for r in E.itertuples(index=False):
        d = G[r.u][r.v]
        d.update({"overlap": round(r.overlap, 4), "local_bridge": r.local_bridge,
                  "tie_strength_index": None if pd.isna(r.idx) else round(float(r.idx), 4), "tie_strength": r.cls})
        if r.local_bridge and r.span is not None:
            d["span"] = float("inf") if r.span == float("inf") else int(r.span)

    # nodes: strong and weak ties, violations of strong triadic closure
    strong_u = nx.Graph()
    strong_u.add_nodes_from(G)
    strong_u.add_edges_from((r.u, r.v) for r in E.itertuples(index=False) if r.cls == "strong")
    counts = {n: {"strong": 0, "weak": 0, "intermediate": 0, "unclassified": 0} for n in G}
    for r in E.itertuples(index=False):
        c = r.cls
        counts[r.u][c] += 1
        counts[r.v][c] += 1
    violations = {}
    for a in strong_u:
        sn = list(strong_u[a])
        violations[a] = sum(1 for b, c in itertools.combinations(sn, 2) if not U.has_edge(b, c)) if len(sn) < 3000 else 0
    for n in G:
        tot = sum(c for k, c in counts[n].items() if k != "unclassified")
        G.nodes[n].update({"strong_ties": counts[n]["strong"], "weak_ties": counts[n]["weak"],
                           "weak_tie_share": round(counts[n]["weak"] / tot, 4) if tot else 0,
                           "stc_violations": violations.get(n, 0)})
        if levels == 3:
            G.nodes[n]["intermediate_ties"] = counts[n]["intermediate"]

    lb = E[E["local_bridge"] == 1]
    summary = {"tie_strength_by": "+".join(used), "strong_ties": int((E["cls"] == "strong").sum()),
               "weak_ties": int((E["cls"] == "weak").sum()),
               "strong_tie_share": round(float((E["cls"] == "strong").sum() / max(1, (E["cls"] != "unclassified").sum())), 4),
               "local_bridges": int(len(lb)),
               "weak_share_of_local_bridges": round(float((lb["cls"] == "weak").mean()), 4) if len(lb) else None,
               "stc_violations": int(sum(violations.values()))}
    if (E["cls"] == "unclassified").any():
        summary["unclassified_ties"] = int((E["cls"] == "unclassified").sum())
    if manual_set and _rule_text(spec):
        summary["tie_strength_rule"] = _rule_text(spec)
    if levels == 3:
        summary["intermediate_ties"] = int((E["cls"] == "intermediate").sum())
    if E["weight"].nunique() > 1 and E["overlap"].nunique() > 1:
        summary["weight_overlap_correlation"] = round(float(E["weight"].corr(E["overlap"], method="spearman")), 4)
    table = E.groupby("cls").agg(ties=("u", "size"), mean_weight=("weight", "mean"), mean_overlap=("overlap", "mean"),
                                 local_bridges=("local_bridge", "sum"), mean_index=("idx", "mean")).reset_index()
    table.insert(2, "share", (table["ties"] / len(E)).round(4))
    table = table.round(4).rename(columns={"cls": "tie_strength"})
    order = {"strong": 0, "intermediate": 1, "weak": 2, "unclassified": 3}
    table = table.sort_values("tie_strength", key=lambda s: s.map(order)).reset_index(drop=True)
    log.info(f"tie strength by {'+'.join(used)}: {summary['strong_ties']:,} strong, {summary['weak_ties']:,} weak, "
             f"{summary['local_bridges']:,} local bridges")
    return {k: v for k, v in summary.items() if v is not None}, {"tie_strength": table}


def _rule_text(spec: dict) -> str:
    """The researcher's classification, in words, for the summary."""
    parts = []
    if as_list(spec.get("weak_values")):
        parts.append("weak = " + "|".join(map(str, as_list(spec["weak_values"]))))
    if as_list(spec.get("strong_values")):
        parts.append("strong = " + "|".join(map(str, as_list(spec["strong_values"]))))
    if not parts:
        if nonempty(spec.get("weak_max")):
            parts.append(f"weak <= {spec['weak_max']}")
        if nonempty(spec.get("threshold")):
            parts.append(f"strong >= {spec['threshold']}")
    return "; ".join(parts)
