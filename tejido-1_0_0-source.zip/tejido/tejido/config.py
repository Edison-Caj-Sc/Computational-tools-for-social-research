"""Loading, normalizing and validating the YAML configuration.

Sections (all optional except builder.type):
  project · input · prepare · builder · nodes · filters · analysis · time · layers · output
Old names (edgelist, matrix, cooccurrence, social, worldbank_csv, worldbank_api) keep working; indicators = table with preset indicators."""
from __future__ import annotations

import copy
from pathlib import Path

import yaml

from .utils import ConfigError, as_list

DEFAULTS: dict = {
    "project": "my_network",
    "input": {"type": "table", "path": None, "sheet": None, "encoding": None},
    "prepare": [],
    "builder": {"type": None},
    "nodes": None,
    "filters": {"min_weight": None, "max_weight": None, "min_degree": None, "top_nodes": None,
                "largest_component": False, "remove_isolates": True, "k_core": None, "keep_nodes": None,
                "drop_nodes": None, "keep_edges": None, "ego": None, "backbone": None},
    "analysis": {"centrality": ["degree", "betweenness", "closeness", "pagerank"], "communities": "louvain",
                 "resolution": 1.0, "seed": 2026, "distance": "auto", "betweenness_sample": "auto", "normalized": True,
                 "groups": [], "attributes": [], "null_model": None},
    "time": None,
    "layers": None,
    "output": {"dir": "results", "formats": ["csv", "graphml", "gexf", "html", "report"], "language": "en",
               "html": {"size_by": "pagerank", "color_by": "community", "max_nodes": 1500}},
}
INPUT_TYPES = {"table", "documents", "api", "none"}
INPUT_ALIASES = {"indicators": {"type": "table", "preset": "indicators"},
                 "worldbank_csv": {"type": "table", "preset": "worldbank"},
                 "worldbank_api": {"type": "api", "source": "worldbank"}}
BUILDER_ALIASES = {"edgelist": ("ties", {"format": "edgelist"}), "matrix": ("ties", {"format": "matrix"}),
                   "cooccurrence": ("affiliation", {}), "social": ("interactions", {}),
                   "documents": ("text", {})}
PATH_KEYS = {"path", "gazetteer"}


def _merge(base: dict, new: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (new or {}).items():
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def normalize(cfg: dict) -> dict:
    """Translates old names into the general ones."""
    i = cfg["input"]
    if i.get("type") in INPUT_ALIASES:
        i.update({k: v for k, v in INPUT_ALIASES[i["type"]].items() if k not in i or k == "type"})
    b = cfg["builder"]
    if b.get("type") in BUILDER_ALIASES:
        canon, extra = BUILDER_ALIASES[b["type"]]
        b["type"] = canon
        for k, v in extra.items():
            b.setdefault(k, v)
    if isinstance(cfg.get("time"), str):
        cfg["time"] = {"column": cfg["time"]}
    if isinstance(cfg.get("layers"), str):
        cfg["layers"] = {"by": cfg["layers"]}
    cfg["prepare"] = as_list(cfg.get("prepare"))
    return cfg


def load_config(source) -> dict:
    """Accepts a YAML path or a dict; returns the full, normalized configuration."""
    if isinstance(source, (str, Path)):
        path = Path(source)
        if not path.exists():
            raise ConfigError(f"Configuration file not found: {path}")
        try:
            user = yaml.safe_load(path.read_text(encoding="utf-8-sig")) or {}
        except yaml.YAMLError as e:
            raise ConfigError(f"{path.name} is not valid YAML: {e}") from e
        except UnicodeDecodeError as e:
            raise ConfigError(f"{path.name} must be saved as UTF-8 text") from e
        base = path.parent
    else:
        user = copy.deepcopy(dict(source))
        base = Path(user.pop("_base_dir", None) or Path.cwd())
    if not isinstance(user, dict):
        raise ConfigError("The configuration must be a YAML mapping (key: value).")
    for section in ("input", "builder", "filters", "analysis", "output"):
        if user.get(section) is not None and not isinstance(user[section], dict):
            raise ConfigError(f"'{section}' must be a mapping (key: value), not {type(user[section]).__name__}")
    cfg = normalize(_merge(DEFAULTS, user))
    cfg["_base_dir"] = str(base)
    if cfg.get("project") in (None, ""):
        cfg["project"] = DEFAULTS["project"]
    cfg["project"] = str(cfg["project"])
    if not cfg["builder"].get("type"):
        raise ConfigError("Missing 'builder.type'. Run 'tejido list builders' to see the options.")
    if cfg["input"]["type"] not in INPUT_TYPES:
        raise ConfigError(f"'input.type' must be one of {sorted(INPUT_TYPES)}")
    cfg["output"]["formats"] = [str(f).lower() for f in as_list(cfg["output"]["formats"])]
    return cfg


def resolve(cfg: dict, path) -> Path:
    """Relative paths are read from the folder of the configuration file."""
    if str(path).startswith(("http://", "https://")):
        return path
    p = Path(path)
    return p if p.is_absolute() else Path(cfg.get("_base_dir", ".")) / p


def absolutize(obj, base: Path):
    """Makes every 'path'/'gazetteer' value absolute (used when a config moves to another folder)."""
    if isinstance(obj, dict):
        return {k: (str((Path(base) / v).resolve()) if k in PATH_KEYS and isinstance(v, str) and v
                    and not Path(v).is_absolute() and not v.startswith(("http://", "https://"))
                    else absolutize(v, base)) for k, v in obj.items()}
    if isinstance(obj, list):
        return [absolutize(x, base) for x in obj]
    return obj
