"""Estandarización: lista de operaciones que se aplican en orden.

Cada operación es un diccionario con 'tipo' y sus opciones. Para añadir una nueva
basta con escribir una función op_<tipo>(df, op, cfg) y registrarla en OPS.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import resolve
from .utils import (ConfigError, as_list, expand_columns, groups, log, map_values,
                    weighted_mean, weighted_quantile, weights_of)


def _vars(df, op, key="variables"):
    cols = expand_columns(df, op.get(key), required=True)
    if not cols:
        raise ConfigError(f"La operación {op['tipo']!r} necesita '{key}'.")
    return cols


def _num(s):
    return pd.to_numeric(s, errors="coerce")


def op_faltantes(df, op, cfg):
    """Convierte códigos como 99 o 999999 en faltantes."""
    codes = [float(c) for c in as_list(op.get("codigos"))]
    for c in _vars(df, op):
        num = _num(df[c])
        df[c] = df[c].mask(num.isin(codes))
    return df


def op_recodificar(df, op, cfg):
    var = str(op["variable"]).lower()
    df[str(op.get("nueva", var)).lower()] = map_values(df[var], op["mapa"], op.get("otros", "conservar"))
    return df


def op_dividir(df, op, cfg):
    """Divide variables entre otra variable o un número (per cápita, mensual…)."""
    divisor = op.get("entre")
    d = _num(df[str(divisor).lower()]) if isinstance(divisor, str) else float(divisor)
    for c in _vars(df, op):
        df[c + op.get("sufijo", "")] = _num(df[c]) / d
    return df


def op_multiplicar(df, op, cfg):
    factor = op.get("por")
    f = _num(df[str(factor).lower()]) if isinstance(factor, str) else float(factor)
    for c in _vars(df, op):
        df[c + op.get("sufijo", "")] = _num(df[c]) * f
    return df


def op_deflactar(df, op, cfg):
    """Pasa montos nominales a reales.

    metodo 'tabla': índice por año (y opcionalmente región). real = nominal * I_base / I_año
    metodo 'columna': divide entre una variable de la base (p. ej. el deflactor espacial).
    """
    cols, suf = _vars(df, op), op.get("sufijo", "_real")
    metodo = op.get("metodo", "tabla")
    if metodo == "columna":
        d = _num(df[str(op["columna"]).lower()])
        for c in cols:
            df[c + suf] = _num(df[c]) / d
        return df
    por = [str(p).lower() for p in as_list(op.get("por"))]
    if op.get("archivo"):
        tab = pd.read_csv(resolve(cfg, op["archivo"]))
        tab.columns = [c.lower() for c in tab.columns]
    elif op.get("indices"):
        tab = pd.DataFrame({"anio": [int(k) for k in op["indices"]],
                            "indice": [float(v) for v in op["indices"].values()]})
    else:
        raise ConfigError("'deflactar' con metodo 'tabla' necesita 'indices' o 'archivo'.")
    base = int(op.get("anio_base", tab["anio"].max()))
    tab["_f"] = np.nan
    for _, g in tab.groupby(por) if por else [(None, tab)]:
        ref = g.loc[g["anio"] == base, "indice"]
        if ref.empty:
            raise ConfigError(f"El año base {base} no está en la tabla de índices.")
        tab.loc[g.index, "_f"] = float(ref.iloc[0]) / g["indice"]
    on = ["anio"] + por
    key = df[on].copy()
    key["anio"] = key["anio"].astype(int)
    tab["anio"] = tab["anio"].astype(int)
    f = key.merge(tab[on + ["_f"]], on=on, how="left")["_f"].to_numpy()
    if np.isnan(f).any():
        log.warning(f"  · deflactar: {int(np.isnan(f).sum()):,} filas sin índice (años o regiones faltantes)")
    for c in cols:
        df[c + suf] = _num(df[c]).to_numpy() * f
    return df


def _by_group(df, op, cfg, func):
    w = weights_of(df, cfg, bool(op.get("ponderado")))
    for idx in groups(df, op.get("por_grupo")):
        func(idx, None if w is None else w.loc[idx])


def op_escalar(df, op, cfg):
    """zscore | minmax | robusto | log | log1p | percentil (opcionalmente por grupo y ponderado)."""
    metodo = op.get("metodo", "zscore")
    valid = {"zscore", "minmax", "robusto", "log", "log1p", "percentil"}
    if metodo not in valid:
        raise ConfigError(f"'escalar.metodo' debe ser uno de {sorted(valid)}")
    suf = op.get("sufijo", f"_{metodo}")
    for c in _vars(df, op):
        x = _num(df[c])
        if metodo == "log":
            df[c + suf] = np.log(x.where(x > 0))
            continue
        if metodo == "log1p":
            df[c + suf] = np.log1p(x.where(x > -1))
            continue
        res = pd.Series(np.nan, index=df.index)

        def apply(idx, w, x=x, res=res):
            v = x.loc[idx]
            if metodo == "zscore":
                mu = weighted_mean(v, w)
                sd = np.sqrt(weighted_mean((v - mu) ** 2, w))
                res.loc[idx] = (v - mu) / sd if sd else np.nan
            elif metodo == "minmax":
                lo, hi = v.min(), v.max()
                res.loc[idx] = (v - lo) / (hi - lo) if hi > lo else np.nan
            elif metodo == "robusto":
                med = weighted_quantile(v, .5, w)
                iqr = weighted_quantile(v, .75, w) - weighted_quantile(v, .25, w)
                res.loc[idx] = (v - med) / iqr if iqr else np.nan
            else:  # percentil ponderado (0-100)
                order = v.sort_values().index
                ww = pd.Series(1.0, index=v.index) if w is None else w
                ok = v.loc[order].notna()
                cw = ww.loc[order][ok].cumsum()
                res.loc[cw.index] = 100 * (cw - ww.loc[cw.index] / 2) / ww.loc[cw.index].sum()

        _by_group(df, op, cfg, apply)
        df[c + suf] = res
    return df


def op_winsorizar(df, op, cfg):
    lo_q, hi_q = float(op.get("inferior", 0.01)), float(op.get("superior", 0.99))
    for c in _vars(df, op):
        x = _num(df[c])
        out = x.copy()

        def apply(idx, w, x=x, out=out):
            v = x.loc[idx]
            out.loc[idx] = v.clip(weighted_quantile(v, lo_q, w), weighted_quantile(v, hi_q, w))

        _by_group(df, op, cfg, apply)
        df[c + op.get("sufijo", "")] = out
    return df


def op_cortes(df, op, cfg):
    """Crea categorías por cortes fijos o por cuantiles (quintiles ponderados, etc.)."""
    var = str(op["variable"]).lower()
    new = str(op.get("nueva", f"{var}_cat")).lower()
    x = _num(df[var])
    etiquetas = op.get("etiquetas")
    if op.get("cortes"):
        bins = [-np.inf] + [float(b) for b in op["cortes"]] + [np.inf]
        df[new] = pd.cut(x, bins=bins, labels=etiquetas, right=False).astype(object)
        return df
    n = int(op.get("cuantiles", 5))
    res = pd.Series(np.nan, index=df.index, dtype=object)

    def apply(idx, w):
        v = x.loc[idx]
        qs = [weighted_quantile(v, k / n, w) for k in range(1, n)]
        cat = np.searchsorted(qs, v.to_numpy(), side="right") + 1
        cat = pd.Series(cat, index=idx).where(v.notna())
        res.loc[idx] = cat.map(lambda k: np.nan if pd.isna(k) else (etiquetas[int(k) - 1] if etiquetas else int(k)))

    _by_group(df, op, cfg, apply)
    df[new] = res
    return df


def op_agrupar_raras(df, op, cfg):
    """Junta categorías poco frecuentes en 'otros'."""
    var = str(op["variable"]).lower()
    share = df[var].value_counts(normalize=True)
    rare = share[share < float(op.get("minimo", 0.01))].index
    df[str(op.get("nueva", var)).lower()] = df[var].astype(object).where(~df[var].isin(rare), op.get("etiqueta", "otros"))
    return df


def op_dummies(df, op, cfg):
    for c in _vars(df, op):
        d = pd.get_dummies(df[c], prefix=op.get("prefijo", c), drop_first=bool(op.get("eliminar_primera")),
                           dtype=float)
        d[df[c].isna()] = np.nan
        df = pd.concat([df, d], axis=1)
    return df


def op_ubigeo(df, op, cfg):
    """Ubigeo de 6 dígitos, códigos de departamento/provincia y equivalencias entre años."""
    var = str(op.get("variable", "ubigeo")).lower()
    num = _num(df[var])
    u = num.astype("Int64").astype(str).str.zfill(6).where(num.notna())
    if op.get("equivalencias"):
        tab = pd.read_csv(resolve(cfg, op["equivalencias"]), dtype=str)
        o, d = op.get("origen", "origen"), op.get("destino", "destino")
        mp = dict(zip(tab[o].str.zfill(6), tab[d].str.zfill(6)))
        n = u.isin(list(mp)).sum()
        u = u.map(lambda x: mp.get(x, x) if isinstance(x, str) else x)
        log.info(f"  · ubigeo: {n:,} filas actualizadas con la tabla de equivalencias")
    df[var] = u
    crear = [str(c).lower() for c in as_list(op.get("crear", ["departamento", "provincia"]))]
    if "departamento" in crear:
        df["cod_departamento"] = u.str[:2]
    if "provincia" in crear:
        df["cod_provincia"] = u.str[:4]
    return df


def op_equivalencias(df, op, cfg):
    """Aplica una tabla de correspondencias (p. ej. CIIU rev.3 -> rev.4)."""
    var = str(op["variable"]).lower()
    tab = pd.read_csv(resolve(cfg, op["archivo"]), dtype=str)
    mp = dict(zip(tab[op.get("origen", "origen")].str.strip(), tab[op.get("destino", "destino")].str.strip()))
    df[str(op.get("nueva", var + "_eq")).lower()] = map_values(df[var].astype("string").str.strip(), mp,
                                                              op.get("otros", "nan"))
    return df


def op_renombrar(df, op, cfg):
    return df.rename(columns={str(k).lower(): str(v).lower() for k, v in op["mapa"].items()})


def op_eliminar(df, op, cfg):
    return df.drop(columns=_vars(df, op))


def op_filtrar(df, op, cfg):
    n = len(df)
    df = df.query(str(op["condicion"]))
    log.info(f"  · filtrar '{op['condicion']}': {n:,} -> {len(df):,} filas")
    return df


OPS = {name[3:]: fn for name, fn in globals().items() if name.startswith("op_")}


def standardize(df: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    for i, op in enumerate(cfg.get("estandarizar") or [], 1):
        tipo = op["tipo"]
        if tipo not in OPS:
            raise ConfigError(f"Operación desconocida {tipo!r}. Opciones: {sorted(OPS)}")
        log.info(f"Estandarizar {i}: {tipo}")
        df = OPS[tipo](df.copy(), op, cfg)
    return df
