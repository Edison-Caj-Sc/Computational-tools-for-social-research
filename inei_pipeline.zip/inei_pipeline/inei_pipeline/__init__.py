"""inei_pipeline: de los microdatos del INEI a una base lista para analizar."""
from .config import load_config
from .pipeline import Pipeline, run

__version__ = "0.1.0"
__all__ = ["Pipeline", "run", "load_config"]
