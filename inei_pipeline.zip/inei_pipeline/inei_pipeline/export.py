"""Exportación de la base final, diccionario, reporte y código del diseño muestral."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

from .config import resolve
from .utils import ConfigError, log


def _for_stata(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for c in df.columns:
        if not pd.api.types.is_numeric_dtype(df[c]):
            df[c] = df[c].astype(object).where(df[c].notna(), "").astype(str)
    df.columns = [c[:32] for c in df.columns]
    return df


def write_table(df: pd.DataFrame, path: Path, fmt: str, labels: dict) -> None:
    if fmt == "csv":
        df.to_csv(path, index=False, encoding="utf-8-sig")
    elif fmt == "parquet":
        try:
            df.to_parquet(path, index=False)
        except ImportError as e:
            raise ConfigError("Para exportar parquet instala pyarrow: pip install pyarrow") from e
    elif fmt == "dta":
        d = _for_stata(df)
        vl = {k[:32]: str(v)[:80] for k, v in labels.items() if k[:32] in d.columns and v}
        d.to_stata(path, write_index=False, version=118, variable_labels=vl)
    elif fmt == "sav":
        import pyreadstat
        d = df.copy()
        for c in d.columns:
            if not pd.api.types.is_numeric_dtype(d[c]):
                d[c] = d[c].astype(object).where(d[c].notna(), None)
        pyreadstat.write_sav(d, str(path), column_labels={k: v for k, v in labels.items() if k in d.columns and v})
    elif fmt == "xlsx":
        if len(df) > 1_048_000:
            raise ConfigError("Excel admite hasta ~1 millón de filas; usa csv o parquet.")
        df.to_excel(path, index=False)
    else:
        raise ConfigError(f"Formato desconocido {fmt!r}. Opciones: csv, parquet, dta, sav, xlsx")


def codebook(df: pd.DataFrame, labels: dict) -> pd.DataFrame:
    rows = []
    for c in df.columns:
        s = df[c]
        num = pd.api.types.is_numeric_dtype(s)
        rows.append({
            "variable": c, "etiqueta": labels.get(c, ""),
            "tipo": "numerica" if num else "categorica",
            "n_faltantes": int(s.isna().sum()), "pct_faltantes": round(100 * s.isna().mean(), 2),
            "n_valores": int(s.nunique()),
            "min": s.min() if num else "", "max": s.max() if num else "",
            "valores_ejemplo": "" if num and s.nunique() > 15 else ", ".join(map(str, s.dropna().unique()[:10])),
        })
    return pd.DataFrame(rows)


def design_snippets(cfg: dict, name: str) -> str:
    d = cfg.get("diseno") or {}
    st, cl, w = d.get("estrato"), d.get("conglomerado"), d.get("peso")
    return f"""# Diseño muestral de {name}

Estrato: `{st}` · Conglomerado: `{cl}` · Peso: `{w}`

## Stata
```stata
svyset {cl} [pweight={w}], strata({st}) vce(linearized) singleunit(certainty)
svy: mean <variable>
```

## R (paquete survey)
```r
library(survey)
diseno <- svydesign(ids = ~{cl}, strata = ~{st}, weights = ~{w}, data = datos, nest = TRUE)
options(survey.lonely.psu = "certainty")
svymean(~<variable>, diseno, na.rm = TRUE)
```

## Python (paquete samplics)
```python
from samplics.estimation import TaylorEstimator
est = TaylorEstimator("mean")
est.estimate(y=datos["<variable>"], samp_weight=datos["{w}"], stratum=datos["{st}"], psu=datos["{cl}"], remove_nan=True)
```

Si usaste imputación múltiple (m > 1), estima en cada base y combina con las reglas de Rubin
(`mi estimate` en Stata o `mitools::MIcombine` en R).
"""


def export(datasets: list[pd.DataFrame], cfg: dict, labels: dict, report: list[dict]) -> Path:
    ecfg = cfg["exportar"]
    folder = resolve(cfg, ecfg["carpeta"])
    folder.mkdir(parents=True, exist_ok=True)
    name = ecfg["nombre"]
    keep = ecfg.get("variables")
    for k, df in enumerate(datasets, 1):
        if keep:
            missing = [v for v in keep if v not in df.columns]
            if missing:
                raise ConfigError(f"'exportar.variables' pide columnas que no existen: {missing}")
            df = df[[v for v in keep] + [c for c in df.columns if c.endswith("_imp") and c[:-4] in keep]]
        suffix = f"_imp{k}" if len(datasets) > 1 else ""
        for fmt in ecfg["formatos"]:
            path = folder / f"{name}{suffix}.{fmt}"
            write_table(df, path, fmt, labels)
            log.info(f"Guardado: {path}")
    codebook(datasets[0] if not keep else df, labels).to_csv(folder / f"{name}_diccionario.csv", index=False,
                                                             encoding="utf-8-sig")
    if report:
        pd.DataFrame(report).to_csv(folder / f"{name}_reporte_imputacion.csv", index=False, encoding="utf-8-sig")
    (folder / f"{name}_diseno_muestral.md").write_text(design_snippets(cfg, name), encoding="utf-8")
    clean_cfg = {k: v for k, v in cfg.items() if not k.startswith("_")}
    (folder / f"{name}_configuracion_usada.yaml").write_text(
        yaml.safe_dump(json.loads(json.dumps(clean_cfg, default=str)), allow_unicode=True, sort_keys=False),
        encoding="utf-8")
    return folder
