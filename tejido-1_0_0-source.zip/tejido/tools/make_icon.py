"""Draws installer/tejido.ico (the Tejido mark: an indigo diamond crossed by a cochineal thread) at the sizes Windows
uses. Run it again only if the mark changes:  python tools/make_icon.py"""
from pathlib import Path

from PIL import Image, ImageDraw

INDIGO, COCHINEAL = (40, 60, 122, 255), (166, 30, 68, 255)
SIZES = [16, 20, 24, 32, 40, 48, 64, 128, 256]


def mark(px: int) -> Image.Image:
    k = 8                                              # draw large, then reduce: smooth edges at every size
    s = px * k
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    u = s / 22                                         # the same 22-unit grid as the SVG logo
    w = max(round(2.4 * u), 2 * k) if px <= 24 else round(2.2 * u)
    pts = [(11 * u, 2 * u), (20 * u, 11 * u), (11 * u, 20 * u), (2 * u, 11 * u)]
    d.line(pts + [pts[0]], fill=INDIGO, width=w, joint="curve")
    d.line([(6.5 * u, 6.5 * u), (15.5 * u, 15.5 * u)], fill=COCHINEAL, width=w)
    d.line([(15.5 * u, 6.5 * u), (12.4 * u, 9.6 * u)], fill=INDIGO, width=w)
    d.line([(9.6 * u, 12.4 * u), (6.5 * u, 15.5 * u)], fill=INDIGO, width=w)
    return img.resize((px, px), Image.LANCZOS)


def main() -> None:
    out = Path(__file__).resolve().parents[1] / "installer" / "tejido.ico"
    images = [mark(px) for px in SIZES]
    images[-1].save(out, format="ICO", sizes=[(px, px) for px in SIZES], append_images=images[:-1])
    print(f"Saved {out}")


if __name__ == "__main__":
    main()
