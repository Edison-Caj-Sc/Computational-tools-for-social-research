# =====================================================================
#  04 · REGRESIÓN BINOMIAL NEGATIVA
#  Para: conteos con sobredispersión (varianza mayor que la media), muy común en datos sociales.
#  Interpretación: igual que Poisson, con razones de tasas de incidencia (IRR).
#  Compara con Poisson: si theta es pequeño y la prueba LR es significativa, prefiere este modelo.
# =====================================================================

# ---------------------------------------------------------------------
# 0. CONFIGURACIÓN · edita solo esta sección
# ---------------------------------------------------------------------
archivo        <- NULL
dependiente    <- "n_organizaciones"
predictores    <- c("educ_jefe", "edad_jefe", "sexo_jefe", "area", "mieperho")
factores       <- list(sexo_jefe = "hombre", area = "urbano")
terminos_extra <- NULL
formula_manual <- NULL
exposicion     <- NULL                    # variable de exposición; entra como offset(log())
variable_foco  <- "educ_jefe"
usar_diseno    <- FALSE                   # ver nota en la sección 2
diseno         <- list(estrato = "estrato", conglomerado = "conglome", peso = "factor07")
carpeta_salida <- "resultados/04_binomial_negativa"

# ---------------------------------------------------------------------
# 1. Preparación
# ---------------------------------------------------------------------
source("utilidades.R"); instalar_si_falta()
salida  <- preparar_salida(carpeta_salida)
formula <- construir_formula(dependiente, predictores,
                             c(terminos_extra, if (!is.null(exposicion)) sprintf("offset(log(%s))", exposicion)),
                             formula_manual)
datos   <- preparar_datos(cargar_datos(archivo), variables_formula(formula), factores,
                          extra = vars_diseno(usar_diseno, diseno))
y <- all.vars(formula)[1]
if (any(datos[[y]] < 0 | datos[[y]] != round(datos[[y]])))
  stop("La variable dependiente debe ser un conteo entero mayor o igual a 0.")

# ---------------------------------------------------------------------
# 2. Estimación
#    El paquete survey no estima binomial negativa. Con 'usar_diseno = TRUE' se usan los
#    pesos y errores robustos por conglomerado: una aproximación razonable, pero no ignora
#    los estratos. Repórtalo así en tu trabajo.
# ---------------------------------------------------------------------
encabezado("Modelos")
if (usar_diseno) {
  datos$.peso <- datos[[diseno$peso]] / mean(datos[[diseno$peso]])   # pesos normalizados (suman n)
  modelo  <- MASS::glm.nb(formula, data = datos, weights = .peso)
  poisson <- glm(formula, data = datos, family = poisson(), weights = .peso)
  vc <- sandwich::vcovCL(modelo, cluster = datos[[diseno$conglomerado]])
  message("Aproximación al diseño: pesos normalizados + errores robustos por conglomerado.")
} else {
  modelo  <- MASS::glm.nb(formula, data = datos)
  poisson <- glm(formula, data = datos, family = poisson())
  vc <- NULL
}
print(summary(modelo))
coefs <- tabla_coeficientes(modelo, exponenciar = TRUE, vcov = vc)
names(coefs) <- sub("^exp_", "irr_", names(coefs))
print(redondear(coefs, 3)); guardar_tabla(coefs, "2_coeficientes", salida)

# ---------------------------------------------------------------------
# 3. ¿Binomial negativa o Poisson?
# ---------------------------------------------------------------------
encabezado("Comparación con Poisson")
lr <- 2 * as.numeric(logLik(modelo) - logLik(poisson))
comp <- comparar_modelos(poisson = poisson, binomial_negativa = modelo)
comp$theta <- c(NA, modelo$theta)
print(redondear(comp, 3)); guardar_tabla(comp, "3_comparacion_modelos", salida)
p_lr <- 0.5 * pchisq(lr, df = 1, lower.tail = FALSE)            # prueba en el borde: p / 2
cat(sprintf("Prueba LR (H0: Poisson): chi2 = %.2f, p = %.4g → %s\n", lr, p_lr,
            ifelse(p_lr < .05, "prefiere binomial negativa", "Poisson es suficiente")))
cat(sprintf("theta = %.3f (más pequeño = más sobredispersión)\n", modelo$theta))
mu <- fitted(modelo)
cat(sprintf("Ceros observados: %.1f %% · esperados por el modelo: %.1f %%\n",
            100 * mean(datos[[y]] == 0), 100 * mean(dnbinom(0, size = modelo$theta, mu = mu))))

# ---------------------------------------------------------------------
# 4. Interpretación
# ---------------------------------------------------------------------
encabezado("Efectos marginales promedio (cambio en el número esperado)")
ame <- efectos_marginales(modelo, datos, NULL, vcov = if (is.null(vc)) TRUE else vc,
                          pesos = if (usar_diseno) datos$.peso else NULL)
print(redondear(ame, 4)); guardar_tabla(ame, "4_efectos_marginales", salida)
guardar_grafico(grafico_predicciones(modelo, datos, variable_foco, NULL, paste("Conteo esperado de", y)),
                "4_predicciones", salida)
guardar_texto(summary(modelo), "resumen_modelo", salida)
encabezado(paste("Listo. Resultados en", salida))
