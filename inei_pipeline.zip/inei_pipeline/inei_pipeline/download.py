"""Descarga de microdatos del INEI usando el paquete inei-microdatos."""
from __future__ import annotations

import copy
import re

from .config import resolve
from .utils import ConfigError, as_list, log

LAYOUT = "{year}/{code}.zip"   # carpeta/AÑO/CODIGO.zip


def module_number(code: str) -> int | None:
    m = re.search(r"modulo0*(\d+)", str(code), flags=re.I)
    return int(m.group(1)) if m else None


def select_catalog(cfg: dict) -> list[dict]:
    """Filtra el catálogo de inei-microdatos según encuesta, años, período y módulos."""
    try:
        from inei_microdatos import load_catalog
        from inei_microdatos.catalog import filter_catalog
    except ImportError as e:  # pragma: no cover
        raise ConfigError("Instala inei-microdatos: pip install inei-microdatos") from e

    d, years = cfg["datos"], cfg["_anios"]
    entries = filter_catalog(load_catalog(), survey=d["encuesta"], year_min=min(years), year_max=max(years))
    if d.get("etiqueta"):
        entries = [e for e in entries if e["label"].strip().lower() == d["etiqueta"].strip().lower()]
    elif "panel" not in str(d["encuesta"]).lower():
        entries = [e for e in entries if "panel" not in e["label"].lower()]
    if not entries:
        raise ConfigError(f"No encontré la encuesta {d['encuesta']!r} para esos años. "
                          "Prueba: inei-pipeline encuestas")

    wanted = {int(m) for m in as_list(d.get("modulos"))}
    period = str(d.get("periodo") or "").lower()
    out = []
    for e in entries:
        e = copy.deepcopy(e)
        new_years = {}
        for y, periods in e["years"].items():
            if int(y) not in years:
                continue
            keep = {}
            for p, pdata in periods.items():
                if period and period not in p.lower():
                    continue
                mods = [m for m in pdata["modules"]
                        if not wanted or module_number(m.get("csv_code") or m.get("stata_code") or "") in wanted
                        or (str(m.get("module_code", "")).isdigit() and int(m["module_code"]) in wanted)]
                if mods:
                    keep[p] = {**pdata, "modules": mods}
            if keep:
                new_years[y] = keep
        if new_years:
            e["years"] = new_years
            out.append(e)
    if not out:
        raise ConfigError("Ningún módulo coincide con 'datos.modulos' y 'datos.periodo'.")
    return out


def download(cfg: dict) -> dict:
    from inei_microdatos import download_modules

    d = cfg["datos"]
    catalog = select_catalog(cfg)
    dest = resolve(cfg, d["carpeta"])
    n = sum(len(p["modules"]) for e in catalog for y in e["years"].values() for p in y.values())
    log.info(f"Descargando {n} módulos en {dest} …")
    res = download_modules(catalog, dest=dest, fmt=d["formato"], layout=LAYOUT, workers=int(d["hilos"]))
    log.info(f"Descarga: {res}")
    return res
