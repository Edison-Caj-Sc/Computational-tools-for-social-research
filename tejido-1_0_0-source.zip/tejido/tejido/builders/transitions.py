"""Transitions: units that move from one state to another over time.

Nodes are states (occupations, places of residence, schools, stages of a procedure, parties);
directed ties count how many times units moved from one state to the next.
format: long  one row per unit and moment (unit, order, state)
        wide  one row per unit, one column per moment in time order (states: [s2019, s2020, …])
Ties carry count, probability (share of moves out of the source) and number of units; nodes carry
frequency, stays, entries and exits (moves in from and out to other states), starts and ends (units whose
observed trajectory begins or ends in the state) and stay rate. A mobility table is added as "transition_matrix"."""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..graph import to_graph
from ..utils import ConfigError, as_list, log, require_columns
from . import register


@register("transitions", "Sequences of states: mobility, trajectories, migration, process steps")
def build(data: pd.DataFrame, opts: dict, cfg: dict):
    unit = opts.get("unit")
    fmt = opts.get("format", "long")
    if fmt == "wide":
        cols = as_list(opts.get("states"))
        require_columns(data, [unit] + cols, "transitions (wide)")
        if len(cols) < 2:
            raise ConfigError("transitions (wide): 'states' must list at least two columns in time order")
        df = data.reset_index(drop=True)
        uid = df[unit].astype(str) if unit else pd.Series([f"u{i + 1}" for i in range(len(df))])
        long = pd.DataFrame({"unit": np.repeat(uid.to_numpy(), len(cols)),
                             "order": np.tile(np.arange(len(cols)), len(df)),
                             "state": df[cols].to_numpy().ravel()})
    elif fmt == "long":
        state, order = opts.get("state"), opts.get("order")
        if not (unit and state and order):
            raise ConfigError("transitions (long): set 'unit', 'state' and 'order' (time or sequence column)")
        require_columns(data, [unit, state, order], "transitions")
        long = data[[unit, order, state]].rename(columns={unit: "unit", order: "order", state: "state"})
        long["unit"] = long["unit"].astype(str)
    else:
        raise ConfigError("transitions: 'format' must be long or wide")
    long = long[long["state"].notna() & (long["state"].astype(str).str.strip() != "")]
    long = long.assign(state=long["state"].astype(str).str.strip()).sort_values(["unit", "order"], kind="stable")
    if opts.get("collapse_repeats"):                  # count only changes of state
        long = long[long["state"] != long.groupby("unit")["state"].shift()]
    lag = int(opts.get("lag", 1))
    long["next"] = long.groupby("unit")["state"].shift(-lag)
    moves = long.dropna(subset=["next"])
    if moves.empty:
        raise ConfigError("transitions: no unit has two or more states")

    stays = moves[moves["state"] == moves["next"]].groupby("state").size()
    agg = moves.groupby(["state", "next"]).agg(count=("unit", "size"), units=("unit", "nunique")).reset_index()
    out_total = agg.groupby("state")["count"].sum()
    agg["probability"] = (agg["count"] / agg["state"].map(out_total)).round(4)
    table = agg.pivot_table(index="state", columns="next", values="count", fill_value=0).astype(int)
    table.index.name, table.columns.name = "origin", "destination"
    if not opts.get("self_loops", False):
        agg = agg[agg["state"] != agg["next"]]
    agg = agg[agg["count"] >= float(opts.get("min_transitions", 1))]
    wkey = opts.get("weight", "count")
    if wkey not in ("count", "probability", "units"):
        raise ConfigError("transitions: 'weight' must be count, probability or units")
    edges = agg.rename(columns={"state": "source", "next": "target"}).assign(weight=lambda d: d[wkey].astype(float))

    first = long.groupby("unit")["state"].first().value_counts()
    last = long.groupby("unit")["state"].last().value_counts()
    nodes = long.groupby("state").agg(frequency=("unit", "size"), units=("unit", "nunique")).rename_axis("id").reset_index()
    nodes["stays"] = nodes["id"].map(stays).fillna(0).astype(int)
    change = moves[moves["state"] != moves["next"]]
    nodes["entries"] = nodes["id"].map(change.groupby("next").size()).fillna(0).astype(int)
    nodes["exits"] = nodes["id"].map(change.groupby("state").size()).fillna(0).astype(int)
    nodes["starts"] = nodes["id"].map(first).fillna(0).astype(int)
    nodes["ends"] = nodes["id"].map(last).fillna(0).astype(int)
    outflow = out_total.reindex(nodes["id"]).fillna(0).to_numpy()
    nodes["stay_rate"] = np.where(outflow > 0, nodes["stays"] / np.where(outflow > 0, outflow, 1), np.nan).round(4)
    nodes["type"] = "state"
    nodes["keep_isolated"] = True
    G = to_graph(edges, directed=True, nodes=nodes, self_loops=bool(opts.get("self_loops", False)))
    n_moves = int(len(moves))
    changes = int((moves["state"] != moves["next"]).sum())
    G.graph["summary"] = {"units": int(long["unit"].nunique()), "transitions": n_moves,
                          "mobility_rate": round(changes / n_moves, 4) if n_moves else 0}
    G.graph["tables"] = {"transition_matrix": table.reset_index()}
    log.info(f"transitions: {long['unit'].nunique():,} units, {n_moves:,} transitions, {len(nodes)} states")
    return G
