"""Exponential random graph models (ERGM): which local patterns make ties more or less likely.

  analysis:
    ergm:
      terms: [edges, gwesp(0.5), nodematch(sex), nodecov(age)]   # empty: edges + gwesp(0.5) (+ mutual if directed)
      method: auto          # mple | mcmle | auto (MCMC maximum likelihood up to 150 nodes, otherwise pseudo-likelihood)
      samples: 500          # networks simulated in each MCMC round
      gof: true             # goodness of fit: degrees, shared partners and distances of simulated networks
      max_seconds: 300

P(Y = y) is proportional to exp(theta . g(y)), where g counts patterns (ties, reciprocated ties, shared partners, ties
between similar nodes…). A positive coefficient means that a tie which adds one unit of that pattern is more likely,
holding the rest constant; exp(coefficient) multiplies its conditional odds.

Terms (names and definitions as in the R package ergm, Hunter et al. 2008; Morris, Handcock & Hunter 2008):
  edges · mutual (directed) · triangles (undirected) · ttriple (directed transitive triples) · isolates
  gwesp(decay): geometrically weighted edgewise shared partners; outgoing two-paths in directed networks
                (Snijders, Pattison, Robins & Handcock 2006; Hunter 2007)
  gwdegree(decay) (undirected) · gwidegree(decay) · gwodegree(decay) (directed)   (Hunter 2007)
  nodematch(attr) · nodefactor(attr) · nodecov(attr) · absdiff(attr) · nodeicov(attr) · nodeocov(attr) (directed)

Estimation
  mple: maximum pseudo-likelihood, a logistic regression of each dyad on its change statistics (Strauss & Ikeda 1990);
        exact for models without dependence terms, approximate standard errors otherwise.
  mcmle: Monte Carlo maximum likelihood (Geyer & Thompson 1992; Hunter & Handcock 2006) started at the MPLE, with
        tie/no-tie Metropolis–Hastings sampling (Morris, Handcock & Hunter 2008) and the step length of Hummel, Hunter &
        Handcock (2012); converged when every simulated mean is within 0.1 standard deviations of the observed statistic.
  gof:  observed degrees, edgewise shared partners and geodesic distances against networks simulated from the model
        (Hunter, Goodreau & Handcock 2008).
Ties are taken as present or absent (weights are ignored).
"""
from __future__ import annotations

import math
import random
import re
import time

import networkx as nx
import numpy as np
import pandas as pd

from .utils import ConfigError, log

LIMIT_MCMLE, LIMIT_MPLE = 500, 2000
TERM_RE = re.compile(r"^\s*([a-z_]+)\s*(?:\(\s*([^)]*)\))?\s*$", re.I)
ALIASES = {"triangle": "triangles", "edge": "edges", "gwesp_fixed": "gwesp"}
DIRECTED_ONLY = {"mutual", "ttriple", "gwidegree", "gwodegree", "nodeicov", "nodeocov"}
UNDIRECTED_ONLY = {"triangles", "gwdegree"}
ATTRIBUTE_TERMS = {"nodematch", "nodefactor", "nodecov", "absdiff", "nodeicov", "nodeocov"}
DECAY_TERMS = {"gwesp", "gwdegree", "gwidegree", "gwodegree"}
KNOWN = {"edges", "isolates"} | DIRECTED_ONLY | UNDIRECTED_ONLY | ATTRIBUTE_TERMS | DECAY_TERMS


class State:
    """The network being sampled: neighbor sets and a list of ties (for tie/no-tie proposals)."""

    def __init__(self, n, directed, edges=()):
        self.n, self.directed = n, directed
        self.out = [set() for _ in range(n)]
        self.inn = [set() for _ in range(n)] if directed else self.out
        self.elist, self.eidx = [], {}
        for i, j in edges:
            self.add(i, j)

    def key(self, i, j):
        return (i, j) if self.directed or i < j else (j, i)

    def has(self, i, j):
        return j in self.out[i]

    def add(self, i, j):
        self.out[i].add(j)
        self.inn[j].add(i)
        k = self.key(i, j)
        self.eidx[k] = len(self.elist)
        self.elist.append(k)

    def remove(self, i, j):
        self.out[i].discard(j)
        self.inn[j].discard(i)
        k = self.key(i, j)
        pos = self.eidx.pop(k)
        last = self.elist.pop()
        if last != k:
            self.elist[pos] = last
            self.eidx[last] = pos

    def copy(self):
        return State(self.n, self.directed, list(self.elist))


class Model:
    """Terms of the model and their change statistics: how g(y) changes when the tie i→j is added."""

    def __init__(self, G: nx.Graph, nodes, terms):
        self.n, self.directed = len(nodes), G.is_directed()
        self.names, self.parts, self.base = [], [], []
        for raw in terms:
            m = TERM_RE.match(str(raw))
            if not m:
                raise ConfigError(f"ERGM term not understood: {raw!r} (examples: edges, gwesp(0.5), nodematch(sex))")
            name, arg = ALIASES.get(m.group(1).lower(), m.group(1).lower()), (m.group(2) or "").strip()
            if name not in KNOWN:
                raise ConfigError(f"Unknown ERGM term {name!r}. Available: {', '.join(sorted(KNOWN))}")
            if self.directed and name in UNDIRECTED_ONLY:
                raise ConfigError(f"ERGM term {name} is for undirected networks"
                                  + (" (use ttriple or gwesp)" if name == "triangles" else " (use gwidegree / gwodegree)"))
            if not self.directed and name in DIRECTED_ONLY:
                raise ConfigError(f"ERGM term {name} is for directed networks")
            if name in ATTRIBUTE_TERMS:
                if not arg:
                    raise ConfigError(f"ERGM term {name} needs a node attribute, e.g. {name}(sex)")
                vals = [G.nodes[v].get(arg) for v in nodes]
                if all(v is None or (isinstance(v, float) and math.isnan(v)) for v in vals):
                    raise ConfigError(f"ERGM term {name}({arg}): no node has the attribute {arg!r}")
                self._attribute_term(name, arg, vals)
            elif name in DECAY_TERMS:
                decay = float(arg) if arg else 0.5
                r = 1 - math.exp(-decay)
                self.parts.append((name, r, math.exp(decay)))
                self.names.append(f"{name}({decay:g})")
                self.base.append(0.0)
            else:
                self.parts.append((name, None, None))
                self.names.append(name)
                self.base.append(float(self.n) if name == "isolates" else 0.0)   # g(empty network)

    def _attribute_term(self, name, arg, vals):
        if name in ("nodematch", "nodefactor"):
            cats = [None if v is None or (isinstance(v, float) and math.isnan(v)) else str(v) for v in vals]
            if name == "nodematch":
                self.parts.append(("nodematch", cats, None))
                self.names.append(f"nodematch({arg})")
                self.base.append(0.0)
            else:
                levels = sorted({c for c in cats if c is not None})
                for lev in levels[1:]:                               # first level is the reference, as in ergm
                    self.parts.append(("nodefactor", [c == lev for c in cats], None))
                    self.names.append(f"nodefactor({arg}).{lev}")
                    self.base.append(0.0)
            return
        nums = []
        for v in vals:
            try:
                x = float(v)
                nums.append(None if math.isnan(x) else x)
            except (TypeError, ValueError):
                nums.append(None)
        present = [x for x in nums if x is not None]
        if not present:
            raise ConfigError(f"ERGM term {name}({arg}) needs a numeric attribute")
        if len(present) < len(nums):
            mean = sum(present) / len(present)
            log.warning(f"ERGM {name}({arg}): {len(nums) - len(present)} nodes without a value use the mean, {mean:.4g}")
            nums = [mean if x is None else x for x in nums]
        self.parts.append((name, nums, None))
        self.names.append(f"{name}({arg})")
        self.base.append(0.0)

    def delta(self, i, j, st: State, y: bool):
        """Change in each statistic when i→j is added to the network without it (y: whether it is present now)."""
        out, inn, yy = st.out, st.inn, 1 if y else 0
        res = []
        for name, a, b in self.parts:
            if name == "edges":
                res.append(1.0)
            elif name == "mutual":
                res.append(1.0 if i in out[j] else 0.0)
            elif name == "triangles":
                res.append(float(len(out[i] & out[j])))
            elif name == "ttriple":
                res.append(float(len(out[i] & out[j]) + len(inn[i] & inn[j]) + len(out[i] & inn[j])))
            elif name == "isolates":
                if self.directed:
                    di, dj = len(out[i]) + len(inn[i]) - yy, len(out[j]) + len(inn[j]) - yy
                else:
                    di, dj = len(out[i]) - yy, len(out[j]) - yy
                res.append(-float(di == 0) - float(dj == 0))
            elif name == "gwesp":
                r, ea = a, b
                if self.directed:                                   # outgoing two-paths i→k→j
                    c = len(out[i] & inn[j])
                    s = sum(r ** (len(out[i] & inn[h]) - yy) for h in out[i] & out[j])
                    s += sum(r ** (len(out[h] & inn[j]) - yy) for h in inn[i] & inn[j])
                else:
                    cn = out[i] & out[j]
                    c = len(cn)
                    s = sum(r ** (len(out[i] & out[h]) - yy) + r ** (len(out[j] & out[h]) - yy) for h in cn)
                res.append(ea * (1 - r ** c) + s)
            elif name == "gwdegree":
                res.append(a ** (len(out[i]) - yy) + a ** (len(out[j]) - yy))
            elif name == "gwidegree":
                res.append(a ** (len(inn[j]) - yy))
            elif name == "gwodegree":
                res.append(a ** (len(out[i]) - yy))
            elif name == "nodematch":
                res.append(1.0 if a[i] is not None and a[i] == a[j] else 0.0)
            elif name == "nodefactor":
                res.append(float(a[i]) + float(a[j]))
            elif name == "nodecov":
                res.append(a[i] + a[j])
            elif name == "absdiff":
                res.append(abs(a[i] - a[j]))
            elif name == "nodeocov":
                res.append(a[i])
            elif name == "nodeicov":
                res.append(a[j])
        return res

    def statistics(self, edges):
        """g(y): the change statistics summed while the ties are added one by one, plus g(empty network)."""
        st, g = State(self.n, self.directed), list(self.base)
        for i, j in edges:
            d = self.delta(i, j, st, False)
            g = [x + z for x, z in zip(g, d)]
            st.add(i, j)
        return np.array(g)


# ---------------------------------------------------------------- pseudo-likelihood
def _dyads(n, directed):
    for i in range(n):
        for j in (range(n) if directed else range(i + 1, n)):
            if i != j:
                yield i, j


def _logistic(X, y, w):
    p = X.shape[1]
    beta = np.zeros(p)

    def ll(b):
        eta = X @ b
        return float(np.sum(w * (y * eta - np.logaddexp(0, eta))))

    cur = ll(beta)
    for _ in range(200):
        eta = X @ beta
        mu = 1 / (1 + np.exp(-eta))
        H = X.T @ (X * (w * mu * (1 - mu))[:, None]) + 1e-9 * np.eye(p)
        step = np.linalg.solve(H, X.T @ (w * (y - mu)))
        t = 1.0
        while t > 1e-6:
            new = ll(beta + t * step)
            if new >= cur - 1e-12:
                break
            t /= 2
        beta, delta, cur = beta + t * step, np.max(np.abs(t * step)), new
        if delta < 1e-9:
            break
    mu = 1 / (1 + np.exp(-(X @ beta)))
    H = X.T @ (X * (w * mu * (1 - mu))[:, None])
    return beta, np.linalg.pinv(H), cur


def mple(model: Model, st: State, g_obs=None):
    rows, ys = [], []
    for i, j in _dyads(model.n, model.directed):
        y = st.has(i, j)
        rows.append(model.delta(i, j, st, y))
        ys.append(1.0 if y else 0.0)
    X, y = np.array(rows, dtype=float), np.array(ys)
    p = X.shape[1]
    beta, cov = np.full(p, np.nan), np.full((p, p), np.nan)
    keep, free = np.ones(len(y), dtype=bool), []
    for k in range(p):                                  # observed statistic at its smallest or largest possible value
        up, down = X[:, k] > 0, X[:, k] < 0             # (no dyad could move it further): coefficient −inf or +inf, as in ergm
        if not (up.any() or down.any()):
            if g_obs is not None and g_obs[k] == 0 and model.parts[k][0] not in ("nodecov", "absdiff", "nodeicov", "nodeocov"):
                beta[k] = -np.inf                       # a count at zero that no single tie could raise
                log.warning(f"ERGM term {model.names[k]}: the observed value is the smallest possible; "
                            "its coefficient is fixed at -infinity, as in the R package ergm")
            else:
                beta[k] = 0.0
                log.warning(f"ERGM term {model.names[k]}: no tie changes it in this network; it cannot be estimated")
            continue
        if np.all(y[up] == 0) and np.all(y[down] == 1):
            beta[k] = -np.inf
        elif np.all(y[up] == 1) and np.all(y[down] == 0):
            beta[k] = np.inf
        if not np.isinf(beta[k]):
            free.append(k)
        else:
            keep &= X[:, k] == 0
            log.warning(f"ERGM term {model.names[k]}: the observed value is the most extreme possible; "
                        f"its coefficient is fixed at {'-' if beta[k] < 0 else '+'}infinity, as in the R package ergm")
    data = np.column_stack([X[keep][:, free], y[keep]])
    uniq, counts = np.unique(data, axis=0, return_counts=True)       # identical dyads weigh once, with their count
    b, c, pll = _logistic(uniq[:, :-1], uniq[:, -1], counts.astype(float))
    beta[free] = b
    cov[np.ix_(free, free)] = c
    if np.any(np.abs(b) > 15):
        log.warning("ERGM: some coefficients are very large (a pattern that almost never or always occurs); interpret with care")
    return beta, cov, pll


# ---------------------------------------------------------------- simulation
def _sampler(model, theta, st: State, rng: random.Random, steps, every=0, on_sample=None):
    """Tie/no-tie Metropolis–Hastings. Returns the change in g(y) over the run."""
    n, directed = model.n, model.directed
    dyads = n * (n - 1) if directed else n * (n - 1) // 2
    th = list(theta)
    change = [0.0] * len(th)
    for step in range(1, steps + 1):
        E = len(st.elist)
        if E and rng.random() < 0.5:
            i, j = st.elist[rng.randrange(E)]
        else:
            i = rng.randrange(n)
            j = rng.randrange(n - 1)
            if j >= i:
                j += 1
            if not directed and i > j:
                i, j = j, i
        y = j in st.out[i]
        d = model.delta(i, j, st, y)
        s = sum(t * x for t, x in zip(th, d) if x)
        if y:
            s = -s
        if s != s:                                      # inf - inf: a move both forbidden and forced
            continue
        E2 = E - 1 if y else E + 1
        qf = (0.5 / E if (E and y) else 0.0) + (0.5 if E else 1.0) / dyads
        qr = (0.5 / E2 if (E2 and not y) else 0.0) + (0.5 if E2 else 1.0) / dyads
        a = s + math.log(qr / qf)
        if a >= 0 or (a > -745 and rng.random() < math.exp(a)):
            if y:
                st.remove(i, j)
                change = [c - x for c, x in zip(change, d)]
            else:
                st.add(i, j)
                change = [c + x for c, x in zip(change, d)]
        if every and step % every == 0 and on_sample:
            on_sample(change)
    return change


def simulate_stats(model, theta, st0, g0, samples, interval, burnin, rng):
    st = st0.copy()
    base = np.array(_sampler(model, theta, st, rng, burnin))
    out = []
    _sampler(model, theta, st, rng, samples * interval, interval, lambda c: out.append(list(c)))
    return g0 + base + np.array(out), st


def _inside(Z, x):
    """Is x inside the cloud of simulated statistics? (Mahalanobis approximation of the convex hull.)"""
    mu = Z.mean(0)
    P = np.linalg.pinv(np.cov(Z.T).reshape(len(mu), len(mu)))
    d = np.einsum("ij,jk,ik->i", Z - mu, P, Z - mu)
    return float((x - mu) @ P @ (x - mu)) <= float(np.quantile(d, 0.95))


def _gt_step(theta0, Z, g_obs, iters=30):
    """Geyer–Thompson: maximizes the importance-sampling approximation of the log-likelihood ratio."""
    th = theta0.copy()

    def parts(t):
        a = (Z - g_obs) @ (t - theta0)
        w = np.exp(a - a.max())
        w /= w.sum()
        return a, w

    def obj(t):
        a = (Z - g_obs) @ (t - theta0)
        return -(np.log(np.mean(np.exp(a - a.max()))) + a.max())

    cur = obj(th)
    for _ in range(iters):
        _, w = parts(th)
        if 1 / np.sum(w ** 2) < 0.1 * len(Z):                     # weights too uneven: stop here, resample
            break
        m = w @ Z
        C = (Z - m).T @ ((Z - m) * w[:, None])
        step = np.linalg.pinv(C) @ (g_obs - m)
        t = 1.0
        while t > 1e-4:
            new = obj(th + t * step)
            if new >= cur - 1e-12:
                break
            t /= 2
        th, cur = th + t * step, new
        if np.max(np.abs(t * step)) < 1e-7:
            break
    return th


def mcmle(model, st, g_obs, theta0, rng, samples, interval, burnin, max_iter, deadline):
    free = np.isfinite(theta0)
    theta, Z, converged, it = theta0.copy(), None, False, 0
    for it in range(1, max_iter + 1):
        Zfull, _ = simulate_stats(model, theta, st, g_obs, samples, interval, burnin, rng)
        Z = Zfull[:, free]
        sd = Z.std(0)
        if "edges" in model.names:
            e = Z[:, model.names.index("edges")].mean()
            dyads = model.n * (model.n - 1) / (1 if model.directed else 2)
            if e < 1 or e > 0.98 * dyads:
                log.warning("ERGM: the simulated networks are almost empty or complete: the model looks degenerate "
                            "(replace triangles by gwesp, or remove terms)")
                break
        tr = np.where(sd > 0, (Z.mean(0) - g_obs[free]) / np.where(sd > 0, sd, 1), 0.0)
        if np.all(np.abs(tr) < 0.1):
            converged = True
            theta[free] = _gt_step(theta[free], Z, g_obs[free])        # final Monte Carlo MLE from the last sample
            break
        if time.monotonic() > deadline:
            log.warning("ERGM: time limit reached before convergence")
            break
        mu, obs = Z.mean(0), g_obs[free]
        gamma = next((g for g in np.arange(1.0, 0.0, -0.05) if _inside(Z, g * obs + (1 - g) * mu)), 0.05)
        if gamma >= 0.999:
            theta[free] = _gt_step(theta[free], Z, obs)
        else:
            theta[free] = theta[free] + np.linalg.pinv(np.cov(Z.T).reshape(len(mu), len(mu))) @ (gamma * obs + (1 - gamma) * mu - mu)
    cov = tr_full = None
    if Z is not None:
        cov = np.full((len(theta), len(theta)), np.nan)
        cov[np.ix_(free, free)] = np.linalg.pinv(np.cov(Z.T).reshape(int(free.sum()), int(free.sum())))
        tr_full = np.full(len(theta), np.nan)
        tr_full[free] = (Z.mean(0) - g_obs[free]) / np.where(Z.std(0) > 0, Z.std(0), np.nan)
    return theta, cov, converged, it, tr_full, Z


# ---------------------------------------------------------------- goodness of fit
def _gof_stats(st: State, cap_deg=30, cap_esp=20, cap_dist=15):
    n, directed = st.n, st.directed
    res = {}
    if directed:
        res["in-degree"] = np.bincount([min(len(s), cap_deg) for s in st.inn], minlength=cap_deg + 1)
        res["out-degree"] = np.bincount([min(len(s), cap_deg) for s in st.out], minlength=cap_deg + 1)
        esp = [len(st.out[i] & st.inn[j]) for i, j in st.elist]
    else:
        res["degree"] = np.bincount([min(len(s), cap_deg) for s in st.out], minlength=cap_deg + 1)
        esp = [len(st.out[i] & st.out[j]) for i, j in st.elist]
    res["shared partners"] = np.bincount([min(x, cap_esp) for x in esp], minlength=cap_esp + 1)
    dist = np.zeros(cap_dist + 2)                                   # 1..cap, last = unreachable
    for s in range(n):
        seen, frontier, d = {s}, [s], 0
        while frontier and d < cap_dist:
            d += 1
            nxt = []
            for u in frontier:
                for v in st.out[u]:
                    if v not in seen:
                        seen.add(v)
                        nxt.append(v)
            dist[d] += len(nxt)
            frontier = nxt
        dist[-1] += n - len(seen)
    if not directed:
        dist /= 2
    res["distance"] = dist[1:]
    return res


def gof(model, theta, st_obs, rng, nsim, interval, burnin):
    obs = _gof_stats(st_obs)
    st = st_obs.copy()
    _sampler(model, theta, st, rng, burnin)
    sims = []
    for _ in range(nsim):
        _sampler(model, theta, st, rng, interval)
        sims.append(_gof_stats(st))
    rows, outside = [], 0
    for stat, o in obs.items():
        S = np.array([s[stat] for s in sims])
        last = max(int(np.max(np.nonzero(o)[0])) if o.any() else 0, int(np.max(np.nonzero(S.sum(0))[0])) if S.any() else 0)
        for k in range(last + 1):
            if stat == "distance":
                label = "unreachable" if k == len(o) - 1 else str(k + 1)
            else:
                label = str(k)
            lo, hi = np.percentile(S[:, k], [2.5, 97.5])
            out_ = bool(o[k] < lo or o[k] > hi)
            outside += out_
            rows.append({"statistic": stat, "value": label, "observed": float(o[k]), "simulated_mean": round(float(S[:, k].mean()), 3),
                         "low_2.5": float(lo), "high_97.5": float(hi), "outside": out_})
    return pd.DataFrame(rows), (outside / len(rows) if rows else 0.0)


# ---------------------------------------------------------------- entry point
def ergm(G: nx.Graph, spec, seed: int = 2026) -> tuple[dict, dict]:
    spec = spec if isinstance(spec, dict) else {}
    nodes = list(G)
    n, directed = len(nodes), G.is_directed()
    if n < 3 or G.number_of_edges() == 0:
        log.warning("ERGM: needs at least 3 nodes and one tie")
        return {}, {}
    if n > LIMIT_MPLE:
        log.warning(f"ERGM: skipped for {n:,} nodes (limit {LIMIT_MPLE:,}); filter the network or take a sample")
        return {}, {}
    terms = spec.get("terms") or (["edges", "mutual", "gwesp(0.5)"] if directed else ["edges", "gwesp(0.5)"])
    if isinstance(terms, str):
        terms = [t for t in re.split(r",(?![^(]*\))", terms) if t.strip()]
    model = Model(G, nodes, terms)
    idx = {v: k for k, v in enumerate(nodes)}
    edges = []
    for u, v in G.edges():
        if u != v:
            edges.append((idx[u], idx[v]) if directed else tuple(sorted((idx[u], idx[v]))))
    edges = list(dict.fromkeys(edges))
    st = State(n, directed, edges)
    g_obs = model.statistics(edges)
    method = str(spec.get("method", "auto")).lower()
    if method not in ("auto", "mple", "mcmle"):
        raise ConfigError("analysis.ergm.method must be auto, mple or mcmle")
    dependent = any(p[0] in ("mutual", "triangles", "ttriple", "isolates", "gwesp", "gwdegree", "gwidegree", "gwodegree")
                    for p in model.parts)
    if method == "auto":
        method = "mcmle" if dependent and n <= 150 else "mple"
    if method == "mcmle" and n > LIMIT_MCMLE:
        log.warning(f"ERGM: MCMC estimation is limited to {LIMIT_MCMLE} nodes; using pseudo-likelihood")
        method = "mple"
    t0 = time.monotonic()
    rng = random.Random(seed)
    theta, cov, pll = mple(model, st, g_obs)
    summary = {"ergm_terms": len(model.names)}
    tr, converged, iters = None, None, 0
    samples = int(spec.get("samples", 500))
    interval = int(spec.get("interval", max(256, 2 * n)))
    burnin = int(spec.get("burnin", 16 * interval))
    if method == "mcmle" and dependent:
        deadline = t0 + float(spec.get("max_seconds", 300))
        theta, cov, converged, iters, tr, _ = mcmle(model, st, g_obs, theta, rng, samples, interval, burnin,
                                                   int(spec.get("max_iterations", 20)), deadline)
        summary.update({"ergm_method": "MCMC maximum likelihood", "ergm_converged": bool(converged), "ergm_iterations": iters})
        if not converged:
            log.warning("ERGM: the MCMC estimation did not converge; treat the results as provisional "
                        "(try fewer or other terms, or more samples)")
    else:
        summary.update({"ergm_method": "maximum pseudo-likelihood", "ergm_pseudo_loglik": round(pll, 3)})
        if dependent:
            log.warning("ERGM: with dependence terms, pseudo-likelihood standard errors are only approximate")
    se = np.sqrt(np.clip(np.diag(cov), 0, None)) if cov is not None else np.full(len(theta), np.nan)
    se = np.where(np.isfinite(theta), se, np.nan)
    rows = []
    for k, name in enumerate(model.names):
        z = theta[k] / se[k] if math.isfinite(theta[k]) and se[k] > 0 else float("nan")
        p = math.erfc(abs(z) / math.sqrt(2)) if math.isfinite(z) else float("nan")
        est = float(theta[k])
        row = {"term": name, "estimate": round(est, 4) if math.isfinite(est) else ("-inf" if est < 0 else "inf"),
               "std_error": round(float(se[k]), 4) if math.isfinite(se[k]) else None,
               "z": round(float(z), 3) if math.isfinite(z) else None, "p_value": round(p, 4) if math.isfinite(p) else None,
               "odds_ratio": round(math.exp(min(est, 50)), 4) if math.isfinite(est) else (0.0 if est < 0 else None),
               "observed": round(float(g_obs[k]), 3)}
        if tr is not None:
            row["mcmc_t"] = round(float(tr[k]), 3) if math.isfinite(tr[k]) else None
        rows.append(row)
    tables = {"ergm": pd.DataFrame(rows)}
    if spec.get("gof", True) and (method == "mcmle" or n <= LIMIT_MCMLE):
        nsim = int(spec.get("gof_samples", 100 if n <= 100 else 50))
        gt, share = gof(model, theta, st, rng, nsim, 2 * interval, burnin)
        tables["ergm_gof"] = gt
        summary["ergm_gof_outside"] = round(share, 3)
    summary["ergm_seconds"] = round(time.monotonic() - t0, 1)
    return summary, tables
