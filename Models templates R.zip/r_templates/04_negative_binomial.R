# =====================================================================
#  04 · NEGATIVE BINOMIAL REGRESSION
#  For: overdispersed counts (variance greater than the mean), very common in social data.
#  Interpretation: same as Poisson, with incidence rate ratios (IRR).
#  Compared with Poisson: if theta is small and the LR test is significant, prefer this model.
# =====================================================================

# ---------------------------------------------------------------------
# 0. SETTINGS · edit this section only
# ---------------------------------------------------------------------
file           <- NULL
outcome        <- "n_organizations"
predictors     <- c("head_educ", "head_age", "head_sex", "area", "hh_size")
factors        <- list(head_sex = "male", area = "urban")
extra_terms    <- NULL
manual_formula <- NULL
exposure       <- NULL                    # exposure variable; enters as offset(log())
focus_variable <- "head_educ"
use_design     <- FALSE                   # see the note in section 2
design         <- list(stratum = "stratum", psu = "psu", weight = "weight")
output_dir     <- "results/04_negative_binomial"

# ---------------------------------------------------------------------
# 1. Preparation
# ---------------------------------------------------------------------
source("utils.R"); install_if_missing()
out     <- prepare_output(output_dir)
formula <- build_formula(outcome, predictors,
                         c(extra_terms, if (!is.null(exposure)) sprintf("offset(log(%s))", exposure)),
                         manual_formula)
data    <- prepare_data(load_data(file), formula_vars(formula), factors, extra = design_vars(use_design, design))
y <- all.vars(formula)[1]
if (any(data[[y]] < 0 | data[[y]] != round(data[[y]]))) stop("The outcome must be a non-negative integer count.")

# ---------------------------------------------------------------------
# 2. Estimation
#    The survey package does not fit negative binomial models. With 'use_design = TRUE'
#    the template uses the weights and cluster-robust standard errors: a reasonable
#    approximation that ignores the strata. Report it as such.
# ---------------------------------------------------------------------
header("Models")
if (use_design) {
  data$.w <- data[[design$weight]] / mean(data[[design$weight]])   # normalized weights (sum to n)
  model   <- MASS::glm.nb(formula, data = data, weights = .w)
  poisson <- glm(formula, data = data, family = poisson(), weights = .w)
  vc <- sandwich::vcovCL(model, cluster = data[[design$psu]])
  message("Design approximation: normalized weights + cluster-robust standard errors.")
} else {
  model   <- MASS::glm.nb(formula, data = data)
  poisson <- glm(formula, data = data, family = poisson())
  vc <- NULL
}
print(summary(model))
coefs <- coef_table(model, exponentiate = TRUE, vcov = vc)
names(coefs) <- sub("^exp_", "irr_", names(coefs))
print(round_df(coefs, 3)); save_table(coefs, "2_coefficients", out)

# ---------------------------------------------------------------------
# 3. Negative binomial or Poisson?
# ---------------------------------------------------------------------
header("Comparison with Poisson")
lr <- 2 * as.numeric(logLik(model) - logLik(poisson))
comp <- compare_models(poisson = poisson, negative_binomial = model)
comp$theta <- c(NA, model$theta)
print(round_df(comp, 3)); save_table(comp, "3_model_comparison", out)
p_lr <- 0.5 * pchisq(lr, df = 1, lower.tail = FALSE)            # boundary test: p / 2
cat(sprintf("LR test (H0: Poisson): chi2 = %.2f, p = %.4g → %s\n", lr, p_lr,
            ifelse(p_lr < .05, "prefer negative binomial", "Poisson is enough")))
cat(sprintf("theta = %.3f (smaller = more overdispersion)\n", model$theta))
mu <- fitted(model)
cat(sprintf("Observed zeros: %.1f %% · expected by the model: %.1f %%\n",
            100 * mean(data[[y]] == 0), 100 * mean(dnbinom(0, size = model$theta, mu = mu))))

# ---------------------------------------------------------------------
# 4. Interpretation
# ---------------------------------------------------------------------
header("Average marginal effects (change in expected count)")
ame <- marginal_effects(model, data, NULL, weights = if (use_design) data$.w else NULL,
                        vcov = if (is.null(vc)) TRUE else vc)
print(round_df(ame, 4)); save_table(ame, "4_marginal_effects", out)
save_plot(prediction_plot(model, data, focus_variable, NULL, paste("Expected count of", y)), "4_predictions", out)
save_text(summary(model), "model_summary", out)
header(paste("Done. Results in", out))
