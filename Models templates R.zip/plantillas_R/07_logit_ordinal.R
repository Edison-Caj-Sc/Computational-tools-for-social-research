# =====================================================================
#  07 · LOGIT ORDINAL (odds proporcionales)
#  Para: variables con categorías ordenadas: escalas Likert, confianza, satisfacción,
#  nivel educativo, autopercepción de clase.
#  Interpretación: OR > 1 → mayor probabilidad de estar en categorías más altas.
#  Supuesto clave: el efecto de cada variable es igual en todos los cortes (se verifica abajo).
# =====================================================================

# ---------------------------------------------------------------------
# 0. CONFIGURACIÓN · edita solo esta sección
# ---------------------------------------------------------------------
archivo        <- NULL
dependiente    <- "confianza"
orden          <- c("nada", "poca", "suficiente", "mucha")   # de menor a mayor
predictores    <- c("educ_jefe", "participa_org", "sexo_jefe", "area", "edad_jefe")
factores       <- list(sexo_jefe = "hombre", area = "urbano")
terminos_extra <- NULL
formula_manual <- NULL
variable_foco  <- "educ_jefe"
usar_diseno    <- FALSE
diseno         <- list(estrato = "estrato", conglomerado = "conglome", peso = "factor07")
carpeta_salida <- "resultados/07_logit_ordinal"

# ---------------------------------------------------------------------
# 1. Preparación
# ---------------------------------------------------------------------
source("utilidades.R"); instalar_si_falta()
salida  <- preparar_salida(carpeta_salida)
formula <- construir_formula(dependiente, predictores, terminos_extra, formula_manual)
y <- all.vars(formula)[1]
datos   <- preparar_datos(cargar_datos(archivo), variables_formula(formula), factores,
                          ordenadas = setNames(list(orden), y), extra = vars_diseno(usar_diseno, diseno))
dis <- if (usar_diseno) crear_diseno(datos, diseno) else NULL

encabezado("Distribución de la variable dependiente")
print(round(prop.table(table(datos[[y]])), 3))

# ---------------------------------------------------------------------
# 2. Estimación
# ---------------------------------------------------------------------
encabezado("Modelo")
modelo <- if (usar_diseno) svyolr(formula, design = dis) else MASS::polr(formula, data = datos, Hess = TRUE)
print(summary(modelo))
ct <- coef(summary(modelo))
es_corte <- rownames(ct) %in% names(modelo$zeta)
z <- ct[, "t value"]
tab <- data.frame(termino = rownames(ct), tipo = ifelse(es_corte, "corte", "coeficiente"),
                  estimacion = ct[, "Value"], ee = ct[, "Std. Error"], z = z, p = 2 * pnorm(-abs(z)))
tab$ic_inf <- tab$estimacion - qnorm(.975) * tab$ee
tab$ic_sup <- tab$estimacion + qnorm(.975) * tab$ee
tab$or <- ifelse(es_corte, NA, exp(tab$estimacion))
tab$or_ic_inf <- ifelse(es_corte, NA, exp(tab$ic_inf))
tab$or_ic_sup <- ifelse(es_corte, NA, exp(tab$ic_sup))
tab$signif <- estrellas(tab$p)
rownames(tab) <- NULL
print(redondear(tab, 3)); guardar_tabla(tab, "2_coeficientes", salida)

# ---------------------------------------------------------------------
# 3. Supuesto de odds proporcionales
#    Se estima un logit binario en cada corte (Y > categoría k). Si los coeficientes
#    cambian mucho entre cortes, el supuesto no se cumple: considera 08_logit_multinomial.R
# ---------------------------------------------------------------------
if (!usar_diseno) {
  encabezado("Verificación de odds proporcionales (logits por corte)")
  niveles <- levels(datos[[y]])
  cortes <- lapply(seq_len(length(niveles) - 1), function(k) {
    d <- datos; d$.y_bin <- as.integer(as.integer(d[[y]]) > k)
    coef(glm(update(formula, .y_bin ~ .), data = d, family = binomial()))[-1]
  })
  po <- as.data.frame(do.call(cbind, cortes))
  names(po) <- paste0("mayor_que_", niveles[-length(niveles)])
  po$ordinal <- coef(modelo)[rownames(po)]
  po$rango_entre_cortes <- apply(po[, seq_along(cortes)], 1, function(x) diff(range(x)))
  po <- cbind(termino = rownames(po), po); rownames(po) <- NULL
  print(redondear(po, 3)); guardar_tabla(po, "3_odds_proporcionales", salida)
  cat("Si un coeficiente cambia de signo o de magnitud de forma marcada entre cortes, el supuesto es dudoso.\n")
  ajuste <- data.frame(n = nobs(modelo), AIC = AIC(modelo), BIC = BIC(modelo),
                       pseudo_r2_mcfadden = 1 - as.numeric(logLik(modelo) /
                                                             logLik(update(modelo, . ~ 1))))
  print(redondear(ajuste, 3)); guardar_tabla(ajuste, "3_ajuste", salida)
}

# ---------------------------------------------------------------------
# 4. Interpretación: efectos marginales sobre la probabilidad de cada categoría
# ---------------------------------------------------------------------
encabezado("Efectos marginales promedio por categoría")
ame <- efectos_marginales(modelo, datos, dis)
print(redondear(ame, 4)); guardar_tabla(ame, "4_efectos_marginales", salida)
g <- grafico_predicciones(modelo, datos, c(variable_foco, "group"), dis, paste("Probabilidad de cada categoría de", y)) +
  labs(y = "Probabilidad", colour = y, fill = y)
g$data$group <- factor(g$data$group, levels = levels(datos[[y]]))   # leyenda en el orden de la escala
guardar_grafico(g, "4_predicciones", salida)
guardar_texto(summary(modelo), "resumen_modelo", salida)
encabezado(paste("Listo. Resultados en", salida))
