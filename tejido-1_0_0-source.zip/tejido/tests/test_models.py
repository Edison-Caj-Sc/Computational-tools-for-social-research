"""Blockmodels and ERGM. Reference values were computed with the R packages ergm 4.12.0 (statnet) and blockmodeling 1.1.8
on the same networks: Padgett's Florentine marriages (networkx; Pucci added as the isolate it is in statnet's flomarriage)
and Sampson's monks, 'liking' at the end of the study (statnet's samplike, in tests/data)."""
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
import pytest

from tejido import analyze
from tejido.blockmodel import _counts, _regular_errors, _structural_errors, blockmodel
from tejido.ergm import Model, State, ergm, mple

DATA = Path(__file__).parent / "data"


def florentine():
    G = nx.florentine_families_graph()
    G.add_node("Pucci")
    return G


def sampson():
    G = nx.from_pandas_edgelist(pd.read_csv(DATA / "sampson_like.csv"), create_using=nx.DiGraph)
    for _, r in pd.read_csv(DATA / "sampson_groups.csv").iterrows():
        G.nodes[r["name"]]["group"] = r["group"]
    return G


def _mple(G, terms):
    nodes = list(G)
    idx = {v: k for k, v in enumerate(nodes)}
    edges = [(idx[u], idx[v]) if G.is_directed() else tuple(sorted((idx[u], idx[v]))) for u, v in G.edges()]
    model = Model(G, nodes, terms)
    g = model.statistics(edges)
    beta, _, _ = mple(model, State(len(nodes), G.is_directed(), edges), g)
    return g, beta


@pytest.mark.parametrize("terms,stats,coefs", [
    (["edges", "triangles"], [20, 3], [-1.700935, 0.220849]),
    (["edges", "gwesp(0.25)", "gwdegree(0.5)", "isolates"], [20, 8.221199, 20.937674, 1], [-1.329275, 0.099520, -1.535026, -1.763225])])
def test_ergm_statistics_and_mple_match_statnet_undirected(terms, stats, coefs):
    g, beta = _mple(florentine(), terms)
    assert np.allclose(g, stats, atol=1e-5) and np.allclose(beta, coefs, atol=1e-5)


@pytest.mark.parametrize("terms,stats,coefs", [
    (["edges", "mutual", "nodematch(group)", "nodefactor(group)"], [88, 28, 63, 31, 82], [-2.637498, 1.370228, 2.102708, 0.236608, 0.344450]),
    (["edges", "mutual", "gwesp(0.5)", "gwidegree(0.5)"], [88, 28, 91.879824, 28.307099], None),
    (["edges", "mutual", "ttriple", "isolates"], [88, 28, 154, 0], [-2.537327, 2.230151, 0.190942, -np.inf])])
def test_ergm_statistics_and_mple_match_statnet_directed(terms, stats, coefs):
    g, beta = _mple(sampson(), terms)
    assert np.allclose(g, stats, atol=1e-5)
    if coefs is not None:
        assert np.allclose(beta, coefs, atol=1e-5)          # -inf: statistic at its smallest value, fixed as in ergm


def test_ergm_dyad_independent_mple_is_the_mle():
    G = nx.gnp_random_graph(40, 0.1, seed=4)
    s, t = ergm(G, {"terms": ["edges"], "method": "mple", "gof": False})
    p = G.number_of_edges() / (40 * 39 / 2)
    assert t["ergm"].estimate[0] == pytest.approx(np.log(p / (1 - p)), abs=1e-4)


def test_ergm_mcmle_close_to_statnet_and_gof():
    s, t = ergm(florentine(), {"terms": ["edges", "triangles"], "method": "mcmle"}, seed=1)
    est = t["ergm"].estimate.tolist()
    assert s["ergm_converged"] and abs(est[0] + 1.691) < 0.15 and abs(est[1] - 0.181) < 0.25   # statnet MLE, SE 0.32 and 0.56
    gof = t["ergm_gof"]
    assert set(gof.statistic) == {"degree", "shared partners", "distance"} and 0 <= s["ergm_gof_outside"] <= 1


def test_ergm_detects_homophily():
    rng = np.random.default_rng(5)
    G = nx.Graph()
    G.add_nodes_from((i, {"g": "a" if i < 30 else "b"}) for i in range(60))
    for i in range(60):
        for j in range(i + 1, 60):
            if rng.random() < (0.15 if (i < 30) == (j < 30) else 0.03):
                G.add_edge(i, j)
    s, t = ergm(G, {"terms": ["edges", "nodematch(g)"], "gof": False})
    row = t["ergm"].set_index("term").loc["nodematch(g)"]
    assert row.estimate > 1 and row.p_value < 0.001


def test_ergm_rejects_wrong_terms():
    from tejido.utils import ConfigError
    with pytest.raises(ConfigError):
        ergm(nx.path_graph(5), {"terms": ["edges", "mutual"]})        # mutual needs a directed network
    with pytest.raises(ConfigError):
        ergm(nx.path_graph(5), {"terms": ["edges", "nodematch"]})     # needs an attribute


def test_block_inconsistencies_match_r_blockmodeling():
    G = florentine()
    nodes = ["Acciaiuoli", "Albizzi", "Barbadori", "Bischeri", "Castellani", "Ginori", "Guadagni", "Lamberteschi", "Medici",
             "Pazzi", "Peruzzi", "Pucci", "Ridolfi", "Salviati", "Strozzi", "Tornabuoni"]       # statnet's order
    A = nx.to_numpy_array(G, nodelist=nodes)
    clu = np.array([2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 1, 2, 2, 2, 1, 2]) - 1                 # best partition found by blockmodeling
    T, s, _ = _counts(A, clu, 2)
    assert _structural_errors(T, s) == 32                                               # critFunC(..., c("nul","com"))
    S = sampson()
    A2 = nx.to_numpy_array(S, nodelist=sorted(S))
    lab = np.arange(len(A2)) % 3
    assert _regular_errors(A2, lab, 3)[0] == _regular_errors(A2, lab, 3)[0] >= 0


def test_generalized_blockmodel_finds_as_good_as_r():
    s, _ = blockmodel(florentine(), {"method": "generalized", "blocks": 2}, seed=1)
    assert s["blockmodel_errors"] <= 32                                                 # best of 100 starts in blockmodeling
    s, _ = blockmodel(sampson(), {"method": "generalized", "blocks": 3, "equivalence": "regular"}, seed=1)
    assert s["blockmodel_errors"] <= 3


def _planted(directed=False):
    G = nx.stochastic_block_model([20, 15, 15], [[.6, .05, .02], [.05, .5, .05], [.02, .05, .55]], seed=7, directed=directed)
    truth = [G.nodes[v]["block"] for v in G]
    for v in G:
        del G.nodes[v]["block"]
    return G, truth


def _agreement(a, b):
    """Share of node pairs on which two partitions agree (Rand index)."""
    a, b = np.asarray(a), np.asarray(b)
    same_a, same_b = a[:, None] == a[None, :], b[:, None] == b[None, :]
    iu = np.triu_indices(len(a), 1)
    return float((same_a == same_b)[iu].mean())


@pytest.mark.parametrize("method", ["concor", "structural", "sbm"])
def test_blockmodels_recover_planted_positions(method):
    G, truth = _planted()
    s, t = blockmodel(G, {"method": method, "blocks": None if method == "sbm" else 3}, seed=1)
    found = [G.nodes[v]["block"] for v in G]
    assert _agreement(found, truth) > (0.95 if method == "sbm" else 0.8)
    assert {"blocks", "block_image"} <= set(t) and 0 <= s["blockmodel_r2"] <= 1
    if method == "sbm":
        assert s["blocks"] == 3                               # chosen by ICL


@pytest.mark.parametrize("equivalence", ["structural", "regular"])
def test_generalized_blockmodel_recovers_ideal_blocks(equivalence):
    """Core of 6 nodes (complete) and periphery of 18, each periphery node tied to exactly one core node:
    structural equivalence errs only on the periphery ties; regular equivalence fits perfectly (0 errors)."""
    G = nx.complete_graph(6)
    for i in range(18):
        G.add_edge(6 + i, i % 6)
    s, t = blockmodel(G, {"method": "generalized", "blocks": 2, "equivalence": equivalence}, seed=1)
    found = [G.nodes[v]["block"] for v in sorted(G)]
    assert _agreement(found, [0] * 6 + [1] * 18) == 1.0 and "block_types" in t
    if equivalence == "regular":
        assert s["blockmodel_errors"] == 0 and "regular" in " ".join(t["block_types"].astype(str).values.ravel())


def test_blockmodel_and_ergm_through_the_pipeline():
    G, _ = _planted(directed=True)
    G2, comms, summary, tables = analyze(G, blockmodel={"method": "sbm"}, ergm={"terms": ["edges", "mutual"], "method": "mple", "gof": False},
                                         centrality=["degree"])
    assert "block" in next(iter(G2.nodes(data=True)))[1]
    assert {"ergm", "blocks", "block_image"} <= set(tables) and summary["ergm_method"] == "maximum pseudo-likelihood"
