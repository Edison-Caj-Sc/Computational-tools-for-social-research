"""Tests with small synthetic data (no internet needed)."""
import shutil
from pathlib import Path

import networkx as nx
import pandas as pd
import pytest

import tejido.io as tio
from tejido import build, run
from tejido.cli import main
from tejido.utils import ConfigError

EXAMPLES = Path(__file__).parents[1] / "tejido" / "examples"


@pytest.fixture
def examples(tmp_path):
    dest = tmp_path / "ex"
    shutil.copytree(EXAMPLES, dest, ignore=shutil.ignore_patterns("results"))
    return dest


@pytest.mark.parametrize("name", ["documents", "social_media", "qualitative_codes", "worldbank_csv", "personal_networks",
                                  "trajectories", "survey_items", "districts", "social_evolution"])
def test_examples_run_and_export(examples, name):
    r = run(examples / f"{name}.yaml")
    assert r.graph.number_of_nodes() > 5 and r.graph.number_of_edges() > 5
    out = Path(r.output_dir)
    assert any(out.glob("*.html")) and any(out.glob("*_report.md")) and any(out.glob("*_nodes.csv"))
    for f in out.glob("*.graphml"):
        assert nx.read_graphml(f).number_of_nodes() == r.graph.number_of_nodes()
    for f in out.glob("*.gexf"):
        assert nx.read_gexf(f).number_of_nodes() == r.graph.number_of_nodes()


def test_social_recovers_groups(examples):
    r = run(examples / "social_media.yaml")
    assert r.summary["communities"] == 3 and r.graph.is_directed()


def test_cooccurrence_weights():
    df = pd.DataFrame({"seg": [1, 1, 1, 2, 2, 3, 3, 3, 4], "code": list("abcabacdd")})
    expected = {"count": 2, "jaccard": 2 / 3, "cosine": 2 / 6 ** .5, "newman": 1.5, "association": 4 / 3}
    for w, val in expected.items():
        G = build(df, "cooccurrence", group="seg", item="code", weighting=w)
        assert G["a"]["b"]["weight"] == pytest.approx(val)
    G = build(df, "cooccurrence", group="seg", item="code", mode="bipartite")
    assert G.number_of_edges() == 9 and "keep_isolated" not in G.nodes["1"]


def test_cooccurrence_wide_and_split():
    wide = pd.DataFrame({"id": [1, 2, 3], "c_x": [1, 1, 0], "c_y": [1, 0, 1], "c_z": [0, 1, 1]})
    G = build(wide, "cooccurrence", format="wide", items=["c_*"], group="id")
    assert set(G.edges) == {("c_x", "c_y"), ("c_x", "c_z"), ("c_y", "c_z")}
    long = pd.DataFrame({"paper": ["p1", "p2"], "authors": ["Ana; Luis; Rosa", "Ana; Rosa"]})
    G = build(long, "cooccurrence", group="paper", item="authors", split=";")
    assert G["Ana"]["Rosa"]["weight"] == 2


def test_edgelist_and_matrix(tmp_path):
    df = pd.DataFrame({"from": ["A", "A", "B", "C"], "to": ["B", "B", "A", "A"], "amount": [1, 2, 5, 1],
                       "kind": ["x", "y", "x", "x"]})
    G = build(df, "edgelist", source="from", target="to", weight="amount", edge_attributes={"kind": "values"})
    assert G["A"]["B"]["weight"] == 3 and G["A"]["B"]["kind"] == "x|y" and G.is_directed()
    U = build(df, "edgelist", source="from", target="to", directed=False)
    assert U["A"]["B"]["weight"] == 3
    m = pd.DataFrame({"actor": ["A", "B", "C"], "A": [0, 2, 0], "B": [1, 0, 0], "C": [4, 0, 0]})
    D = build(m, "matrix")
    assert D["A"]["C"]["weight"] == 4 and not D.has_edge("C", "A")
    S = build(m, "matrix", directed=False)
    assert S["A"]["B"]["weight"] == 3
    with pytest.raises(ConfigError):
        build(m.rename(columns={"C": "Z"}), "matrix")


def test_social_counts():
    df = pd.DataFrame({"u": ["ana", "ana", "bob", "cy"], "t": ["hola @Bob #Agua", "@bob y @cy", "ok #agua #Cuenca", "x"],
                       "rt": [None, None, "ana", "ana"]})
    G = build(df, "social", author="u", text="t", repost_of="rt")
    assert G["ana"]["bob"]["weight"] == 2 and G["ana"]["bob"]["n_mention"] == 2
    assert G["bob"]["ana"]["n_repost"] == 1 and G.nodes["ana"]["activity"] == 2
    H = build(df, "social", author="u", text="t", network="hashtags")
    assert set(H.edges) == {("#agua", "#cuenca")} or set(H.edges) == {("#cuenca", "#agua")}


def test_similarity_options():
    rows = [{"id": f"e{i}", "x": i % 3, "y": (i % 3) * 2 + i * .01, "z": i} for i in range(12)]
    df = pd.DataFrame(rows)
    G = build(df, "similarity", entity="id", features=["x", "y"], metric="euclidean", sparsify={"method": "knn", "k": 2})
    assert all(d >= 2 for _, d in G.degree())
    for spec in [{"method": "threshold", "threshold": .5}, {"method": "top_percent", "percent": 10},
                 {"method": "backbone", "alpha": .3}]:
        build(df, "similarity", entity="id", metric="correlation", sparsify=spec)


def test_worldbank_aggregates_and_years(examples):
    wb = tio.read_worldbank_csv(examples / "data" / "worldbank_format_SIMULATED.csv")
    G = build(wb, "similarity", format="worldbank")
    assert "WLD" not in G and "LCN" not in G and "PER" in G and G.nodes["PER"]["label"] == "Peru"
    T = build(wb, "similarity", format="worldbank", indicators=["SP.DYN.LE00.IN"], features_from="years",
              metric="correlation", transform={"scale": "none"})
    assert T.number_of_nodes() > 20


def test_worldbank_api_mocked(monkeypatch):
    def fake(url):
        rec = lambda c, v: {"country": {"id": c[:2], "value": c}, "countryiso3code": c, "indicator": {"id": "X", "value": "Ind"},
                            "date": "2020", "value": v}
        return [{"pages": 1}, [rec("PER", 1.0), rec("BOL", None)]]
    monkeypatch.setattr(tio, "_get_json", fake)
    df = tio.read_worldbank_api(["X"])
    assert list(df["country_code"]) == ["PER"] and df["value"].iloc[0] == 1.0


def test_text_entities_and_splitting():
    es = ("La Autoridad Nacional del Agua (ANA) firmó un convenio con el Gobierno Regional de Cajamarca y la "
          "Municipalidad Provincial de Cajamarca. El Ministerio de Agricultura y Riego coordina con la ANA.")
    G = build(pd.DataFrame({"text": [es]}), "text", language="es")
    assert {"Autoridad Nacional del Agua", "Gobierno Regional de Cajamarca", "Municipalidad Provincial de Cajamarca",
            "Ministerio de Agricultura y Riego"} == set(G.nodes)
    assert G["Autoridad Nacional del Agua"]["Ministerio de Agricultura y Riego"]["main_relation"] == "coordination"
    en = "The Ministry of Health and the World Bank signed an agreement. The Ministry of Agriculture and Rural Development joined."
    G = build(pd.DataFrame({"text": [en]}), "text", language="en")
    assert set(G.nodes) == {"Ministry of Health", "World Bank", "Ministry of Agriculture and Rural Development"}
    with pytest.raises(ConfigError):
        build(pd.DataFrame({"text": ["sin organizaciones aquí"]}), "text")


def test_cli(tmp_path, capsys):
    main(["list", "builders"])
    assert "similarity" in capsys.readouterr().out
    main(["init", str(tmp_path / "ex")])
    assert (tmp_path / "ex" / "documents.yaml").exists() and (tmp_path / "ex" / "docs").is_dir()


def test_config_errors(tmp_path):
    with pytest.raises(ConfigError):
        run({"builder": {}})
    with pytest.raises(ConfigError):
        run({"builder": {"type": "nope"}, "input": {"type": "none"}})
