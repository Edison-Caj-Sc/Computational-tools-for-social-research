"""Interfaz de línea de comandos: inei-pipeline <comando>."""
from __future__ import annotations

import argparse
import sys

from .utils import ConfigError, log


def main(argv=None):
    p = argparse.ArgumentParser(prog="inei-pipeline",
                                description="Descarga, une, armoniza, estandariza e imputa microdatos del INEI.")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("iniciar", help="Crea una configuración de ejemplo comentada")
    s.add_argument("archivo", nargs="?", default="config.yaml")

    s = sub.add_parser("ejecutar", help="Ejecuta el flujo completo")
    s.add_argument("config")
    s.add_argument("--sin-descarga", action="store_true", help="Usar archivos ya descargados")

    s = sub.add_parser("descargar", help="Solo descarga los módulos")
    s.add_argument("config")

    s = sub.add_parser("buscar", help="Busca variables por nombre o descripción")
    s.add_argument("texto")
    s.add_argument("--encuesta", default=None)
    s.add_argument("--anio", default=None)

    s = sub.add_parser("rastrear", help="Muestra cómo cambia una variable entre años (útil para armonizar)")
    s.add_argument("variable")
    s.add_argument("--encuesta", default="Condiciones de Vida y Pobreza - ENAHO")

    s = sub.add_parser("encuestas", help="Lista las encuestas del catálogo del INEI")
    s.add_argument("filtro", nargs="?", default=None, help="Texto para filtrar (opcional)")

    sub.add_parser("operaciones", help="Lista las operaciones de estandarización e imputación")

    a = p.parse_args(argv)
    try:
        if a.cmd == "iniciar":
            from .config import write_template
            print(f"Creado {write_template(a.archivo)}. Edítalo y luego: inei-pipeline ejecutar {a.archivo}")
        elif a.cmd == "ejecutar":
            from .pipeline import run
            run(a.config, descargar=False if a.sin_descarga else None)
        elif a.cmd == "descargar":
            from .pipeline import Pipeline
            Pipeline(a.config).download()
        elif a.cmd == "buscar":
            from inei_microdatos import search_variables
            seen = set()
            for r in search_variables(a.texto, survey=a.encuesta, year=a.anio):
                key = (r["variable"], r["module_name"])
                if key not in seen:
                    seen.add(key)
                    print(f"{r['variable']:<14} {r['year']}  {r['module_name'][:28]:<28} {r['label'][:70]}")
                if len(seen) >= 60:
                    print("… (más resultados; afina la búsqueda)")
                    break
        elif a.cmd == "rastrear":
            from inei_microdatos import search_across_years
            by = search_across_years(a.variable, survey=a.encuesta)
            for y in sorted(by):
                r = by[y][0]
                vals = r.get("values") or {}
                print(f"{y}  {r['label'][:60]}")
                if vals:
                    print("      " + "; ".join(f"{k}={v}" for k, v in list(vals.items())[:12]))
        elif a.cmd == "encuestas":
            from inei_microdatos import load_catalog
            for e in load_catalog():
                years = sorted(int(y) for y in e["years"])
                text = f"{e['label']} ({e['category']})"
                if not a.filtro or a.filtro.lower() in text.lower():
                    print(f"{min(years)}-{max(years)}  {text}")
        elif a.cmd == "operaciones":
            from .impute import METHODS
            from .standardize import OPS
            print("Estandarizar (tipo):", ", ".join(sorted(OPS)))
            print("Imputar (metodo):  ", ", ".join(sorted(METHODS)))
    except ConfigError as e:
        log.error(str(e))
        sys.exit(1)


if __name__ == "__main__":
    main()
