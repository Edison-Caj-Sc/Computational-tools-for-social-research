"""The six stages, usable one by one from Python or all together with run():

read → prepare → build → filter → analyze → export   (+ layers and time when configured)"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import networkx as nx
import pandas as pd

from . import builders
from .analyze import analyze as _analyze
from .config import BUILDER_ALIASES, load_config, resolve
from .export import export as _export
from .filters import apply_filters
from .graph import attach_nodes
from .io import read as _read, read_table
from .prepare import prepare as _prepare
from .utils import log


@dataclass
class Result:
    graph: nx.Graph
    communities: list = field(default_factory=list)
    summary: dict = field(default_factory=dict)
    output_dir: str | None = None
    tables: dict = field(default_factory=dict)


def read(config) -> pd.DataFrame:
    """Stage 1. Reads what 'input' describes."""
    return _read(load_config(config) if not isinstance(config, dict) or "_base_dir" not in config else config)


def prepare(data: pd.DataFrame, steps, cfg: dict | None = None) -> pd.DataFrame:
    """Stage 2. Applies the 'prepare' steps."""
    return _prepare(data, steps, cfg)


def build(data: pd.DataFrame, builder: str, cfg: dict | None = None, **options) -> nx.Graph:
    """Stage 3. build(df, "ties", source="a", target="b") → networkx graph."""
    canon, extra = BUILDER_ALIASES.get(builder, (builder, {}))
    return builders.get(canon)(data, {**extra, **options}, cfg or {"_base_dir": "."})


def filter(G: nx.Graph, **filters) -> nx.Graph:  # noqa: A001 - public stage name
    """Stage 4. filter(G, min_weight=2, largest_component=True)."""
    return apply_filters(G, filters)


def analyze(G: nx.Graph, config=None, **analysis):
    """Stage 5. Returns (G, communities, summary, tables)."""
    cfg = load_config({"builder": {"type": "ties"}, **(config or {}), "analysis": {**((config or {}).get("analysis") or {}), **analysis}})
    return _analyze(G, cfg)


def _network(data: pd.DataFrame, cfg: dict, label: str | None = None) -> Result:
    opts = {k: v for k, v in cfg["builder"].items() if k != "type"}
    G = builders.get(cfg["builder"]["type"])(data, opts, cfg)
    if cfg.get("nodes"):
        spec = cfg["nodes"] if isinstance(cfg["nodes"], dict) else {"path": cfg["nodes"]}
        attach_nodes(G, read_table(resolve(cfg, spec["path"])), spec.get("id", "id"), spec.get("columns"))
    if label is None:
        log.info(f"Built network: {G.number_of_nodes():,} nodes, {G.number_of_edges():,} ties")
    extra_summary, extra_tables = G.graph.get("summary"), G.graph.get("tables")
    G = apply_filters(G, cfg["filters"])
    G.graph["summary"], G.graph["tables"] = extra_summary or {}, extra_tables or {}
    G, comms, summ, tables = _analyze(G, cfg)
    return Result(G, comms, summ, None, tables)


def run(config, data: pd.DataFrame | None = None) -> Result:
    """All stages. 'config' is a YAML path or a dict; 'data' skips reading."""
    started = time.time()
    cfg = load_config(config)
    log.info(f"Project: {cfg['project']} · builder: {cfg['builder']['type']}")
    if data is None:
        data = _read(cfg)
    if cfg["prepare"]:
        data = _prepare(data, cfg["prepare"], cfg)
    res = _network(data, cfg)
    if cfg.get("layers"):
        from .layers import analyze_layers
        res.tables.update(analyze_layers(res.graph, cfg["layers"], int(cfg["analysis"].get("seed", 2026))))
    if cfg.get("time"):
        from .temporal import snapshots

        def make(subset, sub_cfg, label):
            r = _network(subset, sub_cfg, label)
            if cfg["time"].get("export_snapshots"):
                sc = dict(sub_cfg, project=f"{cfg['project']}_{label}",
                          output={**cfg["output"], "dir": str(resolve(cfg, cfg["output"]["dir"]) / "snapshots"),
                                  "formats": [f for f in cfg["output"]["formats"] if f in ("csv", "gexf", "graphml")],
                                  "run_record": False})
                _export(r.graph, r.communities, r.summary, sc)
            return r
        res.tables.update(snapshots(data, cfg, make))
    if cfg["output"].get("formats"):
        res.output_dir = str(_export(res.graph, res.communities, res.summary, cfg, res.tables, started))
    for k, v in res.summary.items():
        log.info(f"  {k}: {v}")
    log.info(f"Finished in {time.time() - started:.1f} s")
    return res
