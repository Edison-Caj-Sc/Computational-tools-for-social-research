"""Activity log: what the program did, when, and what went wrong.

The log is a text file that rotates (five files of 1 MB at most), kept in the 'logs' folder of the workspace
when the visual interface runs, or wherever --log-file says on the command line. It records the session
(version, system), each build (project, type of network, size, duration), files received, errors with their
traceback and security events (requests refused). It never records the contents of the data, and session
tokens are masked."""
from __future__ import annotations

import logging
import platform
import re
import sys
import threading
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path

from .utils import log

LOG_NAME = "tejido.log"
MAX_BYTES = 1_000_000
BACKUPS = 4
FORMAT = "%(asctime)s %(levelname)-7s %(name)s: %(message)s"
security = logging.getLogger("tejido.security")
access = logging.getLogger("tejido.access")

_SECRET = re.compile(r"(?i)\b(t|token|launch|x-token|tejido_session[\w]*)(=|:\s*)([A-Za-z0-9_\-]{8,})")
_CONTROL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")


def redact(text: str) -> str:
    """Session tokens out of anything that is written down; control characters too, and every line after the first
    is indented, so text that came from outside can never pose as a record of its own."""
    s = _CONTROL.sub("?", _SECRET.sub(lambda m: f"{m.group(1)}{m.group(2)}***", str(text)))
    return s.replace("\r", "?").replace("\n", "\n    ")


def clean(value, limit: int = 200) -> str:
    """A value that came from outside (file name, header…) made safe to write in one log line."""
    s = _CONTROL.sub("?", str(value)).replace("\n", "\\n")
    return s if len(s) <= limit else s[:limit] + "…"


class _Redact(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if getattr(record, "_tejido_redacted", False):          # several handlers see the same record
            return True
        try:
            record.msg, record.args = redact(record.getMessage()), None
            record._tejido_redacted = True
        except Exception:                                   # never lose a record because of its formatting
            pass
        return True


class _UTCFormatter(logging.Formatter):
    """ISO 8601 timestamps with the local UTC offset, so logs from different computers can be compared."""

    def formatTime(self, record, datefmt=None):
        t = time.localtime(record.created)
        return time.strftime("%Y-%m-%dT%H:%M:%S", t) + f".{int(record.msecs):03d}" + time.strftime("%z", t)


def log_file(folder) -> Path:
    return Path(folder) / LOG_NAME


def setup(folder=None, file=None, level: int | str = logging.INFO) -> Path | None:
    """Starts writing the activity log to <folder>/tejido.log (or to 'file'). Safe to call more than once."""
    path = Path(file) if file else (log_file(folder) if folder else None)
    if isinstance(level, str):
        level = getattr(logging, level.upper(), logging.INFO)
    log.setLevel(min(level, logging.INFO) if path else level)
    for h in log.handlers:                                   # the console keeps its own level
        if isinstance(h, logging.StreamHandler) and not isinstance(h, RotatingFileHandler):
            h.setLevel(level)
            if not any(isinstance(f, _Redact) for f in h.filters):
                h.addFilter(_Redact())
    if path is None:
        return None
    path = path.expanduser().resolve()
    for h in list(log.handlers):
        if isinstance(h, RotatingFileHandler):
            if Path(h.baseFilename) == path:
                return path
            log.removeHandler(h)
            h.close()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        h = RotatingFileHandler(path, maxBytes=MAX_BYTES, backupCount=BACKUPS, encoding="utf-8", delay=True)
    except OSError as e:                                     # a read-only folder must not stop the program
        log.warning(f"The activity log cannot be written to {path}: {e}")
        return None
    h.setLevel(logging.DEBUG)
    h.setFormatter(_UTCFormatter(FORMAT))
    h.addFilter(_Redact())
    log.addHandler(h)
    try:
        path.touch(exist_ok=True)
        path.chmod(0o600)                                    # only the user reads it (no effect on Windows)
    except OSError:
        pass
    return path


def shutdown() -> None:
    for h in list(log.handlers):
        if isinstance(h, RotatingFileHandler):
            log.removeHandler(h)
            h.close()


def session_start(what: str, **details) -> None:
    from . import __version__
    extra = " · ".join(f"{k}: {clean(v)}" for k, v in details.items() if v not in (None, ""))
    log.info(f"=== Tejido {__version__} · {what} · Python {platform.python_version()} · "
             f"{platform.system()} {platform.release()} ({platform.machine()})" + (f" · {extra}" if extra else ""))


def install_excepthooks() -> None:
    """Errors nobody caught are written to the log before the program stops."""
    def hook(kind, value, tb):
        if not issubclass(kind, KeyboardInterrupt):
            log.critical("Unexpected error; the program stops", exc_info=(kind, value, tb))
        sys.__excepthook__(kind, value, tb)

    def thread_hook(args):
        if args.exc_type is not SystemExit:
            log.error(f"Unexpected error in a background task ({args.thread.name if args.thread else '?'})",
                      exc_info=(args.exc_type, args.exc_value, args.exc_traceback))
    sys.excepthook = hook
    threading.excepthook = thread_hook


def tail(path, lines: int = 300, max_bytes: int = 400_000) -> str:
    """The last lines of the log file (reads only its end)."""
    p = Path(path)
    if not p.is_file():
        return ""
    with open(p, "rb") as fh:
        fh.seek(0, 2)
        size = fh.tell()
        fh.seek(max(0, size - max_bytes))
        text = fh.read().decode("utf-8", "replace")
    out = text.splitlines()
    if size > max_bytes and out:
        out = out[1:]                                        # the first line is probably cut
    return "\n".join(out[-max(1, int(lines)):])
