"""Armonización: construye variables comparables entre años a partir de reglas."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .utils import ConfigError, as_list, expand_columns, log, map_values, tidy, year_matches

DERIVE = {"contar", "alguno", "todos", "suma", "promedio", "maximo", "minimo"}
_warned: set = set()


def _derive(df: pd.DataFrame, spec: dict) -> pd.Series:
    func = spec.get("funcion")
    if func not in DERIVE:
        raise ConfigError(f"'derivar.funcion' debe ser una de {sorted(DERIVE)}; recibí {func!r}")
    cols = expand_columns(df, spec.get("columnas"))
    if not cols:
        return pd.Series(np.nan, index=df.index)
    block = df[cols].apply(pd.to_numeric, errors="coerce")
    for v in as_list(spec.get("excluir_valores")):
        block = block.mask(block == float(v))
    all_missing = block.isna().all(axis=1)
    if func == "contar":
        out = block.notna().sum(axis=1).astype(float)
    elif func == "alguno":
        out = block.notna().any(axis=1).astype(float)
    elif func == "todos":
        out = block.notna().all(axis=1).astype(float)
    elif func == "suma":
        out = block.sum(axis=1, min_count=1)
    elif func == "promedio":
        out = block.mean(axis=1)
    elif func == "maximo":
        out = block.max(axis=1)
    else:
        out = block.min(axis=1)
    default_nan = func in ("suma", "promedio", "maximo", "minimo")
    if str(spec.get("todos_faltantes", "nan" if default_nan else "cero")).lower() == "nan":
        out[all_missing] = np.nan
    return out


def _apply_rule(df: pd.DataFrame, rule: dict, name: str, year: int) -> pd.Series:
    if "variable" in rule:
        var = str(rule["variable"]).lower()
        if var not in df.columns:
            key = (name, var, year)
            if key not in _warned:
                log.warning(f"  · {name}: la variable {var!r} no existe en {year}; queda vacía")
                _warned.add(key)
            return pd.Series(np.nan, index=df.index)
        s = df[var]
    elif "expresion" in rule:
        try:
            s = df.eval(str(rule["expresion"]).lower())
        except Exception as e:
            raise ConfigError(f"Error en la expresión de {name!r} ({year}): {e}") from e
    elif "derivar" in rule:
        s = _derive(df, rule["derivar"])
    elif "valor" in rule:
        s = pd.Series(rule["valor"], index=df.index)
    else:
        raise ConfigError(f"La regla de {name!r} necesita 'variable', 'expresion', 'derivar' o 'valor'.")

    s = s.copy()
    if rule.get("faltantes"):
        num = pd.to_numeric(s, errors="coerce")
        s = s.mask(num.isin([float(v) for v in as_list(rule["faltantes"])]))
    if rule.get("recodificar"):
        before = s.notna().sum()
        s = map_values(s, rule["recodificar"], rule.get("otros", "nan"))
        lost = before - s.notna().sum()
        if lost:
            log.info(f"  · {name} ({year}): {lost:,} valores no estaban en 'recodificar' y quedaron faltantes")
    if rule.get("multiplicar") is not None:
        s = pd.to_numeric(s, errors="coerce") * float(rule["multiplicar"])
    return s


def harmonize_year(df: pd.DataFrame, year: int, cfg: dict) -> pd.DataFrame:
    hcfg = cfg["armonizar"]
    lvl_keys = cfg["llaves"][cfg["unir"]["nivel"]]
    keep = ["anio"] + [k for k in lvl_keys if k in df.columns]
    conservar = hcfg.get("conservar") or []
    if conservar == "todo" or conservar == ["todo"]:
        extra = [c for c in df.columns if c not in keep]
    else:
        extra = [c for c in expand_columns(df, conservar) if c not in keep]
        missing = [c for c in as_list(conservar) if "*" not in str(c) and str(c).lower() not in df.columns]
        if missing:
            log.warning(f"  · {year}: variables a conservar que no existen: {missing}")
    out = df[keep + extra].copy()

    new_cols = {}
    for name, spec in (hcfg.get("variables") or {}).items():
        rule = next((r for r in spec["reglas"] if year_matches(year, r.get("anios", "todos"))), None)
        if rule is None:
            log.warning(f"  · {name}: ninguna regla cubre el año {year}; queda vacía")
            s = pd.Series(np.nan, index=df.index)
        else:
            s = _apply_rule(df, rule, name, year)
        tipo = str(spec.get("tipo", "")).lower()
        if tipo == "numerico":
            s = pd.to_numeric(s, errors="coerce")
        elif tipo in ("categorico", "texto"):
            s = s.astype(object).where(s.notna(), np.nan)
        else:
            s = tidy(s)
        new_cols[name] = s
    if new_cols:
        out = pd.concat([out.drop(columns=[c for c in new_cols if c in out.columns]),
                         pd.DataFrame(new_cols, index=df.index)], axis=1)
    return out


def labels(cfg: dict) -> dict:
    return {n: s.get("etiqueta", "") for n, s in (cfg["armonizar"].get("variables") or {}).items()}
