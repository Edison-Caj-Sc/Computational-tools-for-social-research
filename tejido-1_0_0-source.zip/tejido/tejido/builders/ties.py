"""Direct ties: each relation is recorded explicitly.

format: edgelist        one row per tie (source, target, optional weight and relation type)
        adjacency_list  one row per actor with its contacts in one cell ("Ana; Luis; Rosa")
        matrix          square matrix: first column = row labels, other columns = the same actors
Examples: transfers, trade or migration flows, friendships, follows, citations, alliances.

Undirected networks (directed: false)
  matrix: a symmetric matrix gives each pair once; a non-symmetric one is combined with
          symmetrize: sum (default, as rows of a list add up) | max | min | mean
  lists:  both_directions: auto (default) | once | add. 'once': a tie listed as A→B and B→A counts once;
          'add': rows are separate records and their weights add up; 'auto': 'once' when every row has its mirror
          with the same weight (a symmetric listing), otherwise 'add'."""
from __future__ import annotations

from collections import Counter

import numpy as np
import pandas as pd

from ..config import resolve
from ..graph import add_relation_counts, aggregate_edges, to_graph
from ..io import read_table
from ..utils import ConfigError, log, require_columns
from . import register


def node_table(cfg: dict, opts: dict) -> pd.DataFrame | None:
    spec = opts.get("nodes")
    if not spec:
        return None
    nodes = read_table(resolve(cfg, spec["path"]))
    require_columns(nodes, spec.get("id", "id"), "builder.nodes")
    return nodes.rename(columns={spec.get("id", "id"): "id"})


SYMMETRIZE = {"max": np.maximum, "min": np.minimum, "mean": lambda a, b: (a + b) / 2, "sum": np.add}


def _from_matrix(data: pd.DataFrame, directed: bool = True, symmetrize: str = "sum") -> pd.DataFrame:
    m = data.set_index(data.columns[0])
    m.index, m.columns = m.index.astype(str), m.columns.astype(str)
    if set(m.index) != set(m.columns):
        extra = sorted(set(m.index) ^ set(m.columns))[:10]
        raise ConfigError(f"Matrix rows and columns must be the same actors. Mismatched labels: {extra}")
    m = m.loc[:, m.index].apply(pd.to_numeric, errors="coerce").fillna(0)
    if not directed:                                   # each pair once: the upper triangle (and the diagonal)
        a = m.to_numpy(float)
        if not np.allclose(a, a.T):
            if symmetrize not in SYMMETRIZE:
                raise ConfigError(f"ties: 'symmetrize' must be one of {sorted(SYMMETRIZE)}")
            log.info(f"ties: the matrix is not symmetric; each pair takes the {symmetrize} of its two cells")
            d = np.diag(a).copy()
            a = SYMMETRIZE[symmetrize](a, a.T)
            np.fill_diagonal(a, d)
        m = pd.DataFrame(np.triu(a), index=m.index, columns=m.columns)
    m.index.name, m.columns.name = "source", "target"
    edges = m.stack().rename("weight").reset_index()
    edges.columns = ["source", "target", "weight"]
    return edges[edges["weight"] != 0]


def _mirrored(df: pd.DataFrame, weight) -> bool:
    """Every tie between two different actors is listed in both directions with the same weight."""
    s, t = df["source"].astype(str), df["target"].astype(str)
    w = pd.to_numeric(df[weight], errors="coerce").fillna(0) if weight else pd.Series(1.0, index=df.index)
    off = (s != t).to_numpy()
    if not off.any():
        return False
    return Counter(zip(s[off], t[off], w[off])) == Counter(zip(t[off], s[off], w[off]))


def _both_directions(df: pd.DataFrame, weight, mode: str) -> pd.DataFrame:
    df = df.dropna(subset=["source", "target"])
    mode = str(mode).lower()
    if mode not in ("auto", "once", "add"):
        raise ConfigError("ties: 'both_directions' must be auto, once or add")
    if mode == "auto":
        mode = "once" if _mirrored(df, weight) else "add"
        if mode == "once":
            log.info("ties: each tie is listed in both directions; counted once (both_directions: add sums them)")
    if mode == "add":
        return df
    s, t = df["source"].astype(str), df["target"].astype(str)
    listed = set(zip(s, t))
    reverse_listed = np.array([(b, a) in listed for a, b in zip(s, t)], dtype=bool)
    return df[(s <= t).to_numpy() | ~reverse_listed]


@register("ties", "Direct ties: edge list, adjacency list or adjacency matrix (flows, friendships, citations)")
def build(data: pd.DataFrame, opts: dict, cfg: dict):
    fmt = opts.get("format", "edgelist")
    directed = bool(opts.get("directed", True))
    attrs = dict(opts.get("edge_attributes") or {})
    weight = opts.get("weight")
    if fmt == "matrix":
        df, weight = _from_matrix(data, directed, str(opts.get("symmetrize", "sum")).lower()), "weight"
    elif fmt in ("edgelist", "adjacency_list"):
        src = opts.get("source", "source")
        tgt = opts.get("targets", opts.get("target", "targets" if fmt == "adjacency_list" else "target"))
        require_columns(data, [src, tgt, weight, opts.get("relation")] + list(attrs), "ties")
        df = data.rename(columns={src: "source", tgt: "target"})
        if opts.get("filter"):
            from ..safe_expr import query
            df = query(df, opts["filter"], "ties.filter")
        if fmt == "adjacency_list":
            sep = str(opts.get("sep", ";"))
            df = df.assign(target=df["target"].astype("string").str.split(sep)).explode("target")
            df["target"] = df["target"].str.strip()
            df = df[df["target"].notna() & (df["target"] != "")]
    else:
        raise ConfigError("ties: 'format' must be edgelist, adjacency_list or matrix")
    if not directed and fmt != "matrix":
        df = _both_directions(df, weight, opts.get("both_directions", "auto"))
    if opts.get("relation"):                               # several kinds of tie in one table
        df = df.copy()
        df["relation"] = df[opts["relation"]].astype("string")
        attrs.update(add_relation_counts(df, "relation"))
        attrs["relation"] = "values"
    edges = aggregate_edges(df, directed, weight, attrs)
    if fmt == "matrix":
        edges = edges[edges["weight"] > float(opts.get("threshold", 0))]
    self_loops = bool(opts.get("self_loops", opts.get("diagonal", False)))
    return to_graph(edges, directed, node_table(cfg, opts), self_loops)
