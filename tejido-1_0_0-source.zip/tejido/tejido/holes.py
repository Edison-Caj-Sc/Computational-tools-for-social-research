"""Structural holes (Burt 1992): gaps between contacts that are not tied to each other, the brokers
who span them, and the holes between groups.

analysis:
  structural_holes:
    groups: community      # community | <node attribute>: holes between these groups
    broker_share: 0.25     # brokers: the 25% least constrained nodes with 2+ contacts that span holes
    hole_ratio: 0.5        # a pair of groups is a hole when ties between them < 0.5 × expected (and expected ≥ 1)

Nodes get: holes (pairs of contacts not tied to each other), hole_share, constraint, effective_size,
efficiency, hierarchy (concentration of constraint on one contact), groups_spanned and hole_role
(broker, intermediate, embedded, pendant, isolate). Tables: brokers and structural_holes (group pairs)."""
from __future__ import annotations

import itertools
import math

import networkx as nx
import numpy as np
import pandas as pd

from .utils import log

ROLES = ("broker", "intermediate", "embedded", "pendant", "isolate")


def burt(U: nx.Graph) -> dict:
    """Constraint, effective size, efficiency and hierarchy for an undirected weighted graph
    (reciprocal weights already added, as in Burt's p_ij = (z_ij + z_ji) / Σ (z_iq + z_qi))."""
    adj = {v: {u: float(d.get("weight", 1) or 0) for u, d in U[v].items() if u != v} for v in U}
    s = {v: sum(a.values()) for v, a in adj.items()}
    mx = {v: max(a.values()) if a else 0 for v, a in adj.items()}
    p = lambda i, j: adj[i].get(j, 0) / s[i] if s[i] > 0 else 0
    out = {}
    for i, ai in adj.items():
        k = len(ai)
        if k == 0:
            out[i] = {"constraint": np.nan, "effective_size": 0.0, "efficiency": np.nan, "hierarchy": np.nan}
            continue
        local, es = {}, 0.0
        for j in ai:
            shared = [q for q in adj[j] if q in ai and q != j]
            indirect = sum(p(i, q) * p(q, j) for q in shared)
            local[j] = (p(i, j) + indirect) ** 2
            es += 1 - sum(p(i, q) * (adj[j][q] / mx[j] if mx[j] else 0) for q in shared)
        C = sum(local.values())
        H = np.nan
        if k > 1 and C > 0:
            r = [c / (C / k) for c in local.values() if c > 0]
            H = sum(x * math.log(x) for x in r) / (k * math.log(k))
        out[i] = {"constraint": C, "effective_size": es, "efficiency": es / k, "hierarchy": H}
    return out


def structural_holes(G: nx.Graph, spec, comms) -> tuple[dict, dict]:
    spec = spec if isinstance(spec, dict) else {}
    if spec.get("enabled") is False:
        return {}, {}
    from .analyze import undirected_simple
    U = undirected_simple(G) if G.is_directed() else G
    if U.number_of_edges() > 300_000:
        log.warning("structural_holes: network too large; skipped")
        return {}, {}
    B = burt(U)
    tri = nx.triangles(nx.Graph(U))
    deg = {v: len(set(U[v]) - {v}) for v in U}
    by = spec.get("groups", "community")
    group = {v: d.get(by) for v, d in G.nodes(data=True)} if by else {}
    if by == "community" and not any(x is not None for x in group.values()) and comms:
        group = {v: i for i, c in enumerate(comms, 1) for v in c}
    for v in U:
        k = deg[v]
        pairs = k * (k - 1) // 2
        holes = pairs - tri.get(v, 0)
        mine = group.get(v)
        others = {group.get(u) for u in U[v] if u != v} - {None, mine}
        G.nodes[v].update({"holes": int(holes), "hole_share": round(holes / pairs, 4) if pairs else 0.0,
                           "groups_spanned": len(others)})
        for key, val in B[v].items():
            if val == val:                                   # not NaN
                G.nodes[v][key] = round(float(val), 6)
    share = float(spec.get("broker_share", .25))
    cand = {v: B[v]["constraint"] for v in U if deg[v] >= 2 and B[v]["constraint"] == B[v]["constraint"]}
    lo = np.quantile(list(cand.values()), share) if cand else None
    hi = np.quantile(list(cand.values()), 1 - share) if cand else None
    for v in G:
        k = deg.get(v, 0)
        if k == 0:
            role = "isolate"
        elif k == 1:
            role = "pendant"
        elif cand.get(v) is not None and cand[v] <= lo and G.nodes[v]["holes"] > 0:
            role = "broker"
        elif cand.get(v) is not None and cand[v] >= hi:
            role = "embedded"
        else:
            role = "intermediate"
        G.nodes[v]["hole_role"] = role
    roles = pd.Series({v: G.nodes[v]["hole_role"] for v in G})
    br = [v for v in G if G.nodes[v]["hole_role"] == "broker"]
    cols = ["holes", "hole_share", "constraint", "effective_size", "efficiency", "hierarchy", "groups_spanned", "betweenness"]
    brokers = pd.DataFrame([{"node": G.nodes[v].get("label", v), "hole_role": G.nodes[v]["hole_role"], "degree": deg[v],
                             **{c: G.nodes[v].get(c) for c in cols if c != "betweenness" or "betweenness" in G.nodes[v]}}
                            for v in U if deg[v] >= 2])
    if len(brokers):
        brokers = brokers.sort_values(["constraint", "holes"], ascending=[True, False]).head(200).reset_index(drop=True)
    vals = [B[v]["constraint"] for v in cand]
    summary = {"brokers": len(br), "mean_node_constraint": round(float(np.mean(vals)), 4) if vals else None,
               "mean_hole_share": round(float(np.mean([G.nodes[v]["hole_share"] for v in U if deg[v] >= 2])), 4) if cand else None,
               "embedded_nodes": int((roles == "embedded").sum())}
    tables = {"brokers": brokers} if len(brokers) else {}
    gt = group_holes(U, group, float(spec.get("hole_ratio", .5)))
    if gt is not None:
        tables["structural_holes"] = gt
        summary["group_holes"] = int(gt["hole"].sum())
    log.info(f"structural holes: {len(br)} brokers" + (f", {summary.get('group_holes', 0)} holes between groups ({by})" if gt is not None else ""))
    return {k: v for k, v in summary.items() if v is not None}, tables


def group_holes(U: nx.Graph, group: dict, ratio: float) -> pd.DataFrame | None:
    """Pairs of groups with fewer ties between them than expected from their ties overall, and the nodes
    that connect them (boundary spanners)."""
    members = {}
    for v, g in group.items():
        if g is not None and v in U:
            members.setdefault(str(g), set()).add(v)
    if len(members) < 2:
        return None
    if len(members) > 30:
        members = dict(sorted(members.items(), key=lambda kv: -len(kv[1]))[:30])
    gof = {v: g for g, vs in members.items() for v in vs}
    m = U.number_of_edges()
    vol = {g: sum(U.degree(v) for v in vs) for g, vs in members.items()}
    between = {}
    for u, v in U.edges:
        a, b = gof.get(u), gof.get(v)
        if a and b and a != b:
            between[tuple(sorted((a, b)))] = between.get(tuple(sorted((a, b))), 0) + 1
    # ties of each node into each group (a member of a group counts as tied to its own group)
    into = {v: {} for v in U}
    for v in U:
        for u in U[v]:
            if u != v and gof.get(u):
                into[v][gof[u]] = into[v].get(gof[u], 0) + 1
        if gof.get(v):
            into[v][gof[v]] = into[v].get(gof[v], 0) + 1
    rows = []
    for a, b in itertools.combinations(sorted(members), 2):
        expected = vol[a] * vol[b] / (2 * m) if m else 0
        obs = between.get((a, b), 0)
        spanners = [v for v in U if into[v].get(a) and into[v].get(b)]
        spanners.sort(key=lambda v: (-min(into[v][a], into[v][b]), -U.degree(v)))   # tied to both groups the most
        rows.append({"group_a": a, "group_b": b, "size_a": len(members[a]), "size_b": len(members[b]), "ties_between": obs,
                     "expected": round(expected, 3), "ratio": round(obs / expected, 4) if expected else None,
                     "hole": bool(expected >= 1 and obs / expected < ratio), "spanners": len(spanners),
                     "main_spanners": "; ".join(str(U.nodes[v].get("label", v)) for v in spanners[:6])})
    return pd.DataFrame(rows).sort_values(["hole", "ratio"], ascending=[False, True]).reset_index(drop=True)
