"""Time: the same network built for each period (snapshots), to follow how it changes.

time: {column: date, every: year, cumulative: false, export_snapshots: false}
every: year | quarter | month | week | day | a number (bins of that width for numeric columns)
→ table 'evolution' (one row per period: size, density, cohesion, communities, tie persistence and
node turnover) and 'node_evolution' (node measures per period)."""
from __future__ import annotations

import copy

import numpy as np
import pandas as pd

from .utils import ConfigError, log

FREQ = {"year": "Y", "quarter": "Q", "month": "M", "week": "W", "day": "D"}


def period_labels(s: pd.Series, every) -> pd.Series:
    if every in FREQ:
        d = pd.to_datetime(s, errors="coerce")
        if d.notna().sum() == 0:
            raise ConfigError(f"time: column {s.name!r} has no readable dates")
        return d.dt.to_period(FREQ[every]).astype("string").where(d.notna())
    x = pd.to_numeric(s, errors="coerce")
    if every is None:
        if x.notna().all():
            return x.astype("Int64").astype("string") if (x % 1 == 0).all() else x.astype("string")
        return s.astype("string")
    width = float(every)
    start = np.floor(x / width) * width
    fmt = (lambda v: f"{int(v)}–{int(v + width - 1)}") if width % 1 == 0 and (x.dropna() % 1 == 0).all() \
        else (lambda v: f"{v:g}–{v + width:g}")
    return start.map(lambda v: fmt(v) if pd.notna(v) else None).astype("string")


def snapshots(data: pd.DataFrame, cfg: dict, make_network) -> dict:
    """make_network(subset, cfg) → Result. Returns the evolution tables."""
    t = cfg["time"]
    col = t.get("column")
    if not col or col not in data.columns:
        raise ConfigError(f"time.column {col!r} not found in the data. Available: {list(data.columns)[:20]}")
    labels = period_labels(data[col], t.get("every"))
    order = sorted(labels.dropna().unique(), key=lambda v: (pd.to_numeric(str(v).split("–")[0], errors="coerce"), str(v)))
    if t.get("periods"):
        order = [p for p in order if p in {str(x) for x in t["periods"]}]
    if len(order) < 2:
        raise ConfigError("time: fewer than two periods found")
    if len(order) > 60:
        raise ConfigError(f"time: {len(order)} periods; use a coarser 'every'")
    sub = copy.deepcopy(cfg)
    sub["analysis"]["null_model"] = None
    sub["analysis"]["groups"] = []
    if sub["analysis"].get("ergm") or sub["analysis"].get("blockmodel"):
        log.info("time: ERGM and blockmodels are estimated for the whole network only, not for each period")
    sub["analysis"]["ergm"] = sub["analysis"]["blockmodel"] = None
    sub["layers"] = None
    sub["time"] = None
    rows, node_rows, prev_edges, prev_nodes = [], [], None, None
    keys = ["degree", "strength", "betweenness", "pagerank", "eigenvector", "closeness", "community"]
    for i, p in enumerate(order):
        mask = labels.isin(order[:i + 1]) if t.get("cumulative") else labels == p
        try:
            r = make_network(data[mask.fillna(False).to_numpy()], sub, p)
        except ConfigError as e:
            log.warning(f"time: period {p} skipped ({e})")
            continue
        G = r.graph
        edges = {tuple(sorted(map(str, e))) if not G.is_directed() else tuple(map(str, e)) for e in G.edges}
        nodes = set(map(str, G.nodes))
        row = {"period": p, "rows": int(mask.sum())}
        row.update({k: v for k, v in r.summary.items() if isinstance(v, (int, float)) and not isinstance(v, bool)})
        if prev_edges is not None:
            union = edges | prev_edges
            row.update({"tie_persistence": round(len(edges & prev_edges) / len(union), 4) if union else None,
                        "new_ties": len(edges - prev_edges), "lost_ties": len(prev_edges - edges),
                        "new_nodes": len(nodes - prev_nodes), "lost_nodes": len(prev_nodes - nodes)})
        rows.append(row)
        prev_edges, prev_nodes = edges, nodes
        for n, d in G.nodes(data=True):
            node_rows.append({"period": p, "id": n, "label": d.get("label", n),
                              **{k: d[k] for k in keys if k in d}})
    log.info(f"time: {len(rows)} periods by {t.get('every') or col}" + (" (cumulative)" if t.get("cumulative") else ""))
    return {"evolution": pd.DataFrame(rows), "node_evolution": pd.DataFrame(node_rows)}
