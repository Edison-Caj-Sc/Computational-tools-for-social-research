# =====================================================================
#  08 · LOGIT MULTINOMIAL
#  Para: variables con 3 o más categorías sin orden: tipo de empleo, partido votado,
#  religión, medio de transporte.
#  Interpretación: razón de riesgos relativos (RRR) de cada categoría frente a la de
#  referencia. Para comunicar, usa los efectos marginales por categoría.
#  Supuesto: independencia de alternativas irrelevantes (IIA).
# =====================================================================

# ---------------------------------------------------------------------
# 0. CONFIGURACIÓN · edita solo esta sección
# ---------------------------------------------------------------------
archivo        <- NULL
dependiente    <- "ocupacion"
referencia_y   <- "asalariado_informal"   # categoría de comparación de la dependiente
predictores    <- c("educ_jefe", "edad_jefe", "sexo_jefe", "area")
factores       <- list(sexo_jefe = "hombre", area = "urbano")
terminos_extra <- NULL
formula_manual <- NULL
variable_foco  <- "educ_jefe"
usar_diseno    <- FALSE                   # ver nota en la sección 2
diseno         <- list(estrato = "estrato", conglomerado = "conglome", peso = "factor07")
carpeta_salida <- "resultados/08_logit_multinomial"

# ---------------------------------------------------------------------
# 1. Preparación
# ---------------------------------------------------------------------
source("utilidades.R"); instalar_si_falta()
salida  <- preparar_salida(carpeta_salida)
formula <- construir_formula(dependiente, predictores, terminos_extra, formula_manual)
y <- all.vars(formula)[1]
datos   <- preparar_datos(cargar_datos(archivo), variables_formula(formula),
                          c(factores, setNames(list(referencia_y), y)), extra = vars_diseno(usar_diseno, diseno))
if (nlevels(datos[[y]]) < 3) stop("La dependiente tiene menos de 3 categorías: usa 02_regresion_logistica.R")

encabezado("Distribución de la variable dependiente")
print(round(prop.table(table(datos[[y]])), 3))

# ---------------------------------------------------------------------
# 2. Estimación
#    Con 'usar_diseno = TRUE' se usan pesos normalizados y errores robustos por
#    conglomerado (aproximación). Para inferencia de diseño completa, ver el paquete svyVGAM.
# ---------------------------------------------------------------------
encabezado("Modelo")
if (usar_diseno) {
  datos$.peso <- datos[[diseno$peso]] / mean(datos[[diseno$peso]])
  modelo <- nnet::multinom(formula, data = datos, weights = .peso, trace = FALSE, Hess = TRUE)
  vc <- vcov_cluster_multinom(modelo, datos, formula, datos[[diseno$conglomerado]], datos$.peso)
  message("Aproximación al diseño: pesos normalizados + errores robustos por conglomerado.")
} else {
  modelo <- nnet::multinom(formula, data = datos, trace = FALSE, Hess = TRUE)
  vc <- vcov(modelo)
}
b <- coef(modelo)
ee <- matrix(sqrt(diag(vc)), nrow = nrow(b), byrow = TRUE, dimnames = dimnames(b))
tab <- do.call(rbind, lapply(rownames(b), function(cat) {
  z <- b[cat, ] / ee[cat, ]
  data.frame(categoria = cat, termino = colnames(b), estimacion = b[cat, ], ee = ee[cat, ], z = z,
             p = 2 * pnorm(-abs(z)), rrr = exp(b[cat, ]),
             rrr_ic_inf = exp(b[cat, ] - qnorm(.975) * ee[cat, ]),
             rrr_ic_sup = exp(b[cat, ] + qnorm(.975) * ee[cat, ]))
}))
tab$signif <- estrellas(tab$p); rownames(tab) <- NULL
cat("Cada fila compara la categoría indicada con la referencia:", referencia_y, "\n")
print(redondear(tab, 3)); guardar_tabla(tab, "2_coeficientes", salida)

# ---------------------------------------------------------------------
# 3. Ajuste
# ---------------------------------------------------------------------
encabezado("Ajuste")
nulo <- nnet::multinom(update(formula, . ~ 1), data = datos, trace = FALSE,
                       weights = if (usar_diseno) .peso else NULL)
lr <- 2 * as.numeric(logLik(modelo) - logLik(nulo))
ajuste <- data.frame(n = nrow(datos), AIC = AIC(modelo), BIC = BIC(modelo),
                     pseudo_r2_mcfadden = 1 - as.numeric(logLik(modelo) / logLik(nulo)),
                     lr_chi2 = lr, lr_p = pchisq(lr, df = length(b) - nrow(b), lower.tail = FALSE))
pred <- predict(modelo)
ajuste$exactitud <- mean(pred == datos[[y]])
ajuste$exactitud_azar <- max(prop.table(table(datos[[y]])))
print(redondear(ajuste, 3)); guardar_tabla(ajuste, "3_ajuste", salida)
cat("IIA: si añadir o quitar una categoría cambiaría las demás elecciones, el supuesto es dudoso;\n",
    "en ese caso considera modelos anidados o probit multinomial.\n")

# ---------------------------------------------------------------------
# 4. Interpretación: efectos marginales sobre la probabilidad de cada categoría
# ---------------------------------------------------------------------
encabezado("Efectos marginales promedio por categoría")
ame <- efectos_marginales(modelo, datos, NULL, pesos = if (usar_diseno) datos$.peso else NULL, type = "probs")
ame$efecto_pp <- 100 * ame$efecto
print(redondear(ame, 4)); guardar_tabla(ame, "4_efectos_marginales", salida)
g <- grafico_predicciones(modelo, datos, c(variable_foco, "group"), NULL, paste("Probabilidad de cada categoría de", y),
                          type = "probs") + labs(y = "Probabilidad", colour = y, fill = y)
guardar_grafico(g, "4_predicciones", salida)
guardar_texto(summary(modelo), "resumen_modelo", salida)
encabezado(paste("Listo. Resultados en", salida))
