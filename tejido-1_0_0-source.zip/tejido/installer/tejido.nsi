﻿; Instalador de Tejido para Windows (NSIS 3, Modern UI 2). Compilar con: makensis tejido.nsi
; Guardado en UTF-8 con BOM: así NSIS lee bien «Velásquez» en Windows y en Linux.
; Uso: copie dist/tejido.exe (o tejido-windows.exe renombrado) y ejecute  makensis installer/tejido.nsi  desde la carpeta tejido/
Unicode true
!include "MUI2.nsh"

!define APPNAME "Tejido"
!define VERSION "1.0.0"
!define PUBLISHER "Angel Edison Ayala Velásquez"
!define UNINSTKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}"

Name "${APPNAME} ${VERSION}"
OutFile "tejido-1_0_0-instalador-windows.exe"
InstallDir "$LOCALAPPDATA\Programs\${APPNAME}"
RequestExecutionLevel user
SetCompressor /SOLID lzma
!define URL "https://github.com/Edison-Caj-Sc/Computational-tools-for-social-research"

; Propiedades del instalador (clic derecho → Propiedades → Detalles)
VIProductVersion "1.0.0.0"
VIAddVersionKey /LANG=0 "ProductName" "${APPNAME}"
VIAddVersionKey /LANG=0 "ProductVersion" "${VERSION}"
VIAddVersionKey /LANG=0 "FileVersion" "${VERSION}"
VIAddVersionKey /LANG=0 "CompanyName" "${PUBLISHER}"
VIAddVersionKey /LANG=0 "LegalCopyright" "Copyright (c) 2026 ${PUBLISHER}. Licencia MIT."
VIAddVersionKey /LANG=0 "FileDescription" "Instalador de ${APPNAME} ${VERSION}"
BrandingText "${APPNAME} ${VERSION} · © 2026 ${PUBLISHER}"

!define MUI_ICON "tejido.ico"
!define MUI_UNICON "tejido.ico"
!define MUI_FINISHPAGE_RUN "$INSTDIR\tejido.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Abrir Tejido"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "..\LICENSE"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Spanish"

Section "Tejido"
  SetOutPath "$INSTDIR"
  File "..\dist\tejido.exe"
  File "..\LICENSE"
  File "..\THIRD_PARTY_NOTICES.md"
  File "..\tejido\ui\static\THIRD-PARTY-LICENSES.txt"
  WriteUninstaller "$INSTDIR\Desinstalar.exe"
  CreateDirectory "$SMPROGRAMS\${APPNAME}"
  CreateShortcut "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk" "$INSTDIR\tejido.exe"
  CreateShortcut "$SMPROGRAMS\${APPNAME}\Desinstalar ${APPNAME}.lnk" "$INSTDIR\Desinstalar.exe"
  CreateShortcut "$DESKTOP\${APPNAME}.lnk" "$INSTDIR\tejido.exe"
  WriteRegStr HKCU "${UNINSTKEY}" "DisplayName" "${APPNAME}"
  WriteRegStr HKCU "${UNINSTKEY}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKCU "${UNINSTKEY}" "Publisher" "${PUBLISHER}"
  WriteRegStr HKCU "${UNINSTKEY}" "URLInfoAbout" "${URL}"
  WriteRegStr HKCU "${UNINSTKEY}" "InstallLocation" "$INSTDIR"
  File "..\SECURITY.md"
  WriteRegStr HKCU "${UNINSTKEY}" "DisplayIcon" "$INSTDIR\tejido.exe"
  WriteRegStr HKCU "${UNINSTKEY}" "UninstallString" '"$INSTDIR\Desinstalar.exe"'
  WriteRegDWORD HKCU "${UNINSTKEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNINSTKEY}" "NoRepair" 1
SectionEnd

Section "Uninstall"
  Delete "$INSTDIR\tejido.exe"
  Delete "$INSTDIR\LICENSE"
  Delete "$INSTDIR\THIRD_PARTY_NOTICES.md"
  Delete "$INSTDIR\THIRD-PARTY-LICENSES.txt"
  Delete "$INSTDIR\SECURITY.md"
  Delete "$INSTDIR\Desinstalar.exe"
  RMDir "$INSTDIR"
  Delete "$SMPROGRAMS\${APPNAME}\*.lnk"
  RMDir "$SMPROGRAMS\${APPNAME}"
  Delete "$DESKTOP\${APPNAME}.lnk"
  DeleteRegKey HKCU "${UNINSTKEY}"
SectionEnd
