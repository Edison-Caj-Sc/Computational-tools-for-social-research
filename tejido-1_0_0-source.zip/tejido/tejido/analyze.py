"""Stage 5 · analyze: node measures (here), groups (groups.py) and whole-network statistics (network.py).

analysis:
  centrality: [degree, betweenness, closeness, pagerank]   # or "all"; see NODE_MEASURES
  distance: auto                                # path length: auto | steps | inverse_weight | weight | <tie attribute>
  betweenness_sample: auto                      # auto | exact | number of sampled source nodes
  normalized: true                              # betweenness between 0 and 1 (false: raw path counts)
  group_centrality: community                   # group degree, betweenness and closeness of communities or an attribute
  structural_holes: {groups: community}         # brokers, holes per node and between groups (holes.py)
  tie_strength: {by: auto}                      # strong and weak ties, local bridges, triadic closure (tie_strength.py)
  communities: louvain                          # louvain | greedy | label_propagation | girvan_newman | attribute | none
  groups: [kcore, cliques, equivalence, core_periphery]
  attributes: [type, sex]                       # homophily: assortativity, E-I index, Coleman index
  brokerage: sector                             # Gould–Fernandez roles by this node attribute
  null_model: {model: configuration, n: 50}     # compare with random networks (z-scores, small-world sigma)
  blockmodel: {method: concor, blocks: 4}       # positions: concor | structural | generalized | sbm (blockmodel.py)
  ergm: {terms: [edges, gwesp(0.5)]}            # exponential random graph model (ergm.py)"""
from __future__ import annotations

import math
from collections import Counter, defaultdict

import networkx as nx
import numpy as np

from .utils import ConfigError, as_list, log

NODE_MEASURES = {
    "degree": "Number of ties (in/out when directed) and strength (sum of weights)",
    "strength": "Sum of tie weights",
    "betweenness": "How often a node lies on shortest paths between others (brokerage potential)",
    "edge_betweenness": "Same for ties: which ties bridge parts of the network (stored on ties)",
    "ego_betweenness": "Betweenness within the node's own neighborhood (Everett & Borgatti): local brokerage",
    "flow_betweenness": "Current-flow (random-walk) betweenness: brokerage counting all paths, not only the shortest",
    "closeness": "Inverse mean distance to the others; directed networks also get out_closeness",
    "harmonic": "Mean inverse distance; works with disconnected networks (directed: from the others, plus out_harmonic)",
    "information": "Information centrality (Stephenson & Zelen): closeness counting all paths",
    "eccentricity": "Longest distance to any other node in its component",
    "eigenvector": "Connected to well-connected nodes",
    "katz": "Reach through all paths, discounting longer ones",
    "pagerank": "Importance from incoming ties of important nodes",
    "hubs": "HITS hub and authority scores (who points to the important, who is pointed to)",
    "laplacian": "Drop in network energy when the node is removed",
    "subgraph": "Participation in closed walks (Estrada subgraph centrality)",
    "voterank": "Rank of the best spreaders for diffusion (1 = best)",
    "coreness": "Highest k-core the node belongs to",
    "clustering": "Share of a node's neighbors that are connected (and number of triangles)",
    "neighbor_degree": "Mean degree of the node's neighbors",
    "reciprocity": "Share of a node's ties that are reciprocated (directed)",
    "constraint": "Burt's constraint: dependence on redundant contacts (low = structural holes)",
    "effective_size": "Burt's effective size and efficiency: non-redundant contacts",
    "brokerage": "Gould–Fernandez brokerage roles (by analysis.brokerage attribute) or total open two-paths",
    "cut_points": "Articulation points: nodes whose removal disconnects the network",
}
CENTRALITIES = set(NODE_MEASURES)          # name kept for the interface
FAMILIES = {
    "connections": ["degree", "strength", "neighbor_degree", "reciprocity"],
    "betweenness": ["betweenness", "edge_betweenness", "ego_betweenness", "flow_betweenness", "brokerage",
                    "constraint", "effective_size", "cut_points"],
    "closeness": ["closeness", "harmonic", "information", "eccentricity"],
    "influence": ["eigenvector", "katz", "pagerank", "hubs", "laplacian", "subgraph", "voterank"],
    "cohesion": ["coreness", "clustering"],
}
DISTANCES = {"auto": "Inverse weight if ties have different weights, otherwise steps",
             "steps": "Number of steps (weights ignored)",
             "inverse_weight": "Strong ties are short (distance = 1 / weight)",
             "weight": "The weight is already a distance or cost (km, time, price)"}
COMMUNITIES = {"louvain", "greedy", "label_propagation", "girvan_newman", "attribute", "none", None}
BIG = 3000                                 # above this many nodes, costly measures are approximated or skipped


def _set(G, name, values):
    nx.set_node_attributes(G, {n: (round(float(v), 6) if isinstance(v, (float, np.floating)) else v)
                               for n, v in values.items()}, name)


def undirected_simple(G) -> nx.Graph:
    """Undirected, no self-loops; reciprocal weights are added."""
    U = nx.Graph()
    U.add_nodes_from(G.nodes(data=True))
    for u, v, w in G.edges(data="weight", default=1):
        if u != v:
            w0 = U[u][v]["weight"] if U.has_edge(u, v) else 0
            U.add_edge(u, v, weight=w0 + (w or 0))
    return U


def set_distance(G, how="auto") -> str | None:
    """Path length used by betweenness and closeness. Returns the edge attribute to use (None = steps)."""
    how = how or "auto"
    if how == "auto":
        how = "inverse_weight" if is_weighted(G) else "steps"
    if how == "steps":
        return None
    for u, v, d in G.edges(data=True):
        if how == "inverse_weight":
            w = d.get("weight", 1) or 0
            d["distance"] = 1 / w if w > 0 else math.inf
        else:
            x = d.get("weight", 1) if how == "weight" else d.get(how)
            if x is None:
                raise ConfigError(f"analysis.distance: tie {u} — {v} has no attribute {how!r}")
            d["distance"] = float(x) if float(x) > 0 else 1e-9
    return "distance"


def is_weighted(G) -> bool:
    return len({w for *_, w in G.edges(data="weight", default=1)}) > 1


def distance_rows(G: nx.Graph, weighted: bool, reverse: bool = False, chunk: int = 400, nodes=None, sources=None):
    """All-pairs shortest paths computed in C (scipy), yielded in blocks of rows: (row indices, D)."""
    from scipy.sparse.csgraph import dijkstra
    nodes = list(G) if nodes is None else nodes
    A = nx.to_scipy_sparse_array(G, nodelist=nodes, weight="distance" if weighted else None, format="csr", dtype=float)
    A.data[~np.isfinite(A.data)] = 0
    A.eliminate_zeros()
    if reverse:
        A = A.T.tocsr()
    order = np.arange(len(nodes)) if sources is None else np.asarray(sources)
    for start in range(0, len(order), chunk):
        ind = order[start:start + chunk]
        yield ind, dijkstra(A, directed=G.is_directed(), indices=ind, unweighted=not weighted)


def _closeness(G, nodes, n, w, reverse):
    clo = {}
    for ind, D in distance_rows(G, w, reverse=reverse, nodes=nodes):
        for i, row in zip(ind, D):
            fin = row[np.isfinite(row)]
            r, tot = len(fin), fin.sum()
            clo[nodes[i]] = ((r - 1) / tot) * ((r - 1) / (n - 1)) if tot > 0 and n > 1 else 0.0
    return clo


def _harmonic(G, nodes, n, w, reverse):
    har = {}
    for ind, D in distance_rows(G, w, reverse=reverse, nodes=nodes):
        with np.errstate(divide="ignore"):
            inv = np.where(np.isfinite(D) & (D > 0), 1 / D, 0)
        for i, v in zip(ind, inv.sum(axis=1)):
            har[nodes[i]] = v / max(n - 1, 1)
    return har


def _path_measures(G: nx.Graph, which: set, w: bool) -> None:
    """Closeness (Wasserman–Faust scaling) and harmonic closeness, inward and, if directed, also outward
    (out_closeness, out_harmonic); eccentricity."""
    nodes, n = list(G), G.number_of_nodes()
    if n > 20000:
        log.warning(f"closeness/harmonic/eccentricity: skipped for {n:,} nodes (limit 20,000)")
        return
    if "closeness" in which:
        _set(G, "closeness", _closeness(G, nodes, n, w, reverse=G.is_directed()))
        if G.is_directed():
            _set(G, "out_closeness", _closeness(G, nodes, n, w, reverse=False))
    if "harmonic" in which:
        _set(G, "harmonic", _harmonic(G, nodes, n, w, reverse=G.is_directed()))
        if G.is_directed():
            _set(G, "out_harmonic", _harmonic(G, nodes, n, w, reverse=False))
    if "eccentricity" in which:
        U = undirected_simple(G) if G.is_directed() else G
        ecc = {}
        for ind, D in distance_rows(U, False, nodes=nodes):
            D = np.where(np.isfinite(D), D, -1)
            for i, v in zip(ind, D.max(axis=1)):
                ecc[nodes[i]] = int(v)
        _set(G, "eccentricity", ecc)


def laplacian(G: nx.Graph) -> dict:
    """Laplacian centrality (Qi et al. 2012), closed form: drop in Laplacian energy when a node is removed."""
    U = undirected_simple(G) if G.is_directed() else G
    s = dict(U.degree(weight="weight"))
    energy = sum(v * v for v in s.values()) + 2 * sum(w * w for *_, w in U.edges(data="weight", default=1))
    drop = {v: s[v] ** 2 + sum(2 * s[u] * d.get("weight", 1) + d.get("weight", 1) ** 2 for u, d in U[v].items() if u != v)
            for v in U}
    return {v: x / energy if energy else 0 for v, x in drop.items()}


def ego_betweenness(G: nx.Graph) -> dict:
    """Everett & Borgatti (2005): betweenness of each node inside its ego network (node + neighbors)."""
    out = {}
    if G.is_directed():
        succ = {v: set(G.successors(v)) - {v} for v in G}
        pred = {v: set(G.predecessors(v)) - {v} for v in G}
        for v in G:
            ego = succ[v] | pred[v] | {v}
            total = 0.0
            for a in pred[v]:
                for b in succ[v]:
                    if a != b and b not in succ[a]:
                        total += 1 / (len(succ[a] & pred[b] & ego))
            out[v] = total
        return out
    adj = {v: set(G[v]) - {v} for v in G}
    for v in G:
        N = list(adj[v])
        if len(N) > 2000:
            log.warning(f"ego_betweenness: node {v} has {len(N):,} neighbors; skipped")
            continue
        total = 0.0
        for i, a in enumerate(N):
            near = adj[a] & adj[v]
            for b in N[i + 1:]:
                if b not in adj[a]:
                    total += 1 / (1 + len(near & adj[b]))
        out[v] = total
    return out


def _by_component(G, fn, limit, name) -> dict:
    """Runs an undirected, connected-graph measure on each component (values are within-component)."""
    U = undirected_simple(G) if G.is_directed() else G
    out = {}
    for c in nx.connected_components(U):
        if len(c) < 3:
            out.update({v: 0.0 for v in c})
            continue
        if len(c) > limit:
            log.warning(f"{name}: component of {len(c):,} nodes above the limit of {limit:,}; skipped")
            continue
        out.update(fn(U.subgraph(c).copy()))
    return out


def group_centrality(G: nx.Graph, by: str, comms, dist, normalized=True):
    """Group degree, betweenness and closeness (Everett & Borgatti 1999) of communities or attribute groups."""
    import pandas as pd
    if by == "community":
        groups = {f"community {i}": set(c) for i, c in enumerate(comms, 1)}
    else:
        groups = {}
        for v, d in G.nodes(data=True):
            if d.get(by) is not None:
                groups.setdefault(str(d[by]), set()).add(v)
    groups = {k: g for k, g in groups.items() if 0 < len(g) < G.number_of_nodes()}
    if not groups:
        log.warning(f"group_centrality: no groups found for {by!r}")
        return None
    if len(groups) > 50:
        groups = dict(sorted(groups.items(), key=lambda kv: -len(kv[1]))[:50])
    n = G.number_of_nodes()
    gb = {}
    fit = [k for k, g in groups.items() if n - len(g) >= 2]      # betweenness needs two nodes outside the group
    if n <= 1500 and fit:
        vals = nx.group_betweenness_centrality(G, [list(groups[k]) for k in fit], normalized=normalized, weight=dist)
        gb = dict(zip(fit, vals if isinstance(vals, list) else [vals]))
    rows = []
    for k, g in groups.items():
        row = {"group": k, "size": len(g), "group_degree": round(nx.group_degree_centrality(G, g), 6)}
        if k in gb:
            row["group_betweenness"] = round(float(gb[k]), 6)
        if n <= 5000:
            row["group_closeness"] = round(nx.group_closeness_centrality(G, g, weight=dist), 6)
        rows.append(row)
    return pd.DataFrame(rows)


def _components(G):
    return nx.weakly_connected_components(G) if G.is_directed() else nx.connected_components(G)


def brokerage(G: nx.Graph, attr: str | None) -> dict:
    """Gould & Fernandez (1989) roles of b in open two-paths a → b → c (a and c not tied)."""
    D = G if G.is_directed() else G.to_directed()
    succ = {n: set(D.successors(n)) - {n} for n in D}
    work = sum(len(set(D.predecessors(n))) * len(succ[n]) for n in D)
    if work > 5e7:
        log.warning("brokerage: network too large for the exact count; skipped")
        return {}
    grp = {n: G.nodes[n].get(attr) for n in G} if attr else None
    roles = defaultdict(Counter)
    for b in D:
        for a in set(D.predecessors(b)) - {b}:
            for c in succ[b]:
                if a == c or c in succ[a]:
                    continue
                roles[b]["total"] += 1
                if grp:
                    ga, gb, gc = grp[a], grp[b], grp[c]
                    role = ("coordinator" if ga == gb == gc else "itinerant" if ga == gc else
                            "gatekeeper" if gb == gc else "representative" if ga == gb else "liaison")
                    roles[b][role] += 1
    div = 1 if G.is_directed() else 2                  # undirected two-paths are seen in both directions
    names = ["total"] + (["coordinator", "itinerant", "gatekeeper", "representative", "liaison"] if grp else [])
    return {f"brokerage_{r}" if r != "total" else "brokerage": {n: roles[n][r] / div for n in G} for r in names}


def node_measures(G: nx.Graph, which, seed: int, cfg_analysis: dict | None = None) -> None:
    a = cfg_analysis or {}
    which = set(as_list(which))
    if "all" in which:
        which = set(NODE_MEASURES)
    unknown = which - CENTRALITIES
    if unknown:
        raise ConfigError(f"Unknown measures {sorted(unknown)}. Options: {sorted(CENTRALITIES)} or 'all'")
    n, directed = G.number_of_nodes(), G.is_directed()
    U = undirected_simple(G) if directed else G

    def safe(name, fn):
        try:
            fn()
        except Exception as e:                         # disconnected, non-convergent or degenerate networks
            log.warning(f"{name} not computed: {e}")

    if "degree" in which:
        _set(G, "degree", dict(G.degree()))
        if directed:
            _set(G, "in_degree", dict(G.in_degree()))
            _set(G, "out_degree", dict(G.out_degree()))
    if "strength" in which or "degree" in which:
        _set(G, "strength", dict(G.degree(weight="weight")))
        if directed:
            _set(G, "in_strength", dict(G.in_degree(weight="weight")))
            _set(G, "out_strength", dict(G.out_degree(weight="weight")))
    dist = set_distance(G, a.get("distance", "auto"))
    norm = bool(a.get("normalized", True))
    spec = a.get("betweenness_sample", "auto")
    k = None if spec in ("exact", None, False) or (spec == "auto" and n <= 1000) else \
        min(n, 300 if spec == "auto" else int(spec))
    if k and k < n and which & {"betweenness", "edge_betweenness"}:
        log.info(f"betweenness: estimated from {k} sampled nodes (network has {n:,}; betweenness_sample: exact for all)")
    if "betweenness" in which:
        safe("betweenness", lambda: _set(G, "betweenness", nx.betweenness_centrality(G, k=k, normalized=norm, weight=dist, seed=seed)))
    if "edge_betweenness" in which:
        eb = nx.edge_betweenness_centrality(G, k=k, normalized=norm, weight=dist, seed=seed)
        nx.set_edge_attributes(G, {e: round(v, 6) for e, v in eb.items()}, "edge_betweenness")
    if "ego_betweenness" in which:
        safe("ego_betweenness", lambda: _set(G, "ego_betweenness", ego_betweenness(G)))
    if "flow_betweenness" in which:
        def flow(H):
            if H.number_of_nodes() <= 1000:
                return nx.current_flow_betweenness_centrality(H, weight="weight")
            return nx.approximate_current_flow_betweenness_centrality(H, weight="weight", seed=seed)
        safe("flow_betweenness", lambda: _set(G, "flow_betweenness", _by_component(G, flow, 10000, "flow_betweenness")))
    if which & {"closeness", "harmonic", "eccentricity"}:
        safe("closeness/harmonic/eccentricity", lambda: _path_measures(G, which, dist is not None))
    if "information" in which:
        safe("information", lambda: _set(G, "information", _by_component(
            G, lambda H: nx.information_centrality(H, weight="weight"), 3000, "information")))
    if "eigenvector" in which:
        def ev():
            f = nx.eigenvector_centrality_numpy if n <= 5000 else \
                (lambda H, weight: nx.eigenvector_centrality(H, weight=weight, max_iter=1000))
            _set(G, "eigenvector", f(G, weight="weight"))
        safe("eigenvector", ev)
    if "katz" in which:
        def katz():
            from scipy.sparse.linalg import eigs
            A = nx.to_scipy_sparse_array(G, weight="weight", dtype=float)
            lam = abs(eigs(A, k=1, which="LM", return_eigenvectors=False)[0]) if n > 2 else 1.0
            alpha = .85 / lam if lam > 0 else .1
            f = nx.katz_centrality_numpy if n <= 2000 else nx.katz_centrality
            _set(G, "katz", f(G, alpha=alpha, weight="weight"))
        safe("katz", katz)
    if "pagerank" in which:
        safe("pagerank", lambda: _set(G, "pagerank", nx.pagerank(G, weight="weight")))
    if "hubs" in which:
        def hits():
            h, au = nx.hits(G, max_iter=1000, normalized=True)
            _set(G, "hub", h)
            _set(G, "authority", au)
        safe("hubs", hits)
    if "laplacian" in which:
        safe("laplacian", lambda: _set(G, "laplacian", laplacian(G)))
    if "subgraph" in which:
        if n <= 2000:
            safe("subgraph", lambda: _set(G, "subgraph", nx.subgraph_centrality(nx.Graph(U))))
        else:
            log.warning(f"subgraph: skipped for {n:,} nodes (limit 2,000)")
    if "voterank" in which:
        top = nx.voterank(U, number_of_nodes=min(n, int(a.get("spreaders", 50))))
        _set(G, "voterank", {x: i for i, x in enumerate(top, 1)})
    if "coreness" in which:
        H = nx.Graph(U)
        H.remove_edges_from(nx.selfloop_edges(H))
        _set(G, "coreness", nx.core_number(H))
    if "clustering" in which:
        _set(G, "clustering", nx.clustering(nx.Graph(U)))
        _set(G, "triangles", nx.triangles(nx.Graph(U)))
    if "neighbor_degree" in which:
        _set(G, "neighbor_degree", nx.average_neighbor_degree(G))
    if "reciprocity" in which and directed:
        _set(G, "reciprocity", {k: (v or 0) for k, v in nx.reciprocity(G, G.nodes).items()})
    if "constraint" in which or "effective_size" in which:
        if G.number_of_edges() > 300_000:
            log.warning("structural holes: network too large; skipped")
        else:                                          # Burt's formulas on mutual weights (see holes.burt)
            from .holes import burt
            B = burt(U)
            keep = ["constraint"] * ("constraint" in which) + ["effective_size", "efficiency"] * ("effective_size" in which)
            for key in keep:
                _set(G, key, {v: b[key] for v, b in B.items() if b[key] == b[key]})
    if "brokerage" in which:
        for name, vals in brokerage(G, a.get("brokerage")).items():
            _set(G, name, vals)
    if "cut_points" in which:
        cut = set(nx.articulation_points(nx.Graph(U)))
        _set(G, "cut_point", {x: int(x in cut) for x in G})


def analyze(G: nx.Graph, cfg: dict):
    """Node measures, groups and network statistics. Returns (G, communities, summary, tables)."""
    from .groups import analyze_groups
    from .network import network_statistics
    a = cfg["analysis"]
    seed = int(a.get("seed", 2026))
    node_measures(G, a.get("centrality") or [], seed, a)
    comms, g_summary, g_tables = analyze_groups(G, a, seed)
    if a.get("group_centrality"):
        try:
            t = group_centrality(G, a["group_centrality"], comms, set_distance(G, a.get("distance", "auto")),
                                 bool(a.get("normalized", True)))
        except (ZeroDivisionError, nx.NetworkXError) as e:      # degenerate networks (e.g. only self-loops)
            log.warning(f"group_centrality not computed: {e}")
            t = None
        if t is not None:
            g_tables["group_centrality"] = t
    extra_summary = {}
    if a.get("tie_strength"):
        from .tie_strength import tie_strength
        ts, tt = tie_strength(G, a["tie_strength"])
        extra_summary.update(ts)
        g_tables.update(tt)
    if a.get("structural_holes"):
        from .holes import structural_holes
        hs, ht = structural_holes(G, a["structural_holes"], comms)
        extra_summary.update(hs)
        g_tables.update(ht)
    if a.get("blockmodel"):
        from .blockmodel import blockmodel
        bs, bt = blockmodel(G, a["blockmodel"], seed)
        extra_summary.update(bs)
        g_tables.update(bt)
    if a.get("ergm"):
        from .ergm import ergm
        es, et = ergm(G, a["ergm"] if isinstance(a["ergm"], dict) else {}, seed)
        extra_summary.update(es)
        g_tables.update(et)
    summary, tables = network_statistics(G, comms, a, seed)
    summary.update(extra_summary)
    summary.update(g_summary)
    tables.update(g_tables)
    summary.update(G.graph.get("summary") or {})        # results a builder adds (ego, transitions…)
    tables.update(G.graph.get("tables") or {})
    return G, comms, summary, tables
