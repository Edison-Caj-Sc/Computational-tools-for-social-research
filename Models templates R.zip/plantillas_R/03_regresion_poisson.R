# =====================================================================
#  03 · REGRESIÓN DE POISSON
#  Para: conteos (0, 1, 2…): número de organizaciones, hijos, visitas, conflictos.
#  Interpretación: razón de tasas de incidencia (IRR). IRR = 1,20 → 20 % más eventos.
#  Supuesto clave: media = varianza. Si hay sobredispersión, usa 04_binomial_negativa.R
# =====================================================================

# ---------------------------------------------------------------------
# 0. CONFIGURACIÓN · edita solo esta sección
# ---------------------------------------------------------------------
archivo        <- NULL
dependiente    <- "n_organizaciones"      # entero mayor o igual a 0
predictores    <- c("educ_jefe", "edad_jefe", "sexo_jefe", "area", "mieperho")
factores       <- list(sexo_jefe = "hombre", area = "urbano")
terminos_extra <- NULL
formula_manual <- NULL
exposicion     <- NULL                    # variable de exposición (tiempo, población); entra como offset(log())
variable_foco  <- "educ_jefe"
usar_diseno    <- FALSE
diseno         <- list(estrato = "estrato", conglomerado = "conglome", peso = "factor07")
carpeta_salida <- "resultados/03_regresion_poisson"

# ---------------------------------------------------------------------
# 1. Preparación
# ---------------------------------------------------------------------
source("utilidades.R"); instalar_si_falta()
salida  <- preparar_salida(carpeta_salida)
formula <- construir_formula(dependiente, predictores,
                             c(terminos_extra, if (!is.null(exposicion)) sprintf("offset(log(%s))", exposicion)),
                             formula_manual)
datos   <- preparar_datos(cargar_datos(archivo), variables_formula(formula), factores,
                          extra = vars_diseno(usar_diseno, diseno))
y <- all.vars(formula)[1]
if (any(datos[[y]] < 0 | datos[[y]] != round(datos[[y]])))
  stop("La variable dependiente debe ser un conteo entero mayor o igual a 0.")
if (!is.null(exposicion) && any(datos[[exposicion]] <= 0)) stop("La exposición debe ser mayor que 0.")
dis <- if (usar_diseno) crear_diseno(datos, diseno) else NULL

encabezado("Distribución del conteo")
desc <- data.frame(media = mean(datos[[y]]), varianza = var(datos[[y]]), pct_ceros = 100 * mean(datos[[y]] == 0))
desc$varianza_sobre_media <- desc$varianza / desc$media
print(redondear(desc, 3)); guardar_tabla(desc, "1_descriptivos", salida)
g <- ggplot(datos, aes(.data[[y]])) + geom_bar(fill = "steelblue") + theme_minimal() +
  labs(title = paste("Distribución de", y), x = y, y = "Frecuencia")
guardar_grafico(g, "1_distribucion_dependiente", salida)

# ---------------------------------------------------------------------
# 2. Estimación
# ---------------------------------------------------------------------
encabezado("Modelo")
modelo <- if (usar_diseno) svyglm(formula, design = dis, family = quasipoisson()) else
  glm(formula, data = datos, family = poisson())
print(summary(modelo))
coefs <- tabla_coeficientes(modelo, exponenciar = TRUE)
names(coefs) <- sub("^exp_", "irr_", names(coefs))
print(redondear(coefs, 3)); guardar_tabla(coefs, "2_coeficientes", salida)

# ---------------------------------------------------------------------
# 3. Sobredispersión y ajuste
# ---------------------------------------------------------------------
encabezado("Sobredispersión")
mu <- fitted(modelo); obs <- datos[[y]]
dispersion <- sum((obs - mu)^2 / mu) / (nrow(datos) - length(coef(modelo)))
aux <- lm(((obs - mu)^2 - obs) / mu ~ mu - 1)      # prueba de Cameron y Trivedi (alfa > 0)
ct  <- summary(aux)$coefficients
sobre <- data.frame(dispersion_pearson = dispersion, alfa_cameron_trivedi = ct[1, 1],
                    p_cameron_trivedi = pt(ct[1, 3], df.residual(aux), lower.tail = FALSE))
sobre$lectura <- ifelse(sobre$p_cameron_trivedi < .05 | dispersion > 1.5,
                        "Hay sobredispersión: usa binomial negativa o errores robustos",
                        "Sin sobredispersión relevante")
print(redondear(sobre, 3)); guardar_tabla(sobre, "3_sobredispersion", salida)

if (!usar_diseno) {
  cat("\nErrores robustos (válidos aunque haya sobredispersión):\n")
  robustos <- tabla_coeficientes(modelo, exponenciar = TRUE, vcov = sandwich::vcovHC(modelo, type = "HC0"))
  names(robustos) <- sub("^exp_", "irr_", names(robustos))
  print(redondear(robustos, 3)); guardar_tabla(robustos, "3_coeficientes_robustos", salida)
  obs_ceros <- mean(obs == 0); esp_ceros <- mean(dpois(0, mu))
  cat(sprintf("Ceros observados: %.1f %% · esperados por Poisson: %.1f %%\n", 100 * obs_ceros, 100 * esp_ceros))
  if (obs_ceros > esp_ceros * 1.2) cat("Exceso de ceros: considera un modelo hurdle o inflado de ceros (paquete pscl).\n")
}

# ---------------------------------------------------------------------
# 4. Interpretación
# ---------------------------------------------------------------------
encabezado("Efectos marginales promedio (cambio en el número esperado)")
ame <- efectos_marginales(modelo, datos, dis, vcov = if (usar_diseno) TRUE else sandwich::vcovHC(modelo, type = "HC0"))
print(redondear(ame, 4)); guardar_tabla(ame, "4_efectos_marginales", salida)
guardar_grafico(grafico_predicciones(modelo, datos, variable_foco, dis, paste("Conteo esperado de", y)),
                "4_predicciones", salida)
guardar_texto(summary(modelo), "resumen_modelo", salida)
encabezado(paste("Listo. Resultados en", salida))
