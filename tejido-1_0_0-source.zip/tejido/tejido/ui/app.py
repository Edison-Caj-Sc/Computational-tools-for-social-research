"""Desktop launcher: starts the local server, opens the browser and shows a small
control window (so the program can be closed without a console)."""
from __future__ import annotations

import locale
import threading
import webbrowser

from .. import __author__, __version__, logs
from ..utils import log
from .server import serve

TEXT = {
    "en": {"running": "Tejido is running in your web browser.", "workspace": "Workspace", "open": "Open interface",
           "folder": "Workspace folder", "log": "Activity log", "quit": "Quit Tejido",
           "note": "Closing this window stops the program. Everything runs on this computer.",
           "failed": "Tejido could not start"},
    "es": {"running": "Tejido está abierto en tu navegador.", "workspace": "Carpeta de trabajo", "open": "Abrir la interfaz",
           "folder": "Carpeta de trabajo", "log": "Registro de actividad", "quit": "Salir de Tejido",
           "note": "Al cerrar esta ventana el programa se detiene. Todo se ejecuta en esta computadora.",
           "failed": "Tejido no pudo iniciarse"}}


def _language() -> str:
    """Spanish when the system's display language is Spanish (on Windows, the language of its menus, as the browser
    does; elsewhere, the locale)."""
    import sys
    if sys.platform.startswith("win"):
        try:
            import ctypes
            return "es" if ctypes.windll.kernel32.GetUserDefaultUILanguage() & 0x3FF == 0x0A else "en"
        except (AttributeError, OSError):
            pass
    try:
        code = (locale.getlocale()[0] or "") or ""
    except (ValueError, TypeError):
        code = ""
    return "es" if code.lower().startswith(("es", "spanish")) else "en"


def desktop(workspace=None) -> None:
    import tkinter as tk
    from tkinter import messagebox, ttk

    from ..gui import open_path

    t = TEXT[_language()]
    try:
        server, _ = serve(workspace, open_browser=True)
    except Exception as e:                                   # port or folder problem: say it, do not vanish
        log.exception("Tejido could not start")
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Tejido", f"{t['failed']}:\n{e}")
        root.destroy()
        return
    threading.Thread(target=server.serve_forever, daemon=True, name="server").start()
    state = server.state

    def safe(fn):
        def run():
            try:
                fn()
            except Exception as e:
                messagebox.showerror("Tejido", str(e))
        return run

    root = tk.Tk()
    root.title(f"Tejido {__version__}")
    root.geometry("460x250")
    root.resizable(False, False)
    frm = ttk.Frame(root, padding=18)
    frm.pack(fill="both", expand=True)
    ttk.Label(frm, text=f"Tejido {__version__}", font=("", 15, "bold")).pack(anchor="w")
    ttk.Label(frm, text=t["running"]).pack(anchor="w", pady=(2, 8))
    ttk.Label(frm, text=f"{t['workspace']}: {state.workspace}", wraplength=420, foreground="#555").pack(anchor="w")
    bar = ttk.Frame(frm)
    bar.pack(anchor="w", pady=(14, 6))
    ttk.Button(bar, text=t["open"], command=lambda: webbrowser.open(server.launch_url)).pack(side="left")
    ttk.Button(bar, text=t["folder"], command=safe(lambda: open_path(state.workspace))).pack(side="left", padx=6)
    ttk.Button(bar, text=t["log"], command=safe(lambda: open_path(state.log_path or state.workspace))).pack(side="left")
    ttk.Button(frm, text=t["quit"], command=root.destroy).pack(anchor="w", pady=(4, 0))
    ttk.Label(frm, text=t["note"], foreground="#666", wraplength=420).pack(anchor="w", pady=(12, 0))
    ttk.Label(frm, text=f"© 2026 {__author__} · MIT", foreground="#666").pack(anchor="w", pady=(4, 0))
    try:
        root.mainloop()
    finally:
        server.shutdown()
        server.server_close()
        log.info("=== Tejido closed")
        logs.shutdown()
