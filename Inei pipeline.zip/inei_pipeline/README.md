# inei-pipeline

De los microdatos del INEI a una base lista para analizar, con **un solo archivo de configuración**.

```
descargar → leer y unir módulos → armonizar entre años → estandarizar → imputar → exportar
```

La descarga se apoya en [inei-microdatos](https://github.com/fiorellarmartins/inei-microdatos). Este paquete se ocupa de lo que viene después: unir módulos con las llaves correctas, construir variables comparables entre años, estandarizar e imputar de forma transparente y reproducible.

## Instalación

```bash
pip install "git+https://github.com/Edison-Caj-Sc/Computational-tools-for-social-research.git#subdirectory=inei_pipeline"
# opcional: knn/iterativo y parquet
pip install scikit-learn pyarrow
```

## Uso rápido

```bash
inei-pipeline iniciar config.yaml      # crea una configuración comentada de ejemplo
inei-pipeline ejecutar config.yaml     # corre todo el flujo
```

Herramientas para escribir las reglas de armonización:

```bash
inei-pipeline encuestas endes           # nombres de encuestas del catálogo
inei-pipeline buscar "confianza" --encuesta enaho --anio 2024
inei-pipeline rastrear p801_1          # etiqueta y códigos de la variable en cada año
inei-pipeline operaciones              # lista de operaciones disponibles
```

Desde Python o un notebook:

```python
from inei_pipeline import Pipeline

p = Pipeline("config.yaml")
datos = p.run()                        # o paso a paso:
base = p.build()                       # leer + unir + armonizar
base = p.standardize(base)
bases, reporte = p.impute(base)
p.export(bases, reporte)
```

## El archivo de configuración

Todo se controla en `config.yaml` (ver `ejemplos/capital_social.yaml`). Solo escribes lo que quieres cambiar; el resto usa valores por defecto.

| Sección | Qué decide |
|---|---|
| `datos` | Encuesta, años, período, módulos, formato, si descargar o usar archivos locales (`carpeta/AÑO/`) |
| `unir` | Nivel de la base (hogar, persona o vivienda), tabla base, columnas duplicadas, agregación de personas a hogar, filtros |
| `armonizar` | Variables comparables entre años mediante reglas por rango de años |
| `diseno` | Estrato, conglomerado y peso (para ponderar y para exportar código de estimación) |
| `estandarizar` | Lista ordenada de operaciones |
| `imputar` | Reglas por variable, imputación múltiple, banderas |
| `exportar` | Carpeta, formatos y variables finales |

### Reglas de armonización

Para cada año se usa la primera regla cuyo `anios` lo incluya. Una regla toma su valor de `variable`, `expresion`, `derivar` (contar, alguno, todos, suma, promedio, maximo, minimo sobre varias columnas, admite comodines como `p801_*`) o `valor`. Puede añadir `faltantes`, `recodificar`, `otros` y `multiplicar`.

```yaml
educ:
  etiqueta: Nivel educativo
  reglas:
    - anios: 2004-2011
      variable: p301a
      recodificar: {1: sin_nivel, 2: inicial, 3: primaria, 4: primaria}
    - anios: 2012-2024
      variable: p301a
      faltantes: [99]
      recodificar: {1: sin_nivel, 2: inicial, 3: primaria, 4: primaria}
```

### Estandarización

| `tipo` | Para qué |
|---|---|
| `faltantes` | Convertir códigos (9, 99, 999999) en faltantes |
| `recodificar` | Recodificar con un diccionario |
| `dividir`, `multiplicar` | Per cápita, mensualizar, cambiar unidades |
| `deflactar` | Montos reales con índice por año (y región) o con una columna de la base |
| `escalar` | `zscore`, `minmax`, `robusto`, `log`, `log1p`, `percentil`; por grupo y ponderado |
| `winsorizar` | Recortar extremos por percentiles, por grupo y ponderado |
| `cortes` | Categorías por cortes fijos o cuantiles ponderados |
| `agrupar_raras` | Juntar categorías poco frecuentes en "otros" |
| `dummies` | Variables indicadoras |
| `ubigeo` | Ubigeo de 6 dígitos, códigos de departamento y provincia, equivalencias entre años |
| `equivalencias` | Tablas de correspondencia (por ejemplo, CIIU rev. 3 a rev. 4) |
| `renombrar`, `eliminar`, `filtrar` | Ordenar la base final |

### Imputación

| `metodo` | Descripción |
|---|---|
| `media`, `mediana`, `moda` | Por grupo y ponderadas si se pide |
| `constante` | Un valor fijo |
| `hotdeck` | Donante aleatorio del mismo grupo, con probabilidad proporcional al peso |
| `knn` | Vecinos más cercanos sobre predictores estandarizados |
| `iterativo` | Regresiones encadenadas (tipo MICE); con `m > 1` genera imputación múltiple |
| `interpolar` | Interpolación lineal dentro de grupos ordenados |

Con `banderas: true` cada variable imputada tiene su `<variable>_imp` (1 = imputado). El dato original nunca se pierde sin dejar rastro.

## Resultados

En la carpeta de exportación se guardan la base (csv, parquet, dta, sav o xlsx), un diccionario de variables, el reporte de imputación, el código para declarar el diseño muestral en Stata, R y Python, y una copia de la configuración usada para reproducir el resultado.

## Añadir una operación nueva

En `standardize.py`, escribe una función `op_<nombre>(df, op, cfg)` que devuelva el DataFrame. Queda disponible automáticamente como `tipo: <nombre>`.

## Advertencias

Las recodificaciones deben verificarse con los cuestionarios y fichas técnicas del INEI de cada año. `rastrear` ayuda, pero no reemplaza esa revisión. Imputar cambia los datos: reporta siempre qué se imputó y cómo. `knn` puede ser lento con bases de cientos de miles de filas.

## Pruebas

```bash
pip install pytest && pytest tests
```

Las pruebas usan datos sintéticos con la estructura de la ENAHO y no requieren internet.

## Créditos

- **Descarga, catálogo e índice de variables:** [inei-microdatos](https://github.com/fiorellarmartins/inei-microdatos), de Fiorella Ramirez (licencia MIT). inei-pipeline lo usa como dependencia, no copia su código. Los comandos `encuestas`, `buscar` y `rastrear` se basan en su catálogo.
- **Datos:** Instituto Nacional de Estadística e Informática (INEI). Cita siempre la encuesta y el año, por ejemplo: INEI. *Encuesta Nacional de Hogares sobre Condiciones de Vida y Pobreza (ENAHO), 2024*. Lima: INEI. https://proyectos.inei.gob.pe/microdatos/
- **Librerías:** pandas, NumPy, PyYAML, pyreadstat, scikit-learn (`KNNImputer`, `IterativeImputer`) y pyarrow.
- **Código de diseño muestral generado para:** el paquete `survey` de R (Thomas Lumley), `samplics` de Python y los comandos `svy` de Stata.
- **Proyectos relacionados que inspiraron este trabajo:** [PeruData/ENAHO](https://github.com/PeruData/ENAHO), de Sebastián Sardón, y el paquete de R [enaho](https://dopatendo.github.io/enaho/), de Andrés Christiansen.

## Licencia

MIT. Autor: Angel Edison Ayala Velásquez.
