"""Indicator data: units (countries, regions, provinces…) × indicators × years, in almost any layout.

Reads World Bank downloads (data.worldbank.org CSV, DataBank exports, Excel) and similar tables from
other sources (CEPALSTAT, OECD, IMF, ILOSTAT, Eurostat, Our World in Data, national statistics
offices…), including untidy ones: titles or notes above the header, footnotes below, several sheets,
missing-value markers (.., -, n.d., :), decimal commas, thousands separators, flags next to values
(12.3 p), and years written as 2015, 2015 [YR2015], YR2015, X2015, 2015.0 or a date.

Layouts (``layout``):
  years_wide        one column per year: unit, [indicator], 2015, 2016, …
  long              one row per value: unit, [indicator], year, value
  indicators_wide   one row per unit and year, one column per indicator: unit, year, gdp, life_exp, …
  units_wide        one row per year, one column per unit: year, Peru, Chile, … (one indicator)

input options (all optional; detected when absent): unit, unit_code, indicator, indicator_code, year,
value (column names), layout, header_row (1 = first row), indicator_name (files with one indicator),
sheet, missing (extra missing-value markers).

Output: the long table country, country_code, indicator, indicator_code, year, value, is_aggregate
("country" is the unit: a country, region, province…). The 'worldbank' prepare step and the
similarity builder (format: worldbank) turn it into one row per unit."""
from __future__ import annotations

import csv
import datetime as _dt
import io as _io
import re
import zipfile
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd

from .utils import ConfigError, as_list, fold, log

PANEL_COLUMNS = ["country", "country_code", "indicator", "indicator_code", "year", "value", "is_aggregate"]
LAYOUTS = ("years_wide", "long", "indicators_wide", "units_wide")
ROLE_NAMES = ("unit", "unit_code", "indicator", "indicator_code", "year", "value")

# header names of each role (accents and case ignored); earlier names win ties
ROLES = {
    "unit_code": ["country code", "country iso3 code", "iso3 code", "iso3", "iso 3", "iso code", "iso alpha 3", "iso",
                  "codigo pais", "codigo del pais", "cod pais", "country id", "economy code", "ref area", "location",
                  "geo", "geo code", "area code", "codigo de area", "ubigeo", "code", "codigo", "cod"],
    "unit": ["country name", "country", "countries", "pais", "paises", "nombre del pais", "nombre pais", "pais o territorio",
             "entity", "entidad", "economy", "economia", "nation", "nacion", "reference area", "area name", "area",
             "territory", "territorio", "geography", "geografia", "location name", "departamento", "region", "provincia",
             "province", "distrito", "district", "estado", "state", "municipio", "municipality", "ciudad", "city",
             "jurisdiccion", "jurisdiction", "ambito", "unidad territorial", "zona"],
    "indicator_code": ["indicator code", "series code", "codigo del indicador", "codigo de indicador", "codigo indicador",
                       "codigo de la serie", "codigo de serie", "indicator id", "series id", "weo subject code",
                       "subject code", "measure code", "variable code", "codigo de variable"],
    "indicator": ["indicator name", "indicator", "indicators", "series name", "series", "serie", "indicador", "indicadores",
                  "nombre del indicador", "nombre de la serie", "variable name", "variable", "variables",
                  "subject descriptor", "subject", "measure", "medida", "concepto", "descriptor", "item", "topic", "tema"],
    "year": ["year", "years", "ano", "anos", "anio", "anios", "time period", "time", "period", "periodo", "obs time",
             "reference year", "ref year", "ano de referencia", "fecha", "date", "yr"],
    "value": ["value", "values", "valor", "valores", "obs value", "observation value", "observation", "dato", "datos",
              "amount", "monto", "cifra", "cifras", "estimate", "estimacion"],
}
MEASURE = ["units", "unit of measure", "unit measure", "unidad de medida", "unidad", "unidades", "unit", "scale", "escala"]
NOTES = ["notes", "note", "nota", "notas", "footnotes", "footnote", "flag", "flags", "obs status", "status", "source",
         "sources", "fuente", "fuentes", "estimates start after", "country series specific notes", "comment", "comments",
         "comentario", "comentarios", "observaciones", "observacion", "decimals", "unit mult", "last updated", "last update",
         "obs flag", "observation status", "conf status", "dataflow", "freq", "frequency", "frecuencia"]
MISSING = {"", ".", "..", "...", "-", "--", "---", "—", "–", "_", "n.d.", "n.d", "nd", "na", "n/a", "n.a.", "n.a", "nan",
           "null", "none", ":", "x", "s.d.", "s/d", "sd", "#n/a", "#value!", "#div/0!", "#ref!", "*", "**", "***",
           "no disponible", "not available", "(na)", "(x)", "(..)", "s.i.", "s/i", "nc"}
NOTE_ROW = re.compile(r"^\s*(fuente|source|nota|notas|note|notes|data from database|last updated|elaborad|elaboration|"
                      r"\(\*|\*|\d\s*/|a/|b/|c/|footnote|definition|definici|cita|citation)", re.I)

YEAR_HEADER = re.compile(r"^\s*(?:[a-z]{1,3}\s*)?((?:1[6-9]|2[01])\d\d)(?:\.0+)?(?:\s*\[\s*yr\d{4}\s*\])?"
                         r"(?:\s*(?:[a-z]{1,2}/?|\d/|\(\w{1,3}\)|\*{1,3}|[a-z]\d/))?\s*$", re.I)
YEAR_VALUE = re.compile(r"^\s*(?:yr|y|x)?((?:1[6-9]|2[01])\d\d)(?:\.0+)?(?:\s*\[\s*yr\d{4}\s*\])?"
                        r"(?:\s*[-/_ ]?\s*(?:[qsmt]\d{1,2}|\d{1,2}(?:[-/]\d{1,2})?(?:[ t]\d{1,2}:\d{2}(?::\d{2})?)?))?\s*$", re.I)
NUMBER = re.compile(r"^[-+]?[\d][\d.,]*$")
AGGREGATE_CODES = set("""AFE AFW ARB CEB CSS EAP EAR EAS ECA ECS EMU EUU FCS HIC HPC IBD IBT IDA IDB IDX INX LAC
LCN LDC LIC LMC LMY LTE MEA MIC MNA NAC OED OSS PRE PSS PST SAS SSA SSF SST TEA TEC TLA TMN TSA TSS UMC WLD""".split())
AGGREGATE_WORDS = re.compile(            # world, regions, income and lending groups (World Bank names in English and Spanish)
    r"\b(world|mundo|mundial|total|totales|income|ingresos?|excluding|excluye|excluido|not classified|no clasificado|"
    r"small states|estados peque\w*os|peque\w*os estados|fragile|fragiles|fragilidad|conflict|conflicto|"
    r"heavily indebted|pobres muy endeudados|least developed|menos adelantados|menos desarrollados|dividend|dividendo|"
    r"euro area|zona del euro|european union|union europea|oecd|ocde|ibrd|birf|ida only|ida total|ida blend|aif|"
    r"sub saharan|subsahariana|al sur del sahara|latin america|america latina|east asia|asia oriental|south asia|"
    r"asia meridional|middle east|oriente medio|north america|america del norte|arab world|mundo arabe|pacific island|"
    r"islas del pac\w*fico|europe central asia|europa y asia central|central europe and the baltics|"
    r"europa central y del baltico|africa eastern|africa western|africa oriental y meridional|africa occidental y central|"
    r"promedio|average|media regional)\b")
CONTINENTS = {"africa", "asia", "europe", "europa", "oceania", "americas", "america", "north america", "south america",
              "latin america", "central america", "america del sur", "sudamerica", "america del norte", "centroamerica",
              "america central", "caribbean", "caribe", "antarctica"}


# ---------------------------------------------------------------------------
# cells
# ---------------------------------------------------------------------------

def _blank(x) -> bool:
    return x is None or (isinstance(x, float) and np.isnan(x)) or (isinstance(x, str) and not x.strip()) or x is pd.NaT


def _text(x) -> str:
    """A cell as text (Excel numbers 2015.0 → '2015', dates → the date)."""
    if _blank(x):
        return ""
    if isinstance(x, (float, np.floating)) and float(x).is_integer():
        return str(int(x))
    if isinstance(x, (_dt.datetime, pd.Timestamp)):
        return x.strftime("%Y-%m-%d") if (x.hour, x.minute) == (0, 0) else str(x)
    return re.sub(r"[\s\u00a0\u202f]+", " ", str(x)).strip()


def year_of(x):
    """2015, 2015.0, '2015 [YR2015]', 'YR2015', 'X2015', '2015-03-31', '2015Q1', a date → 2015 (else NaN)."""
    if _blank(x):
        return np.nan
    if isinstance(x, (_dt.date, pd.Timestamp)):
        return x.year
    if isinstance(x, (int, np.integer, float, np.floating)) and not isinstance(x, bool):
        return int(x) if float(x).is_integer() and 1600 <= x <= 2199 else np.nan
    m = YEAR_VALUE.match(str(x))
    return int(m.group(1)) if m else np.nan


def _is_numberish(s: str) -> bool:
    s = re.sub(r"[\s\u00a0\u202f']", "", s).replace("−", "-").rstrip("%")
    return bool(NUMBER.match(s))


def to_numbers(values: pd.Series, decimal: str | None = None, missing=()) -> tuple[pd.Series, int]:
    """Cleans a column of values: missing markers, flags (12.3 p), %, thousands separators and decimal commas
    (``decimal`` is the file's hint: ',' for semicolon-separated files).
    Returns the numbers and how many non-empty cells were not numbers."""
    if pd.api.types.is_numeric_dtype(values):
        return values.astype(float), 0
    miss = MISSING | {str(m).strip().lower() for m in missing}
    out = np.full(len(values), np.nan)
    raw = []
    for i, x in enumerate(values):
        if isinstance(x, (int, float, np.integer, np.floating)) and not isinstance(x, bool):
            out[i] = float(x)
            continue
        s = _text(x)
        if s.lower() in miss:
            continue
        s = s.replace("−", "-").replace("–", "-")
        s = re.sub(r"(?<=\d)[\s\u00a0\u202f'](?=\d)", "", s)          # 1 234,5 · 1'234.5
        s = re.sub(r"^([-+]?[\d.,]+)\s*(?:%|[a-z]{1,2}/?|\d/|\*{1,3}|[†‡§]|\(\w{1,3}\))$", r"\1", s, flags=re.I)  # flags, %
        raw.append((i, s))
    decimal = _guess_decimal([s for _, s in raw], decimal)
    bad = 0
    for i, s in raw:
        if not NUMBER.match(s):
            bad += 1
            continue
        s = s.replace(".", "").replace(",", ".") if decimal == "," else s.replace(",", "")
        try:
            out[i] = float(s)
        except ValueError:
            bad += 1
    return pd.Series(out, index=values.index), bad


def _guess_decimal(strings, hint=None) -> str:
    """Decimal separator of a column: the last one when both appear (1.234,5 · 1,234.5); a comma when it cannot be a
    thousands separator (3,5); dots only as thousands (1.234.567, or 1.234 in a semicolon file)."""
    both = [s for s in strings if "." in s and "," in s]
    if both:
        last = Counter("," if s.rfind(",") > s.rfind(".") else "." for s in both)
        return last.most_common(1)[0][0]
    comma = [s for s in strings if "," in s]
    dot = [s for s in strings if "." in s]
    thousands = lambda sep, v: all(re.fullmatch(rf"[-+]?\d{{1,3}}(\{sep}\d{{3}})+", x) for x in v)
    if comma:
        if any(x.count(",") > 1 for x in comma) or (thousands(",", comma) and hint != ","):
            return "."
        return ","
    if dot:
        if any(x.count(".") > 1 for x in dot) or (thousands(".", dot) and hint == ","):
            return ","
        return "."
    return hint or "."


# ---------------------------------------------------------------------------
# reading the grid of cells
# ---------------------------------------------------------------------------

def _choose_sep(lines: list[str]) -> str:
    best, best_score = ",", 0
    sample = [ln for ln in lines[:300] if ln.strip()]
    for cand in [",", ";", "\t", "|"]:
        counts = [len(next(csv.reader([ln], delimiter=cand))) for ln in sample]
        counts = [c for c in counts if c > 1]
        if not counts:
            continue
        width, n = Counter(counts).most_common(1)[0]
        score = n * (width - 1) + sum(counts) * 0.01
        if score > best_score:
            best, best_score = cand, score
    return best


def _grids(f: Path, opts: dict) -> list[tuple[str | None, list[list], str | None]]:
    """(sheet name, rows of cells, decimal hint) for each table in the file."""
    ext = f.suffix.lower()
    if ext in (".csv", ".tsv", ".txt"):
        data = f.read_bytes()
        enc = opts.get("encoding")
        for e in [enc] if enc else ["utf-8-sig", "latin-1"]:
            try:
                text = data.decode(e)
                break
            except UnicodeDecodeError:
                continue
        lines = text.splitlines()
        sep = "\t" if ext == ".tsv" else _choose_sep(lines)
        rows = list(csv.reader(_io.StringIO(text), delimiter=sep))
        return [(None, rows, "," if sep == ";" else None)]
    if ext in (".xlsx", ".xlsm", ".xls"):
        sheet = opts.get("sheet")
        if isinstance(sheet, str) and sheet.strip().isdigit():
            sheet = int(sheet) - 1 if int(sheet) > 0 else 0
        try:
            books = pd.read_excel(f, sheet_name=None if sheet in (None, "") else sheet, header=None, dtype=object)
        except ImportError as e:
            raise ConfigError(f"{f.name}: reading old Excel files (.xls) needs the xlrd package (pip install xlrd); "
                              "or save it as .xlsx or CSV") from e
        if isinstance(books, pd.DataFrame):
            books = {str(sheet): books}
        return [(str(name), df.values.tolist(), None) for name, df in books.items()]
    from .io import read_table
    df = read_table(f, encoding=opts.get("encoding"))
    return [(None, [list(df.columns)] + df.values.tolist(), None)]


def _role(name: str, roles=("unit_code", "unit", "indicator_code", "indicator", "year", "value")):
    """(role, score) a header suggests: exact name 3, name starting with it 2, containing it 1."""
    k = re.sub(r"[^a-z0-9]+", " ", fold(name)).strip()
    if not k:
        return None, 0
    best = (None, 0, 0)
    for role in roles:
        for rank, syn in enumerate(ROLES[role]):
            if k == syn:
                sc = 3
            elif k.startswith(syn + " ") or k.endswith(" " + syn):
                sc = 2
            elif len(syn) > 3 and f" {syn} " in f" {k} ":
                sc = 1
            else:
                continue
            key = (sc, -rank)
            if key > (best[1], best[2]):
                best = (role, sc, -rank)
    return best[0], best[1]


def _kind(name: str, lst) -> bool:
    k = re.sub(r"[^a-z0-9]+", " ", fold(name)).strip()
    return k in lst or any(k.startswith(x + " ") for x in lst if len(x) > 4)


def _row_score(row) -> float:
    cells = [_text(x) for x in row]
    full = [c for c in cells if c]
    if len(full) < 2:
        return -1
    years = sum(bool(YEAR_HEADER.match(c)) for c in full)
    nums = sum(_is_numberish(c) and not YEAR_HEADER.match(c) for c in full)
    kw = sum(_role(c)[1] >= 2 for c in full)
    return (len(full) - years - nums) + 2 * kw + 1.5 * years - 2 * nums


def _title(rows: list[list]) -> str | None:
    """Name of the indicator from the lines above the header: 'Indicador: …', or a table title such as
    'Cuadro 7.1: Producto bruto interno por departamentos, 2018-2020' plus a units line '(Millones de soles)'."""
    lines = [" ".join(_text(x) for x in r if _text(x)) for r in rows]
    lines = [ln for ln in lines if ln]
    for ln in lines:
        m = re.match(r"^(indicador|indicator|serie|series|variable|subject|tema)\s*[:\-–]\s*(.+)$", ln, re.I)
        if m:
            return m.group(2).strip()[:150]
    title = units = None
    for ln in lines:
        if re.fullmatch(r"\(.{2,80}\)", ln):
            units = units or ln
        elif not title and not NOTE_ROW.match(ln) and not re.match(r"^(data source|last updated|cepalstat|base de datos)", ln, re.I):
            t = re.sub(r"^(cuadro|tabla|table|gr[aá]fico|figura|figure|anexo|annex)\s*[\w.\-]*\s*[:.\-–]\s*", "", ln, flags=re.I)
            title = re.sub(r",?\s*\(?\d{4}(\s*[-–/]\s*\d{4})?\)?\s*$", "", t).strip() or None
    if title:
        return (title + (f" {units}" if units else ""))[:150]
    return None


def _frame(rows: list[list], header_row=None) -> tuple[pd.DataFrame, int]:
    rows = [list(r) for r in rows if r is not None]
    if not rows:
        raise ConfigError("the file is empty")
    width = max(len(r) for r in rows)
    rows = [r + [None] * (width - len(r)) for r in rows]
    if header_row:
        h = int(header_row) - 1
        if not 0 <= h < len(rows):
            raise ConfigError(f"header_row {header_row} is outside the file ({len(rows)} rows)")
    else:
        scores = [_row_score(r) for r in rows[:60]]
        h = int(np.argmax(scores)) if scores else 0
    names, seen = [], Counter()
    for i, x in enumerate(rows[h]):
        n = _text(x) or f"column_{i + 1}"
        seen[n] += 1
        names.append(n if seen[n] == 1 else f"{n}_{seen[n]}")
    df = pd.DataFrame(rows[h + 1:], columns=names, dtype=object)
    title = _title(rows[:h])
    df = df.map(lambda x: None if _blank(x) else (x.strip() if isinstance(x, str) else x))
    df = df.dropna(axis=1, how="all").dropna(axis=0, how="all")
    if df.shape[1] >= 3:                       # titles, notes and sources: rows with a single cell
        df = df[df.notna().sum(axis=1) > 1]
    if len(df.columns):
        first = df.iloc[:, 0].map(_text)
        df = df[~first.str.match(NOTE_ROW) | (df.notna().sum(axis=1) > 2)]
    df = df.reset_index(drop=True)
    df.attrs["title"] = title
    return df, h + 1


# ---------------------------------------------------------------------------
# roles and layout
# ---------------------------------------------------------------------------

def _col(df, name, what):
    if name in (None, ""):
        return None
    for c in df.columns:
        if c == name or fold(c) == fold(name):
            return c
    raise ConfigError(f"indicator data: {what} column {name!r} not found. Columns: {list(df.columns)[:30]}")


def _share(s: pd.Series, test) -> float:
    v = s.dropna()
    return float(v.map(test).mean()) if len(v) else 0.0


def _roles(df: pd.DataFrame, opts: dict) -> tuple[dict, list, list, list]:
    """Role → column, year columns, measure columns, columns to ignore."""
    roles = {r: _col(df, opts.get(r), r) for r in ROLE_NAMES}
    taken = {c for c in roles.values() if c}
    year_cols = [c for c in df.columns if c not in taken and YEAR_HEADER.match(str(c))]
    if roles["year"] or roles["value"]:
        year_cols = []
    rest = [c for c in df.columns if c not in taken and c not in year_cols]
    measure = [c for c in rest if _kind(c, MEASURE)]
    notes = [c for c in rest if _kind(c, NOTES)]
    cands = []
    for c in rest:
        if c in measure or c in notes:
            continue
        r, sc = _role(c, [r for r in ROLE_NAMES if not roles[r]])
        if r:
            cands.append((sc, c, r))
    for sc, c, r in sorted(cands, key=lambda x: -x[0]):
        if not roles[r] and c not in taken:
            roles[r] = c
            taken.add(c)
    if roles["year"] and _share(df[roles["year"]], lambda x: not np.isnan(year_of(x))) < 0.6:
        roles["year"] = None                    # e.g. a column called "period" that holds text
    if roles["unit_code"] and not roles["unit"] and \
            _share(df[roles["unit_code"]], lambda x: bool(re.fullmatch(r"[A-Z0-9_]{2,8}", _text(x)))) < 0.6:
        roles["unit"], roles["unit_code"] = roles["unit_code"], None   # "code" that holds names
    return roles, year_cols, measure, notes


def _numeric_share(s: pd.Series) -> float:
    return _share(s, lambda x: isinstance(x, (int, float, np.integer, np.floating)) or _text(x).lower() in MISSING
                  or _is_numberish(re.sub(r"\s*(%|[a-z]{1,2}|\*+)$", "", _text(x), flags=re.I)))


def _fallbacks(df, roles, year_cols, skip, layout=None):
    free = [c for c in df.columns if c not in skip and c not in year_cols and c not in roles.values()]
    if not roles["year"] and not year_cols:
        for c in free:
            if _share(df[c], lambda x: not np.isnan(year_of(x))) >= 0.9 and df[c].nunique() > 1:
                roles["year"] = c
                free.remove(c)
                break
    if not roles["unit"] and not roles["unit_code"] and layout != "units_wide":
        for c in free:
            if _numeric_share(df[c]) < 0.2 and df[c].nunique() > 1 and df[c].notna().mean() > 0.8 and \
                    _share(df[c], lambda x: not np.isnan(year_of(x))) < 0.5:
                roles["unit"] = c
                free.remove(c)
                break
    if roles["unit"] and not roles["unit_code"]:
        for c in free:
            if _share(df[c], lambda x: bool(re.fullmatch(r"[A-Z]{2,3}", _text(x)))) >= 0.9 and \
                    df[c].nunique() == df[roles["unit"]].nunique():
                roles["unit_code"] = c
                break
    return roles


def is_aggregate(code, name) -> bool:
    """World, regions, income and lending groups, continents, averages…"""
    c, n = _text(code).upper(), re.sub(r"[^a-z0-9 ]+", " ", fold(_text(name)))
    n = re.sub(r"\s+", " ", n).strip()
    if c in AGGREGATE_CODES or c.startswith("OWID_") or re.fullmatch(r"(EU|EA|EEA|EFTA|EMU|OECD|OCDE|G7|G20)\d*(_\d+)?", c):
        return True
    return bool(AGGREGATE_WORDS.search(n)) or n in CONTINENTS or re.sub(r"\s*\(.*$", "", n) in CONTINENTS \
        or bool(re.match(r"^(africa|asia|europe|europa|oceania|americas?)\b.*\b(un|wb|who|unicef)\b", n))


def _dimension_name(row, dims, measure):
    parts = [f"{d}: {_text(row[d])}" for d in dims if _text(row[d])]
    meas = [f"{_text(row[m])}" for m in measure if _text(row[m])]
    return (" — " + ", ".join(parts) if parts else "") + (f" ({', '.join(meas)})" if meas else "")


def _varying(df, keys, cols):
    """Columns that take several values for the same keys (they distinguish series)."""
    if not cols:
        return []
    keys = [k for k in keys if k]
    if not keys:
        return [c for c in cols if df[c].nunique() > 1]
    g = df.groupby(keys, dropna=False)
    return [c for c in cols if df[c].nunique() > 1 and g[c].nunique(dropna=False).max() > 1]


# ---------------------------------------------------------------------------
# one table → long data
# ---------------------------------------------------------------------------

def _tidy(df: pd.DataFrame, opts: dict, decimal, default_name: str) -> tuple[pd.DataFrame, dict]:
    roles, year_cols, measure, notes = _roles(df, opts)
    layout = opts.get("layout") if opts.get("layout") not in (None, "", "auto") else None
    if layout and layout not in LAYOUTS:
        raise ConfigError(f"indicator data: layout must be one of {LAYOUTS}")
    skip = set(measure) | set(notes)
    roles = _fallbacks(df, roles, year_cols, skip, layout)
    others = [c for c in df.columns if c not in roles.values() and c not in year_cols and c not in skip]
    numeric = [c for c in others if _numeric_share(df[c]) >= 0.6]
    texts = [c for c in others if c not in numeric]
    bad = 0

    def numbers(cols):                       # each column guesses its own decimal separator
        nonlocal df, bad
        df = df.copy()
        for c in cols:
            df[c], b = to_numbers(df[c], decimal, as_list(opts.get("missing")))
            bad += b
    if not layout:
        if year_cols and not roles["year"] and not roles["value"]:
            layout = "years_wide"
        elif roles["value"] or (roles["indicator"] and len(numeric) == 1):
            layout = "long"
        elif roles["unit"] and numeric:
            layout = "indicators_wide"
        elif roles["year"] and numeric:
            layout = "units_wide"
        else:
            raise ConfigError("indicator data: could not recognize the layout. Choose it and the columns of units, "
                              "years and values (input: layout, unit, year, value…)")
    if layout == "units_wide":                 # one indicator; the column headers are the units
        if not roles["year"]:
            raise ConfigError("indicator data (one column per unit): no year column found; set 'year'")
        cols = numeric or others
        numbers(cols)
        long = df.melt(id_vars=[roles["year"]], value_vars=cols, var_name="_unit", value_name="_value")
        long["_ind"] = opts.get("indicator_name") or default_name
        u, uc, ind, ic, yr, val = "_unit", None, "_ind", None, roles["year"], "_value"
        dims = []
    else:
        u, uc = roles["unit"], roles["unit_code"]
        if not u and not uc:
            raise ConfigError("indicator data: no column of units (countries, regions…) found; set 'unit'")
        ind, ic = roles["indicator"], roles["indicator_code"]
        if layout == "years_wide":
            if not year_cols:
                raise ConfigError("indicator data: no year columns (2015, 2016…) found")
            ids = [c for c in (u, uc, ind, ic) if c] + texts + measure
            numbers(year_cols)
            long = df.melt(id_vars=ids, value_vars=year_cols, var_name="_year", value_name="_value")
            yr, val = "_year", "_value"
        elif layout == "long":
            val = roles["value"] or (numeric[0] if len(numeric) == 1 else None)
            if not val:
                raise ConfigError("indicator data (one row per value): no value column found; set 'value'")
            texts = [c for c in texts + numeric if c != val]
            long, yr = df.copy(), roles["year"]
        else:                                  # indicators_wide
            ids = [c for c in (u, uc, roles["year"]) if c] + texts + measure
            if not numeric:
                raise ConfigError("indicator data: no numeric columns to use as indicators")
            numbers(numeric)
            long = df.melt(id_vars=ids, value_vars=numeric, var_name="_ind", value_name="_value")
            ind, ic, yr, val = "_ind", None, roles["year"], "_value"
        if not ind:
            long["_ind"] = opts.get("indicator_name") or default_name
            ind = "_ind"
        dims = _varying(long, [u or uc, ind, yr], [c for c in texts if long[c].nunique() <= 200])
        measure = _varying(long, [ind], measure) if layout != "indicators_wide" else []
    values, b = to_numbers(long[val], decimal, as_list(opts.get("missing")))
    bad += b
    name = long[ind].map(_text)
    if dims or measure:
        name = name + long.apply(lambda r: _dimension_name(r, dims, measure), axis=1)
    code = long[ic].map(_text) if ic else name
    if ic and (dims or measure):
        code = code + long.apply(lambda r: _dimension_name(r, dims, measure), axis=1)
    unit_name = long[u].map(_text) if u else long[uc].map(_text)
    unit_code = long[uc].map(_text).where(lambda c: c != "", unit_name) if uc else unit_name
    if layout == "years_wide":
        years = long[yr].map(lambda h: int(YEAR_HEADER.match(str(h)).group(1)))
    else:
        years = long[yr].map(year_of) if yr else pd.Series(np.nan, index=long.index)
    out = pd.DataFrame({"country": unit_name, "country_code": unit_code, "indicator": name, "indicator_code": code,
                        "year": years, "value": values})
    out = out[(out["country_code"] != "") & out["value"].notna()]
    if yr:
        no_year = out["year"].isna()
        if no_year.any():
            log.warning(f"indicator data: {int(no_year.sum()):,} values without a recognizable year were dropped")
            out = out[~no_year]
    out["year"] = out["year"].astype("Int64")
    codes = out.drop_duplicates("country_code")
    agg = {c: is_aggregate(c, n) for c, n in zip(codes["country_code"], codes["country"])}
    out["is_aggregate"] = out["country_code"].map(agg).astype(bool)
    info = {"layout": layout, "columns": {r: c for r, c in [("unit", u), ("unit_code", uc), ("indicator", roles.get("indicator")),
                                                             ("indicator_code", ic), ("year", roles.get("year")),
                                                             ("value", roles.get("value") or (val if layout == "long" else None))]
                                          if c and not str(c).startswith("_")},
            "year_columns": len(year_cols) if layout == "years_wide" else 0,
            "dimensions": dims + measure, "not_numeric": int(bad)}
    return out.reset_index(drop=True), info


def _score(out: pd.DataFrame) -> float:
    return float(out["value"].notna().sum()) if len(out) else 0.0


def _files(path) -> list[Path]:
    """Table files at path; a ZIP (World Bank CSV downloads come zipped) gives its tables, without metadata files."""
    from .io import TABLE_EXT, _expand
    out = []
    for f in _expand(path, TABLE_EXT | {".xlsm", ".zip"}):
        if f.suffix.lower() != ".zip":
            out.append(f)
            continue
        out += _unzip(f)
    return out


_UNZIPPED: dict = {}                      # (path, size, modified) → extracted tables, so a preview does not unzip again
ZIP_MAX_FILES = 200


def _unzip(f: Path) -> list[Path]:
    """Tables inside a ZIP, extracted to a temporary folder that is removed when the program ends. The number of
    files and their total size are limited (TEJIDO_MAX_UNZIP_MB, 1024 by default), against 'ZIP bombs'."""
    from .io import TABLE_EXT, _limit_mb, temp_folder
    st = f.stat()
    key = (str(f.resolve()), st.st_size, st.st_mtime_ns)
    if key in _UNZIPPED and all(p.exists() for p in _UNZIPPED[key]):
        return list(_UNZIPPED[key])
    limit = _limit_mb("TEJIDO_MAX_UNZIP_MB", 1024) * 1024 * 1024
    try:
        with zipfile.ZipFile(f) as z:
            members = [m for m in z.infolist() if not m.is_dir() and Path(m.filename).suffix.lower() in TABLE_EXT | {".xlsm"}
                       and not Path(m.filename).name.lower().startswith(("metadata", "__macosx", "."))]
            if not members:
                raise ConfigError(f"{f.name}: the ZIP file holds no tables")
            if len(members) > ZIP_MAX_FILES:
                raise ConfigError(f"{f.name}: the ZIP file holds {len(members):,} tables (the limit is {ZIP_MAX_FILES})")
            if sum(m.file_size for m in members) > limit:
                raise ConfigError(f"{f.name}: its tables take more than {limit // 1024 // 1024:,} MB unzipped")
            tmp, out, written = temp_folder("tejido_zip_"), [], 0
            for i, m in enumerate(members):        # only the file name: nothing is written outside the folder
                target = tmp / f"{i:03d}" / Path(m.filename).name     # own folder: equal names do not collide
                target.parent.mkdir()
                with z.open(m) as src, open(target, "wb") as dst:
                    while chunk := src.read(1 << 20):
                        written += len(chunk)
                        if written > limit:        # the size a ZIP declares can be false
                            raise ConfigError(f"{f.name}: its tables take more than {limit // 1024 // 1024:,} MB unzipped")
                        dst.write(chunk)
                out.append(target)
    except zipfile.BadZipFile as e:
        raise ConfigError(f"{f.name}: the ZIP file is damaged or incomplete") from e
    except (RuntimeError, NotImplementedError) as e:      # password or unsupported compression
        raise ConfigError(f"{f.name}: the ZIP file cannot be opened ({e})") from e
    _UNZIPPED[key] = out
    return list(out)


def inspect_indicators(path, opts: dict | None = None, max_rows: int | None = None) -> tuple[pd.DataFrame, dict]:
    """Reads indicator data from one or more files. Returns the long table and what was recognized
    (max_rows: read only the first rows of each table, to recognize it quickly)."""
    opts = dict(opts or {})
    frames, infos = [], []
    files = _files(path)
    for f in files:
        best, errors = None, []
        for sheet, rows, dec in _grids(f, opts):
            if max_rows:
                rows = rows[:max_rows]
            try:
                df, h = _frame(rows, opts.get("header_row"))
                out, info = _tidy(df, opts, dec, opts.get("indicator_name") or df.attrs.get("title") or f.stem)
            except ConfigError as e:
                errors.append(f"{sheet}: {e}" if sheet else str(e))
                continue
            info.update({"file": f.name, "sheet": sheet, "header_row": h, "raw_columns": [str(c) for c in df.columns]})
            if best is None or _score(out) > _score(best[0]):
                best = (out, info)
        if best is None:
            raise ConfigError(f"{f.name}: " + (errors[0] if errors else "no data found"))
        frames.append(best[0])
        infos.append(best[1])
    out = pd.concat(frames, ignore_index=True)
    dup = out.duplicated(["country_code", "indicator_code", "year"], keep=False)
    info = dict(infos[0])
    info.update({"files": len(files), "units": int(out.loc[~out["is_aggregate"], "country_code"].nunique()),
                 "aggregates": int(out.loc[out["is_aggregate"], "country_code"].nunique()),
                 "indicators": int(out["indicator_code"].nunique()), "values": int(len(out)),
                 "years": [int(out["year"].min()), int(out["year"].max())] if out["year"].notna().any() else None,
                 "repeated": int(dup.sum()), "not_numeric": sum(i["not_numeric"] for i in infos)})
    msg = (f"Indicator data ({info['layout']}): {info['units']:,} units, {info['indicators']:,} indicators"
           + (f", {info['years'][0]}–{info['years'][1]}" if info["years"] else "")
           + (f", {info['aggregates']} aggregates" if info["aggregates"] else ""))
    log.info(msg)
    if info["not_numeric"]:
        log.warning(f"indicator data: {info['not_numeric']:,} cells that are not numbers were treated as missing")
    if info["repeated"]:
        log.warning(f"indicator data: {info['repeated']:,} values repeat the same unit, indicator and year; they are averaged")
    return out, info


def read_indicators(path, opts: dict | None = None) -> pd.DataFrame:
    return inspect_indicators(path, opts)[0]


def is_clear(out: pd.DataFrame, info: dict) -> bool:
    """True when recognized data clearly are units × years (not just any table with a number column)."""
    cols, lay = info["columns"], info["layout"]
    explicit_unit = any(_role(c)[1] >= 2 for c in [cols.get("unit"), cols.get("unit_code")] if c)
    clear = (lay == "years_wide" and (info["year_columns"] >= 3 and (cols.get("unit") or cols.get("unit_code"))
                                       or info["year_columns"] >= 2 and explicit_unit)) or \
            (lay in ("long", "indicators_wide") and explicit_unit and cols.get("year") and info["years"]
             and out.groupby("country_code")["year"].nunique().median() >= 2) or \
            (lay == "long" and explicit_unit and cols.get("indicator") and cols.get("value"))
    return bool(clear) and info["units"] >= 2


def detect_indicators(path, sheet=None) -> dict | None:
    """What a table holds when it clearly is indicator data (units × years), else None. Reads only its first rows."""
    try:
        out, info = inspect_indicators(path, {"sheet": sheet} if sheet not in (None, "") else {}, max_rows=3000)
    except Exception:                              # noqa: BLE001 — not indicator data
        return None
    return info if is_clear(out, info) else None
