# =====================================================================
#  01 · REGRESIÓN LINEAL (MCO)
#  Para: variables dependientes continuas (ingreso en logaritmo, puntajes, índices).
#  Interpretación: cambio en Y por cada unidad de X, manteniendo lo demás constante.
#  Si Y está en logaritmo: 100 × (exp(b) − 1) = cambio porcentual en Y.
# =====================================================================

# ---------------------------------------------------------------------
# 0. CONFIGURACIÓN · edita solo esta sección
# ---------------------------------------------------------------------
archivo        <- NULL                    # NULL = datos de ejemplo; o "datos/mi_base.csv" (.csv .dta .sav .xlsx .rds)
dependiente    <- "log_ingreso"
predictores    <- c("educ_jefe", "edad_jefe", "sexo_jefe", "area", "mieperho")
factores       <- list(sexo_jefe = "hombre", area = "urbano")  # variable = categoría de referencia
terminos_extra <- NULL                    # p. ej. c("I(edad_jefe^2)", "educ_jefe:sexo_jefe")
formula_manual <- NULL                    # p. ej. "log_ingreso ~ educ_jefe * area" (reemplaza lo anterior)
variable_foco  <- "educ_jefe"             # para el gráfico de predicciones
usar_diseno    <- FALSE                   # TRUE = estimación con diseño muestral (ENAHO, ENDES…)
diseno         <- list(estrato = "estrato", conglomerado = "conglome", peso = "factor07")
errores_robustos <- "HC3"                 # sin diseño: "HC0".."HC3", "cluster" o NULL (clásicos)
carpeta_salida <- "resultados/01_regresion_lineal"

# ---------------------------------------------------------------------
# 1. Preparación
# ---------------------------------------------------------------------
source("utilidades.R"); instalar_si_falta()
salida  <- preparar_salida(carpeta_salida)
formula <- construir_formula(dependiente, predictores, terminos_extra, formula_manual)
datos   <- preparar_datos(cargar_datos(archivo), variables_formula(formula), factores,
                          extra = c(vars_diseno(usar_diseno, diseno),
                                    if (identical(errores_robustos, "cluster")) diseno$conglomerado))
dis     <- if (usar_diseno) crear_diseno(datos, diseno) else NULL
y       <- all.vars(formula)[1]

encabezado("Descriptivos de la variable dependiente")
print(summary(datos[[y]]))
g <- ggplot(datos, aes(.data[[y]])) + geom_histogram(bins = 40, fill = "steelblue", colour = "white") +
  theme_minimal() + labs(title = paste("Distribución de", y))
guardar_grafico(g, "1_distribucion_dependiente", salida)

# ---------------------------------------------------------------------
# 2. Estimación
# ---------------------------------------------------------------------
encabezado("Modelo")
if (usar_diseno) {
  modelo <- svyglm(formula, design = dis, family = gaussian())
  vc <- NULL                               # el diseño ya da errores estándar correctos
} else {
  modelo <- lm(formula, data = datos)
  vc <- if (is.null(errores_robustos)) NULL else if (errores_robustos == "cluster")
    sandwich::vcovCL(modelo, cluster = datos[[diseno$conglomerado]]) else
    sandwich::vcovHC(modelo, type = errores_robustos)
}
print(summary(modelo))
coefs <- tabla_coeficientes(modelo, vcov = vc)
coefs$cambio_pct_si_log_y <- 100 * (exp(coefs$estimacion) - 1)   # útil solo si Y está en logaritmo
print(redondear(coefs, 3))
guardar_tabla(coefs, "2_coeficientes", salida)

# ---------------------------------------------------------------------
# 3. Ajuste y supuestos
# ---------------------------------------------------------------------
encabezado("Ajuste y diagnósticos")
if (usar_diseno) {
  ajuste <- data.frame(n = nrow(datos), r2_ponderado = r2_ponderado(modelo, dis))
  print(redondear(ajuste, 3)); guardar_tabla(ajuste, "3_ajuste", salida)
  print(prueba_global(modelo))
} else {
  s <- summary(modelo)
  ajuste <- data.frame(n = nobs(modelo), r2 = s$r.squared, r2_ajustado = s$adj.r.squared,
                       AIC = AIC(modelo), BIC = BIC(modelo))
  print(redondear(ajuste, 3)); guardar_tabla(ajuste, "3_ajuste", salida)

  diag <- data.frame(
    prueba = c("Breusch-Pagan (heterocedasticidad)", "RESET (forma funcional)"),
    estadistico = c(lmtest::bptest(modelo)$statistic, lmtest::resettest(modelo)$statistic),
    p = c(lmtest::bptest(modelo)$p.value, lmtest::resettest(modelo)$p.value))
  diag$lectura <- ifelse(diag$p < .05, "Problema detectado (p < 0,05)", "Sin evidencia de problema")
  print(redondear(diag, 4)); guardar_tabla(diag, "3_pruebas", salida)

  if (length(attr(terms(modelo), "term.labels")) > 1) {
    v <- car::vif(modelo)
    v <- if (is.matrix(v)) data.frame(termino = rownames(v), vif = v[, ncol(v)]^2) else
      data.frame(termino = names(v), vif = v)
    v$lectura <- ifelse(v$vif > 5, "Colinealidad alta (> 5)", "Aceptable")
    print(redondear(v, 2)); guardar_tabla(v, "3_vif", salida)
  }
  png(file.path(salida, "3_graficos_diagnostico.png"), width = 2400, height = 2400, res = 300)
  par(mfrow = c(2, 2)); plot(modelo); dev.off()
  cook <- cooks.distance(modelo)
  cat("Observaciones influyentes (Cook > 4/n):", sum(cook > 4 / nobs(modelo)), "\n")
}

# ---------------------------------------------------------------------
# 4. Interpretación: efectos marginales y predicciones
# ---------------------------------------------------------------------
encabezado("Efectos marginales promedio")
ame <- efectos_marginales(modelo, datos, dis, vcov = if (is.null(vc)) TRUE else vc)
print(redondear(ame, 4)); guardar_tabla(ame, "4_efectos_marginales", salida)
guardar_grafico(grafico_predicciones(modelo, datos, variable_foco, dis, paste("Predicción de", y)),
                "4_predicciones", salida)
guardar_texto(summary(modelo), "resumen_modelo", salida)
encabezado(paste("Listo. Resultados en", salida))
