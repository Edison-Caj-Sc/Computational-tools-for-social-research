"""Tests for the network appearance (0.7): the shared style module and the styled interactive page."""
import json
import shutil
import subprocess
from pathlib import Path

import networkx as nx
import pytest

from tejido.export import _numeric_attr, html

STYLE_JS = Path(__file__).parents[1] / "tejido" / "ui" / "static" / "style.js"


def graph():
    G = nx.karate_club_graph()
    for n, d in G.nodes(data=True):
        d.update(label=f"n{n}", community=int(d["club"] == "Officer"), score=float(G.degree(n)) / 3 + n / 100,
                 kind="a" if n % 3 else "b")
    return G


def test_numeric_attributes_use_a_gradient():
    G = graph()
    assert _numeric_attr("score", [d["score"] for _, d in G.nodes(data=True)])
    assert not _numeric_attr("community", [d["community"] for _, d in G.nodes(data=True)])   # codes stay categories
    assert not _numeric_attr("kind", [d["kind"] for _, d in G.nodes(data=True)])
    assert not _numeric_attr("few", [1, 2, 1, 2, 3])                                         # few values: categories


def test_interactive_page_uses_the_chosen_look(tmp_path):
    G, out = graph(), tmp_path / "net.html"
    style = {"shape_by": "kind", "label_by": "#size", "halos": True, "palette": "andean", "layout": "circle"}
    html(G, out, "Karate", {"nodes": 34}, {"color_by": "score", "size_by": "score", "style": style})
    page = out.read_text(encoding="utf-8")
    assert "TejidoStyle" in page and '"halos": true' in page and '"numeric": true' in page
    data = json.loads(page.split("const D = ", 1)[1].split(", TS = TejidoStyle", 1)[0])
    assert {n["shape_key"] for n in data["nodes"]} == {"a", "b"} and " · " in data["nodes"][0]["label"]
    html(G, out, "Karate", {}, {"color_by": "community"})          # without a look: same page as before, Tejido colors
    data = json.loads(out.read_text(encoding="utf-8").split("const D = ", 1)[1].split(", TS = TejidoStyle", 1)[0])
    assert data["numeric"] is False and {n["group"] for n in data["nodes"]} == {"0", "1"}


@pytest.mark.skipif(not shutil.which("node"), reason="Node.js not installed")
def test_style_module():
    script = STYLE_JS.read_text(encoding="utf-8") + """
    const T = globalThis.TejidoStyle, out = {};
    out.clean = T.clean({size_min: 999, palette: "nope", shadow: "true", layout: "rings", extra: 1});
    out.preset = T.preset("print", {layout: "groups", shape_by: "type", palette: "andean"});
    out.diff = T.diff({palette: "okabe", border: 1});
    const nodes = Array.from({length: 40}, (_, i) => ({id: "n" + i, value: i, group: String(i % 4)}));
    out.layouts = ["circle", "rings", "groups"].map(l => Object.keys(T.layout(nodes, T.clean({layout: l}))).length);
    out.force = T.layout(nodes, T.clean({}));
    out.hull = T.hull([{x: 0, y: 0}, {x: 2, y: 0}, {x: 1, y: 1}, {x: 1, y: .2}, {x: 0, y: 2}, {x: 2, y: 2}]).length;
    out.ramp = [T.ramp(["#000000", "#ffffff"], 0), T.ramp(["#000000", "#ffffff"], .5), T.ramp(["#000000", "#ffffff"], 1)];
    out.gradient = [T.edgeColor(T.clean({edge_color: "gradient"}), T.colors(T.clean({})), "#123456", false),
                    T.edgeColor(T.clean({edge_color: "gradient", border_color: "background"}), T.colors(T.clean({})), "#123456", false)];
    out.short = [T.shortName("Cámara de Comercio y Producción de Cajamarca"), T.shortName("SUNAT")];
    const crowd = [{id: "a", x: 0, y: 0, r: 10, w: 120, h: 14}, {id: "b", x: 5, y: 3, r: 8, w: 100, h: 14}, {id: "c", x: 300, y: 0, r: 5, w: 40, h: 12}];
    out.pick = [...T.pickLabels(crowd, new Set(["a", "b", "c"]))];
    T.spread(crowd);
    out.apart = T.pickLabels(crowd, new Set(["a", "b", "c"])).size;
    console.log(JSON.stringify(out));"""
    r = json.loads(subprocess.run(["node", "-e", script], capture_output=True, text=True, check=True).stdout)
    c = r["clean"]
    assert c["size_min"] == 30 and c["palette"] == "tejido" and c["shadow"] is True and c["layout"] == "rings" and "extra" not in c
    p = r["preset"]
    assert p["palette"] == "gray" and p["background"] == "white" and p["layout"] == "groups" and p["shape_by"] == "type"
    assert r["diff"] == {"palette": "okabe"}
    assert r["layouts"] == [40, 40, 40] and r["force"] is None and r["hull"] == 4
    assert r["ramp"] == ["#000000", "#808080", "#ffffff"]
    assert r["gradient"][0] == {"inherit": "both", "opacity": .45} and r["gradient"][1]["color"] == "#123456"
    assert r["short"] == ["Cámara de Comercio…", "SUNAT"]
    assert r["pick"] == ["a", "c"] and r["apart"] == 3          # overlapping name hidden; after spreading, all fit
