"""Browser-based visual interface (runs locally; no data leaves your computer)."""
