@echo off
REM Builds dist\tejido.exe on a Windows computer that has Python.
REM The resulting .exe runs on other Windows computers WITHOUT Python.
REM If NSIS (makensis) is installed, it also builds the installer in dist\.
py -m pip install --upgrade pip
py -m pip install -r installer\requirements-build.txt
py -m pip install --no-deps .
py -m PyInstaller tejido.spec --noconfirm
set MAKENSIS=makensis
where makensis >nul 2>nul || set MAKENSIS="%ProgramFiles(x86)%\NSIS\makensis.exe"
%MAKENSIS% installer\tejido.nsi && move /Y installer\tejido-*-instalador-windows.exe dist\ >nul
echo.
echo Done: dist\tejido.exe  (double-click to open the window)
pause
