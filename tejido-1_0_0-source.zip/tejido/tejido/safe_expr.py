"""Row filters and computed columns written by the user ("year >= 2015 and region == 'Lima'").

pandas evaluates such expressions with access to Python objects, so an expression inside a configuration
file received from someone else could run commands on the computer. Before pandas sees an expression, it
is checked here against a short list of what a filter or a formula needs: column names, numbers, texts,
comparisons, arithmetic, and/or/not, lists, a few column methods (isin, isna, between, str.contains…) and
mathematical functions. Anything else (@variables, imports, attributes of Python objects, file access) is
refused with an explanation."""
from __future__ import annotations

import ast
import re

import pandas as pd

from .utils import ConfigError

MAX_LENGTH = 2000
FUNCTIONS = {"sin", "cos", "tan", "exp", "log", "expm1", "log1p", "sqrt", "sinh", "cosh", "tanh", "arcsin", "arccos",
             "arctan", "arccosh", "arcsinh", "arctanh", "abs", "log10", "floor", "ceil", "arctan2"}
CONSTANTS = {"True", "False", "None", "inf", "Inf", "nan", "NaN", "index"}
ACCESSORS = {"str", "dt"}
METHODS = {
    # missing values and membership
    "isin", "isna", "isnull", "notna", "notnull", "between", "fillna", "where", "mask", "clip",
    # numbers
    "abs", "round", "astype", "rank", "cumsum", "shift", "diff", "mean", "sum", "min", "max", "median", "std",
    "count", "nunique",
    # texts (after .str)
    "contains", "startswith", "endswith", "match", "fullmatch", "lower", "upper", "title", "capitalize", "strip",
    "lstrip", "rstrip", "len", "slice", "get", "zfill", "replace", "isdigit", "isnumeric", "isalpha",
    # dates (after .dt)
    "year", "month", "day", "hour", "minute", "second", "quarter", "weekday", "dayofweek", "dayofyear", "date",
    "days"}
_OPERATORS = (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow, ast.BitAnd, ast.BitOr, ast.BitXor,
              ast.And, ast.Or, ast.Not, ast.Invert, ast.USub, ast.UAdd, ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt,
              ast.GtE, ast.In, ast.NotIn, ast.Load)
_BACKTICK = re.compile(r"`([^`\n]+)`")


def _refuse(where: str, expr: str, why: str):
    raise ConfigError(f"{where}: {expr!r} is not allowed: {why}. Use column names, numbers, texts in quotes, "
                      "comparisons (== != < <= > >=), arithmetic, and / or / not, lists, and methods such as "
                      ".isin([...]), .isna(), .between(a, b) or .str.contains('…').")


def check(expr, columns, where: str = "expression") -> str:
    """Returns the expression if it only uses what a filter or formula needs; otherwise raises ConfigError."""
    if not isinstance(expr, str):
        raise ConfigError(f"{where}: the expression must be text, like \"year >= 2015\" (got {type(expr).__name__})")
    text = expr.strip()
    if not text:
        raise ConfigError(f"{where}: the expression is empty")
    if len(text) > MAX_LENGTH:
        raise ConfigError(f"{where}: the expression is too long ({len(text):,} characters; the limit is {MAX_LENGTH:,})")
    cols = {str(c) for c in columns}
    quoted: dict[str, str] = {}

    def swap(m):                                   # `column with spaces` → a plain name the parser accepts
        name = f"_tejido_col_{len(quoted)}_"
        quoted[name] = m.group(1)
        return name
    try:
        tree = ast.parse(_BACKTICK.sub(swap, text), mode="eval")
    except SyntaxError as e:
        hint = " (variables with @ are not available)" if "@" in text else ""
        raise ConfigError(f"{where}: could not read {expr!r}: {e.msg}{hint}") from e
    for col in quoted.values():
        if col not in cols:
            raise ConfigError(f"{where}: column {col!r} not found. Available: {sorted(cols)[:30]}")

    def chain_ok(node) -> bool:                    # column.method(...) or column.str.method(...)
        if isinstance(node, ast.Name):
            return True
        if isinstance(node, ast.Attribute):
            return node.attr in ACCESSORS and chain_ok(node.value)
        if isinstance(node, (ast.Call, ast.Subscript, ast.BinOp, ast.Compare, ast.BoolOp, ast.UnaryOp)):
            return True                            # their parts are checked on their own
        return False

    for node in ast.walk(tree):
        if isinstance(node, (ast.Expression, ast.BoolOp, ast.BinOp, ast.UnaryOp, ast.Compare, ast.List, ast.Tuple) + _OPERATORS):
            if isinstance(node, ast.BinOp) and isinstance(node.op, ast.MatMult):
                _refuse(where, expr, "the @ operator is not available")
            continue
        if isinstance(node, ast.Constant):
            if not isinstance(node.value, (str, int, float, bool, type(None))):
                _refuse(where, expr, f"values of type {type(node.value).__name__} are not available")
            continue
        if isinstance(node, ast.Name):
            if node.id in quoted or node.id in cols or node.id in CONSTANTS or node.id in FUNCTIONS:
                continue
            raise ConfigError(f"{where}: {node.id!r} in {expr!r} is not a column. Available: {sorted(cols)[:30]}. "
                              "Write texts in quotes ('Lima') and columns with spaces between backticks (`my column`).")
        if isinstance(node, ast.Attribute):
            if node.attr.startswith("_") or node.attr not in METHODS | ACCESSORS:
                _refuse(where, expr, f"'.{node.attr}' is not among the available methods")
            if not chain_ok(node.value):
                _refuse(where, expr, f"'.{node.attr}' must follow a column")
            continue
        if isinstance(node, ast.Call):
            f = node.func
            if isinstance(f, ast.Name):
                if f.id not in FUNCTIONS:
                    _refuse(where, expr, f"the function {f.id!r} is not available")
            elif not (isinstance(f, ast.Attribute) and f.attr in METHODS):
                _refuse(where, expr, "only column methods and mathematical functions can be called")
            if any(isinstance(a, ast.Starred) for a in node.args) or any(k.arg is None for k in node.keywords):
                _refuse(where, expr, "* and ** arguments are not available")
            continue
        if isinstance(node, ast.keyword):
            continue
        if isinstance(node, ast.Subscript):
            _refuse(where, expr, "square brackets after a value are not available (use .str.slice or .str.get)")
        _refuse(where, expr, f"{type(node).__name__} is not available")
    return text


def query(df: pd.DataFrame, expr, where: str = "filter") -> pd.DataFrame:
    """Rows of df for which the (checked) expression is true."""
    text = check(expr, df.columns, where)
    try:
        return df.query(text, engine="python", local_dict={}, global_dict={})
    except ConfigError:
        raise
    except Exception as e:
        raise ConfigError(f"{where}: could not evaluate {expr!r}: {e}") from e


def evaluate(df: pd.DataFrame, expr, where: str = "compute"):
    """Value of the (checked) expression for each row of df."""
    text = check(expr, df.columns, where)
    try:
        return df.eval(text, engine="python", local_dict={}, global_dict={})
    except ConfigError:
        raise
    except Exception as e:
        raise ConfigError(f"{where}: could not evaluate {expr!r}: {e}") from e
