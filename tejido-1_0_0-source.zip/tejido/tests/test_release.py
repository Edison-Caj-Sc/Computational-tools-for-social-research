"""Tests for 1.0: safe expressions, logs and run records, hardened server and exports, release metadata,
and the bugs fixed before the release."""
import json
import logging
import re
import threading
import zipfile
from pathlib import Path

import pandas as pd
import pytest

import tejido
from tejido import build, logs, run
from tejido.io import _years, read_table
from tejido.prepare import prepare
from tejido.safe_expr import check, query
from tejido.utils import ConfigError, file_stem

ROOT = Path(__file__).resolve().parents[1]


# ---------------------------------------------------------------- expressions
DF = pd.DataFrame({"year": [2014, 2016, 2018], "region": ["Lima", "Cajamarca", "Lima"], "income": [10.0, 20.0, None],
                   "tipo de relación": ["a", "b", "a"], "name": ["Ana", "luis", "ROSA"]})


@pytest.mark.parametrize("expr,rows", [
    ("year >= 2015 and region == 'Cajamarca'", 1), ("region in ['Lima', 'Cusco']", 2), ("region.isin(['Lima'])", 2),
    ("income.isna()", 1), ("`tipo de relación` == 'a'", 2), ("name.str.lower().str.contains('a')", 2),
    ("year.between(2015, 2017)", 1), ("sqrt(income) > 3", 2), ("(year > 2015) & ~income.isna()", 1)])
def test_safe_expressions_still_work(expr, rows):
    assert len(query(DF, expr)) == rows


@pytest.mark.parametrize("expr", [
    "@pd.io.common.os.system('echo x')", "pd.io.common.os.system('echo x')", "__import__('os').system('id')",
    "year.to_csv('/tmp/x')", "year.__class__", "year.apply(print)", "open('/etc/passwd')", "(lambda: 1)()",
    "[x for x in year]", "year[0]", "f'{year}'", "year.values.tofile('/tmp/x')", "nope > 1", "x" * 3000])
def test_unsafe_expressions_are_refused(expr, tmp_path):
    with pytest.raises(ConfigError):
        check(expr, DF.columns)


def test_compute_cannot_run_commands(tmp_path):
    flag = tmp_path / "pwned"
    with pytest.raises(ConfigError):
        prepare(DF, [{"compute": {"b": f"@pd.io.common.os.system('echo x > {flag}')"}}], {})
    with pytest.raises(ConfigError):
        prepare(DF, [{"filter": f"@pd.io.common.os.system('echo x > {flag}') == 0"}], {})
    assert not flag.exists()
    assert prepare(DF, [{"compute": {"half": "income / 2"}}], {})["half"].tolist()[:2] == [5.0, 10.0]


def test_ties_filter_is_checked():
    e = pd.DataFrame({"source": ["a", "b"], "target": ["b", "c"], "k": [1, 2]})
    assert build(e, "ties", filter="k > 1").number_of_edges() == 1
    with pytest.raises(ConfigError):
        build(e, "ties", filter="@pd.io.common.os.getcwd() == ''")


def test_a_wrong_prepare_step_says_which():
    with pytest.raises(ConfigError, match=r"step 1 \(recode\)"):
        prepare(DF, [{"recode": "not a mapping"}], {})


# ---------------------------------------------------------------- bugs fixed before 1.0
def test_columns_with_spaces_and_accents(tmp_path):
    e = pd.DataFrame({"from": ["a", "b"], "to": ["b", "c"], "tipo de relación": ["x", "y"], "2020": [5, 6]})
    G = build(e, "ties", source="from", target="to", edge_attributes={"tipo de relación": "first", "2020": "sum"})
    assert G.edges["a", "b"]["tipo de relación"] == "x" and G.edges["b", "c"]["2020"] == 6
    pd.DataFrame({"id": ["a", "b", "c"], "nivel educativo": ["p", "s", "u"]}).to_csv(tmp_path / "n.csv", index=False)
    G = build(e, "ties", source="from", target="to", nodes={"path": str(tmp_path / "n.csv")})
    assert G.nodes["a"]["nivel educativo"] == "p" and "_1" not in G.nodes["a"]


def test_affiliation_without_shared_groups():
    df = pd.DataFrame({"segment": [1, 2], "code": ["x", "y"]})
    G = build(df, "affiliation", group="segment", member="code")
    assert G.number_of_edges() == 0 and set(G) == {"x", "y"}


@pytest.mark.parametrize("spec,expected", [("2015:2017", [2015, 2016, 2017]), ("2015-2017", [2015, 2016, 2017]),
                                           ("2020", [2020]), ([2016, 2015], [2015, 2016]), ("latest", None)])
def test_years(spec, expected):
    assert _years(spec, list(range(2010, 2024))) == expected


def test_years_explains_a_wrong_value():
    with pytest.raises(ConfigError, match="year"):
        _years("abc", [2020])


@pytest.mark.parametrize("name,content", [("empty.csv", b""), ("fake.xlsx", b"not a workbook"), ("bad.json", b"{"),
                                          ("list.json", b"[1, 2]"), ("bad.xls", b"xx"), ("bad.jsonl", b"{\n")])
def test_unreadable_files_give_a_clear_message(tmp_path, name, content):
    (tmp_path / name).write_bytes(content)
    with pytest.raises(ConfigError, match=re.escape(name)):
        read_table(tmp_path / name)


def test_utf16_csv_and_wrapped_json(tmp_path):
    (tmp_path / "u.csv").write_bytes("a,b\n1,ñ\n".encode("utf-16"))
    assert read_table(tmp_path / "u.csv").columns.tolist() == ["a", "b"]
    (tmp_path / "w.json").write_text('{"data": [{"a": 1}, {"a": 2}]}', encoding="utf-8")
    assert read_table(tmp_path / "w.json")["a"].tolist() == [1, 2]


def test_zip_limits(tmp_path, monkeypatch):
    from tejido.panel import _unzip
    z = tmp_path / "many.zip"
    with zipfile.ZipFile(z, "w") as f:
        for i in range(201):
            f.writestr(f"t{i}.csv", "a\n1\n")
    with pytest.raises(ConfigError, match="200"):
        _unzip(z)
    big = tmp_path / "big.zip"
    with zipfile.ZipFile(big, "w", zipfile.ZIP_DEFLATED) as f:
        f.writestr("t.csv", "a\n" + "1\n" * 1_100_000)
    monkeypatch.setenv("TEJIDO_MAX_UNZIP_MB", "1")
    with pytest.raises(ConfigError, match="MB"):
        _unzip(big)
    with zipfile.ZipFile(tmp_path / "dup.zip", "w") as f:            # equal names in two folders do not collide
        f.writestr("a/t.csv", "x\n1\n")
        f.writestr("b/t.csv", "x\n2\n")
    assert len({p.read_text() for p in _unzip(tmp_path / "dup.zip")}) == 2


def test_only_web_addresses_are_downloaded():
    from tejido.io import _download
    with pytest.raises(ConfigError, match="http"):
        _download("file:///etc/passwd")


# ---------------------------------------------------------------- exports
EDGES = pd.DataFrame({"source": ["a\x0bx", "=1+1", "c", "__DATA__"], "target": ["=1+1", "c", "a\x0bx", "c"],
                      "note": ["form\x0cfeed", '=HYPERLINK("http://x")', "@x", "</script><img src=x onerror=alert(1)><!--"]})


def test_exports_survive_hostile_values(tmp_path):
    openpyxl = pytest.importorskip("openpyxl")
    run({"project": "__DATA__", "builder": {"type": "ties", "edge_attributes": {"note": "first"}},
         "output": {"dir": str(tmp_path), "formats": ["xlsx", "graphml", "gexf", "json", "pajek", "ucinet", "matrix",
                                                      "html", "report", "csv"]}}, EDGES)
    page = (tmp_path / "DATA.html").read_text(encoding="utf-8")
    assert "<h1>__DATA__</h1>" in page and "<img src=x" not in page and 'content="Tejido 1.0.0"' in page
    assert not re.search(r"__(VIS|STYLE|STYLEJS|STATS|VERSION|AUTHOR)__", page)
    cells = {c.value: c.data_type for c in openpyxl.load_workbook(tmp_path / "DATA.xlsx")["nodes"]["A"]}
    assert cells["=1+1"] == "s"                                         # a text, not a formula
    assert "Made with" in (tmp_path / "DATA_report.md").read_text(encoding="utf-8") or \
        "made with" in (tmp_path / "DATA_report.md").read_text(encoding="utf-8")


def test_project_name_cannot_leave_the_results_folder(tmp_path):
    out = tmp_path / "out"
    run({"project": "../../escape", "builder": {"type": "ties"}, "output": {"dir": str(out), "formats": ["csv"]}},
        EDGES[["source", "target"]])
    assert (out / "escape_nodes.csv").exists() and not (tmp_path / "escape_nodes.csv").exists()
    assert file_stem("con") == "con_" and file_stem("") == "my_network" and file_stem("R&D") == "R&D"


def test_escape_formulas_option(tmp_path):
    run({"project": "x", "builder": {"type": "ties"}, "output": {"dir": str(tmp_path), "formats": ["csv"], "escape_formulas": True}},
        EDGES[["source", "target"]])
    assert "'=1+1" in (tmp_path / "x_nodes.csv").read_text(encoding="utf-8-sig")


def test_run_record(tmp_path):
    data = tmp_path / "e.csv"
    EDGES[["source", "target"]].to_csv(data, index=False)
    run({"project": "rec", "input": {"path": str(data)}, "builder": {"type": "ties"},
         "output": {"dir": str(tmp_path / "out"), "formats": ["csv"]}})
    rec = json.loads((tmp_path / "out" / "rec_run.json").read_text(encoding="utf-8"))
    assert rec["version"] == tejido.__version__ and rec["author"] == "Angel Edison Ayala Velásquez"
    assert rec["inputs"][0]["file"] == "e.csv" and len(rec["inputs"][0]["sha256"]) == 64
    assert "rec_nodes.csv" in rec["files"] and rec["network"]["nodes"] == 4
    assert all(rec["libraries"][k] for k in ("python", "pandas", "numpy", "scipy", "networkx", "pyyaml"))
    assert Path(rec["inputs"][0]["path"]).is_absolute()


# ---------------------------------------------------------------- activity log
def test_activity_log_masks_keys_and_rotates(tmp_path):
    try:
        path = logs.setup(tmp_path / "logs")
        logging.getLogger("tejido").info("GET /api/file?path=x&t=SECRETSECRETSECRET1234 and X-Token: abcdefghijklmnop")
        logging.getLogger("tejido").info("line\nforged [ERROR] line")
        text = path.read_text(encoding="utf-8")
        assert "SECRETSECRET" not in text and "abcdefghijklmnop" not in text and "t=***" in text
        assert "\n    forged" in text and not re.search(r"^forged", text, re.M)   # cannot pose as a record
        assert re.search(r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}[+-]\d{4} INFO", text, re.M)
        assert "INFO" in logs.tail(path, 5)
    finally:
        logs.shutdown()


def test_console_that_cannot_show_accents(monkeypatch, capsys):
    import io
    import sys

    from tejido.utils import safe_console
    raw = io.BytesIO()
    monkeypatch.setattr(sys, "stdout", io.TextIOWrapper(raw, encoding="ascii"))
    safe_console()
    print("© Velásquez")
    sys.stdout.flush()
    assert raw.getvalue() == b"? Vel?squez\n"


def test_cli_logs_and_version(tmp_path, capsys):
    from tejido.cli import main
    with pytest.raises(SystemExit):
        main(["--version"])
    assert "Angel Edison Ayala Velásquez" in capsys.readouterr().out
    main(["logs", "--workspace", str(tmp_path)])
    assert "tejido.log" in capsys.readouterr().out


# ---------------------------------------------------------------- server
@pytest.fixture
def app(tmp_path):
    from tejido.ui.server import serve
    server, url = serve(tmp_path / "ws", port=0, open_browser=False)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    yield server, url.rstrip("/")
    server.shutdown()
    server.server_close()
    logs.shutdown()


def req(url, path, method="GET", headers=None, data=None):
    import http.client
    u = url.replace("http://", "")
    c = http.client.HTTPConnection(u, timeout=10)
    c.request(method, path, body=data, headers=headers or {})
    r = c.getresponse()
    out = r.status, dict(r.getheaders()), r.read()
    c.close()
    return out


def test_launch_address_gives_a_session_cookie(app):
    server, url = app
    st = server.state
    code, h, body = req(url, "/")
    assert code == 403 and st.token.encode() not in body
    code, h, _ = req(url, f"/?launch={st.launch}")
    assert code == 303 and h["Location"] == "/" and "HttpOnly" in h["Set-Cookie"] and "SameSite=Strict" in h["Set-Cookie"]
    cookie = h["Set-Cookie"].split(";")[0]
    code, h, body = req(url, "/", headers={"Cookie": cookie})
    assert code == 200 and st.token.encode() in body and "script-src 'self'" in h["Content-Security-Policy"]
    assert h["X-Frame-Options"] == "DENY" and h["Server"].strip() == "tejido"
    assert req(url, "/?launch=wrong")[0] == 403


def test_requests_from_other_sites_are_refused(app):
    server, url = app
    tok = {"X-Token": server.state.token}
    assert req(url, "/api/schema", headers=tok)[0] == 200
    assert req(url, "/api/schema", headers={**tok, "Origin": "https://evil.example"})[0] == 403
    assert req(url, "/api/schema", headers={**tok, "Sec-Fetch-Site": "cross-site"})[0] == 403
    assert req(url, "/api/schema", headers={**tok, "Host": "evil.example:80"})[0] == 403
    assert req(url, "/api/schema", headers={**tok, "Host": "127.0.0.1:1"})[0] == 403      # another port
    text = server.state.log_path.read_text(encoding="utf-8")
    assert "Refused" in text and "evil.example" in text and server.state.token not in text


def test_uploads_are_limited(app, monkeypatch):
    server, url = app
    tok = {"X-Token": server.state.token}
    code, _, body = req(url, "/api/upload?name=run.exe&batch=b", "POST", tok, b"MZ")
    assert code == 400 and b"not accepted" in body
    code, _, body = req(url, "/api/upload?name=..%2F..%2Fevil.csv&batch=..", "POST", tok, b"a\n1\n")
    saved = Path(json.loads(body)["file"])
    assert code == 200 and saved.parent.parent == server.state.workspace / "uploads" and saved.name == "evil.csv"
    monkeypatch.setenv("TEJIDO_MAX_UPLOAD_MB", "1")
    code, _, body = req(url, "/api/upload?name=big.csv&batch=b", "POST", {**tok, "Content-Length": str(2 * 1024 * 1024)}, b"")
    assert code == 413


def test_results_stay_in_the_workspace_and_files_are_sandboxed(app, tmp_path):
    from tejido.ui.server import start_job
    import time
    server, url = app
    st = server.state
    data = st.workspace / "uploads" / "e.csv"
    data.parent.mkdir(parents=True, exist_ok=True)
    EDGES[["source", "target"]].to_csv(data, index=False)
    start_job({"project": "p", "input": {"path": str(data)}, "builder": {"type": "ties"},
               "output": {"dir": str(tmp_path / "elsewhere"), "formats": ["html"]}}, st)
    for _ in range(100):
        if st.job["state"] != "running":
            break
        time.sleep(.1)
    assert st.job["state"] == "done" and not (tmp_path / "elsewhere").exists()
    f = next(x for x in st.job["result"]["files"] if x["name"].endswith(".html"))
    assert "t=" not in f["url"]
    code, h, _ = req(url, f["url"], headers={"X-Token": st.token})
    assert code == 200 and h["Content-Security-Policy"].startswith("sandbox")
    tok = {"X-Token": st.token, "Content-Type": "application/json"}
    code, _, _ = req(url, "/api/open", "POST", tok, json.dumps({"path": str(data)}).encode())
    assert code == 400                                                   # a file is never opened (run)
    code, _, body = req(url, "/api/logs?lines=50", headers={"X-Token": st.token})
    assert code == 200 and "Build" in json.loads(body)["text"]


def test_about_names_the_owner(app):
    server, url = app
    schema = json.loads(req(url, "/api/schema", headers={"X-Token": server.state.token})[2])
    a = schema["about"]
    assert a["author"] == "Angel Edison Ayala Velásquez" and a["version"] == tejido.__version__ and a["license"] == "MIT"
    page = (ROOT / "tejido" / "ui" / "index.html").read_text(encoding="utf-8")
    assert "© 2026 Angel Edison Ayala Velásquez" in page and "<style>" not in page and "onclick=" not in page


# ---------------------------------------------------------------- release metadata agree
def test_versions_agree():
    v = tejido.__version__
    assert re.search(rf'^version = "{re.escape(v)}"', (ROOT / "pyproject.toml").read_text(encoding="utf-8"), re.M)
    nsi = (ROOT / "installer" / "tejido.nsi").read_text(encoding="utf-8")
    assert f'!define VERSION "{v}"' in nsi and f'tejido-{v.replace(".", "_")}-instalador' in nsi and f'VIProductVersion "{v}.0"' in nsi
    assert f"'FileVersion', '{v}'" in (ROOT / "installer" / "version_info.txt").read_text(encoding="utf-8")
    assert f"## {v}" in (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert f"(Version {v})" in readme and f"version = {{{v}}}" in readme
    assert "Angel Edison Ayala Velásquez" in (ROOT / "LICENSE").read_text(encoding="utf-8")
    assert (ROOT / "tejido" / "ui" / "static" / "LICENSE.txt").read_text() == (ROOT / "LICENSE").read_text()
