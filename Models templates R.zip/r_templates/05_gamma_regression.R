# =====================================================================
#  05 · GAMMA REGRESSION (log link)
#  For: positive, right-skewed continuous outcomes (income, spending, time, amounts).
#  Advantage over OLS on log(Y): it models the mean of Y on its original scale and
#  allows the variance to grow with the mean.
#  Interpretation: exp(b) is a multiplicative effect. exp(b) = 1.08 → Y is 8 % higher.
# =====================================================================

# ---------------------------------------------------------------------
# 0. SETTINGS · edit this section only
# ---------------------------------------------------------------------
file           <- NULL
outcome        <- "income"                # strictly greater than 0
predictors     <- c("head_educ", "head_age", "head_sex", "area", "hh_size")
factors        <- list(head_sex = "male", area = "urban")
extra_terms    <- NULL
manual_formula <- NULL
link           <- "log"                   # "log" (recommended), "identity" or "inverse"
focus_variable <- "head_educ"
use_design     <- FALSE
design         <- list(stratum = "stratum", psu = "psu", weight = "weight")
output_dir     <- "results/05_gamma_regression"

# ---------------------------------------------------------------------
# 1. Preparation
# ---------------------------------------------------------------------
source("utils.R"); install_if_missing()
out     <- prepare_output(output_dir)
formula <- build_formula(outcome, predictors, extra_terms, manual_formula)
data    <- prepare_data(load_data(file), formula_vars(formula), factors, extra = design_vars(use_design, design))
y <- all.vars(formula)[1]
if (any(data[[y]] <= 0))
  stop(sprintf("Gamma requires Y > 0 and there are %d values <= 0. Drop them or use another model (e.g. Tweedie or hurdle).",
               sum(data[[y]] <= 0)))
dsg <- if (use_design) create_design(data, design) else NULL

header("Descriptives")
desc <- data.frame(mean = mean(data[[y]]), median = median(data[[y]]), sd = sd(data[[y]]),
                   skewness = mean((data[[y]] - mean(data[[y]]))^3) / sd(data[[y]])^3)
print(round_df(desc, 2)); save_table(desc, "1_descriptives", out)
g <- ggplot(data, aes(.data[[y]])) + geom_histogram(bins = 50, fill = "steelblue", colour = "white") +
  theme_minimal() + labs(title = paste("Distribution of", y))
save_plot(g, "1_outcome_distribution", out)

# ---------------------------------------------------------------------
# 2. Estimation
# ---------------------------------------------------------------------
header("Model")
fam <- Gamma(link = link)
model <- if (use_design) svyglm(formula, design = dsg, family = fam) else
  glm(formula, data = data, family = fam, control = glm.control(maxit = 100))
print(summary(model))
coefs <- coef_table(model, exponentiate = link == "log")
print(round_df(coefs, 3)); save_table(coefs, "2_coefficients", out)

# ---------------------------------------------------------------------
# 3. Fit and diagnostics
# ---------------------------------------------------------------------
header("Fit")
disp <- summary(model)$dispersion
fit <- data.frame(n = nrow(data), dispersion = disp, implied_cv = sqrt(disp),
                  squared_corr_obs_pred = cor(data[[y]], fitted(model))^2)
if (!use_design) { fit$AIC <- AIC(model); fit$BIC <- BIC(model) }
print(round_df(fit, 3)); save_table(fit, "3_fit", out)
dg <- data.frame(fitted = fitted(model), residual = residuals(model, type = "deviance"))
g <- ggplot(dg, aes(log(fitted), residual)) + geom_point(alpha = .3) +
  geom_smooth(se = FALSE, colour = "red", method = "loess", formula = y ~ x) + theme_minimal() +
  labs(title = "Deviance residuals vs. fitted values",
       subtitle = "A flat line around 0 suggests a good specification", x = "log(fitted value)")
save_plot(g, "3_residuals", out)

# ---------------------------------------------------------------------
# 4. Interpretation
# ---------------------------------------------------------------------
header("Average marginal effects (in units of Y)")
ame <- marginal_effects(model, data, dsg)
print(round_df(ame, 3)); save_table(ame, "4_marginal_effects", out)
save_plot(prediction_plot(model, data, focus_variable, dsg, paste("Expected", y)), "4_predictions", out)
save_text(summary(model), "model_summary", out)
header(paste("Done. Results in", out))
