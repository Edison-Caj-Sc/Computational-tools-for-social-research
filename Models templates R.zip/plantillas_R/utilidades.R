# =====================================================================
#  utilidades.R · funciones compartidas por todas las plantillas
#  No necesitas editar este archivo.
# =====================================================================

PAQUETES <- c("survey", "MASS", "nnet", "sandwich", "lmtest", "car",
              "ggplot2", "broom", "marginaleffects", "haven", "readxl")

instalar_si_falta <- function(paquetes = PAQUETES) {
  faltan <- paquetes[!vapply(paquetes, requireNamespace, logical(1), quietly = TRUE)]
  if (length(faltan)) {
    message("Instalando paquetes que faltan: ", paste(faltan, collapse = ", "))
    install.packages(faltan, repos = "https://cloud.r-project.org")
  }
  invisible(suppressPackageStartupMessages(lapply(paquetes, library, character.only = TRUE)))
}

encabezado <- function(texto) {
  cat("\n", strrep("=", 70), "\n ", texto, "\n", strrep("=", 70), "\n", sep = "")
}

# ---------------------------------------------------------------------
# Datos
# ---------------------------------------------------------------------

cargar_datos <- function(archivo = NULL) {
  if (is.null(archivo)) {
    message("Usando datos de ejemplo simulados (cambia 'archivo' para usar tus datos).")
    return(datos_ejemplo())
  }
  if (!file.exists(archivo)) stop("No encuentro el archivo: ", archivo)
  ext <- tolower(tools::file_ext(archivo))
  d <- switch(ext,
    csv  = utils::read.csv(archivo, encoding = "UTF-8", fileEncoding = "UTF-8-BOM",
                           stringsAsFactors = FALSE),
    dta  = haven::zap_labels(haven::read_dta(archivo)),
    sav  = haven::zap_labels(haven::read_sav(archivo)),
    xlsx = , xls = as.data.frame(readxl::read_excel(archivo)),
    rds  = readRDS(archivo),
    stop("Formato no soportado: .", ext, " (usa csv, dta, sav, xlsx o rds)")
  )
  as.data.frame(d)
}

#' Datos simulados con estructura de una encuesta de hogares (no son datos reales).
datos_ejemplo <- function(n = 3000, semilla = 2026) {
  set.seed(semilla)
  k <- n / 20
  conglome <- rep(seq_len(k), each = 20)
  estrato  <- rep(sample(1:8, k, TRUE, prob = c(.2, .15, .1, .1, .15, .1, .1, .1)), each = 20)
  area     <- ifelse(estrato <= 5, "urbano", "rural")
  rural    <- as.integer(area == "rural")
  u        <- rep(rnorm(k, 0, .25), each = 20)                     # efecto del conglomerado
  sexo_jefe <- sample(c("hombre", "mujer"), n, TRUE, prob = c(.72, .28))
  mujer    <- as.integer(sexo_jefe == "mujer")
  edad_jefe <- round(pmin(pmax(rnorm(n, 48, 14), 18), 95))
  educ_jefe <- round(pmin(pmax(rnorm(n, 11 - 4 * rural, 3.5), 0), 18))
  mieperho <- pmax(1, rpois(n, 3.3 + .6 * rural))
  log_ingreso <- 5.7 + .08 * educ_jefe + .012 * edad_jefe - .15 * mujer - .35 * rural + u + rnorm(n, 0, .6)
  ingreso  <- round(exp(log_ingreso), 1)
  mu_org   <- exp(-.6 + .05 * educ_jefe + .3 * rural + .1 * mieperho + u)
  n_organizaciones <- rnbinom(n, size = 1.2, mu = mu_org)
  mu_alim  <- plogis(.8 - .5 * (log_ingreso - 6.5) + .3 * rural)
  prop_gasto_alim <- round(rbeta(n, mu_alim * 20, (1 - mu_alim) * 20), 3)
  lat_conf <- .05 * educ_jefe + .4 * (n_organizaciones > 0) - .3 * rural + rlogis(n)
  confianza <- cut(lat_conf, c(-Inf, -.3, .8, 2, Inf), labels = c("nada", "poca", "suficiente", "mucha"))
  util <- cbind(asalariado_formal = -2.5 + .25 * educ_jefe - 1.2 * rural,
                asalariado_informal = 0,
                independiente = -1 + .02 * edad_jefe - .4 * mujer + .3 * rural)
  pr <- exp(util) / rowSums(exp(util))
  ocupacion <- colnames(util)[apply(pr, 1, function(p) sample(3, 1, prob = p))]
  d <- data.frame(conglome, estrato, factor07 = round(runif(n, 60, 140) * (1 + .5 * rural), 1),
                  area, sexo_jefe, edad_jefe, educ_jefe, mieperho, ingreso, log_ingreso = round(log_ingreso, 4),
                  pobre = as.integer(ingreso < 450), n_organizaciones,
                  participa_org = as.integer(n_organizaciones > 0), prop_gasto_alim,
                  confianza = as.character(confianza), ocupacion, stringsAsFactors = FALSE)
  d$log_ingreso[sample(n, 60)] <- NA      # algunos faltantes, como en datos reales
  d
}

#' Selecciona casos completos, convierte factores y fija categorías de referencia.
preparar_datos <- function(datos, variables, factores = list(), ordenadas = list(), extra = character()) {
  variables <- unique(c(variables, extra))
  faltan <- setdiff(variables, names(datos))
  if (length(faltan)) stop("Estas variables no existen en los datos: ", paste(faltan, collapse = ", "))
  d <- datos[, variables, drop = FALSE]
  n0 <- nrow(d)
  d <- d[stats::complete.cases(d), , drop = FALSE]
  if (n0 - nrow(d) > 0)
    message(sprintf("Se excluyen %d de %d casos (%.1f %%) por datos faltantes.",
                    n0 - nrow(d), n0, 100 * (n0 - nrow(d)) / n0))
  for (v in names(factores)) {
    if (!v %in% names(d)) next
    d[[v]] <- factor(d[[v]])
    ref <- factores[[v]]
    if (!is.null(ref) && !is.na(ref)) {
      if (!ref %in% levels(d[[v]]))
        stop(sprintf("La referencia '%s' no es una categoría de '%s'. Categorías: %s",
                     ref, v, paste(levels(d[[v]]), collapse = ", ")))
      d[[v]] <- stats::relevel(d[[v]], ref = as.character(ref))
    }
  }
  for (v in names(ordenadas)) d[[v]] <- factor(d[[v]], levels = ordenadas[[v]], ordered = TRUE)
  if (any(vapply(names(ordenadas), function(v) anyNA(d[[v]]), logical(1))))
    stop("Hay valores que no están en el orden indicado en 'ordenadas'. Revisa las categorías.")
  d
}

construir_formula <- function(dependiente, predictores, extra = NULL, manual = NULL) {
  f <- if (!is.null(manual)) stats::as.formula(manual) else
    stats::reformulate(c(predictores, extra), response = dependiente)
  environment(f) <- parent.frame()          # las variables del script se encuentran desde la fórmula
  f
}

variables_formula <- function(formula) all.vars(formula)

# ---------------------------------------------------------------------
# Diseño muestral
# ---------------------------------------------------------------------

crear_diseno <- function(datos, d) {
  options(survey.lonely.psu = "adjust")
  survey::svydesign(ids = stats::as.formula(paste0("~", d$conglomerado)),
                    strata = stats::as.formula(paste0("~", d$estrato)),
                    weights = stats::as.formula(paste0("~", d$peso)),
                    data = datos, nest = TRUE)
}

vars_diseno <- function(usar, d) if (isTRUE(usar)) unlist(d[c("estrato", "conglomerado", "peso")]) else character()

pesos_para_efectos <- function(diseno) if (is.null(diseno)) NULL else as.numeric(stats::weights(diseno))

# ---------------------------------------------------------------------
# Tablas
# ---------------------------------------------------------------------

estrellas <- function(p) ifelse(p < .001, "***", ifelse(p < .01, "**", ifelse(p < .05, "*", ifelse(p < .1, ".", ""))))

#' Tabla de coeficientes. Con 'exponenciar' muestra OR, IRR o efectos multiplicativos.
tabla_coeficientes <- function(modelo, exponenciar = FALSE, vcov = NULL, nivel = .95) {
  if (!is.null(vcov)) {
    ct <- lmtest::coeftest(modelo, vcov. = vcov)
    ic <- lmtest::coefci(modelo, vcov. = vcov, level = nivel)
    tab <- data.frame(termino = rownames(ct), estimacion = ct[, 1], ee = ct[, 2],
                      estadistico = ct[, 3], p = ct[, 4], ic_inf = ic[, 1], ic_sup = ic[, 2])
  } else {
    t <- broom::tidy(modelo, conf.int = TRUE, conf.level = nivel)
    tab <- data.frame(termino = t$term, estimacion = t$estimate, ee = t$std.error,
                      estadistico = t$statistic, p = t$p.value, ic_inf = t$conf.low, ic_sup = t$conf.high)
  }
  if (exponenciar) {
    tab$exp_estimacion <- exp(tab$estimacion)
    tab$exp_ic_inf <- exp(tab$ic_inf)
    tab$exp_ic_sup <- exp(tab$ic_sup)
    tab$cambio_pct <- 100 * (tab$exp_estimacion - 1)
  }
  tab$signif <- estrellas(tab$p)
  rownames(tab) <- NULL
  tab
}

#' Efectos marginales promedio (AME), ponderados si hay diseño muestral.
efectos_marginales <- function(modelo, datos, diseno = NULL, pesos = NULL, ...) {
  args <- list(modelo, newdata = datos, ...)
  w <- if (!is.null(pesos)) pesos else pesos_para_efectos(diseno)
  if (!is.null(w)) args$wts <- w
  am <- suppressWarnings(do.call(marginaleffects::avg_slopes, args))
  out <- as.data.frame(am)
  keep <- intersect(c("group", "term", "contrast", "estimate", "std.error", "p.value", "conf.low", "conf.high"),
                    names(out))
  out <- out[, keep]
  names(out) <- c(group = "categoria", term = "termino", contrast = "contraste", estimate = "efecto",
                  std.error = "ee", p.value = "p", conf.low = "ic_inf", conf.high = "ic_sup")[keep]
  out$signif <- estrellas(out$p)
  out
}

#' Prueba de Wald conjunta de todos los términos (modelos con diseño muestral).
prueba_global <- function(modelo) {
  terminos <- attr(stats::terms(modelo), "term.labels")
  survey::regTermTest(modelo, stats::reformulate(terminos), method = "Wald")
}

#' R² ponderado por los pesos del diseño.
r2_ponderado <- function(modelo, diseno) {
  w <- stats::weights(diseno); y <- stats::model.response(stats::model.frame(modelo))
  1 - sum(w * (y - stats::fitted(modelo))^2) / sum(w * (y - stats::weighted.mean(y, w))^2)
}

#' Errores robustos por conglomerado para nnet::multinom (sandwich no lo soporta).
vcov_cluster_multinom <- function(modelo, datos, formula, cluster, pesos = NULL) {
  X <- stats::model.matrix(formula, data = datos)
  P <- stats::fitted(modelo)
  Y <- stats::model.matrix(~ y - 1, data.frame(y = datos[[all.vars(formula)[1]]]))
  w <- if (is.null(pesos)) rep(1, nrow(X)) else pesos
  S <- do.call(cbind, lapply(2:ncol(P), function(j) (Y[, j] - P[, j]) * w * X))
  U <- rowsum(S, cluster)
  G <- nrow(U)
  B <- stats::vcov(modelo)
  V <- B %*% (crossprod(U) * G / (G - 1)) %*% B
  dimnames(V) <- dimnames(B)
  V
}

comparar_modelos <- function(...) {
  ms <- list(...)
  data.frame(modelo = names(ms),
             n = vapply(ms, stats::nobs, numeric(1)),
             logLik = vapply(ms, function(m) as.numeric(stats::logLik(m)), numeric(1)),
             AIC = vapply(ms, stats::AIC, numeric(1)),
             BIC = vapply(ms, stats::BIC, numeric(1)), row.names = NULL)
}

redondear <- function(df, dig = 4) {
  df[] <- lapply(df, function(x) if (is.numeric(x)) round(x, dig) else x)
  df
}

# ---------------------------------------------------------------------
# Salidas
# ---------------------------------------------------------------------

preparar_salida <- function(carpeta) {
  dir.create(carpeta, recursive = TRUE, showWarnings = FALSE)
  carpeta
}

guardar_tabla <- function(tabla, nombre, carpeta) {
  ruta <- file.path(carpeta, paste0(nombre, ".csv"))
  con <- file(ruta, open = "w", encoding = "UTF-8")
  on.exit(close(con))
  cat("\ufeff", file = con)                       # BOM: Excel muestra bien las tildes
  utils::write.csv(redondear(tabla), con, row.names = FALSE)
  message("Guardado: ", ruta)
  invisible(ruta)
}

guardar_grafico <- function(grafico, nombre, carpeta, ancho = 7, alto = 5) {
  ruta <- file.path(carpeta, paste0(nombre, ".png"))
  ggplot2::ggsave(ruta, grafico, width = ancho, height = alto, dpi = 300)
  message("Guardado: ", ruta)
  invisible(ruta)
}

guardar_texto <- function(expr, nombre, carpeta) {
  ruta <- file.path(carpeta, paste0(nombre, ".txt"))
  utils::capture.output(expr, file = ruta)
  message("Guardado: ", ruta)
  invisible(ruta)
}

#' Predicciones condicionales: el resto de variables se fija en su media o moda,
#' por eso no requiere pesos.
grafico_predicciones <- function(modelo, datos, foco, diseno = NULL, titulo = NULL, ...) {
  p <- suppressWarnings(marginaleffects::plot_predictions(modelo, condition = foco, newdata = datos, ...))
  p + ggplot2::labs(title = titulo, x = foco, y = "Valor predicho") + ggplot2::theme_minimal(base_size = 12)
}
