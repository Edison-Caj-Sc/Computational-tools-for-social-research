"""Writes tejido/ui/static/THIRD-PARTY-LICENSES.txt: the license texts of the libraries that travel inside the
executable (their BSD/MIT/Apache terms require keeping the notice). Run it on the machine that builds the executable,
with the same packages installed:  python tools/third_party_licenses.py   (needs internet only for the Python, Tcl/Tk
and PyInstaller texts)."""
import importlib.metadata as md
import re
import sys
import tempfile
import urllib.request
import zipfile
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "tejido" / "ui" / "static" / "THIRD-PARTY-LICENSES.txt"
PACKAGES = ["numpy", "pandas", "scipy", "networkx", "PyYAML", "openpyxl", "et_xmlfile", "xlrd", "pypdf", "python-docx",
            "lxml", "pyreadstat", "python-dateutil", "tzdata", "narwhals", "typing_extensions"]
ONLINE = {"Python (PSF License 2.0)": "https://raw.githubusercontent.com/python/cpython/3.12/LICENSE",
          "Tcl (Tcl/Tk License, used by the small launcher window)": "https://raw.githubusercontent.com/tcltk/tcl/main/license.terms",
          "Tk (Tcl/Tk License)": "https://raw.githubusercontent.com/tcltk/tk/main/license.terms",
          "PyInstaller bootloader (GPL-2.0-or-later with the bootloader exception that lets the executable carry any license)":
              "https://raw.githubusercontent.com/pyinstaller/pyinstaller/develop/COPYING.txt"}
LIC = re.compile(r"(licen[cs]e|copying|notice|authors)", re.I)


def from_installed(name):
    d = md.distribution(name)
    files = [f for f in (d.files or []) if ".dist-info" in str(f) and LIC.search(f.name) and not str(f).endswith(".py")]
    meta = d.metadata
    spdx = meta.get("License-Expression") or (meta.get("License") or "").split("\n")[0][:60] or "see text"
    return d.version, spdx, [(f.name, f.locate().read_text(encoding="utf-8", errors="replace")) for f in files]


def from_wheel(name):
    tmp = tempfile.mkdtemp()
    subprocess.run([sys.executable, "-m", "pip", "download", "--no-deps", "--only-binary=:all:", "-q", "-d", tmp, name], check=True)
    whl = next(Path(tmp).glob("*.whl"))
    with zipfile.ZipFile(whl) as z:
        files = [(Path(n).name, z.read(n).decode("utf-8", "replace")) for n in z.namelist() if ".dist-info/" in n and LIC.search(Path(n).name)]
    return whl.name.split("-")[1], "see text", files


out = ["THIRD-PARTY LICENSES FOR TEJIDO",
       "Tejido is MIT licensed (see LICENSE). The executable also contains the components below, each under its own license.",
       "Also bundled, with their licenses in separate files: vis-network (LICENSE-vis-network.txt), the typefaces Instrument Sans",
       "and Newsreader (LICENSE-fonts.txt) and xlrd (LICENSE-xlrd.txt). The versions listed are those installed when this file was made.", ""]
for name in PACKAGES:
    try:
        ver, spdx, files = from_installed(name)
    except md.PackageNotFoundError:
        ver, spdx, files = from_wheel(name)
    print(f"{name} {ver}: {spdx} · {len(files)} license file(s)")
    out += ["=" * 100, f"{name} {ver}  ({spdx})", "=" * 100]
    seen = set()
    for fname, text in files:
        if text.strip() and text not in seen:
            seen.add(text); out += [f"--- {fname} ---", text.strip(), ""]
    if not seen:
        print("  !! no license text found for", name)
for title, url in ONLINE.items():
    out += ["=" * 100, title, "=" * 100]
    try:
        out += [urllib.request.urlopen(url, timeout=30).read().decode("utf-8", "replace").strip(), ""]
        print("ok  ", title.split(" (")[0])
    except Exception as e:
        out += [f"(text not downloaded: {e}) See {url}", ""]; print("FAIL", title.split(" (")[0], e)
OUT.write_text("\n".join(out), encoding="utf-8")
print("written", OUT, OUT.stat().st_size // 1024, "KB")
