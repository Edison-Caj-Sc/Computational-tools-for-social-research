"""Entry point of the standalone executable.

Double-click (no arguments) → visual interface in the browser + a small control window.  With arguments → command line,
e.g.  tejido.exe run config.yaml   ·   tejido.exe init examples   ·   tejido.exe builders"""
import sys


def _hide_console_on_windows():
    """When double-clicked, Windows opens a console window too; detach from it."""
    if sys.platform.startswith("win"):
        try:
            import ctypes
            import logging
            import os
            ctypes.windll.kernel32.FreeConsole()
            sys.stdout = sys.stderr = open(os.devnull, "w")
            for h in logging.getLogger("tejido").handlers:
                if isinstance(h, logging.StreamHandler):
                    h.setStream(sys.stderr)
        except Exception:
            pass


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    if len(sys.argv) == 1:                       # double-click → visual interface in the browser
        try:
            import tkinter  # noqa: F401
            _hide_console_on_windows()
            from tejido.ui.app import desktop
            desktop()
        except ImportError:                      # no tkinter: keep the console as the control
            from tejido.ui.server import main as ui
            ui()
        except Exception:                        # leave a trace even when there is no console to show it
            import logging
            logging.getLogger("tejido").exception("Tejido stopped with an unexpected error")
            raise
    else:
        from tejido.cli import main
        main()
