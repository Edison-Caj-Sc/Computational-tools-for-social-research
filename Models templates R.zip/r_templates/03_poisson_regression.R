# =====================================================================
#  03 · POISSON REGRESSION
#  For: counts (0, 1, 2…): number of organizations, children, visits, conflicts.
#  Interpretation: incidence rate ratio (IRR). IRR = 1.20 → 20 % more events.
#  Key assumption: mean = variance. With overdispersion, use 04_negative_binomial.R
# =====================================================================

# ---------------------------------------------------------------------
# 0. SETTINGS · edit this section only
# ---------------------------------------------------------------------
file           <- NULL
outcome        <- "n_organizations"       # integer >= 0
predictors     <- c("head_educ", "head_age", "head_sex", "area", "hh_size")
factors        <- list(head_sex = "male", area = "urban")
extra_terms    <- NULL
manual_formula <- NULL
exposure       <- NULL                    # exposure variable (time, population); enters as offset(log())
focus_variable <- "head_educ"
use_design     <- FALSE
design         <- list(stratum = "stratum", psu = "psu", weight = "weight")
output_dir     <- "results/03_poisson_regression"

# ---------------------------------------------------------------------
# 1. Preparation
# ---------------------------------------------------------------------
source("utils.R"); install_if_missing()
out     <- prepare_output(output_dir)
formula <- build_formula(outcome, predictors,
                         c(extra_terms, if (!is.null(exposure)) sprintf("offset(log(%s))", exposure)),
                         manual_formula)
data    <- prepare_data(load_data(file), formula_vars(formula), factors, extra = design_vars(use_design, design))
y <- all.vars(formula)[1]
if (any(data[[y]] < 0 | data[[y]] != round(data[[y]]))) stop("The outcome must be a non-negative integer count.")
if (!is.null(exposure) && any(data[[exposure]] <= 0)) stop("Exposure must be greater than 0.")
dsg <- if (use_design) create_design(data, design) else NULL

header("Count distribution")
desc <- data.frame(mean = mean(data[[y]]), variance = var(data[[y]]), pct_zeros = 100 * mean(data[[y]] == 0))
desc$variance_to_mean <- desc$variance / desc$mean
print(round_df(desc, 3)); save_table(desc, "1_descriptives", out)
g <- ggplot(data, aes(.data[[y]])) + geom_bar(fill = "steelblue") + theme_minimal() +
  labs(title = paste("Distribution of", y), x = y, y = "Frequency")
save_plot(g, "1_outcome_distribution", out)

# ---------------------------------------------------------------------
# 2. Estimation
# ---------------------------------------------------------------------
header("Model")
model <- if (use_design) svyglm(formula, design = dsg, family = quasipoisson()) else
  glm(formula, data = data, family = poisson())
print(summary(model))
coefs <- coef_table(model, exponentiate = TRUE)
names(coefs) <- sub("^exp_", "irr_", names(coefs))
print(round_df(coefs, 3)); save_table(coefs, "2_coefficients", out)

# ---------------------------------------------------------------------
# 3. Overdispersion and fit
# ---------------------------------------------------------------------
header("Overdispersion")
mu <- fitted(model); obs <- data[[y]]
dispersion <- sum((obs - mu)^2 / mu) / (nrow(data) - length(coef(model)))
aux <- lm(((obs - mu)^2 - obs) / mu ~ mu - 1)      # Cameron & Trivedi test (alpha > 0)
ct  <- summary(aux)$coefficients
od <- data.frame(pearson_dispersion = dispersion, cameron_trivedi_alpha = ct[1, 1],
                 cameron_trivedi_p = pt(ct[1, 3], df.residual(aux), lower.tail = FALSE))
od$reading <- ifelse(od$cameron_trivedi_p < .05 | dispersion > 1.5,
                     "Overdispersion: use negative binomial or robust standard errors",
                     "No relevant overdispersion")
print(round_df(od, 3)); save_table(od, "3_overdispersion", out)

if (!use_design) {
  cat("\nRobust standard errors (valid even with overdispersion):\n")
  robust <- coef_table(model, exponentiate = TRUE, vcov = sandwich::vcovHC(model, type = "HC0"))
  names(robust) <- sub("^exp_", "irr_", names(robust))
  print(round_df(robust, 3)); save_table(robust, "3_robust_coefficients", out)
  obs_zeros <- mean(obs == 0); exp_zeros <- mean(dpois(0, mu))
  cat(sprintf("Observed zeros: %.1f %% · expected under Poisson: %.1f %%\n", 100 * obs_zeros, 100 * exp_zeros))
  if (obs_zeros > exp_zeros * 1.2) cat("Excess zeros: consider a hurdle or zero-inflated model (pscl package).\n")
}

# ---------------------------------------------------------------------
# 4. Interpretation
# ---------------------------------------------------------------------
header("Average marginal effects (change in expected count)")
ame <- marginal_effects(model, data, dsg, vcov = if (use_design) TRUE else sandwich::vcovHC(model, type = "HC0"))
print(round_df(ame, 4)); save_table(ame, "4_marginal_effects", out)
save_plot(prediction_plot(model, data, focus_variable, dsg, paste("Expected count of", y)), "4_predictions", out)
save_text(summary(model), "model_summary", out)
header(paste("Done. Results in", out))
