# Plantillas R para modelos de regresión

Ocho plantillas listas para usar, con la misma estructura: **editas un bloque de configuración y ejecutas**. Cada una estima el modelo, revisa sus supuestos, calcula efectos interpretables y guarda tablas y gráficos.

## Inicio rápido

1. Abre `plantillas_R.Rproj` en RStudio (así R trabaja desde esta carpeta).
2. Ejecuta una vez `00_instalar_paquetes.R`.
3. Abre cualquier plantilla y pulsa **Source**. Sin cambiar nada, funciona con datos simulados.
4. Para tus datos, edita la sección **0. CONFIGURACIÓN**: `archivo`, `dependiente`, `predictores`, etc.

## ¿Qué modelo uso?

| Plantilla | Variable dependiente | Ejemplo | Se interpreta con |
|---|---|---|---|
| `01_regresion_lineal.R` | Continua | log del ingreso, puntaje | Coeficientes (y % si Y está en log) |
| `02_regresion_logistica.R` | Binaria 0/1 (logit o probit) | pobre, participa, votó | Odds ratios y efectos marginales en puntos porcentuales |
| `03_regresion_poisson.R` | Conteo | n.º de organizaciones, hijos | Razón de tasas (IRR) |
| `04_binomial_negativa.R` | Conteo con sobredispersión | conteos con varianza mayor que la media | IRR, comparación con Poisson |
| `05_regresion_gamma.R` | Continua positiva y asimétrica | ingreso, gasto, tiempo | Efectos multiplicativos (%) |
| `06_regresion_fraccional.R` | Proporción entre 0 y 1 | % del gasto en alimentos | Efectos marginales |
| `07_logit_ordinal.R` | Categorías ordenadas | confianza, Likert | Odds ratios, probabilidad por categoría |
| `08_logit_multinomial.R` | 3 o más categorías sin orden | tipo de empleo, partido | Riesgos relativos (RRR), probabilidad por categoría |

## Opciones de configuración (comunes)

| Opción | Para qué |
|---|---|
| `archivo` | `NULL` usa datos de ejemplo; acepta `.csv`, `.dta`, `.sav`, `.xlsx`, `.rds` |
| `dependiente`, `predictores` | Variables del modelo |
| `factores` | Variables categóricas y su categoría de referencia: `list(area = "urbano")` |
| `terminos_extra` | Interacciones o términos no lineales: `c("I(edad^2)", "educ:area")` |
| `formula_manual` | Escribir la fórmula completa (reemplaza lo anterior) |
| `variable_foco` | Variable del gráfico de predicciones |
| `usar_diseno`, `diseno` | Estimar con el diseño muestral (estrato, conglomerado, peso) |
| `carpeta_salida` | Dónde se guardan los resultados |

Algunas plantillas tienen opciones propias: `enlace` y `umbral` (logística), `exposicion` (conteos), `errores_robustos` (lineal), `orden` (ordinal), `referencia_y` (multinomial), `escala_100` (fraccional).

## Resultados

Cada plantilla crea en `carpeta_salida` los archivos numerados por sección:
- tablas en CSV (se abren bien en Excel): coeficientes, ajuste, pruebas, efectos marginales;
- gráficos en PNG: distribución, diagnósticos y predicciones;
- `resumen_modelo.txt` con la salida completa de R.

## Diseño muestral (ENAHO, ENDES y otras encuestas)

Con `usar_diseno <- TRUE`, las plantillas 01, 02, 03, 05 y 06 usan `survey::svyglm`, y la 07 usa `survey::svyolr`. Así los errores estándar consideran estratos, conglomerados y pesos.

El paquete `survey` no estima binomial negativa ni multinomial. En las plantillas 04 y 08 se usa una **aproximación**: pesos normalizados más errores robustos por conglomerado. Esta aproximación no aprovecha los estratos, y conviene declararlo así al reportar. Para la multinomial, el paquete `svyVGAM` ofrece inferencia de diseño completa.

Las bases exportadas por `inei_pipeline` (en este mismo repositorio) se pueden usar directamente: basta con poner su ruta en `archivo` y sus nombres de variables en `diseno`.

## Verificar que todo funciona

```r
source("probar_plantillas.R")   # ejecuta las 8 plantillas con y sin diseño
```

## Advertencias

- Los datos de ejemplo son **simulados**. Sirven para aprender y probar, no para sacar conclusiones.
- Las plantillas no reemplazan el criterio teórico: elegir variables y especificación sigue siendo tu trabajo.
- Los archivos están en UTF-8. Si ves símbolos raros en las tildes, en RStudio usa *File → Reopen with Encoding → UTF-8*.

## Créditos

Las plantillas se apoyan en estos paquetes de R:
- `survey` (Thomas Lumley);
- `MASS` y `nnet` (William Venables y Brian Ripley);
- `sandwich` y `lmtest` (Achim Zeileis y colaboradores);
- `car` (John Fox y Sanford Weisberg);
- `marginaleffects` (Vincent Arel-Bundock);
- `ggplot2`, `haven` y `readxl` (Hadley Wickham y colaboradores);
- `broom` (David Robinson y colaboradores).

Para citarlos en tu trabajo, usa `citation("nombre_del_paquete")`.

Los métodos implementados provienen de:
- Papke y Wooldridge (1996), regresión fraccional;
- Cameron y Trivedi (1990), prueba de sobredispersión;
- Hosmer y Lemeshow, prueba de bondad de ajuste.

## Licencia

MIT. Autor: Angel Edison Ayala Velásquez.
