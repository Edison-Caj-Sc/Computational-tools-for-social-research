# PyInstaller recipe for the standalone executable.  Build with:  pyinstaller tejido.spec
# Produces dist/tejido(.exe): double-click → window; with arguments → command line.
import os
from PyInstaller.utils.hooks import collect_submodules

# Example configurations, data, documents and the visual interface travel inside the executable.
root = os.path.join(SPECPATH, "tejido")
datas = [(os.path.join(d, f), os.path.relpath(d, SPECPATH))
         for sub in ("examples", "ui")
         for d, _, files in os.walk(os.path.join(root, sub)) if "results" not in d and "__pycache__" not in d
         for f in files if not f.endswith((".py", ".pyc"))]
hidden = (["tejido", "tejido.builders", "tejido.gui", "tejido.cli", "tejido.ui.server", "tejido.ui.app",
           "tejido.logs", "tejido.record", "tejido.safe_expr",
           "tejido.ui.schema", "tejido.layers", "tejido.temporal", "tejido.groups", "tejido.network", "tejido.prepare",
           "tejido.filters", "tejido.ui.i18n", "tejido.holes", "tejido.tie_strength", "tejido.panel", "scipy.sparse.csgraph", "scipy.cluster.hierarchy", "scipy.sparse.linalg"]
          + collect_submodules("networkx.algorithms.community")
          + ["pypdf", "docx", "openpyxl", "xlrd", "pyreadstat", "yaml"])
excludes = ["matplotlib", "IPython", "pytest", "PyQt5", "PyQt6", "PySide6", "notebook", "sphinx",
            "pyarrow", "spacy", "torch", "tensorflow", "sklearn"]

a = Analysis(["launcher.py"], pathex=["."], datas=datas, hiddenimports=hidden, excludes=excludes,
             noarchive=False)
pyz = PYZ(a.pure)
# Windows only: the Tejido icon, and author, copyright and version in the file properties (Properties → Details).
windows = os.name == "nt"
version_file = os.path.join(SPECPATH, "installer", "version_info.txt")
icon_file = os.path.join(SPECPATH, "installer", "tejido.ico")
exe = EXE(pyz, a.scripts, a.binaries, a.datas, [], name="tejido", console=True, upx=False,
          icon=icon_file if windows else None, debug=False, strip=False, version=version_file if windows else None)
