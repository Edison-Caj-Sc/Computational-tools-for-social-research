"""Affiliation (two-mode) data: members that share groups, events or contexts.

member → group examples: codes in interview segments, people in organizations, authors in papers,
directors on company boards, organizations in projects, users and the hashtags they use.
mode: members (members linked by shared groups) · groups (groups linked by shared members) · bipartite"""
from __future__ import annotations

import fnmatch

import numpy as np
import pandas as pd
from scipy import sparse

from ..graph import to_graph
from ..utils import ConfigError, as_list, log, require_columns
from . import register

WEIGHTS = {"count", "jaccard", "cosine", "newman", "association", "overlap"}


def incidence(groups: pd.Series, items: pd.Series, values: pd.Series | None = None):
    """Sparse group × member matrix: 1 when the member is in the group (or the summed 'values')."""
    g_codes, g_labels = pd.factorize(groups.astype(str))
    i_codes, i_labels = pd.factorize(items.astype(str))
    v = np.ones(len(g_codes)) if values is None else pd.to_numeric(values, errors="coerce").fillna(0).to_numpy(float)
    B = sparse.csr_matrix((v, (g_codes, i_codes)), shape=(len(g_labels), len(i_labels)))
    B.sum_duplicates()
    if values is None:
        B.data[:] = 1                                  # duplicates count once
    return B, list(g_labels), list(i_labels)


def project(B, labels, weighting="count", min_weight=1.0):
    """One-mode projection of the columns of B, with several weighting schemes."""
    if weighting not in WEIGHTS:
        raise ConfigError(f"'weighting' must be one of {sorted(WEIGHTS)}")
    B = B.tocsr().astype(float)
    if weighting == "newman":                         # each group contributes 1/(size-1)
        size = np.asarray(B.sum(axis=1)).ravel()
        d = np.where(size > 1, 1 / np.maximum(size - 1, 1), 0)
        C = (B.T @ sparse.diags(d) @ B).tocoo()
    else:
        C = (B.T @ B).tocoo()
    freq = np.asarray(B.sum(axis=0)).ravel()
    counts = (B.T @ B).tocsr()
    keep = C.row < C.col
    r, c, v = C.row[keep], C.col[keep], C.data[keep]
    n_co = np.asarray(counts[r, c]).ravel() if len(r) else np.zeros(0)   # no pair of members shares a group
    if weighting == "jaccard":
        v = n_co / (freq[r] + freq[c] - n_co)
    elif weighting == "cosine":
        v = n_co / np.sqrt(freq[r] * freq[c])
    elif weighting == "overlap":                     # share of the smaller one's groups
        v = n_co / np.minimum(freq[r], freq[c])
    elif weighting == "association":                 # observed / expected under independence
        v = n_co * B.shape[0] / (freq[r] * freq[c])
    ok = n_co >= min_weight
    edges = pd.DataFrame({"source": np.array(labels)[r[ok]], "target": np.array(labels)[c[ok]],
                          "weight": v[ok], "cooccurrences": n_co[ok]})
    return edges, pd.Series(freq, index=labels, name="frequency")


def _attributes(nodes, df, key, cols, where):
    for col in as_list(cols):
        require_columns(df, col, where)
        attr = df.groupby(df[key].astype(str))[col].first()
        mask = nodes["id"].isin(attr.index)
        nodes.loc[mask, col] = nodes.loc[mask, "id"].map(attr)


@register("affiliation", "Two-mode data: members linked by shared groups/events (codes, co-authors, boards)")
def build(data: pd.DataFrame, opts: dict, cfg: dict):
    fmt = opts.get("format", "long")
    member = opts.get("member", opts.get("item"))
    group = opts.get("group")
    if fmt == "long":
        if not group or not member:
            raise ConfigError("affiliation (long): set 'group' (e.g. segment, paper) and 'member' (e.g. code, author)")
        require_columns(data, [group, member, opts.get("value")], "affiliation")
        df = data.dropna(subset=[group, member])
        if opts.get("split"):                         # several members in one cell: "a; b; c"
            df = df.assign(**{member: df[member].astype(str).str.split(opts["split"])}).explode(member)
            df[member] = df[member].str.strip()
            df = df[df[member] != ""]
        B, g_labels, i_labels = incidence(df[group], df[member], df[opts["value"]] if opts.get("value") else None)
    elif fmt == "wide":
        pats = as_list(opts.get("members", opts.get("items")))
        cols = [c for c in data.columns if any(fnmatch.fnmatch(str(c), str(p)) for p in pats)]
        if not cols:
            raise ConfigError("affiliation (wide): 'members' must list columns or patterns like 'code_*'")
        M = data[cols].apply(pd.to_numeric, errors="coerce").fillna(0).to_numpy(float)
        B = sparse.csr_matrix(M if opts.get("value") or opts.get("weighted") else (M > 0).astype(float))
        i_labels = [str(c) for c in cols]
        g_labels = data[group].astype(str).tolist() if group else [str(i) for i in range(len(data))]
        df = data
    else:
        raise ConfigError("affiliation: 'format' must be 'long' or 'wide'")

    mode = {"items": "members", "item": "members", "member": "members"}.get(opts.get("mode", "members"),
                                                                            opts.get("mode", "members"))
    weighting = opts.get("weighting", "count")
    min_w = float(opts.get("min_cooccurrence", opts.get("min_shared", 1)))
    if mode == "members":
        edges, freq = project(B, i_labels, weighting, min_w)
        node_type = "member"
    elif mode == "groups":
        edges, freq = project(B.T.tocsr(), g_labels, weighting, min_w)
        node_type = "group"
    elif mode == "bipartite":
        coo = B.tocoo()
        edges = pd.DataFrame({"source": np.array(g_labels)[coo.row], "target": np.array(i_labels)[coo.col],
                              "weight": coo.data})
        freq = pd.concat([pd.Series(np.asarray((B > 0).sum(axis=1)).ravel(), index=g_labels),
                          pd.Series(np.asarray((B > 0).sum(axis=0)).ravel(), index=i_labels)])
        node_type = None
    else:
        raise ConfigError("affiliation: 'mode' must be 'members', 'groups' or 'bipartite'")
    log.info(f"affiliation: {B.shape[0]:,} groups × {B.shape[1]:,} members → {len(edges):,} ties")

    nodes = freq.rename("frequency").rename_axis("id").reset_index()
    if mode == "bipartite":
        nodes["type"] = ["group"] * len(g_labels) + ["member"] * len(i_labels)
        nodes["bipartite"] = [0] * len(g_labels) + [1] * len(i_labels)
    else:
        nodes["type"] = node_type
    if fmt == "long":
        if mode != "groups":
            _attributes(nodes, df, member, opts.get("member_attributes", opts.get("item_attributes")),
                        "affiliation.member_attributes")
        if mode != "members":
            _attributes(nodes, df, group, opts.get("group_attributes"), "affiliation.group_attributes")
    nodes["keep_isolated"] = True
    return to_graph(edges, directed=False, nodes=nodes)
