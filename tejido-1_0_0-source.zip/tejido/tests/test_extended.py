"""Tests for the general builders, the prepare/filter stages, the extended analysis, layers and time."""
import networkx as nx
import numpy as np
import pandas as pd
import pytest

from tejido import build, filter, prepare, run
from tejido.analyze import brokerage, node_measures
from tejido.groups import core_periphery
from tejido.network import freeman
from tejido.utils import ConfigError

from pathlib import Path

DATA = Path(__file__).parent / "data"
EXAMPLES = Path(__file__).parents[1] / "tejido" / "examples"


def karate():
    G = nx.karate_club_graph()
    H = nx.relabel_nodes(G, {n: f"n{n}" for n in G})
    for n, d in H.nodes(data=True):
        d["label"] = n
    return H


# ---------------------------------------------------------------- builders
def test_ties_adjacency_list_and_relations():
    df = pd.DataFrame({"who": ["A", "B"], "knows": ["B; C", "C"]})
    G = build(df, "ties", format="adjacency_list", source="who", targets="knows", directed=False)
    assert set(map(frozenset, G.edges)) == {frozenset("AB"), frozenset("AC"), frozenset("BC")}
    e = pd.DataFrame({"a": ["x", "x", "y"], "b": ["y", "y", "z"], "rel": ["kin", "work", "kin"]})
    G = build(e, "ties", source="a", target="b", relation="rel")
    assert G["x"]["y"]["relation"] == "kin|work" and G["x"]["y"]["n_kin"] == 1 and G["x"]["y"]["n_work"] == 1


def test_affiliation_overlap_groups_and_attributes():
    df = pd.DataFrame({"board": ["b1", "b1", "b2", "b2", "b2"], "director": ["ana", "luis", "ana", "luis", "rosa"],
                       "sector": ["mining", "mining", "bank", "bank", "bank"]})
    G = build(df, "affiliation", group="board", member="director", weighting="overlap")
    assert G["ana"]["luis"]["weight"] == 1 and G["ana"]["rosa"]["weight"] == 1
    B = build(df, "affiliation", group="board", member="director", mode="groups", group_attributes=["sector"])
    assert B["b1"]["b2"]["weight"] == 2 and B.nodes["b2"]["sector"] == "bank"


def test_similarity_variables_gower_geographic_mst():
    rng = np.random.default_rng(1)
    f1, f2 = rng.normal(size=300), rng.normal(size=300)
    df = pd.DataFrame({f"a{i}": f1 + rng.normal(scale=.5, size=300) for i in range(4)} |
                      {f"b{i}": f2 + rng.normal(scale=.5, size=300) for i in range(4)})
    G = build(df, "similarity", nodes="columns", metric="partial_correlation", transform={"scale": "none"},
              sparsify={"method": "threshold", "threshold": .1})
    comms = nx.community.louvain_communities(G, seed=1)
    assert sorted(sorted(c) for c in comms) == [[f"a{i}" for i in range(4)], [f"b{i}" for i in range(4)]]
    mixed = pd.DataFrame({"id": list("abcd"), "x": [1, 1.1, 5, 5.2], "kind": ["u", "u", "r", "r"]})
    G = build(mixed, "similarity", entity="id", metric="gower", sparsify={"method": "knn", "k": 1})
    assert G.has_edge("a", "b") and G.has_edge("c", "d") and not G.has_edge("a", "c")
    T = build(mixed, "similarity", entity="id", features=["x"], metric="euclidean", sparsify={"method": "mst"},
              transform={"scale": "none"})
    assert T.number_of_edges() == 3 and nx.is_tree(T)
    geo = pd.DataFrame({"p": ["Lima", "Callao", "Cusco"], "lat": [-12.05, -12.06, -13.53], "lon": [-77.04, -77.15, -71.97]})
    G = build(geo, "similarity", entity="p", metric="geographic", coordinates=["lat", "lon"], sparsify={"method": "radius", "km": 50})
    assert set(G.edges) == {("Lima", "Callao")} and G["Lima"]["Callao"]["distance_km"] < 15


def test_text_terms_documents_and_bipartite():
    docs = pd.DataFrame({"doc_id": ["d1", "d2", "d3"],
                         "text": ["El agua y la minería generan conflicto.", "La minería afecta el agua del río.",
                                  "La educación rural necesita docentes."]})
    G = build(docs, "text", language="es", entities={"patterns": False, "acronyms": False, "terms": True})
    assert G["agua"]["minería"]["weight"] == 2 and G.nodes["agua"]["type"] == "term"
    D = build(docs, "text", mode="documents", entities={"patterns": False, "terms": True})
    assert D.has_edge("d1", "d2") and "agua" in D["d1"]["d2"]["shared"] and "d3" in D
    B = build(docs, "text", mode="bipartite", entities={"patterns": False, "terms": True})
    assert B.has_edge("d3", "educación")


def test_interactions_emails_and_split():
    mail = pd.DataFrame({"from": ["ana@x.pe", "luis@x.pe"], "to": ["luis@x.pe; rosa@x.pe", "ana@x.pe"],
                         "body": ["copia a jefe@x.pe", ""]})
    G = build(mail, "interactions", source="from", targets={"to": "to"}, split=";", text="body", extract=["emails"])
    assert G.has_edge("ana@x.pe", "rosa@x.pe") and G["ana@x.pe"]["jefe@x.pe"]["relation"] == "email"
    assert G["luis@x.pe"]["ana@x.pe"]["n_to"] == 1


def test_ego_measures_wide_and_long(tmp_path):
    wide = pd.DataFrame({"r": ["e1"], "sex": ["w"], "a1": ["Ana"], "a2": ["Luis"], "a3": ["Rosa"],
                         "s1": ["w"], "s2": ["m"], "s3": ["w"], "tie_1_2": [1], "tie_1_3": [0], "tie_2_3": [0],
                         "k_doc": [1], "k_farm": [1]})
    G = build(wide, "ego", ego="r", alters=["a1", "a2", "a3"], alter_attributes={"sex": "s{i}"}, alter_ties="tie_{i}_{j}",
              ego_attributes={"sex": "sex"}, positions={"prestige": {"k_doc": 80, "k_farm": 20}})
    e = G.graph["tables"]["egos"].iloc[0]
    assert e["size"] == 3 and e["density"] == pytest.approx(1 / 3, abs=1e-3) and e["effective_size"] == pytest.approx(3 - 2 / 3, abs=1e-3)
    assert e["same_sex"] == pytest.approx(2 / 3, abs=1e-3) and e["positions_range"] == 60 and e["positions_extensity"] == 2
    assert G.nodes["e1"]["type"] == "ego" and G.has_edge("e1::Ana", "e1::Luis")
    ties = tmp_path / "t.csv"
    pd.DataFrame({"ego": ["e1"], "alter_a": ["Ana"], "alter_b": ["Luis"]}).to_csv(ties, index=False)
    long = pd.DataFrame({"ego": ["e1", "e1", "e2"], "alter": ["Ana", "Luis", "Ana"]})
    L = build(long, "ego", format="long", ego="ego", alter="alter", shared_alters=True,
              alter_ties={"path": str(ties)})
    assert L.degree("Ana") == 3 and L.graph["summary"]["egos"] == 2


def test_transitions_long_and_wide():
    long = pd.DataFrame({"u": [1, 1, 1, 2, 2], "t": [1, 2, 3, 1, 2], "s": ["a", "b", "b", "a", "c"]})
    G = build(long, "transitions", unit="u", order="t", state="s", weight="probability")
    assert G["a"]["b"]["count"] == 1 and G["a"]["b"]["probability"] == .5 and G.nodes["b"]["stays"] == 1
    W = build(pd.DataFrame({"y1": ["a", "a"], "y2": ["b", "c"]}), "transitions", format="wide", states=["y1", "y2"])
    assert set(W.edges) == {("a", "b"), ("a", "c")} and G.graph["summary"]["mobility_rate"] == pytest.approx(2 / 3, abs=1e-3)


# ---------------------------------------------------------------- prepare and filter
def test_prepare_steps(tmp_path):
    other = tmp_path / "o.csv"
    pd.DataFrame({"k": [1, 2], "region": ["N", "S"]}).to_csv(other, index=False)
    df = pd.DataFrame({"k": [1, 2, 2], "x": [10, 20, None], "who": ["a;b", "c", "d"], "sex": [1, 2, 1],
                       "q_1": [1, 2, 3], "q_2": [3, 2, 1]})
    out = prepare(df, [{"fillna": {"x": 0}}, {"compute": {"y": "x * 2"}}, {"recode": {"sex": {1: "m", 2: "w"}}},
                       {"merge": {"path": str(other), "on": "k"}}, {"split": {"who": ";"}}, {"filter": "y >= 0"},
                       {"bin": {"column": "x", "bins": [-1, 15, 30], "labels": ["low", "high"], "into": "lvl"}}])
    assert list(out["who"]) == ["a", "b", "c", "d"] and set(out["sex"]) == {"m", "w"} and out["region"].iloc[0] == "N"
    assert list(out["lvl"]) == ["low", "low", "high", "low"]
    long = prepare(df, [{"to_long": {"id": ["k"], "columns": ["q_*"], "name": "item"}}])
    assert len(long) == 6 and set(long["item"]) == {"q_1", "q_2"}
    with pytest.raises(ConfigError):
        prepare(df, [{"nope": 1}])


def test_filters():
    G = karate()
    nx.set_node_attributes(G, {n: ("A" if i < 17 else "B") for i, n in enumerate(G)}, "club2")
    assert set(filter(G, ego={"nodes": ["n0"], "radius": 1}).nodes) == {"n0", *G["n0"]}
    assert all(d >= 4 for _, d in filter(G, k_core=4).degree())
    assert {d["club2"] for _, d in filter(G, keep_nodes={"club2": ["A"]}).nodes(data=True)} == {"A"}
    assert "n0" not in filter(G, drop_nodes=["n0"])
    W = nx.Graph()
    W.add_weighted_edges_from([("a", "b", 10), ("a", "c", 1), ("a", "d", 1), ("b", "c", 1), ("c", "d", 1), ("b", "d", 1)])
    assert filter(W, backbone={"alpha": .2}).has_edge("a", "b")
    assert set(filter(W, max_weight=1).edges) == set(W.edges) - {("a", "b")}


# ---------------------------------------------------------------- analysis
def test_all_node_measures_and_values():
    G = karate()
    node_measures(G, "all", 1, {})
    d = G.nodes["n0"]
    for k in ["degree", "betweenness", "closeness", "harmonic", "eigenvector", "katz", "pagerank", "hub", "laplacian",
              "subgraph", "coreness", "clustering", "constraint", "effective_size", "brokerage", "cut_point", "eccentricity"]:
        assert k in d, k
    assert G.nodes["n0"]["voterank"] in (1, 2) and G.nodes["n0"]["cut_point"] == 1
    S = nx.star_graph(5)
    assert freeman(dict(S.degree()).values(), 6, "degree") == pytest.approx(1)
    core_periphery(S)
    assert S.nodes[0]["core_periphery"] == "core"


def test_brokerage_roles():
    D = nx.DiGraph([("a", "b"), ("b", "c")])
    nx.set_node_attributes(D, {"a": "x", "b": "y", "c": "y"}, "g")
    assert brokerage(D, "g")["brokerage_gatekeeper"]["b"] == 1
    nx.set_node_attributes(D, {"a": "x", "b": "y", "c": "z"}, "g")
    assert brokerage(D, "g")["brokerage_liaison"]["b"] == 1


def test_run_full_analysis_layers_time_and_formats(tmp_path):
    rng = np.random.default_rng(3)
    rows = [{"a": f"p{rng.integers(12)}", "b": f"p{rng.integers(12)}", "kind": rng.choice(["kin", "work"]),
             "year": int(rng.integers(2018, 2022)), "grp": "x"} for _ in range(150)]
    data = pd.DataFrame(rows)
    nodes = tmp_path / "nodes.csv"
    pd.DataFrame({"id": [f"p{i}" for i in range(12)], "zone": ["n" if i < 6 else "s" for i in range(12)]}).to_csv(nodes, index=False)
    cfg = {"project": "full", "_base_dir": str(tmp_path), "input": {"type": "none"},
           "builder": {"type": "ties", "source": "a", "target": "b", "relation": "kind", "directed": True},
           "nodes": {"path": "nodes.csv"},
           "analysis": {"centrality": "all", "groups": "all", "attributes": ["zone"], "brokerage": "zone",
                        "null_model": {"n": 10}, "communities": "louvain"},
           "layers": {"by": "relation", "qap": 50}, "time": {"column": "year"},
           "output": {"dir": "out", "language": "es",
                      "formats": ["csv", "xlsx", "graphml", "gexf", "json", "pajek", "ucinet", "matrix", "html", "report"]}}
    r = run(cfg, data=data)
    for k in ["homophily", "null_model", "layers", "layer_overlap", "evolution", "node_evolution", "block_image",
              "communities", "triad_census", "degree_distribution"]:
        assert k in r.tables, k
    assert len(r.tables["evolution"]) == 4 and "tie_persistence" in r.tables["evolution"]
    for k in ["dyads_mutual", "hierarchy", "assortativity_zone", "ei_index_zone", "core_size", "blocks", "transitivity_z"]:
        assert k in r.summary, k
    out = tmp_path / "out"
    assert nx.read_pajek(out / "full.net").number_of_nodes() == r.graph.number_of_nodes()
    assert nx.read_graphml(out / "full.graphml").number_of_nodes() == r.graph.number_of_nodes()
    assert (out / "full.dl").read_text().startswith("dl n=") and (out / "full_matrix.csv").exists()
    assert pd.read_excel(out / "full.xlsx", sheet_name=None).keys() >= {"summary", "nodes", "ties", "homophily"}
    assert "## Resumen" in (out / "full_report.md").read_text(encoding="utf-8")


def test_betweenness_and_closeness_family():
    from tejido.analyze import ego_betweenness, group_centrality
    G = karate()
    nx.set_edge_attributes(G, 1, "weight")
    node_measures(G, ["betweenness", "ego_betweenness", "flow_betweenness", "closeness", "information"], 1, {})
    ref = nx.current_flow_betweenness_centrality(nx.relabel_nodes(nx.karate_club_graph(), {n: f"n{n}" for n in range(34)}))
    assert G.nodes["n0"]["flow_betweenness"] == pytest.approx(ref["n0"], abs=1e-5)
    assert ego_betweenness(nx.star_graph(4))[0] == 6 and ego_betweenness(nx.cycle_graph(4))[0] == 1
    raw = karate()                                    # the karate club has tie weights: count steps instead
    node_measures(raw, ["betweenness"], 1, {"normalized": False, "distance": "steps"})
    assert raw.nodes["n0"]["betweenness"] == pytest.approx(231.0714, abs=1e-3)
    D = nx.DiGraph([("a", "b"), ("b", "c")])
    node_measures(D, ["closeness"], 1, {})
    assert D.nodes["a"]["out_closeness"] > 0 and D.nodes["a"]["closeness"] == 0
    W = nx.Graph([("a", "b", {"weight": 1, "km": 10}), ("b", "c", {"weight": 1, "km": 1}), ("a", "c", {"weight": 1, "km": 50})])
    node_measures(W, ["betweenness"], 1, {"distance": "km"})
    assert W.nodes["b"]["betweenness"] == 1
    K = karate()
    nx.set_node_attributes(K, {n: ("A" if int(n[1:]) < 17 else "B") for n in K}, "half")
    t = group_centrality(K, "half", [], None)
    assert set(t.columns) >= {"group", "group_degree", "group_betweenness", "group_closeness"} and len(t) == 2


def test_structural_holes():
    from tejido.holes import burt, structural_holes
    K = nx.karate_club_graph()
    B = burt(K)
    con = nx.constraint(K, weight="weight")
    assert max(abs(B[n]["constraint"] - con[n]) for n in K) < 1e-9
    S = nx.star_graph(4)
    assert burt(S)[0]["hierarchy"] == 0 and burt(S)[0]["effective_size"] == 4
    G = nx.Graph([("a", "b"), ("b", "c"), ("a", "c"), ("c", "d"), ("d", "e"), ("e", "f"), ("d", "f"),
                  ("g", "h"), ("h", "i"), ("g", "i"), ("c", "g")])
    nx.set_edge_attributes(G, 1, "weight")
    nx.set_node_attributes(G, {v: t for t, vs in {"x": "abc", "y": "def", "z": "ghi"}.items() for v in vs}, "team")
    s, t = structural_holes(G, {"groups": "team"}, [])
    assert G.nodes["c"]["hole_role"] == "broker" and G.nodes["c"]["holes"] == 5 and G.nodes["c"]["groups_spanned"] == 2
    assert G.nodes["e"]["hole_role"] == "embedded" and G.nodes["e"]["holes"] == 0
    holes = t["structural_holes"].set_index(["group_a", "group_b"])
    assert holes.loc[("y", "z"), "hole"] and holes.loc[("y", "z"), "ties_between"] == 0
    assert holes.loc[("y", "z"), "main_spanners"] == "c" and s["group_holes"] >= 1


def test_strong_and_weak_ties():
    from tejido.tie_strength import tie_strength
    G = nx.Graph([("a", "b"), ("b", "c"), ("a", "c"), ("c", "d"), ("d", "e"), ("e", "f"), ("d", "f")])
    nx.set_edge_attributes(G, 1, "weight")
    for u, v in [("a", "b"), ("b", "c"), ("a", "c"), ("d", "e"), ("e", "f"), ("d", "f")]:
        G[u][v]["weight"] = 5
    s, t = tie_strength(G, {"by": "auto"})
    assert G["c"]["d"]["local_bridge"] == 1 and G["c"]["d"]["span"] == float("inf") and G["c"]["d"]["tie_strength"] == "weak"
    assert G["a"]["b"]["overlap"] == 1 and G["a"]["b"]["tie_strength"] == "strong"
    assert s["weak_share_of_local_bridges"] == 1 and s["weight_overlap_correlation"] > 0
    F = nx.Graph([("A", "B", {"weight": 3}), ("A", "C", {"weight": 3}), ("B", "D", {"weight": 1}), ("C", "D", {"weight": 1})])
    s, _ = tie_strength(F, {"by": "weight", "threshold": 3})
    assert F.nodes["A"]["stc_violations"] == 1 and F.nodes["A"]["strong_ties"] == 2 and s["strong_ties"] == 2
    D = nx.DiGraph([("a", "b", {"weight": 1}), ("b", "a", {"weight": 1}), ("a", "c", {"weight": 1})])
    s, _ = tie_strength(D, {"by": "reciprocity"})
    assert D["a"]["b"]["tie_strength"] == "strong" and D["a"]["c"]["tie_strength"] == "weak"
    with pytest.raises(ConfigError):
        tie_strength(nx.Graph([("a", "b", {"weight": 1}), ("b", "c", {"weight": 2})]), {"by": "nope"})


def test_researcher_defined_weak_ties():
    import networkx as nx
    from tejido.tie_strength import tie_strength
    G = nx.Graph()
    for u, v, c in [("a", "b", "conocido"), ("b", "c", "vecino"), ("c", "d", "familia"), ("d", "a", "amigo"), ("d", "e", None)]:
        G.add_edge(u, v, weight=1, rel=c)
    s, _ = tie_strength(G, {"by": "rel", "weak_values": ["Conocido", "vecino"], "strong_values": ["familia"]})
    assert G["a"]["b"]["tie_strength"] == "weak" and G["c"]["d"]["tie_strength"] == "strong"
    assert G["a"]["d"]["tie_strength"] == "intermediate" and G["d"]["e"]["tie_strength"] == "unclassified"
    assert s["weak_ties"] == 2 and s["unclassified_ties"] == 1
    H = nx.Graph()
    for i, w in enumerate([1, 2, 3, 4, 5]):
        H.add_edge(i, i + 1, weight=w)
    s, _ = tie_strength(H, {"by": "weight", "weak_max": 2, "threshold": 4})
    assert (s["weak_ties"], s["intermediate_ties"], s["strong_ties"]) == (2, 1, 2)
    s, _ = tie_strength(H, {"by": "weight", "weak_values": ["1", 2, 3]})
    assert (s["weak_ties"], s["strong_ties"]) == (3, 2)


def test_world_bank_is_a_table_source():
    from tejido.ui.schema import INPUT_TYPES
    top = [x["id"] for x in INPUT_TYPES if not x.get("parent")]
    assert top == ["table", "documents"]
    assert {x["id"] for x in INPUT_TYPES if x.get("parent") == "table"} == {"indicators", "worldbank_api"}


def test_csv_separators_and_decimal_comma(tmp_path):
    from tejido.io import read_table
    f = tmp_path / "semi.csv"
    f.write_bytes("nombre;edad;ingreso\nJosé;30;1500,5\nMaría;25;2300,75\n".encode("latin-1"))
    d = read_table(f)
    assert list(d.columns) == ["nombre", "edad", "ingreso"] and d["ingreso"].iloc[0] == 1500.5 and d["nombre"].iloc[0] == "José"
    g = tmp_path / "one.csv"
    g.write_text("nombre\nAna\nLuis\n", encoding="utf-8")
    assert list(read_table(g).columns) == ["nombre"]


def test_tie_strength_only_self_loops_and_wb_without_indicators():
    import networkx as nx
    import pytest
    from tejido.io import read_worldbank_api
    from tejido.tie_strength import tie_strength
    from tejido.utils import ConfigError
    G = nx.Graph()
    G.add_edge(1, 1, weight=2)
    assert tie_strength(G, {"by": "weight"}) == ({}, {})
    with pytest.raises(ConfigError):
        read_worldbank_api([])


INDICATOR_FILES = {      # file → layout, units (not aggregates), aggregates, indicators, years, a value
    "databank.csv": ("years_wide", 2, 1, 2, [2018, 2020], ("PER", "NY.GDP.PCAP.KD", 2019, 6600.2)),
    "cepal.csv": ("long", 2, 1, 2, [2019, 2020], ("Perú", "Tasa de desempleo abierto urbano — Sexo: Mujeres", 2020, 14.5)),
    "owid.csv": ("indicators_wide", 2, 2, 2, [2018, 2019], ("CHL", "Life expectancy", 2019, 80.3)),
    "inei.xlsx": ("years_wide", 3, 1, 1, [2018, 2020], ("Áncash", "Producto Bruto Interno por departamentos (Millones de soles)", 2019, 20001.5)),
    "weo.csv": ("years_wide", 2, 0, 2, [2019, 2021], ("CHL", "NGDPD", 2021, 317.059)),
    "units_wide.csv": ("units_wide", 3, 0, 1, [2018, 2020], ("Chile", "units_wide", 2020, -6.1)),
    "tesis.csv": ("indicators_wide", 3, 0, 3, [2015, 2016], ("Chile", "CT", 2016, 2.2)),
    "estat.csv": ("long", 2, 1, 1, [2019, 2020], ("DE", "estat", 2020, 3.8)),
    "eng.csv": ("years_wide", 2, 0, 1, [2019, 2020], ("Chile", "Population", 2020, 19116209.0)),
}


@pytest.mark.parametrize("name", sorted(INDICATOR_FILES))
def test_indicator_data_in_many_layouts(name):
    from tejido.panel import inspect_indicators
    layout, units, aggs, n_ind, years, (unit, ind, year, value) = INDICATOR_FILES[name]
    out, info = inspect_indicators(DATA / name)
    assert (info["layout"], info["units"], info["aggregates"], info["indicators"], info["years"]) == (layout, units, aggs, n_ind, years)
    row = out[(out["country_code"] == unit) & (out["indicator_code"] == ind) & (out["year"] == year)]
    assert len(row) == 1 and abs(row["value"].iloc[0] - value) < 1e-9


def test_indicator_detection_and_options():
    from tejido.panel import detect_indicators, inspect_indicators, is_aggregate
    assert detect_indicators(DATA / "posts.csv") is None
    assert detect_indicators(DATA / "databank.csv") and detect_indicators(DATA / "tesis.csv")
    out, info = inspect_indicators(DATA / "units_wide.csv", {"indicator_name": "Crecimiento del PIB"})
    assert set(out["indicator"]) == {"Crecimiento del PIB"}
    out, info = inspect_indicators(DATA / "eng.csv", {"layout": "years_wide", "unit": "country", "header_row": 1})
    assert info["columns"]["unit"] == "Country"
    assert is_aggregate("", "América Latina y el Caribe") and is_aggregate("EU27_2020", "") and not is_aggregate("ZAF", "South Africa")


def test_indicator_example_runs(tmp_path):
    import shutil
    shutil.copytree(EXAMPLES, tmp_path / "ex")
    r = run(tmp_path / "ex" / "indicators_messy.yaml")
    assert r.graph.number_of_nodes() == 18                     # the regional aggregate is excluded


def test_world_bank_excel_and_zip_downloads():
    """The .xls (Excel 97-2003) and the zipped CSV that the World Bank offers, with one indicator each."""
    from tejido.panel import inspect_indicators, is_aggregate
    out, info = inspect_indicators(DATA / "worldbank_es.xls")
    assert (info["sheet"], info["header_row"], info["units"], info["years"]) == ("Data", 4, 3, [2019, 2021])
    assert set(out.loc[out["is_aggregate"], "country_code"]) == {"AFE", "WLD"}          # Países Bajos is a country
    assert not is_aggregate("NLD", "Países Bajos") and is_aggregate("", "Estados pequeos de las Islas del Pacfico")
    out, info = inspect_indicators(DATA / "API_SP.POP.TOTL_DS2_en_csv_v2.zip")
    assert (info["units"], info["indicators"], info["aggregates"]) == (2, 1, 1)
    from tejido.io import worldbank_wide
    X = worldbank_wide(inspect_indicators(DATA / "worldbank_es.xls")[0], {})    # one indicator: compared over the years
    assert sorted(X["country_code"]) == ["CHL", "NLD", "PER"] and {"2019", "2020", "2021"} <= set(X.columns)
