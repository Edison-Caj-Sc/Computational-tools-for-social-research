"""Run record: a small JSON file saved with the results that says how they were produced.

<project>_run.json holds the version of Tejido and of its libraries, the date, the configuration used, the
input files with their size and SHA-256 fingerprint, the size of the network and the files written. With it a
result can be traced back to its data and settings, and repeated."""
from __future__ import annotations

import hashlib
import json
import platform
import time
from pathlib import Path

HASH_LIMIT = 512 * 1024 * 1024          # larger files are recorded by size and date only
MAX_FILES = 200


def _sha256(path: Path) -> str | None:
    try:
        if path.stat().st_size > HASH_LIMIT:
            return None
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def _input_files(cfg: dict) -> list[dict]:
    from .config import PATH_KEYS, resolve
    found: list[Path] = []

    def walk(obj):
        if isinstance(obj, dict):
            for k, v in obj.items():
                if k in PATH_KEYS | {"metadata"} and isinstance(v, str) and v and not v.startswith(("http://", "https://")):
                    found.append(Path(resolve(cfg, v)).resolve())
                else:
                    walk(v)
        elif isinstance(obj, list):
            for x in obj:
                walk(x)
    walk({k: cfg.get(k) for k in ("input", "prepare", "builder", "nodes")})
    files: list[Path] = []
    for p in found:
        try:
            if p.is_dir():
                files += [f for f in sorted(p.rglob("*")) if f.is_file()]
            elif p.is_file():
                files.append(p)
        except OSError:
            continue
    out = []
    for f in dict.fromkeys(files):
        if len(out) >= MAX_FILES:
            break
        try:
            st = f.stat()
        except OSError:
            continue
        out.append({"file": f.name, "path": str(f), "bytes": st.st_size,
                    "modified": time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(st.st_mtime)), "sha256": _sha256(f)})
    return out


LIBRARIES = {"pandas": "pandas", "numpy": "numpy", "scipy": "scipy", "networkx": "networkx", "pyyaml": "yaml"}


def _versions() -> dict:
    """Versions of the libraries that compute the results. The modules' own __version__ first: the standalone
    executable does not carry the packages' metadata, so importlib.metadata finds nothing there."""
    import importlib
    from importlib import metadata
    out = {"python": platform.python_version()}
    for name, module in LIBRARIES.items():
        try:
            out[name] = str(importlib.import_module(module).__version__)
        except Exception:
            try:
                out[name] = metadata.version(name)
            except Exception:
                out[name] = None
    return out


def _jsonable(v):
    if isinstance(v, dict):
        return {str(k): _jsonable(x) for k, x in v.items() if not str(k).startswith("_")}
    if isinstance(v, (list, tuple, set)):
        return [_jsonable(x) for x in v]
    if hasattr(v, "item"):
        try:
            v = v.item()
        except Exception:
            return str(v)
    if isinstance(v, float) and v != v:
        return None
    return v if isinstance(v, (str, int, float, bool)) or v is None else str(v)


def build(cfg: dict, summary: dict, files: list[str], started: float | None = None) -> dict:
    from . import __author__, __url__, __version__
    now = time.time()
    return {"program": "Tejido", "version": __version__, "author": __author__, "url": __url__,
            "created": time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(now)),
            "seconds": round(now - started, 2) if started else None,
            "system": f"{platform.system()} {platform.release()} ({platform.machine()})",
            "libraries": _versions(), "project": cfg.get("project"),
            "configuration": _jsonable({k: v for k, v in cfg.items() if not str(k).startswith("_")}),
            "inputs": _input_files(cfg), "network": _jsonable(summary), "files": sorted(files)}


def write(folder: Path, name: str, cfg: dict, summary: dict, started: float | None = None) -> Path:
    path = Path(folder) / f"{name}_run.json"
    files = [f.name for f in Path(folder).glob(f"{name}*") if f.is_file() and f.name != path.name]
    path.write_text(json.dumps(build(cfg, summary, files, started), ensure_ascii=False, indent=1), encoding="utf-8")
    return path
