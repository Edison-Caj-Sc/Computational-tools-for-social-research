"""Local web server behind the visual interface.

It listens only on 127.0.0.1 and nothing is sent to the internet (except the downloads you ask for).
How it is protected (see SECURITY.md):
  · the page opens only through the launch address the program itself gives the browser; the browser then
    keeps a session cookie (HttpOnly, SameSite=Strict), so other users or programs on the computer that
    find the port get nothing;
  · every /api call carries a random token in a header; requests from other sites (Origin, Sec-Fetch-Site)
    or for another host name (DNS rebinding) are refused;
  · the page runs under a Content-Security-Policy without inline or remote scripts; result pages open in a
    sandbox, apart from the interface;
  · uploads are limited in size and kind and stay, with the results, inside the workspace folder;
  · what is refused is written to the activity log (logs/tejido.log in the workspace)."""
from __future__ import annotations

import copy
import json
import logging
import math
import os
import platform
import re
import secrets
import shutil
import threading
import time
import urllib.parse
import webbrowser
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import resources
from pathlib import Path

import yaml

from .. import __author__, __copyright__, __license__, __url__, __version__, logs
from ..analyze import CENTRALITIES, DISTANCES, FAMILIES, NODE_MEASURES
from ..io import DOC_EXT, TABLE_EXT, _limit_mb
from ..utils import ConfigError, file_stem, log
from .schema import BUILDER_FORMS, INPUT_TYPES, PREPARE_FORMS

MAX_JSON = 32 * 1024 * 1024                         # a request with settings; uploads have their own limit
UPLOAD_EXT = TABLE_EXT | DOC_EXT | {".zip", ".xlsm", ".yaml", ".yml"}
JOB_LOG_LINES = 5000

UI_DIR = resources.files("tejido").joinpath("ui")
from ..export import FORMATS as _FORMATS
FORMATS = list(_FORMATS)
NUMERIC_SKIP = {"keep_isolated", "bipartite"}


def _plain(v):
    if hasattr(v, "item"):
        v = v.item()
    if isinstance(v, float) and not math.isfinite(v):
        return None
    if isinstance(v, (str, int, float, bool)) or v is None:
        return v
    return str(v)


class State:
    def __init__(self, workspace: Path):
        self.workspace = workspace.expanduser().resolve()
        try:
            self.workspace.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise ConfigError(f"The workspace folder {self.workspace} cannot be created: {e.strerror or e}") from e
        self.token = secrets.token_urlsafe(32)           # header of every /api call (the page receives it)
        self.launch = secrets.token_urlsafe(32)          # opens the page once, from the address the program gives
        self.session = secrets.token_urlsafe(32)         # cookie the browser keeps after that
        self.cookie = "tejido_session"                   # serve() adds the port: cookies are shared across ports
        self.port = 0
        self.job: dict | None = None
        self.lock = threading.Lock()
        self.log_path: Path | None = None
        self.started = time.time()

    def max_upload(self) -> int:
        return _limit_mb("TEJIDO_MAX_UPLOAD_MB", 1024) * 1024 * 1024

    def inside(self, path) -> Path:
        p = Path(path).resolve()
        if p != self.workspace and self.workspace not in p.parents:
            raise ConfigError("That path is outside the Tejido workspace.")
        return p


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------

def _indicators_preview(out, info) -> dict:
    ind = out.groupby("indicator_code")["indicator"].first()
    return {"kind": "indicators", "units": info["units"], "aggregates": info["aggregates"], "years": info["years"],
            "n_indicators": int(len(ind)), "indicators": [{"code": k, "name": v} for k, v in list(ind.items())[:200]],
            "layout": info["layout"], "header_row": info["header_row"], "sheet": info["sheet"], "roles": info["columns"],
            "columns": info["raw_columns"], "not_numeric": info["not_numeric"], "repeated": info["repeated"],
            "dimensions": info["dimensions"], "files": info["files"]}


def _table_preview(df) -> dict:
    head = df.head(8).astype(object).where(df.head(8).notna(), None)
    return {"kind": "table", "rows": len(df), "columns": [str(c) for c in df.columns],
            "numeric": [str(c) for c in df.select_dtypes("number").columns],
            "head": [{str(k): _plain(v) for k, v in r.items()} for r in head.to_dict("records")]}


def preview(kind: str, path: str, extra: dict | None = None, steps=None, detect: bool = True) -> dict:
    """What the data look like: table head, documents, World Bank contents, or the table after 'prepare'."""
    if kind != "worldbank_api" and not str(path or "").strip():
        raise ConfigError("Choose a file first.")
    if steps or kind == "worldbank_api":
        from ..config import load_config
        from ..io import read
        from ..prepare import prepare
        cfg = load_config({"input": {**(extra or {}), "type": kind, **({"path": path} if path else {})},
                           "builder": {"type": "ties"}})
        df = prepare(read(cfg), steps or [], cfg)
        return {**_table_preview(df), "prepared": bool(steps)}
    from ..io import read_documents, read_table
    from ..panel import detect_indicators, inspect_indicators
    p = Path(path)
    if kind == "table" and detect and p.is_file() and detect_indicators(p, (extra or {}).get("sheet")):
        kind = "indicators"                       # recognized: units × years (World Bank or similar)
    if kind == "table":
        return _table_preview(read_table(p, (extra or {}).get("sheet")))
    if kind == "documents":
        docs = read_documents(p)
        return {"kind": "documents", "documents": len(docs), "names": docs["doc_id"].tolist()[:50],
                "characters": int(docs["text"].str.len().sum()),
                "sample": (docs["text"].iloc[0][:400] if len(docs) else "")}
    if kind in ("indicators", "worldbank_csv", "worldbank"):
        return _indicators_preview(*inspect_indicators(p, extra))
    return {"kind": kind}


def result_payload(res, state: State, max_nodes=3000, max_edges=30000) -> dict:
    G = res.graph
    nodes = sorted(G.nodes, key=lambda n: -G.degree(n))[:max_nodes]
    keep = set(nodes)
    node_rows, numeric, categorical = [], set(), set()
    for n in nodes:
        attrs = {k: _plain(v) for k, v in G.nodes[n].items() if k not in NUMERIC_SKIP}
        for k, v in attrs.items():
            if k == "label":
                continue
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                numeric.add(k)
            elif isinstance(v, str):
                categorical.add(k)
        node_rows.append({"id": str(n), "label": str(G.nodes[n].get("label", n)), "attrs": attrs})
    for k in ("community", "block"):                    # group numbers are categories, not quantities
        if any(k in r["attrs"] for r in node_rows):
            categorical.add(k)
    edges = []
    for u, v, d in G.edges(data=True):
        if u in keep and v in keep and len(edges) < max_edges:
            a = {k: _plain(x) for k, x in d.items() if k != "distance" and not (k.startswith("rel_") and not x)}
            if isinstance(a.get("evidence"), str):
                a["evidence"] = a["evidence"][:3000]
            edges.append({"from": str(u), "to": str(v), "attrs": a})
    comms = [{"size": len(c), "members": [str(G.nodes[m].get("label", m)) for m in
                                           sorted(c, key=lambda m: -G.degree(m))[:12]]} for c in res.communities[:20]]
    files = []
    if res.output_dir:
        for f in sorted(Path(res.output_dir).glob("*")):
            if f.is_file():                              # the session cookie authorizes the download: no token in the address
                files.append({"name": f.name, "size": f.stat().st_size, "path": str(f),
                              "url": "/api/file?" + urllib.parse.urlencode({"path": str(f)})})
    tables = {}
    for name, df in (res.tables or {}).items():
        if df is None or not len(df):
            continue
        sub = df.head(3000)
        tables[name] = {"columns": [str(c) for c in sub.columns], "total": len(df),
                        "rows": [[_plain(v) if not (isinstance(v, float) and math.isnan(v)) else None for v in r]
                                 for r in sub.itertuples(index=False, name=None)]}
    edge_numeric = sorted({k for e in edges for k, v in e["attrs"].items() if isinstance(v, (int, float))
                           and not isinstance(v, bool)})
    return {"summary": {k: _plain(v) for k, v in res.summary.items()}, "directed": G.is_directed(),
            "tables": tables, "edge_numeric": edge_numeric,
            "nodes": node_rows, "edges": edges, "truncated": G.number_of_nodes() > max_nodes,
            "numeric": sorted(numeric - {"community", "block"}), "categorical": sorted(categorical),
            "communities": comms, "files": files, "output_dir": res.output_dir}


RENAMED = {"item": "member", "items": "members", "item_attributes": "member_attributes", "author": "source"}


def ui_names(cfg: dict) -> dict:
    """Old builder, input and option names → the general ones the forms use."""
    from ..config import BUILDER_ALIASES
    i = dict(cfg.get("input") or {})
    if i.get("type") == "worldbank_csv" or (i.get("type", "table") == "table" and i.get("preset") in ("worldbank", "indicators")):
        i["type"] = "indicators"                 # the interface's own input ids
        i.pop("preset", None)
    elif i.get("type") == "api" and i.get("source") == "worldbank":
        i["type"] = "worldbank_api"
        i.pop("source")
    if i:
        cfg = {**cfg, "input": i}
    b = cfg.get("builder") or {}
    if b.get("type") in BUILDER_ALIASES:
        canon, extra = BUILDER_ALIASES[b["type"]]
        b = {"type": canon, **extra, **{k: v for k, v in b.items() if k != "type"}}
        for old, new in RENAMED.items():
            if old in b:
                b.setdefault(new, b.pop(old))
        for kind, col in (("reply", "reply_to"), ("repost", "repost_of"), ("quote", "quote_of")):
            if col in b:
                b.setdefault("targets", {})[kind] = b.pop(col)
        if "edges" in b:
            kinds = b.pop("edges")
            b["kinds"] = kinds
            if "mention" in kinds:
                b.setdefault("extract", ["mentions"])
        if b.get("network") in ("users", "users_hashtags"):
            b["network"] = b["network"].replace("users", "actors")
        cfg = {**cfg, "builder": b}
    return cfg


def example_list() -> list[dict]:
    out = []
    with resources.as_file(resources.files("tejido").joinpath("examples")) as ex:
        for f in sorted(Path(ex).glob("*.yaml")):
            text = f.read_text(encoding="utf-8")
            cfg = yaml.safe_load(text)
            first = text.splitlines()[0].lstrip("# ").strip() if text.startswith("#") else ""
            out.append({"name": f.stem, "project": cfg.get("project"), "builder": cfg["builder"]["type"],
                        "input": (cfg.get("input") or {}).get("type", "table"), "description": first})
    return out


def load_example(name: str, state: State) -> dict:
    if not isinstance(name, str) or not re.fullmatch(r"[\w-]{1,80}", name):
        raise ConfigError(f"Unknown example {name!r}")
    dest, mark = state.workspace / "examples", state.workspace / "examples" / ".version"
    if not dest.exists() or not mark.exists() or mark.read_text(encoding="utf-8").strip() != __version__:
        shutil.rmtree(dest, ignore_errors=True)          # the examples of this version, not of an earlier one
        with resources.as_file(resources.files("tejido").joinpath("examples")) as ex:
            shutil.copytree(ex, dest, ignore=shutil.ignore_patterns("__pycache__", "results"))
        mark.write_text(__version__, encoding="utf-8")
    f = dest / f"{name}.yaml"
    if not f.exists():
        raise ConfigError(f"Unknown example {name!r}")
    from ..config import absolutize
    cfg = ui_names(absolutize(yaml.safe_load(f.read_text(encoding="utf-8")), dest))
    cfg.setdefault("input", {"type": "table"})
    cfg["output"]["dir"] = str(state.workspace / "results" / cfg["project"])
    return cfg


def results_dir(cfg: dict, state: State) -> Path:
    """Where the interface saves results: always inside the workspace (results/<project>), so they can be listed and
    opened from the interface, and a configuration received from someone else cannot write elsewhere."""
    default = state.workspace / "results" / cfg["project"]
    asked = (cfg.get("output") or {}).get("dir")
    if not asked or not isinstance(asked, str):
        return default
    p = Path(asked)
    p = (p if p.is_absolute() else state.workspace / "results" / p).resolve()
    if p == state.workspace or state.workspace not in p.parents:
        log.warning(f"output.dir {logs.clean(asked)!r} is outside the workspace; results are saved in {default}")
        return default
    return p


def start_job(cfg: dict, state: State) -> str:
    from ..pipeline import run
    if not isinstance(cfg, dict) or not isinstance(cfg.get("builder"), dict):
        raise ConfigError("Choose a network type first.")
    cfg = copy.deepcopy({k: v for k, v in cfg.items() if not str(k).startswith("_")})
    cfg["project"] = re.sub(r"[^\w\-]+", "_", file_stem(cfg.get("project"))).strip("_")[:80] or "my_network"
    cfg["output"] = cfg["output"] if isinstance(cfg.get("output"), dict) else {}
    cfg["output"]["dir"] = str(results_dir(cfg, state))
    with state.lock:
        if state.job and state.job["state"] == "running":
            raise ConfigError("A network is already being built. Wait until it finishes.")
        job = {"id": secrets.token_hex(4), "state": "running", "log": [], "error": None, "result": None,
               "started": time.time(), "project": cfg["project"]}
        state.job = job

    class Capture(logging.Handler):
        def emit(self, record):
            if record.name == "tejido" and len(job["log"]) < JOB_LOG_LINES:      # not the access or security records
                job["log"].append(f"[{record.levelname.lower()}] {record.getMessage()}")

    def work():
        h = Capture()
        log.addHandler(h)
        log.info(f"Build {job['id']} started")
        try:
            job["result"] = result_payload(run(cfg), state)
            job["state"] = "done"
        except ConfigError as e:
            job["error"], job["state"] = str(e), "error"
            log.error(f"Build {job['id']} stopped: {e}")
        except MemoryError:
            job["error"], job["state"] = "The computer ran out of memory. Use filters or a smaller sample.", "error"
            log.error(f"Build {job['id']} ran out of memory")
        except Exception as e:                                      # report, do not crash the server
            job["error"], job["state"] = f"{type(e).__name__}: {e}", "error"
            log.exception(f"Build {job['id']} failed with an unexpected error")     # full traceback in the activity log
        finally:
            job["seconds"] = round(time.time() - job["started"], 1)
            log.info(f"Build {job['id']} ended: {job['state']} in {job['seconds']} s")
            log.removeHandler(h)
    threading.Thread(target=work, daemon=True, name=f"build-{job['id']}").start()
    return job["id"]


def about(state: State) -> dict:
    """Who made the program and where it is running: shown in the interface (About) and useful in a bug report."""
    return {"name": "Tejido", "version": __version__, "author": __author__, "copyright": __copyright__,
            "license": __license__, "url": __url__, "python": platform.python_version(),
            "system": f"{platform.system()} {platform.release()}", "workspace": str(state.workspace),
            "log": str(state.log_path) if state.log_path else None, "max_upload_mb": state.max_upload() // 1024 // 1024,
            "citation": f"Ayala Velásquez, A. E. ({time.strftime('%Y')}). Tejido (Version {__version__}) [Computer software]. {__url__}"}


def upload_name(raw: str) -> str:
    """The name a received file is saved with: no folders, no hidden or reserved names, only kinds the program reads."""
    name = file_stem(Path(str(raw).replace("\\", "/")).name, "file", 120)
    name = re.sub(r"[^\w.\- ()]", "_", name)
    ext = Path(name).suffix.lower()
    if ext not in UPLOAD_EXT:
        raise ConfigError(f"Files of type {ext or '(no extension)'} are not accepted. Tables: csv, tsv, txt, xlsx, xls, "
                          "dta, sav, parquet, json, zip. Documents: txt, md, html, pdf, docx.")
    return name


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

PAGE_CSP = ("default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
            "font-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
# A results page is data turned into HTML: it opens apart from the interface (no cookies, no /api, no network).
RESULT_CSP = ("sandbox allow-scripts allow-popups allow-downloads; default-src 'none'; script-src 'unsafe-inline'; "
              "style-src 'unsafe-inline'; img-src data: blob:; base-uri 'none'; form-action 'none'")
FILE_CSP = "sandbox; default-src 'none'"
STATIC_TYPES = {".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".woff2": "font/woff2",
                ".svg": "image/svg+xml", ".txt": "text/plain; charset=utf-8"}
FILE_TYPES = {".html": "text/html; charset=utf-8", ".md": "text/plain; charset=utf-8", ".csv": "text/csv; charset=utf-8",
              ".json": "application/json; charset=utf-8", ".txt": "text/plain; charset=utf-8"}
NO_SESSION = """<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tejido</title><style>body{font:16px/1.55 system-ui,sans-serif;background:#f4f5f8;color:#1b2030;display:grid;place-items:center;
min-height:100vh;margin:0}main{max-width:520px;padding:32px;background:#fff;border:1px solid #dde0e7;border-radius:12px}
h1{font:600 24px Georgia,serif;margin:0 0 12px}p{margin:8px 0;color:#5b6275}@media (prefers-color-scheme:dark){body{background:#111319;
color:#e8e9ef}main{background:#181b24;border-color:#2b3040}p{color:#a0a6b8}}</style>
<main><h1>Tejido</h1><p>Esta dirección solo se abre desde el propio programa. Vuelve a la ventana de Tejido y pulsa
<b>Abrir la interfaz</b> (o ejecuta de nuevo <code>tejido ui</code>).</p>
<p lang="en">This address opens only from the program itself. Go back to the Tejido window and click <b>Open interface</b>
(or run <code>tejido ui</code> again).</p></main></html>"""


class Refused(Exception):
    """A request that is not answered: (status, message for the browser, note for the log)."""

    def __init__(self, status: int, message: str, note: str = ""):
        super().__init__(message)
        self.status, self.message, self.note = status, message, note or message


def content_disposition(kind: str, name: str) -> str:
    """Header for a download whatever the file is called (accents and other alphabets included)."""
    ascii_name = re.sub(r'[^A-Za-z0-9._\- ()]', "_", name) or "file"
    return f"{kind}; filename=\"{ascii_name}\"; filename*=UTF-8''{urllib.parse.quote(name, safe='')}"


def make_handler(state: State):
    class Handler(BaseHTTPRequestHandler):
        server_version = "tejido"                                    # no version or Python details in the header
        sys_version = ""
        protocol_version = "HTTP/1.1"
        timeout = 120                                                # a stalled connection does not hold a thread forever

        def log_message(self, *args):                               # the activity log replaces the console lines
            pass

        # ------------------------------------------------------------- answers
        def _send(self, code, body: bytes, ctype="application/json; charset=utf-8", extra=None):
            headers = {"Content-Type": ctype, "Content-Length": str(len(body)), "Cache-Control": "no-store",
                       "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
                       "Cross-Origin-Opener-Policy": "same-origin", "Cross-Origin-Resource-Policy": "same-origin",
                       "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'"}
            headers.update(extra or {})
            self._status = code
            try:
                self.send_response(code)
                for k, v in headers.items():
                    self.send_header(k, v)
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, TimeoutError):
                self.close_connection = True      # the browser closed or reloaded the page before the answer

        def _json(self, obj, code=200):
            self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"))

        def _error(self, msg, code=400):
            self._json({"error": msg}, code)

        def _record(self, started: float, note: str = "") -> None:
            code, path = getattr(self, "_status", 0), logs.clean(urllib.parse.urlparse(self.path).path, 120)
            line = f"{self.command} {path} → {code} ({(time.time() - started) * 1000:.0f} ms)" + (f" · {note}" if note else "")
            if code in (401, 403):
                logs.security.warning(f"Refused: {line} · from {self.client_address[0]}")
            elif code >= 500:
                logs.access.error(line)
            elif code >= 400 or self.command == "POST":
                logs.access.info(line)
            else:
                logs.access.debug(line)

        # ------------------------------------------------------------- who is asking
        def _check_origin(self) -> None:
            """Only this page may ask: the right host name (no DNS rebinding) and no other site behind the request."""
            host = (self.headers.get("Host") or "").strip().lower()
            if host not in (f"127.0.0.1:{state.port}", f"localhost:{state.port}"):
                raise Refused(403, "Forbidden host", f"host {logs.clean(host, 80)!r}")
            origin = self.headers.get("Origin")
            if origin is not None and origin.rstrip("/").lower() not in (f"http://127.0.0.1:{state.port}", f"http://localhost:{state.port}"):
                raise Refused(403, "Forbidden origin", f"origin {logs.clean(origin, 80)!r}")
            other_site = (self.headers.get("Sec-Fetch-Site") or "same-origin").lower() in ("cross-site", "same-site")
            if other_site and urllib.parse.urlparse(self.path).path.startswith("/api/"):
                raise Refused(403, "Forbidden origin", "request started by another site")

        def _has_session(self) -> bool:
            try:
                c = SimpleCookie(self.headers.get("Cookie") or "").get(state.cookie)
            except CookieError:
                return False
            return bool(c) and secrets.compare_digest(c.value.encode(), state.session.encode())

        def _has_token(self) -> bool:
            return secrets.compare_digest((self.headers.get("X-Token") or "").encode(), state.token.encode())

        def _need_token(self) -> None:
            if not self._has_token():
                raise Refused(403, "Missing or wrong token", "missing or wrong token")

        def _length(self, limit: int) -> int:
            if "chunked" in (self.headers.get("Transfer-Encoding") or "").lower():
                raise Refused(411, "Content-Length required")
            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                raise Refused(400, "Bad Content-Length") from None
            if n < 0:
                raise Refused(400, "Bad Content-Length")
            if n > limit:
                self.close_connection = True                        # the body is not read
                raise Refused(413, f"Too large: the limit is {limit // 1024 // 1024} MB", f"body of {n:,} bytes refused")
            return n

        def _body(self) -> dict:
            n = self._length(MAX_JSON)
            try:
                body = json.loads(self.rfile.read(n).decode("utf-8")) if n else {}
            except (ValueError, UnicodeDecodeError):
                raise Refused(400, "The request is not valid JSON") from None
            if not isinstance(body, dict):
                raise Refused(400, "The request must be a JSON object")
            return body

        def _handle(self, route) -> None:
            started, note = time.time(), ""
            try:
                self._check_origin()
                route(urllib.parse.urlparse(self.path))
            except Refused as e:
                note = e.note
                self.close_connection = self.close_connection or self.command == "POST"   # its body may be unread
                self._error(e.message, e.status)
            except ConfigError as e:
                note = logs.clean(e, 300)
                self.close_connection = self.close_connection or self.command == "POST"
                self._error(str(e))
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, TimeoutError):
                self.close_connection = True
            except Exception as e:                                  # report, do not crash the server
                log.exception(f"Unexpected error answering {self.command} {logs.clean(urllib.parse.urlparse(self.path).path, 120)}")
                self.close_connection = True
                self._error(f"{type(e).__name__}: {e}", 500)
            finally:
                self._record(started, note)

        # ------------------------------------------------------------- GET
        def do_GET(self):
            self._handle(self._get)

        def do_HEAD(self):
            self._handle(self._get)

        def _get(self, url) -> None:
            q = urllib.parse.parse_qs(url.query)
            if url.path in ("/", "/index.html"):
                given = q.get("launch", [""])[0]
                if given:                                            # the address the program opened: keep a cookie, drop the secret
                    if not secrets.compare_digest(given.encode(), state.launch.encode()):
                        raise Refused(403, "Wrong launch address", "wrong launch secret")
                    return self._send(303, b"", "text/plain", {"Location": "/", "Set-Cookie":
                                      f"{state.cookie}={state.session}; Path=/; HttpOnly; SameSite=Strict"})
                if not self._has_session():
                    logs.security.warning(f"Refused: the page was asked without a session · from {self.client_address[0]}")
                    return self._send(403, NO_SESSION.encode("utf-8"), "text/html; charset=utf-8",
                                      {"Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'none'"})
                page = UI_DIR.joinpath("index.html").read_text(encoding="utf-8")
                page = page.replace("__TOKEN__", state.token).replace("__VERSION__", __version__)
                return self._send(200, page.encode("utf-8"), "text/html; charset=utf-8", {"Content-Security-Policy": PAGE_CSP})
            if url.path.startswith("/static/"):                      # the program's own files: nothing private in them
                name = url.path.rsplit("/", 1)[-1]
                f = UI_DIR.joinpath("static").joinpath(name)
                if not re.fullmatch(r"[\w.\-]+", name) or name.startswith(".") or not f.is_file():
                    raise Refused(404, "Not found")
                ctype = STATIC_TYPES.get(Path(name).suffix, "text/plain; charset=utf-8")
                return self._send(200, f.read_bytes(), ctype, {"Cache-Control": "max-age=86400"})
            if url.path == "/favicon.ico":
                return self._send(204, b"", "image/x-icon")
            if url.path == "/api/file":                              # opened in a tab or downloaded: the cookie is enough
                if not (self._has_token() or self._has_session()):
                    raise Refused(403, "Missing or wrong token", "file asked without session")
                f = state.inside(q.get("path", [""])[0])
                if not f.is_file():
                    raise Refused(404, "Not found")
                html = f.suffix.lower() == ".html"
                disp = "inline" if f.suffix.lower() in (".html", ".md", ".txt") else "attachment"
                return self._send(200, f.read_bytes(), FILE_TYPES.get(f.suffix.lower(), "application/octet-stream"),
                                  {"Content-Disposition": content_disposition(disp, f.name),
                                   "Content-Security-Policy": RESULT_CSP if html else FILE_CSP})
            if not url.path.startswith("/api/"):
                raise Refused(404, "Not found")
            self._need_token()
            if url.path == "/api/schema":
                from ..config import DEFAULTS
                from ..export import TR
                from ..groups import GROUPS
                from .i18n import ES, OPTION_LABELS, STAT_HELP
                return self._json({"builders": BUILDER_FORMS, "inputs": INPUT_TYPES, "formats": FORMATS,
                                   "centralities": sorted(CENTRALITIES), "version": __version__,
                                   "measures": NODE_MEASURES, "families": FAMILIES, "distances": DISTANCES,
                                   "groups": GROUPS, "steps": PREPARE_FORMS, "defaults": DEFAULTS,
                                   "communities": ["louvain", "greedy", "label_propagation", "girvan_newman",
                                                   "attribute", "none"],
                                   "option_labels": OPTION_LABELS, "stat_help": STAT_HELP,
                                   "i18n": {"es": {**TR["es"], **ES}}, "workspace": str(state.workspace),
                                   "about": about(state)})
            if url.path == "/api/examples":
                return self._json(example_list())
            if url.path == "/api/status":
                job = state.job
                try:
                    since = max(0, int(q.get("since", ["0"])[0]))
                except ValueError:
                    since = 0
                if not job:
                    return self._json({"state": "idle", "log": []})
                return self._json({"id": job["id"], "state": job["state"], "error": job["error"],
                                   "log": job["log"][since:], "next": len(job["log"]), "project": job.get("project"),
                                   "seconds": job.get("seconds"), "elapsed": round(time.time() - job["started"], 1)})
            if url.path == "/api/result":
                job = state.job
                if not job or job["state"] != "done":
                    raise Refused(404, "No result yet")
                return self._json(job["result"])
            if url.path == "/api/logs":
                try:
                    n = min(2000, max(1, int(q.get("lines", ["300"])[0])))
                except ValueError:
                    n = 300
                return self._json({"path": str(state.log_path) if state.log_path else None,
                                   "text": logs.tail(state.log_path, n) if state.log_path else ""})
            raise Refused(404, "Not found")

        # ------------------------------------------------------------- POST
        def do_POST(self):
            self._handle(self._post)

        def _post(self, url) -> None:
            if not url.path.startswith("/api/"):
                raise Refused(404, "Not found")
            self._need_token()
            if url.path == "/api/upload":
                return self._upload(urllib.parse.parse_qs(url.query))
            body = self._body()
            if url.path == "/api/preview":
                extra, steps = body.get("input"), body.get("prepare")
                return self._json(preview(str(body.get("type") or "table"), str(body.get("path") or ""),
                                          extra if isinstance(extra, dict) else None, steps if isinstance(steps, list) else None,
                                          detect=body.get("detect", True) is not False))
            if url.path == "/api/example":
                cfg = load_example(body.get("name", ""), state)
                pv = preview(cfg["input"]["type"], cfg["input"]["path"]) if cfg["input"].get("path") else {}
                return self._json({"config": cfg, "preview": pv})
            if url.path == "/api/run":
                return self._json({"id": start_job(body.get("config") or {}, state)})
            if url.path == "/api/yaml":
                cfg = body.get("config") if isinstance(body.get("config"), dict) else {}
                cfg = {k: v for k, v in cfg.items() if not str(k).startswith("_")}
                return self._json({"text": yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False)})
            if url.path == "/api/parse_yaml":
                try:
                    cfg = yaml.safe_load(str(body.get("text") or "")) or {}
                except yaml.YAMLError as e:
                    raise ConfigError(f"The file is not valid YAML: {str(e)[:300]}") from e
                if not isinstance(cfg, dict) or not isinstance(cfg.get("builder"), dict):
                    raise ConfigError("This YAML does not look like a tejido configuration.")
                return self._json({"config": ui_names(cfg)})
            if url.path == "/api/open":                              # folders only: a received file is never run
                from ..gui import open_path
                what = body.get("what")
                target = {"workspace": state.workspace, "logs": state.log_path.parent if state.log_path else state.workspace
                          }.get(what) if what else state.inside(body.get("path", ""))
                if target is None or not Path(target).is_dir():
                    raise Refused(400, "Only folders of the workspace can be opened", "open refused: not a workspace folder")
                open_path(target)
                return self._json({"ok": True})
            raise Refused(404, "Not found")

        def _upload(self, q) -> None:
            n = self._length(state.max_upload())
            if n == 0:
                raise Refused(400, "The file is empty")
            try:
                name = upload_name(q.get("name", ["file"])[0])
            except ConfigError:
                self.close_connection = True                        # the body is not read
                raise
            batch = re.sub(r"[^\w\-]", "", q.get("batch", ["upload"])[0])[:40] or "upload"
            folder = state.workspace / "uploads" / batch
            folder.mkdir(parents=True, exist_ok=True)
            dest, part = folder / name, folder / (name + ".part")
            left = n
            try:
                with open(part, "wb") as fh:
                    while left > 0:
                        chunk = self.rfile.read(min(left, 1 << 20))
                        if not chunk:
                            break
                        fh.write(chunk)
                        left -= len(chunk)
                if left:                                            # the browser stopped half way
                    raise Refused(400, "The file arrived incomplete; try again", f"upload of {name!r} incomplete")
                os.replace(part, dest)
            finally:
                if part.exists():
                    part.unlink()
            log.info(f"File received: {logs.clean(name)} ({n:,} bytes)")
            self._json({"file": str(dest), "folder": str(folder)})

    return Handler


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False
    request_queue_size = 32
    state: State
    launch_url: str


def serve(workspace=None, port: int = 0, open_browser: bool = True):
    """Starts the interface. Returns (server, url); call server.serve_forever() to block.
    server.launch_url is the address that opens the page (it carries the launch secret); 'url' alone does not."""
    state = State(Path(workspace) if workspace else Path.home() / "tejido_workspace")
    server = Server(("127.0.0.1", port), make_handler(state))
    state.port = server.server_address[1]
    state.cookie = f"tejido_session_{state.port}"
    state.log_path = logs.setup(state.workspace / "logs")
    logs.install_excepthooks()
    logs.session_start("visual interface", workspace=state.workspace, port=state.port)
    server.state = state
    url = f"http://127.0.0.1:{state.port}/"
    server.launch_url = url + "?launch=" + state.launch
    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(server.launch_url)).start()
    return server, url


def main(workspace=None, port: int = 0, open_browser: bool = True):
    server, _ = serve(workspace, port, open_browser)
    print(f"Tejido {__version__} · © {__author__}\nOpen this address in your browser (it is valid until Tejido closes):\n"
          f"  {server.launch_url}\nWorkspace: {server.state.workspace}\nActivity log: {server.state.log_path}\n"
          "Press Ctrl+C to stop.", flush=True)          # at once, also when the output goes to a file or a pipe
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        log.info("=== Tejido closed")
        logs.shutdown()
