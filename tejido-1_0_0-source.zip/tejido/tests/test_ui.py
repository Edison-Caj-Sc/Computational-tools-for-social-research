"""Tests for the local server behind the visual interface."""
import json
import threading
import time
import urllib.error
import urllib.request

import pytest

from tejido.ui.server import serve


@pytest.fixture
def app(tmp_path):
    server, url = serve(tmp_path / "ws", port=0, open_browser=False)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    yield url.rstrip("/"), server.state
    server.shutdown()
    server.server_close()


def call(url, path, token=None, body=None, raw=None, headers=None):
    h = dict(headers or {})
    if token:
        h["X-Token"] = token
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    if body is not None:
        h["Content-Type"] = "application/json"
    req = urllib.request.Request(url + path, data=data, headers=h, method="POST" if data is not None else "GET")
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def j(resp):
    return json.loads(resp[1])


def wait_done(url, tok):
    for _ in range(200):
        st = j(call(url, "/api/status", tok))
        if st["state"] in ("done", "error"):
            return st
        time.sleep(.1)
    raise AssertionError("job did not finish")


def test_security(app):
    url, st = app
    code, page = call(url, "/")                                           # the bare address gives nothing away
    assert code == 403 and st.token.encode() not in page
    code, page = call(url, "/", headers={"Cookie": f"{st.cookie}={st.session}"})
    assert code == 200 and st.token.encode() in page and b"__TOKEN__" not in page
    assert call(url, "/api/schema")[0] == 403
    assert call(url, "/api/schema", "wrong")[0] == 403
    assert call(url, "/api/schema", st.token, headers={"Host": "evil.example"})[0] == 403
    assert call(url, "/api/run", body={})[0] == 403                       # POST without token
    code, body = call(url, "/api/file?path=/etc/passwd", st.token)
    assert code == 400 and b"outside" in body
    assert call(url, "/static/vis-network.min.js")[0] == 200
    assert call(url, "/static/..%2F..%2Fserver.py")[0] == 404


def test_schema_examples_and_yaml(app):
    url, st = app
    schema = j(call(url, "/api/schema", st.token))
    assert {"ties", "affiliation", "similarity", "text", "interactions", "ego", "transitions"} == set(schema["builders"])
    names = {e["name"] for e in j(call(url, "/api/examples", st.token))}
    assert {"documents", "social_media", "qualitative_codes", "worldbank_csv", "worldbank_api", "personal_networks",
            "trajectories", "survey_items", "districts", "social_evolution", "indicators_messy"} == names
    old = {"project": "x", "builder": {"type": "edgelist", "source": "a"}}
    text = j(call(url, "/api/yaml", st.token, {"config": old}))["text"]
    assert j(call(url, "/api/parse_yaml", st.token, {"text": text}))["config"]["builder"] == \
        {"type": "ties", "format": "edgelist", "source": "a"}
    cfg = {"project": "x", "builder": {"type": "ties", "source": "a"}}
    text = j(call(url, "/api/yaml", st.token, {"config": cfg}))["text"]
    assert j(call(url, "/api/parse_yaml", st.token, {"text": text}))["config"] == cfg
    assert call(url, "/api/parse_yaml", st.token, {"text": "a: 1"})[0] == 400


@pytest.mark.parametrize("name", ["documents", "social_media", "qualitative_codes", "worldbank_csv", "indicators_messy", "personal_networks",
                                  "trajectories", "survey_items", "districts", "social_evolution"])
def test_examples_run_through_the_interface(app, name):
    url, st = app
    ex = j(call(url, "/api/example", st.token, {"name": name}))
    assert ex["preview"]["kind"] in ("table", "documents", "indicators")
    cfg = ex["config"]
    cfg["output"] = {"formats": ["csv", "html", "report"], "html": {"offline": True}}
    assert "id" in j(call(url, "/api/run", st.token, {"config": cfg}))
    status = wait_done(url, st.token)
    assert status["state"] == "done", status
    res = j(call(url, "/api/result", st.token))
    assert res["nodes"] and res["edges"] and res["summary"]["nodes"] >= len(res["nodes"]) > 0
    html = next(f for f in res["files"] if f["name"].endswith(".html"))
    assert "t=" not in html["url"] and call(url, html["url"])[0] == 403        # no token in addresses; no session, no file
    code, page = call(url, html["url"], headers={"Cookie": f"{st.cookie}={st.session}"})
    assert code == 200 and b"cdn.jsdelivr" not in page and b"vis.Network" in page   # offline page


def test_upload_preview_and_errors(app, tmp_path):
    url, st = app
    csv = b"from,to,w\nA,B,1\nB,C,2\nC,A,1\n"
    up = j(call(url, "/api/upload?name=ties.csv&batch=b1", st.token, raw=csv))
    pv = j(call(url, "/api/preview", st.token, {"type": "table", "path": up["file"]}))
    assert pv["columns"] == ["from", "to", "w"] and pv["rows"] == 3
    cfg = {"project": "ties", "input": {"type": "table", "path": up["file"]},
           "builder": {"type": "edgelist", "source": "from", "target": "to", "weight": "w"}}
    call(url, "/api/run", st.token, {"config": cfg})
    assert wait_done(url, st.token)["state"] == "done"
    bad = {"project": "bad", "input": {"type": "table", "path": up["file"]},
           "builder": {"type": "edgelist", "source": "nope", "target": "to"}}
    call(url, "/api/run", st.token, {"config": bad})
    st2 = wait_done(url, st.token)
    assert st2["state"] == "error" and "nope" in st2["error"]


def test_schema_has_interface_texts(app):
    url, st = app
    schema = j(call(url, "/api/schema", st.token))
    assert {"measures", "families", "steps", "option_labels", "i18n", "distances", "groups"} <= set(schema)
    shown = {m for fam in schema["families"].values() for m in fam}
    assert shown == set(schema["measures"]) and "ego_betweenness" in shown and "information" in shown
    assert schema["i18n"]["es"]["Build network"] == "Construir red"
    assert call(url, "/static/app.js")[0] == 200


def test_preview_after_prepare(app, tmp_path):
    url, st = app
    up = j(call(url, "/api/upload?name=t.csv&batch=b", st.token, raw=b"a,b,k\nx,y,1\ny,z,2\n"))
    pv = j(call(url, "/api/preview", st.token, {"type": "table", "path": up["file"],
                                                "prepare": [{"recode": {"k": {"1": "one"}}}, {"filter": "k == 'one'"}]}))
    assert pv["prepared"] and pv["rows"] == 1 and pv["head"][0]["k"] == "one"


def test_result_payload_has_tables(app):
    url, st = app
    cfg = j(call(url, "/api/example", st.token, {"name": "personal_networks"}))["config"]
    cfg["output"] = {"formats": ["csv"]}
    call(url, "/api/run", st.token, {"config": cfg})
    assert wait_done(url, st.token)["state"] == "done"
    res = j(call(url, "/api/result", st.token))
    assert "egos" in res["tables"] and res["tables"]["egos"]["total"] == 40 and res["tables"]["egos"]["columns"][0] == "ego"


def test_interface_in_a_browser(app):
    """End-to-end: the page loads, an example builds, results render (skipped without Playwright/Chromium)."""
    pw = pytest.importorskip("playwright.sync_api")
    url, st = app
    try:
        with pw.sync_playwright() as p:
            b = p.chromium.launch()
            page = b.new_page(locale="en-US", accept_downloads=True)
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)   # CSP violations too
            page.goto(f"{url}/?launch={st.launch}")
            assert "launch" not in page.url                              # the secret does not stay in the address
            page.wait_for_selector(".example")
            page.click(".example:has-text('Occupational mobility')")
            page.wait_for_timeout(500)
            page.click("#btn-run")
            page.wait_for_selector("#status.ok, #status.err", timeout=60000)
            assert "Done" in page.inner_text("#status")
            page.click("nav.tabs button[data-tab=tables]")
            assert "Mobility table" in page.inner_text("#p-tables")
            page.click("nav.tabs button[data-tab=welcome]")
            page.click(".example:has-text('Organizations in documents')")
            page.wait_for_timeout(500)
            page.click("#btn-run")
            page.wait_for_selector("#status.ok, #status.err", timeout=60000)
            assert page.input_value("#tie-style") == "strength"
            page.click("nav.tabs button[data-tab=groups]")
            assert "Brokers and structural holes" in page.inner_text("#p-groups")
            page.click("nav.tabs button[data-tab=network]")         # appearance panel, layouts and image
            page.click("#btn-style")
            assert page.is_visible("#stylebox") and "Appearance" in page.inner_text("#stylebox")
            page.locator("#stylebox select").first.select_option("poster")
            page.locator("#stylebox select").filter(has=page.locator("option[value=rings]")).select_option("groups")
            page.wait_for_timeout(600)
            st = page.evaluate("S.style")
            assert st["halos"] and st["layout"] == "groups" and st["border_color"] == "background"
            assert "style" in page.evaluate("collectConfig().output.html")
            with page.expect_download() as d:
                page.click("#btn-png")
            assert d.value.suggested_filename.endswith(".png")
            page.click("#stylebox .shead .btn.small")              # reset
            assert page.evaluate("Object.keys(TejidoStyle.diff(S.style)).length") == 0
            page.evaluate("""() => { S.rest['analysis.blockmodel.method'] = 'concor';    // blockmodel and ERGM (0.8)
                                    S.rest['analysis.ergm.enabled'] = true; S.rest['analysis.ergm.method'] = 'mple'; }""")
            cfg = page.evaluate("collectConfig().analysis")
            assert cfg["blockmodel"]["method"] == "concor" and cfg["ergm"]["method"] == "mple" and "enabled" not in cfg["ergm"]
            page.click("#btn-run")
            page.wait_for_selector("#status.ok, #status.err", timeout=120000)
            page.click("nav.tabs button[data-tab=model]")
            assert "ERGM" in page.inner_text("#p-model") and page.locator("#p-model svg.gofc").count() >= 2
            page.click("nav.tabs button[data-tab=groups]")
            assert page.locator("canvas.bmatrix").count() == 1
            b.close()
    except Exception as e:                       # no browser installed in this environment
        if "Executable doesn't exist" in str(e):
            pytest.skip("Chromium not installed")
        raise
    assert not errors
