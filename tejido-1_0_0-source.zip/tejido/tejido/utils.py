"""Shared helpers."""
from __future__ import annotations

import logging
import re
import unicodedata

log = logging.getLogger("tejido")
if not log.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
    log.addHandler(_h)
    log.setLevel(logging.INFO)


def safe_console() -> None:
    """A character the console cannot show (© or á in some Windows code pages, a name in another alphabet) is
    replaced instead of stopping the program."""
    import sys
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError, OSError):     # no console (double-click), or not reconfigurable
            pass


class ConfigError(ValueError):
    """User-facing configuration error."""


def as_list(x) -> list:
    if x is None:
        return []
    return list(x) if isinstance(x, (list, tuple, set)) else [x]


def fold(text: str) -> str:
    """Lowercase, strip accents and collapse spaces: used to compare names."""
    s = unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[\s,;:]+", " ", s).strip()


def require_columns(df, cols, where: str) -> None:
    missing = [c for c in as_list(cols) if c and c not in df.columns]
    if missing:
        raise ConfigError(f"{where}: columns not found: {missing}. Available: {list(df.columns)[:30]}")


def split_values(v, sep: str = "|") -> list[str]:
    """'a|b' or ['a', 'b'] → ['a', 'b'] (empty values dropped)."""
    if v is None or (isinstance(v, float) and v != v):
        return []
    items = v if isinstance(v, (list, tuple, set)) else str(v).split(sep)
    return [str(x).strip() for x in items if str(x).strip()]


_RESERVED = {"con", "prn", "aux", "nul"} | {f"{p}{i}" for p in ("com", "lpt") for i in range(1, 10)}


def file_stem(text, default: str = "my_network", maxlen: int = 80) -> str:
    """A project name made safe as the start of file names: no folder separators, no characters or names that
    Windows refuses, no leading dots. Letters with accents, spaces and signs such as & stay."""
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f\x7f]+', "_", str(text if text is not None else ""))
    s = s.strip(" ._")[:maxlen].strip(" ._")
    if not s:
        return default
    return f"{s}_" if s.split(".")[0].lower() in _RESERVED else s


def slug(text, maxlen: int = 40) -> str:
    """Safe short name for attributes and file names."""
    s = re.sub(r"[^\w]+", "_", fold(text)).strip("_")
    return (s or "x")[:maxlen]
