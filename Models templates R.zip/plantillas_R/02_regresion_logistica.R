# =====================================================================
#  02 · REGRESIÓN LOGÍSTICA (y PROBIT)
#  Para: variables dependientes binarias (0/1): pobreza, participación, voto.
#  Interpretación: odds ratio (OR) > 1 aumenta la probabilidad; < 1 la reduce.
#  Para comunicar resultados, prefiere los efectos marginales (puntos porcentuales).
# =====================================================================

# ---------------------------------------------------------------------
# 0. CONFIGURACIÓN · edita solo esta sección
# ---------------------------------------------------------------------
archivo        <- NULL
dependiente    <- "pobre"                 # debe ser 0/1 (o dos categorías; ver 'categoria_exito')
categoria_exito <- NULL                   # si Y es texto, la categoría que vale 1 (p. ej. "pobre")
predictores    <- c("educ_jefe", "edad_jefe", "sexo_jefe", "area", "mieperho")
factores       <- list(sexo_jefe = "hombre", area = "urbano")
terminos_extra <- NULL
formula_manual <- NULL
enlace         <- "logit"                 # "logit" (odds ratios) o "probit"
variable_foco  <- "educ_jefe"
umbral         <- NULL                    # corte para clasificar; NULL = proporción observada de 1
usar_diseno    <- FALSE
diseno         <- list(estrato = "estrato", conglomerado = "conglome", peso = "factor07")
carpeta_salida <- "resultados/02_regresion_logistica"

# ---------------------------------------------------------------------
# 1. Preparación
# ---------------------------------------------------------------------
source("utilidades.R"); instalar_si_falta()
salida  <- preparar_salida(carpeta_salida)
formula <- construir_formula(dependiente, predictores, terminos_extra, formula_manual)
datos   <- preparar_datos(cargar_datos(archivo), variables_formula(formula), factores,
                          extra = vars_diseno(usar_diseno, diseno))
y <- all.vars(formula)[1]
if (!is.null(categoria_exito)) datos[[y]] <- as.integer(datos[[y]] == categoria_exito)
if (!all(datos[[y]] %in% c(0, 1)))
  stop("La variable dependiente debe ser 0/1. Usa 'categoria_exito' si es texto.")
dis <- if (usar_diseno) crear_diseno(datos, diseno) else NULL

encabezado("Distribución de la variable dependiente")
print(prop.table(table(datos[[y]])))
if (usar_diseno) print(svymean(as.formula(paste0("~", y)), dis))
if (min(table(datos[[y]])) < 10 * length(attr(terms(formula), "term.labels")))
  warning("Pocos casos en la categoría menos frecuente para tantos predictores (regla de 10 eventos por variable).")

# ---------------------------------------------------------------------
# 2. Estimación
# ---------------------------------------------------------------------
encabezado("Modelo")
fam <- if (usar_diseno) quasibinomial(link = enlace) else binomial(link = enlace)
modelo <- if (usar_diseno) svyglm(formula, design = dis, family = fam) else glm(formula, data = datos, family = fam)
print(summary(modelo))
coefs <- tabla_coeficientes(modelo, exponenciar = enlace == "logit")
if (enlace == "logit") names(coefs) <- sub("^exp_", "or_", names(coefs))
print(redondear(coefs, 3)); guardar_tabla(coefs, "2_coeficientes", salida)

# ---------------------------------------------------------------------
# 3. Ajuste
# ---------------------------------------------------------------------
encabezado("Ajuste del modelo")
p_hat <- fitted(modelo); obs <- datos[[y]]
auc <- function(p, o) {                    # área bajo la curva ROC (Mann-Whitney)
  r <- rank(p); n1 <- sum(o == 1); n0 <- sum(o == 0)
  (sum(r[o == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}
if (usar_diseno) {
  ajuste <- data.frame(n = nrow(datos), pseudo_r2_nagelkerke = psrsq(modelo, method = "Nagelkerke"),
                       auc_sin_ponderar = auc(p_hat, obs))
  print(prueba_global(modelo))
} else {
  nulo <- update(modelo, . ~ 1)
  ajuste <- data.frame(n = nobs(modelo), pseudo_r2_mcfadden = 1 - as.numeric(logLik(modelo) / logLik(nulo)),
                       auc = auc(p_hat, obs), AIC = AIC(modelo), BIC = BIC(modelo),
                       lr_chi2 = 2 * as.numeric(logLik(modelo) - logLik(nulo)),
                       lr_p = pchisq(2 * as.numeric(logLik(modelo) - logLik(nulo)),
                                     df = length(coef(modelo)) - 1, lower.tail = FALSE))
  # Hosmer-Lemeshow por deciles de probabilidad predicha
  grupos <- cut(p_hat, unique(quantile(p_hat, 0:10 / 10)), include.lowest = TRUE)
  o1 <- tapply(obs, grupos, sum); e1 <- tapply(p_hat, grupos, sum); ng <- tapply(obs, grupos, length)
  hl <- sum((o1 - e1)^2 / (e1 * (1 - e1 / ng)))
  ajuste$hosmer_lemeshow_p <- pchisq(hl, df = nlevels(grupos) - 2, lower.tail = FALSE)
}
print(redondear(ajuste, 3)); guardar_tabla(ajuste, "3_ajuste", salida)
cat("AUC: 0,5 = azar · 0,7–0,8 aceptable · > 0,8 bueno.",
    if (!usar_diseno) "Hosmer-Lemeshow p < 0,05 sugiere mal ajuste.", "\n")

corte <- if (is.null(umbral)) mean(obs) else umbral
clasif <- table(observado = obs, predicho = as.integer(p_hat >= corte))
print(clasif)
metricas <- data.frame(umbral = corte, exactitud = sum(diag(clasif)) / sum(clasif),
                       sensibilidad = clasif["1", "1"] / sum(clasif["1", ]),
                       especificidad = clasif["0", "0"] / sum(clasif["0", ]))
print(redondear(metricas, 3)); guardar_tabla(metricas, "3_clasificacion", salida)

# ---------------------------------------------------------------------
# 4. Interpretación: efectos marginales (puntos porcentuales) y predicciones
# ---------------------------------------------------------------------
encabezado("Efectos marginales promedio (cambio en la probabilidad)")
ame <- efectos_marginales(modelo, datos, dis)
ame$efecto_pp <- 100 * ame$efecto
print(redondear(ame, 4)); guardar_tabla(ame, "4_efectos_marginales", salida)
guardar_grafico(grafico_predicciones(modelo, datos, variable_foco, dis, paste("Probabilidad predicha de", y)) +
                  labs(y = "Probabilidad"), "4_predicciones", salida)
guardar_texto(summary(modelo), "resumen_modelo", salida)
encabezado(paste("Listo. Resultados en", salida))
