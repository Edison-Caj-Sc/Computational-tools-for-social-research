# Ejecuta todas las plantillas con los datos de ejemplo, con y sin diseño muestral.
# Útil después de modificar utilidades.R. Los resultados van a una carpeta temporal.
plantillas <- sort(list.files(pattern = "^0[1-9].*\\.R$"))
salida <- file.path(tempdir(), "prueba_plantillas")
res <- expand.grid(plantilla = plantillas, diseno = c(FALSE, TRUE), stringsAsFactors = FALSE)
res$resultado <- NA_character_
for (i in seq_len(nrow(res))) {
  codigo <- readLines(res$plantilla[i], encoding = "UTF-8")
  codigo <- sub("^usar_diseno +<- FALSE", paste("usar_diseno <-", res$diseno[i]), codigo)
  codigo <- sub('^carpeta_salida +<- "resultados/', paste0('carpeta_salida <- "', salida, "/", res$diseno[i], "_"), codigo)
  r <- tryCatch({
    utils::capture.output(suppressMessages(eval(parse(text = codigo), envir = new.env())))
    "OK"
  }, error = function(e) paste("ERROR:", conditionMessage(e)))
  res$resultado[i] <- r
  cat(sprintf("%-30s diseño=%-5s %s\n", res$plantilla[i], res$diseno[i], r))
}
if (all(res$resultado == "OK")) cat("\nTodas las plantillas funcionan.\n") else stop("Hay plantillas con errores.")
