/* Tejido visual interface. Talks only to the local server (127.0.0.1) with a per-session token.
   Copyright (c) 2026 Angel Edison Ayala Velásquez. MIT License. */
"use strict";
const TOKEN = document.querySelector('meta[name="tejido-token"]').content;
const PALETTE = ["#283c7a", "#a61e44", "#c08f12", "#3f8f7a", "#7a4fa0", "#d0743c", "#4f86c6", "#8c6d3f", "#c1508f",
                 "#5c8a3a", "#9aa3b8", "#6b2d3c", "#2f9fb3", "#e0a96d", "#55607a", "#b9a03a"];
const S = {schema: null, lang: "en", open: "data", inputType: "table", inputPath: "", input: {},
           wb: {indicators: "", countries: "all", years: "2015:2023"}, preview: null, prepared: null,
           builder: null, values: {}, steps: [], rest: {}, loaded: null, result: null, net: null,
           nodesDS: null, edgesDS: null, physics: true, sorts: {}, table: null, metric: null};
const $ = id => document.getElementById(id);
const clone = v => v === undefined ? undefined : JSON.parse(JSON.stringify(v));
const isObj = v => v && typeof v === "object" && !Array.isArray(v);
const nonEmpty = v => v !== undefined && v !== null && v !== "" && !(Array.isArray(v) && !v.length) && !(isObj(v) && !Object.keys(v).length);
const getPath = (o, p) => p.split(".").reduce((x, k) => (x && typeof x === "object") ? x[k] : undefined, o);
function setPath(o, p, v) { const ks = p.split("."); let x = o; ks.slice(0, -1).forEach(k => x = isObj(x[k]) ? x[k] : (x[k] = {})); x[ks.at(-1)] = v; }
function el(tag, attrs = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === "class") e.className = v; else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v === true ? "" : v);
  }
  kids.flat().forEach(c => c != null && c !== false && e.append(c.nodeType ? c : document.createTextNode(c)));
  return e;
}
/* ---------------- language ---------------- */
function t(s) { const d = S.lang === "es" && S.schema && S.schema.i18n.es; return (d && d[s]) || s; }
function tf(s, vars) { return t(s).replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? ""); }
const cap = s => s ? s[0].toUpperCase() + s.slice(1) : s;
const pretty = k => cap(String(k).replace(/_/g, " "));
const optLabel = o => t((S.schema.option_labels || {})[o] || pretty(o));
const valLabel = v => typeof v === "string" && (S.schema.option_labels || {})["val_" + v] ? t(S.schema.option_labels["val_" + v]) : v;
function statLabel(k) {
  if (S.lang === "es" && S.schema.i18n.es[k]) return cap(S.schema.i18n.es[k]);
  if (k.endsWith("_z")) return statLabel(k.slice(0, -2)) + t(" (z vs random networks)");
  for (const p of ["assortativity_", "ei_index_"]) if (k.startsWith(p) && k !== "type_assortativity")
    return t(p === "ei_index_" ? "E-I index by" : "Assortativity by") + " " + k.slice(p.length).replace(/_/g, " ");
  if ((S.schema.option_labels || {})[k]) return optLabel(k);
  for (const [p, txt] of [["iqv_", "Heterogeneity (IQV):"], ["share_", "Share:"], ["same_", "Same as respondent:"], ["ei_", "E-I index:"],
                          ["mean_", "Mean:"], ["sd_", "SD:"], ["diff_", "Difference with respondent:"], ["degree_", "Degree in layer:"],
                          ["n_", "Number of"], ["rel_", "Relation:"], ["brokerage_", "Brokerage:"]])
    if (k.startsWith(p)) return t(txt) + " " + k.slice(p.length).replace(/_/g, " ");
  return pretty(k);
}
/* ---------------- server ---------------- */
async function api(path, body) {
  const opts = {headers: {"X-Token": TOKEN}};
  if (body !== undefined) { opts.method = "POST"; opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
  let r;
  try { r = await fetch(path, opts); }               // the token travels in a header, never in the address
  catch (e) { throw new Error(t("Tejido is not answering. If you closed its window, open the program again.")); }
  const data = await r.json().catch(() => ({error: t("Unexpected server response")}));
  if (r.status === 403) throw new Error(t("This session ended. Open the interface again from the Tejido window."));
  if (!r.ok || data.error) throw new Error(t(data.error || r.statusText));
  return data;
}
async function uploadFile(file, batch) {
  const limit = (S.schema?.about?.max_upload_mb || 1024) * 1048576;
  if (file.size > limit) throw new Error(tf("{f} is larger than {n} MB.", {f: file.name, n: Math.round(limit / 1048576)}));
  if (!file.size) throw new Error(tf("{f} is empty.", {f: file.name}));
  let r;
  try { r = await fetch(`/api/upload?name=${encodeURIComponent(file.name)}&batch=${encodeURIComponent(batch)}`, {method: "POST", headers: {"X-Token": TOKEN}, body: file}); }
  catch (e) { throw new Error(t("Upload failed")); }
  const d = await r.json().catch(() => ({error: t("Unexpected server response")}));
  if (!r.ok || d.error) throw new Error(d.error || t("Upload failed")); return d;
}
function toast(msg, ok = false) {
  const x = $("toast"); x.textContent = msg; x.className = ok ? "ok" : ""; x.style.display = "block";
  clearTimeout(toast.h); toast.h = setTimeout(() => x.style.display = "none", ok ? 2600 : 8000);
}
function setStatus(text, kind = "") {                 // kind: "busy" | "ok" | "err" | ""
  const x = $("status"); S.idleStatus = false;
  x.replaceChildren(...(kind === "busy" ? [el("span", {class: "spin"})] : []), (kind === "ok" ? "✓ " : kind === "err" ? "✕ " : "") + text);
  x.className = kind === "busy" ? "" : kind; x.title = text;
  $("runbar").classList.toggle("busy", kind === "busy");
}
const fmt = v => typeof v === "number" ? (Number.isInteger(v) ? v.toLocaleString() : (+v.toFixed(4)).toLocaleString(undefined, {maximumFractionDigits: 4}))
  : typeof v === "boolean" ? t(v ? "yes" : "no") : (v ?? "");

/* ---------------- settings outside the builder (paths from the root of the configuration) ---------------- */
const F = (name, label, kind, extra = {}) => ({name, label, kind, ...extra});
const NODES_FIELDS = [
  F("nodes.path", "Table of node attributes (optional, with an id column)", "file"),
  F("nodes.id", "Id column in that table", "text", {default: "id", show_if_set: "nodes.path"})];
const FILTER_FIELDS = [
  F("filters.min_weight", "Minimum tie weight", "number"),
  F("filters.max_weight", "Maximum tie weight", "number"),
  F("filters.min_degree", "Minimum ties per node", "number"),
  F("filters.k_core", "Keep the k-core: nodes with at least k ties among themselves", "number"),
  F("filters.top_nodes", "Keep only the N most connected nodes", "number"),
  F("filters.backbone.alpha", "Backbone: keep only significant ties (alpha, e.g. 0.05)", "number"),
  F("filters.keep_edges", "Keep ties whose attribute has these values (relation=funding|agreement)", "pairs", {values: "list"}),
  F("filters.keep_nodes", "Keep nodes whose attribute has these values (type=ngo|state)", "pairs", {values: "list"}),
  F("filters.drop_nodes", "Remove nodes whose attribute has these values", "pairs", {values: "list"}),
  F("filters.ego.nodes", "Only the neighborhood of these nodes (names, comma-separated)", "list"),
  F("filters.ego.radius", "Steps around them", "number", {default: 1, show_if_set: "filters.ego.nodes"}),
  F("filters.remove_isolates", "Remove nodes without ties", "bool", {default: true}),
  F("filters.largest_component", "Keep only the largest connected part", "bool", {default: false})];
const ANALYSIS_FIELDS = [
  F("analysis.centrality", "Node measures", "measures", {default: ["degree", "betweenness", "closeness", "pagerank"]}),
  F("analysis.distance", "Path length for betweenness and closeness", "combo", {options: () => Object.keys(S.schema.distances), default: "auto",
    help: () => t(S.schema.distances[S.rest["analysis.distance"]] || "A tie attribute that is already a distance (km, days, cost)")}),
  F("analysis.betweenness_sample", "Betweenness: shortest paths from", "select", {options: ["auto", "exact", "500", "1000"], default: "auto"}),
  F("analysis.normalized", "Betweenness between 0 and 1 (off: number of paths)", "bool", {default: true}),
  F("analysis.communities", "Communities", "select", {options: () => S.schema.communities, default: "louvain"}),
  F("analysis.resolution", "Resolution (higher: more and smaller communities)", "number", {default: 1, show_if: {"analysis.communities": ["louvain", "greedy"]}}),
  F("analysis.community_attribute", "Communities given by this node attribute", "attribute", {show_if: {"analysis.communities": ["attribute"]}}),
  F("analysis.group_centrality", "Group degree, betweenness and closeness of (community or a node attribute)", "attribute", {options: ["community"]}),
  F("analysis.groups", "Positions and cohesive subgroups", "multiselect", {options: () => Object.keys(S.schema.groups)}),
  F("analysis.blocks", "Number of blocks (empty: automatic)", "number", {show_if: {"analysis.groups": ["equivalence"]}}),
  F("analysis.blockmodel.method", "Blockmodel: positions and roles", "select", {options: ["none", "concor", "structural", "generalized", "sbm"],
    labelPrefix: "bm_", default: "none", help: () => t(S.schema.option_labels["bmhelp_" + S.rest["analysis.blockmodel.method"]] || "")}),
  F("analysis.blockmodel.blocks", "Number of positions (empty: automatic)", "number",
    {show_if: {"analysis.blockmodel.method": ["concor", "structural", "generalized", "sbm"]}}),
  F("analysis.blockmodel.equivalence", "Ideal blocks", "select", {options: ["structural", "regular"], labelPrefix: "eq_", default: "structural",
    show_if: {"analysis.blockmodel.method": ["generalized"]}}),
  F("analysis.attributes", "Homophily by these node attributes (comma-separated)", "list", {suggest: true}),
  F("analysis.brokerage", "Brokerage roles between groups of this node attribute", "attribute",
    {help: () => t("Also select the measure Brokerage roles.")}),
  F("analysis.structural_holes.enabled", "Find structural holes and brokers", "bool", {default: false}),
  F("analysis.structural_holes.groups", "Holes between groups of (community or a node attribute)", "attribute",
    {options: ["community"], default: "community", show_if: {"analysis.structural_holes.enabled": [true]}}),
  F("analysis.structural_holes.broker_share", "Brokers: this share of the least constrained nodes", "number",
    {default: 0.25, show_if: {"analysis.structural_holes.enabled": [true]}}),
  F("analysis.structural_holes.hole_ratio", "A pair of groups is a hole below this share of the expected ties", "number",
    {default: 0.5, show_if: {"analysis.structural_holes.enabled": [true]}}),
  F("analysis.tie_strength.enabled", "Classify ties as strong or weak", "bool", {default: false}),
  F("analysis.tie_strength.by", "Tie strength from", "combo", {options: ["auto", "weight", "overlap", "composite"], labelPrefix: "ts_",
    default: "auto", show_if: {"analysis.tie_strength.enabled": [true]}, help: () => t(S.schema.option_labels["tshelp_" + S.rest["analysis.tie_strength.by"]] || "A tie attribute, such as closeness or frequency of contact.")}),
  F("analysis.tie_strength.levels", "Classes", "select", {options: ["2", "3"], labelPrefix: "levels_", default: "2",
    show_if: {"analysis.tie_strength.enabled": [true]}}),
  F("analysis.tie_strength.weak_values", "Weak ties: these values (comma-separated, e.g. 1, 2 or acquaintance, neighbor)", "list",
    {show_if: {"analysis.tie_strength.enabled": [true]},
     help: () => t("The values you classify as weak; all other values are strong. They take precedence over the classes and limits below.")}),
  F("analysis.tie_strength.strong_values", "Strong ties: these values (optional; the rest are intermediate)", "list",
    {show_if: {"analysis.tie_strength.enabled": [true]}}),
  F("analysis.tie_strength.weak_max", "Weak up to this value (optional, e.g. 2 = not close)", "number",
    {show_if: {"analysis.tie_strength.enabled": [true]},
     help: () => t("With “Strong from this value” too, the values between both limits are intermediate. With Automatic or Composite, both refer to the 0–1 strength index.")}),
  F("analysis.tie_strength.threshold", "Strong from this value (optional, e.g. 3 = very close)", "number",
    {show_if: {"analysis.tie_strength.enabled": [true]}}),
  F("analysis.tie_strength.cut", "Without set values: share of ties classed as weak (0–1)", "number",
    {default: 0.5, show_if: {"analysis.tie_strength.enabled": [true], "analysis.tie_strength.levels": ["2"]}}),
  F("analysis.null_model.model", "Compare with random networks", "select", {options: ["none", "configuration", "erdos_renyi"], default: "none"}),
  F("analysis.null_model.n", "Number of random networks", "number", {default: 50, show_if: {"analysis.null_model.model": ["configuration", "erdos_renyi"]}}),
  F("analysis.ergm.enabled", "Exponential random graph model (ERGM)", "bool", {default: false,
    help: () => t("Which local patterns (reciprocity, shared partners, similarity…) make ties more likely, estimated together.")}),
  F("analysis.ergm.terms", "Model terms (comma-separated)", "list", {show_if: {"analysis.ergm.enabled": [true]},
    help: () => t("Empty: edges and shared partners, gwesp(0.5), plus mutual if directed. Others: triangles, isolates, gwdegree(0.5), gwidegree, gwodegree, nodematch(attribute), nodefactor(attribute), nodecov(attribute), absdiff(attribute), nodeicov, nodeocov.")}),
  F("analysis.ergm.method", "Estimation", "select", {options: ["auto", "mple", "mcmle"], labelPrefix: "em_", default: "auto",
    show_if: {"analysis.ergm.enabled": [true]}}),
  F("analysis.ergm.gof", "Goodness of fit with simulated networks", "bool", {default: true, show_if: {"analysis.ergm.enabled": [true]}}),
  F("analysis.seed", "Random seed (same seed, same results)", "number", {default: 2026})];
const EXTEND_FIELDS = [
  F("layers.by", "Layers: one per value of this tie attribute (empty: off)", "combo", {options: ["relation", "main_relation"]}),
  F("layers.qap", "QAP permutations to test overlap between layers", "number", {default: 200, show_if_set: "layers.by"}),
  F("time.column", "Over time: date or period column (empty: off)", "column"),
  F("time.every", "Period", "combo", {options: ["year", "quarter", "month", "week", "day"], show_if_set: "time.column",
    help: () => t("Or a number to group numeric values (e.g. 5 for five-year groups).")}),
  F("time.cumulative", "Each period includes the earlier ones", "bool", {default: false, show_if_set: "time.column"}),
  F("time.export_snapshots", "Save the network of each period", "bool", {default: false, show_if_set: "time.column"})];
const SAVE_FIELDS = [
  F("output.formats", "Files to save", "multiselect", {options: () => Object.keys(S.schema.formats), default: ["csv", "xlsx", "html", "report"]}),
  F("output.language", "Report language", "select", {options: ["en", "es"], default: () => S.lang}),
  F("output.html.color_by", "Interactive page: color nodes by", "attribute", {default: "community"}),
  F("output.html.size_by", "Interactive page: size nodes by", "attribute", {default: "pagerank"})];
const REST = [...NODES_FIELDS, ...FILTER_FIELDS, ...ANALYSIS_FIELDS, ...EXTEND_FIELDS, ...SAVE_FIELDS];
const val = x => typeof x === "function" ? x() : x;

/* ---------------- generic form controls ---------------- */
function visible(f, vals) {
  if (f.input_types && !f.input_types.includes(S.inputType)) return false;
  if (f.show_if_set && !nonEmpty(vals[f.show_if_set])) return false;
  return Object.entries(f.show_if || {}).every(([k, list]) => {
    const v = vals[k]; return Array.isArray(v) ? v.some(x => list.includes(x)) : list.includes(v);
  });
}
const dependsOn = (fields, name) => fields.some(f => f.show_if_set === name || (f.show_if && name in f.show_if));
function columns() { return (S.prepared || S.preview)?.columns || []; }
function attrSuggestions() {
  const R = S.result, out = new Set(["type", "community", "relation"]);
  if (R) [...R.categorical, ...R.numeric].forEach(a => out.add(a));
  columns().forEach(c => out.add(c));
  return [...out];
}
function pairsToText(o) {
  return isObj(o) ? Object.entries(o).map(([k, v]) => `${k}=${Array.isArray(v) ? v.join("|") : v}`).join(", ") : "";
}
function textToPairs(s, kind) {
  const out = {};
  String(s).split(",").map(x => x.trim()).filter(Boolean).forEach(p => {
    const i = p.indexOf("="); if (i < 1) return;
    const k = p.slice(0, i).trim(), v = p.slice(i + 1).trim();
    out[k] = kind === "list" ? v.split("|").map(x => x.trim()).filter(Boolean) : kind === "number" && v !== "" && !isNaN(v) ? Number(v) : v;
  });
  return out;
}
function accept(f, v) {           // keeps a loaded value only if it fits the control
  if (v === undefined || v === null) return undefined;
  if (["columns", "multiselect", "measures", "list"].includes(f.kind)) return Array.isArray(v) ? v : (typeof v === "string" || typeof v === "number" ? [v] : undefined);
  if (f.kind === "pairs") return isObj(v) ? v : undefined;
  if (f.kind === "bool") return typeof v === "boolean" ? v : undefined;
  if (f.kind === "number") return typeof v === "number" ? v : (v !== "" && !isNaN(v) ? Number(v) : undefined);
  return isObj(v) || Array.isArray(v) ? undefined : String(v);
}
function datalist(options, labelFn) {
  const id = "dl-" + Math.random().toString(36).slice(2, 9);
  return [id, el("datalist", {id}, options.map(o => el("option", {value: o, label: labelFn ? labelFn(o) : undefined})))];
}
function renderFields(box, fields, vals, rerender) {
  box.replaceChildren();
  for (const f of fields) if (visible(f, vals)) box.append(control(f, vals, () => { if (f.reload || dependsOn(fields, f.name)) rerender(); updateLoom(); }));
}
function control(f, vals, changed) {
  const v = vals[f.name];
  const set = x => { if (nonEmpty(x) || typeof x === "boolean" || typeof x === "number") vals[f.name] = x; else delete vals[f.name]; };
  const wrap = ctl => el("div", {class: "field"}, el("label", {text: t(f.label) + (f.required ? " *" : "")}), ctl,
    f.help ? el("div", {class: "hint", text: val(f.help)}) : null);
  const textInput = (value, onval, extra = {}) => el("input", {type: "text", value: value ?? "", ...extra,
    oninput: e => onval(e.target.value), onchange: changed});
  switch (f.kind) {
    case "bool":
      return el("label", {class: "check"}, el("input", {type: "checkbox", checked: !!v, onchange: e => { set(e.target.checked); changed(); }}), t(f.label));
    case "select":
      return wrap(el("select", {onchange: e => { set(e.target.value); changed(); }},
        val(f.options).map(o => el("option", {value: o, text: optLabel((f.labelPrefix || "") + o), selected: o === v}))));
    case "number":
      return wrap(el("input", {type: "number", step: "any", value: v ?? "", oninput: e => set(e.target.value === "" ? undefined : Number(e.target.value)), onchange: changed}));
    case "list":
      return wrap(textInput((v || []).join(", "), s => set(s.split(",").map(x => x.trim()).filter(Boolean)
        .map(x => f.numeric && !isNaN(x) ? Number(x) : x).reduce((a, x, i, arr) => f.numeric && arr.length === 1 ? x : [...a, x], [])),
        f.suggest ? {placeholder: attrSuggestions().slice(0, 4).join(", ")} : {}));
    case "pairs":
      return wrap(textInput(pairsToText(v), s => set(textToPairs(s, f.values)), {placeholder: "a=b, c=d"}));
    case "column": {
      const box = textInput(v, s => set(s || undefined), {list: "dl-cols", placeholder: columns().length ? t("Choose or type a column") : t("Load data first")});
      return wrap(box);
    }
    case "attribute": case "combo": {
      const opts = f.kind === "attribute" ? [...(f.options || []), ...attrSuggestions()] : val(f.options);
      const [id, dl] = datalist([...new Set(opts)], o => f.kind === "combo" ? optLabel(o) : undefined);
      return wrap(el("div", {}, textInput(v, s => set(s || undefined), {list: id}), dl));
    }
    case "columns": case "multiselect": {
      const opts = f.kind === "columns" ? [...new Set([...columns(), ...(v || [])])] : val(f.options), cur = new Set(v || []);
      if (!opts.length) return wrap(el("div", {class: "hint", text: t("Load data to list the columns.")}));
      return wrap(el("div", {class: "chips"}, opts.map(o => el("span", {class: "chip" + (cur.has(o) ? " on" : ""), tabindex: 0, role: "checkbox",
        "aria-checked": String(cur.has(o)), text: f.kind === "multiselect" ? optLabel(o) : o,
        title: f.kind === "multiselect" && S.schema.groups[o] ? t(S.schema.groups[o]) : undefined,
        onclick: e => { cur.has(o) ? cur.delete(o) : cur.add(o); e.target.classList.toggle("on"); set([...cur]); changed(); },
        onkeydown: e => { if (e.key === " " || e.key === "Enter") { e.preventDefault(); e.target.click(); } }}))));
    }
    case "measures": return measuresControl(f, vals, set, changed);
    case "file": {
      const pick = el("input", {type: "file", class: "hidden", onchange: async e => {
        const file = e.target.files[0]; if (!file) return;
        try { set((await uploadFile(file, "aux" + Date.now().toString(36))).file); changed(); rerenderOpen(); } catch (err) { toast(err.message); }
      }});
      return wrap(el("div", {class: "filerow"}, el("span", {class: "hint", text: v ? String(v).split(/[\\/]/).pop() : t("none")}),
        el("button", {class: "btn small", type: "button", text: t("Choose…"), onclick: () => pick.click()}),
        v ? el("button", {class: "btn small", type: "button", text: t("Remove"), onclick: () => { set(undefined); changed(); rerenderOpen(); }}) : null, pick));
    }
    default:
      return wrap(textInput(v, s => set(s || undefined)));
  }
}
function measuresControl(f, vals, set, changed) {
  const cur = new Set(vals[f.name] || []), box = el("div", {class: "field"}, el("span", {class: "flabel", text: t(f.label)}));
  const chip = m => el("span", {class: "chip" + (cur.has(m) ? " on" : ""), tabindex: 0, role: "checkbox", "aria-checked": String(cur.has(m)),
    text: optLabel(m), title: t(S.schema.measures[m]),
    onclick: e => { cur.has(m) ? cur.delete(m) : cur.add(m); e.target.classList.toggle("on"); set([...cur]); changed(); },
    onkeydown: e => { if (e.key === " " || e.key === "Enter") { e.preventDefault(); e.target.click(); } }});
  for (const [fam, list] of Object.entries(S.schema.families)) {
    const all = list.every(m => cur.has(m));
    box.append(el("div", {class: "fam"}, el("span", {text: optLabel("family_" + fam)}),
      el("button", {class: "link", type: "button", text: t(all ? "none" : "all"), onclick: () => {
        list.forEach(m => all ? cur.delete(m) : cur.add(m)); set([...cur]); changed(); rerenderOpen(); }})),
      el("div", {class: "chips"}, list.map(chip)));
  }
  return box;
}

/* ---------------- the stages ---------------- */
const STAGES = [
  {id: "data", title: "Data", render: renderData, done: () => !!S.inputPath || (S.inputType === "worldbank_api" && !!S.wb.indicators),
   sum: () => S.inputType === "worldbank_api" ? (S.wb.indicators || t("World Bank online")) :
     (S.inputPath ? S.inputPath.split(/[\\/]/).filter(Boolean).pop() + (S.preview?.rows ? ` · ${S.preview.rows.toLocaleString()} ${t("rows")}` : "") : t("choose your data"))},
  {id: "prepare", title: "Prepare", render: renderPrepare, done: () => S.steps.length > 0,
   sum: () => S.steps.length ? tf("{n} step(s)", {n: S.steps.length}) : t("optional")},
  {id: "build", title: "Build the network", render: renderBuild, done: () => !!S.builder,
   sum: () => S.builder ? t(S.schema.builders[S.builder].title) : t("choose a type")},
  {id: "filter", title: "Filter", render: b => renderRest(b, "filter", FILTER_FIELDS), done: () => !!S.builder,
   sum: () => { const n = FILTER_FIELDS.filter(f => !["bool"].includes(f.kind) && nonEmpty(S.rest[f.name]) && f.name !== "filters.ego.radius").length;
                return n ? tf("{n} active", {n}) : t("whole network"); }},
  {id: "analyze", title: "Analyze", render: b => renderRest(b, "analyze", ANALYSIS_FIELDS), done: () => !!S.builder,
   sum: () => (n => tf(n === 1 ? "{n} measure" : "{n} measures", {n}))((S.rest["analysis.centrality"] || []).length) + " · " + optLabel(S.rest["analysis.communities"] || "none")},
  {id: "extend", title: "Layers and time", render: b => renderRest(b, "extend", EXTEND_FIELDS),
   done: () => nonEmpty(S.rest["layers.by"]) || nonEmpty(S.rest["time.column"]),
   sum: () => [S.rest["layers.by"] ? t("layers") : "", S.rest["time.column"] ? t("over time") : ""].filter(Boolean).join(" · ") || t("off")},
  {id: "save", title: "Save results", render: b => renderRest(b, "save", SAVE_FIELDS), done: () => !!S.builder,
   sum: () => (S.rest["output.formats"] || []).join(", ")}];
function renderLoom() {
  const loom = el("div", {class: "warp", id: "warp"}); $("loom").replaceChildren(loom);
  STAGES.forEach((st, i) => {
    const body = el("div", {class: "stage-body", id: "body-" + st.id});
    const head = el("button", {class: "stage-head", type: "button", "aria-expanded": String(S.open === st.id), "aria-controls": "body-" + st.id,
      onclick: () => openStage(S.open === st.id ? null : st.id)},
      el("span", {class: "knot"}), el("span", {class: "stage-text"},
        el("span", {class: "stage-title"}, el("b", {text: String(i + 1)}), t(st.title)), el("span", {class: "stage-sum", id: "sum-" + st.id})));
    loom.append(el("section", {class: "stage", id: "stage-" + st.id}, head, body));
  });
  if (S.open) renderStage(S.open);
  updateLoom();
}
function openStage(id) {
  S.open = id;
  STAGES.forEach(st => {
    const sec = $("stage-" + st.id); sec.classList.toggle("open", st.id === id);
    sec.querySelector(".stage-head").setAttribute("aria-expanded", String(st.id === id));
  });
  if (id) { renderStage(id); $("stage-" + id).scrollIntoView({block: "nearest"}); }
  updateLoom();
}
function renderStage(id) { const b = $("body-" + id); if (!b) return; STAGES.find(s => s.id === id).render(b); $("stage-" + id).classList.toggle("open", S.open === id); }
const rerenderOpen = () => S.open && renderStage(S.open);
function weave(last) {                      // the cord is woven down to the knot of the last stage that is set up
  const warp = $("warp"); if (!warp) return;
  const knot = last >= 0 && $("stage-" + STAGES[last].id)?.querySelector(".knot");
  const top = warp.getBoundingClientRect().top, px = knot ? knot.getBoundingClientRect().top - top + knot.offsetHeight / 2 - 24 : 0;
  warp.style.setProperty("--done", Math.max(0, px) + "px");
}
window.addEventListener("resize", () => updateLoom());
function updateLoom() {
  let last = -1;
  STAGES.forEach((st, i) => {
    const done = st.done(); if (done) last = i;
    $("stage-" + st.id)?.classList.toggle("done", done);
    const s = $("sum-" + st.id); if (s) { s.textContent = st.sum(); s.title = s.textContent; }
  });
  weave(last);
  $("dl-cols").replaceChildren(...columns().map(c => el("option", {value: c})));
}
function renderRest(box, id, fields) { renderFields(box, fields, S.rest, () => renderStage(id)); }

/* 1 · data */
function renderData(box) {
  const top = topInput(S.inputType), subs = S.schema.inputs.filter(x => x.parent === top);
  box.replaceChildren(el("div", {class: "seg"}, S.schema.inputs.filter(x => !x.parent).map(x => el("button", {type: "button",
    class: x.id === top ? "on" : "", onclick: () => { if (x.id !== top) setInputType(x.id); }}, t(x.title), el("small", {text: t(x.help)})))));
  if (subs.length) box.append(el("div", {class: "field"}, el("label", {text: t("Table source")}),
    el("select", {onchange: e => setInputType(e.target.value)},
      [S.schema.inputs.find(x => x.id === top), ...subs].map(x => el("option", {value: x.id, text: t(x.sub || x.title), selected: x.id === S.inputType}))),
    S.inputType === top ? el("div", {class: "hint", text: t("Indicator data (countries or regions × years, from the World Bank or similar sources) are recognized automatically.")}) : null));
  if (S.inputType === "worldbank_api") {
    const wb = (k, label, ph) => el("div", {class: "field"}, el("label", {text: t(label)}),
      el("input", {type: "text", value: S.wb[k], placeholder: ph || "", oninput: e => { S.wb[k] = e.target.value; updateLoom(); },
      onchange: () => { S.prepared = null; if (S.wb.indicators.trim()) loadPreview(); }}));
    box.append(wb("indicators", "Indicator codes (comma-separated)", "NY.GDP.PCAP.KD, SP.DYN.LE00.IN"),
      el("div", {class: "row"}, wb("countries", "Countries"), wb("years", "Years", "2015:2023")),
      el("p", {class: "hint", text: t("Find indicator codes at data.worldbank.org (the code appears in each indicator's address).")}));
    return;
  }
  const multiple = S.inputType === "documents";
  const picker = el("input", {type: "file", class: "hidden", multiple, onchange: e => upload([...e.target.files])});
  const drop = el("div", {class: "drop", tabindex: 0, role: "button", onclick: () => picker.click(),
    onkeydown: e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); picker.click(); } }},
    t(multiple ? "Drop documents here or click to choose (PDF, Word, TXT, HTML)" : "Drop a file here or click to choose"));
  ["dragover", "dragenter"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add("over"); }));
  ["dragleave", "drop"].forEach(ev => drop.addEventListener(ev, () => drop.classList.remove("over")));
  drop.addEventListener("drop", e => { e.preventDefault(); upload([...e.dataTransfer.files]); });
  const path = el("input", {type: "text", value: S.inputPath, placeholder: multiple ? "C:\\datos\\informes" : "C:\\datos\\archivo.csv  ·  https://…/datos.csv",
    oninput: e => S.inputPath = e.target.value.trim(), onchange: () => { S.prepared = null; S.autoOff = false; loadPreview(); }});
  box.append(drop, picker, el("div", {class: "field"}, el("label", {text: t("…or a path or web address")}), path));
  const extra = el("div");
  const sheet = F("sheet", S.inputType === "indicators" ? "Excel sheet (name or number; empty: the one with data)" : "Excel sheet (name or number; empty: the first)", "text", {reload: true});
  const xf = multiple ? [F("metadata", "Document details table (doc_id, date, author…), optional", "file", {reload: true})]
    : /\.xls[xm]?$/i.test(S.inputPath) ? [sheet] : [];
  renderFields(extra, xf, S.input, () => { renderStage("data"); loadPreview(); });
  box.append(extra);
  if (S.inputType === "indicators") {        // corrections when the automatic recognition gets something wrong
    const adj = el("div");
    renderFields(adj, INDICATOR_FIELDS, S.input, () => { S.prepared = null; renderStage("data"); loadPreview(); });
    box.append(el("details", {class: "adjust", open: INDICATOR_FIELDS.some(f => nonEmpty(S.input[f.name])) || undefined},
      el("summary", {text: t("Adjust how the data are recognized")}),
      el("p", {class: "hint", text: t("Leave empty what was recognized well. Columns are those of the file, as in the preview.")}), adj));
  }
  box.append(el("div", {id: "preview"}));
  renderPreview($("preview"), S.preview);
}
const INDICATOR_FIELDS = [
  F("layout", "Layout", "select", {reload: true, options: ["auto", "years_wide", "long", "indicators_wide", "units_wide"], labelPrefix: "layout_", default: "auto"}),
  F("unit", "Column of units (countries, regions…)", "column", {reload: true}),
  F("unit_code", "Column of unit codes (optional)", "column", {reload: true}),
  F("indicator", "Column of indicator names", "column", {reload: true, show_if: {layout: ["auto", "years_wide", "long", undefined]}}),
  F("year", "Column of years", "column", {reload: true, show_if: {layout: ["auto", "long", "indicators_wide", "units_wide", undefined]}}),
  F("value", "Column of values", "column", {reload: true, show_if: {layout: ["auto", "long", undefined]}}),
  F("header_row", "Header row (1 = first; empty: automatic)", "number", {reload: true}),
  F("indicator_name", "Indicator name, when the file has only one", "text", {reload: true}),
  F("missing", "Other marks of missing values (comma-separated)", "list", {reload: true})];
const wbInput = () => ({indicators: S.wb.indicators.split(",").map(x => x.trim()).filter(Boolean), countries: S.wb.countries, years: S.wb.years});
const previewInput = () => S.inputType === "worldbank_api" ? {...S.input, ...wbInput()} : S.input;
const topInput = x => (S.schema.inputs.find(i => i.id === x) || {}).parent || x;
function setInputType(x) {
  const files = ["table", "indicators"], keep = files.includes(S.inputType) && files.includes(x) && S.inputPath;
  S.autoOff = x === "table" && S.inputType === "indicators";      // the user chose "any table": do not switch back
  S.inputType = x; S.preview = S.prepared = null;
  if (keep) S.input = S.input.sheet ? {sheet: S.input.sheet} : {}; else { S.inputPath = ""; S.input = {}; }
  const auto = {documents: "text", indicators: "similarity", worldbank_api: "similarity"}[x];
  if (auto) selectBuilder(auto);
  else if (S.builder && !S.schema.builders[S.builder].inputs.includes(x)) S.builder = null;
  if (S.builder === "similarity" && x === "table" && S.values.format === "worldbank") S.values.format = "wide";
  renderStage("data"); updateLoom();
  if (keep) loadPreview();
}
async function upload(files) {
  if (!files.length) return;
  setStatus(tf("Copying {n} file(s) into the workspace…", {n: files.length}), "busy");
  try {
    let last; const batch = Date.now().toString(36);
    for (const f of files) last = await uploadFile(f, batch);
    S.inputPath = (S.inputType === "documents" || files.length > 1) ? last.folder : last.file; S.prepared = null; S.autoOff = false;
    renderStage("data"); await loadPreview();
  } catch (e) { toast(e.message); setStatus(t("Upload failed.")); }
}
async function loadPreview() {
  if (!S.inputPath && !(S.inputType === "worldbank_api" && S.wb.indicators.trim())) return;
  setStatus(t(S.inputType === "worldbank_api" ? "Downloading from the World Bank…" : "Reading data…"), "busy");
  try {
    S.preview = await api("/api/preview", {type: S.inputType, path: S.inputPath, input: previewInput(), detect: !S.autoOff});
    if (S.inputType === "table" && S.preview.kind === "indicators" && !S.autoOff) {   // units × years recognized
      S.inputType = "indicators"; selectBuilder("similarity");
      if (S.open === "data") renderStage("data");
      toast(t("Indicator data recognized (countries or regions × years). To use it as an ordinary table, choose “Any table” in Table source."), true);
    }
    if (S.preview.kind === "indicators" && S.preview.n_indicators === 1 && S.builder === "similarity")
      S.values.features_from = "years";           // one indicator: compare its values over the years
    setStatus(t("Data loaded. Next: build the network."));
  } catch (e) { S.preview = null; toast(e.message); setStatus(t("Could not read the data.")); }
  if (S.open === "data") renderPreview($("preview"), S.preview);
  updateLoom();
}
const ROLE_LABELS = {unit: "units", unit_code: "codes", indicator: "indicators", indicator_code: "indicator codes", year: "years", value: "values"};
function renderPreview(box, p) {
  if (!box) return; box.replaceChildren(); if (!p) return;
  const w = el("div", {class: "preview"});
  if (p.kind === "table") {
    w.append(el("div", {text: tf("{r} rows × {c} columns", {r: p.rows.toLocaleString(), c: p.columns.length}) + (p.prepared ? " · " + t("after preparing") : "")}));
    const tb = el("table", {}, el("tr", {}, p.columns.slice(0, 14).map(c => el("th", {text: c}))));
    p.head.forEach(r => tb.append(el("tr", {}, p.columns.slice(0, 14).map(c => el("td", {text: String(r[c] ?? "").slice(0, 40)})))));
    w.append(tb);
  } else if (p.kind === "documents") {
    w.append(el("div", {text: tf("{n} document(s), {c} characters", {n: p.documents, c: p.characters.toLocaleString()})}),
      el("div", {class: "hint", text: p.names.join(", ")}), el("div", {text: p.sample.slice(0, 300) + "…"}));
  } else if (p.kind === "indicators") {
    const roles = Object.entries(p.roles || {}).map(([r, c]) => `${t(ROLE_LABELS[r] || r)}: «${c}»`).join(" · ");
    w.append(...[el("div", {text: tf(p.n_indicators === 1 ? "{u} units, 1 indicator" : "{u} units, {n} indicators", {u: p.units.toLocaleString(), n: p.n_indicators.toLocaleString()})
        + (p.years ? ` · ${p.years[0]}–${p.years[1]}` : "") + (p.aggregates ? " · " + tf("{a} aggregates (world, regions…)", {a: p.aggregates}) : "")}),
      el("div", {class: "hint", text: t("Recognized as") + ": " + optLabel("layout_" + p.layout) + (p.header_row > 1 ? " · " + tf("header in row {r}", {r: p.header_row}) : "")
        + (p.sheet ? " · " + tf("sheet «{s}»", {s: p.sheet}) : "") + (roles ? " · " + roles : "")
        + (p.dimensions.length ? " · " + tf("series split by: {d}", {d: p.dimensions.join(", ")}) : "")}),
      p.not_numeric ? el("div", {class: "hint", text: tf("{n} cells that are not numbers were treated as missing.", {n: p.not_numeric.toLocaleString()})}) : null,
      p.repeated ? el("div", {class: "hint", text: tf("{n} values repeat the same unit, indicator and year; they will be averaged.", {n: p.repeated.toLocaleString()})}) : null,
      ...p.indicators.slice(0, 30).map(i => el("div", {class: "hint", text: i.code === i.name ? i.name : `${i.code}: ${i.name}`})),
      p.n_indicators > 30 ? el("div", {class: "hint", text: "…"}) : null].filter(Boolean));
  }
  box.append(w);
}

/* 2 · prepare */
const stepSig = () => JSON.stringify(collectSteps());
function newStep(name) {
  const v = {}; S.schema.steps[name].fields.forEach(f => { if (f.default !== undefined) v[f.name] = clone(f.default); });
  return {name, v};
}
function renderPrepare(box) {
  box.replaceChildren(el("p", {class: "hint", text: t("Steps run in order, before the network is built.")}));
  S.steps.forEach((st, i) => {
    const spec = S.schema.steps[st.name], fields = el("div");
    renderFields(fields, spec.fields, st.v, () => renderStage("prepare"));
    const move = d => { const j = i + d; if (j < 0 || j >= S.steps.length) return; [S.steps[i], S.steps[j]] = [S.steps[j], S.steps[i]]; renderStage("prepare"); updateLoom(); };
    box.append(el("div", {class: "step"}, el("div", {class: "step-head"}, el("b", {text: `${i + 1}. ${optLabel("step_" + st.name)}`}),
      el("button", {class: "btn icon", type: "button", title: t("Move up"), text: "↑", onclick: () => move(-1)}),
      el("button", {class: "btn icon", type: "button", title: t("Move down"), text: "↓", onclick: () => move(1)}),
      el("button", {class: "btn icon", type: "button", title: t("Remove step"), text: "✕", onclick: () => { S.steps.splice(i, 1); renderStage("prepare"); updateLoom(); }})),
      el("div", {class: "hint", text: t(spec.help)}), fields));
  });
  const add = el("select", {"aria-label": t("Add a step"), onchange: e => { if (!e.target.value) return; S.steps.push(newStep(e.target.value)); renderStage("prepare"); updateLoom(); }},
    el("option", {value: "", text: t("+ Add a step…")}),
    Object.keys(S.schema.steps).map(k => el("option", {value: k, text: optLabel("step_" + k)})));
  const pv = el("div");
  box.append(el("div", {class: "row", style: "margin-top:10px"}, add,
    el("button", {class: "btn", type: "button", text: t("Preview the result"), onclick: async () => { await refreshPrepared(true); renderPreview(pv, S.prepared || S.preview); }})), pv);
  if (S.prepared) renderPreview(pv, S.prepared);
}
async function refreshPrepared(force) {
  if (!S.steps.length) { S.prepared = null; return; }
  if (!force && S.prepared && S.prepared.sig === stepSig()) return;
  if (!S.inputPath && S.inputType !== "worldbank_api") return;
  setStatus(t("Preparing the data…"), "busy");
  try {
    S.prepared = {...await api("/api/preview", {type: S.inputType, path: S.inputPath, input: previewInput(), prepare: collectSteps()}), sig: stepSig()};
    setStatus(t("Prepared data ready."));
  } catch (e) { toast(e.message); setStatus(t("A prepare step failed: check it.")); }
  updateLoom();
}

/* 3 · build */
function selectBuilder(id) {
  if (S.builder !== id) { S.builder = id; S.values = {}; }
  S.schema.builders[id].fields.forEach(f => { if (!(f.name in S.values) && f.default !== undefined) S.values[f.name] = clone(f.default); });
  if (id === "similarity") S.values.format = ["indicators", "worldbank_api"].includes(S.inputType) ? "worldbank" : (S.values.format === "worldbank" ? "wide" : S.values.format);
}
function renderBuild(box) {
  if (S.steps.length && (!S.prepared || S.prepared.sig !== stepSig()))
    refreshPrepared().then(() => S.open === "build" && renderBuild(box));
  box.replaceChildren(el("div", {class: "builders"}, Object.entries(S.schema.builders).map(([id, b]) => {
    const ok = b.inputs.includes(S.inputType);
    return el("button", {type: "button", class: "builder" + (S.builder === id ? " on" : "") + (ok ? "" : " off"), disabled: !ok,
      title: ok ? t(b.help) : t("Not available for this kind of data"),
      onclick: () => { selectBuilder(id); renderStage("build"); updateLoom(); }}, el("b", {text: t(b.title)}), el("small", {text: t(b.help)}));
  })));
  if (!S.builder) return box.append(el("p", {class: "hint", text: t("Choose what a tie means in your data.")}));
  const fields = el("div"), nodes = el("div");
  renderFields(fields, S.schema.builders[S.builder].fields, S.values, () => renderStage("build"));
  renderFields(nodes, NODES_FIELDS, S.rest, () => renderStage("build"));
  box.append(el("p", {class: "hint", text: t(S.schema.builders[S.builder].help)}), fields, nodes);
}

/* ---------------- configuration ---------------- */
function nested(fields, vals) {
  const out = {};
  for (const f of fields) {
    if (!visible(f, vals)) continue;
    const v = vals[f.name];
    if (nonEmpty(v) || typeof v === "boolean" || typeof v === "number") setPath(out, f.key || f.name, clone(v));
  }
  return out;
}
function collectSteps() {
  return S.steps.map(({name, v}) => {
    const spec = S.schema.steps[name];
    if (spec.mode === "single") {
      const x = v.value, cols = spec.fields[0].kind === "columns";
      return {[name]: cols && !nonEmpty(x) && ["dropna", "deduplicate"].includes(name) ? true : (x ?? "")};
    }
    if (spec.mode === "keyed") return {[name]: {[v.key || ""]: v.value ?? (name === "datetime" ? null : "")}};
    return {[name]: nested(spec.fields, v)};
  });
}
function parseSteps(list) {
  const out = [];
  for (const s of list || []) {
    if (!isObj(s)) continue;
    const [name, arg] = Object.entries(s)[0] || [];
    const spec = S.schema.steps[name]; if (!spec) continue;
    if (spec.mode === "single") out.push({name, v: arg === true ? {} : {value: accept(spec.fields[0], arg) ?? arg}});
    else if (spec.mode === "keyed") Object.entries(isObj(arg) ? arg : {}).forEach(([k, x]) => out.push({name, v: {key: k, value: accept(spec.fields[1], x) ?? x}}));
    else { const v = {}; spec.fields.forEach(f => { const x = accept(f, getPath(arg, f.name)); if (x !== undefined) v[f.name] = x; }); out.push({name, v}); }
  }
  return out;
}
function collectConfig() {
  const cfg = nested(REST, S.rest);
  cfg.project = $("project").value.trim() || "my_network";
  const input = {...S.input, type: S.inputType};
  if (S.inputType === "worldbank_api") Object.assign(input, wbInput());
  else input.path = S.inputPath;
  cfg.input = input;
  if (S.steps.length) cfg.prepare = collectSteps();
  const builder = {type: S.builder, ...(S.builder ? nested(S.schema.builders[S.builder].fields, S.values) : {})};
  if (builder.relations === "none") builder.relations = {};
  if (builder.relations === "custom") builder.relations = builder.relations_custom || {};
  delete builder.relations_custom;
  const lb = S.loaded?.builder;
  if (lb && lb.type === S.builder) {            // keep options the forms do not show
    const shown = new Set(S.schema.builders[S.builder].fields.map(f => (f.key || f.name).split(".")[0]));
    Object.entries(lb).forEach(([k, v]) => { if (!shown.has(k) && !(k in builder)) builder[k] = clone(v); });
  }
  cfg.builder = builder;
  const a = cfg.analysis || (cfg.analysis = {});
  if (!a.null_model || a.null_model.model === "none") delete a.null_model;
  for (const k of ["structural_holes", "tie_strength", "ergm"]) {
    if (!a[k] || !a[k].enabled) delete a[k]; else delete a[k].enabled;
  }
  if (!a.blockmodel || !a.blockmodel.method || a.blockmodel.method === "none") delete a.blockmodel;
  else if (a.blockmodel.blocks === "" || a.blockmodel.blocks == null) delete a.blockmodel.blocks;
  if (a.tie_strength?.levels) a.tie_strength.levels = Number(a.tie_strength.levels);
  if (a.betweenness_sample && !isNaN(a.betweenness_sample)) a.betweenness_sample = Number(a.betweenness_sample);
  if (cfg.time && !isNaN(cfg.time.every)) cfg.time.every = Number(cfg.time.every);
  cfg.output = cfg.output || {}; cfg.output.html = {...(cfg.output.html || {}), offline: true};
  const look = TS.diff(S.style); delete cfg.output.html.style; if (Object.keys(look).length) cfg.output.html.style = look;
  for (const k of ["filters", "analysis", "output", "layers", "time", "nodes"]) {   // keep settings the forms do not show
    if (isObj(S.loaded?.[k])) for (const [x, v] of Object.entries(S.loaded[k])) if (!(x in (cfg[k] || {})) && !REST.some(f => f.name.startsWith(k + "." + x)))
      (cfg[k] ||= {})[x] = clone(v);
  }
  return cfg;
}
function validate(cfg) {
  if (S.inputType !== "worldbank_api" && !cfg.input.path) return t("Choose your data first (stage 1).");
  if (S.inputType === "worldbank_api" && !cfg.input.indicators.length) return t("Write at least one World Bank indicator code.");
  if (!S.builder) return t("Choose a network type (stage 3).");
  const miss = S.schema.builders[S.builder].fields.filter(f => f.required && visible(f, S.values) && !nonEmpty(S.values[f.name]));
  if (miss.length) return t("Please fill:") + " " + miss.map(f => t(f.label)).join(", ");
  return null;
}
function restDefaults() {
  const r = {}; REST.forEach(f => { const d = val(f.default); if (d !== undefined) r[f.name] = clone(d); }); return r;
}
function applyConfig(cfg) {
  S.loaded = clone(cfg);
  $("project").value = cfg.project || "my_network";
  const i = cfg.input || {};
  S.inputType = S.schema.inputs.some(x => x.id === i.type) ? i.type : "table";
  S.inputPath = i.path || "";
  S.input = Object.fromEntries(Object.entries(i).filter(([k]) => ["sheet", "metadata", "encoding", "preset", "source",
    "layout", "unit", "unit_code", "indicator", "indicator_code", "year", "value", "header_row", "indicator_name", "missing"].includes(k)));
  S.autoOff = false;
  if (S.inputType === "worldbank_api") S.wb = {indicators: (i.indicators || []).join(", "), countries: i.countries || "all", years: i.years || "2015:2023"};
  S.steps = parseSteps(cfg.prepare);
  S.preview = S.prepared = null;
  S.builder = null; S.values = {};
  const b = cfg.builder || {};
  if (S.schema.builders[b.type]) {
    S.builder = b.type;
    S.schema.builders[b.type].fields.forEach(f => {
      let x = getPath(b, f.key || f.name);
      if (f.name === "relations" && isObj(x)) { S.values.relations_custom = x; x = Object.keys(x).length ? "custom" : "none"; }
      x = f.name === "relations_custom" ? S.values.relations_custom : accept(f, x);
      if (x === undefined) x = clone(f.default);
      if (x !== undefined) S.values[f.name] = x;
    });
  }
  if (isObj(cfg.output?.html?.style)) { S.style = TS.clean(cfg.output.html.style); saveStyle(); }
  S.rest = restDefaults();
  REST.forEach(f => {
    let x = getPath(cfg, f.name);
    if (f.name === "analysis.centrality" && x === "all") x = Object.keys(S.schema.measures);
    if (f.name === "filters.backbone.alpha" && x === undefined && cfg.filters?.backbone) x = typeof cfg.filters.backbone === "number" ? cfg.filters.backbone : 0.05;
    if (f.name === "filters.ego.nodes" && x === undefined && cfg.filters?.ego && !isObj(cfg.filters.ego)) x = cfg.filters.ego;
    if (f.name === "analysis.null_model.model" && x === undefined && cfg.analysis?.null_model) x = "configuration";
    for (const k of ["structural_holes", "tie_strength", "ergm"]) if (f.name === `analysis.${k}.enabled`) {
      const y = cfg.analysis?.[k]; x = y === true || (isObj(y) && y.enabled !== false);
    }
    x = accept(f, x);
    if (x !== undefined) S.rest[f.name] = x;
  });
  if (cfg.time && typeof cfg.time === "string") S.rest["time.column"] = cfg.time;
  if (cfg.layers && typeof cfg.layers === "string") S.rest["layers.by"] = cfg.layers;
  renderLoom();
}

/* ---------------- run ---------------- */
async function run() {
  const cfg = collectConfig(), problem = validate(cfg);
  if (problem) return toast(problem);
  if (S.running) return;
  $("log").textContent = "";
  try { await api("/api/run", {config: cfg}); } catch (e) { toast(e.message); return setStatus(e.message, "err"); }
  await follow();
}
/* Follows the build that is running on the server until it ends (also after the page is reloaded). */
async function follow() {
  S.running = true; $("btn-run").disabled = true; setStatus(t("Building the network…"), "busy");
  let since = 0, misses = 0;
  try {
    for (;;) {
      await new Promise(r => setTimeout(r, 500));
      let st;
      try { st = await api(`/api/status?since=${since}`); misses = 0; }
      catch (e) { if (++misses < 6) continue; throw e; }       // a slow moment of the computer is not a failure
      since = st.next ?? since;
      if (st.log.length) { $("log").textContent += st.log.join("\n") + "\n"; $("p-log").scrollTop = $("p-log").scrollHeight; }
      if (st.state === "done") {
        S.result = await api("/api/result"); S.sorts = {}; S.metric = null; renderResult();
        setStatus(tf("Done in {s} s.", {s: fmt(st.seconds)}), "ok"); showTab("network"); break;
      }
      if (st.state === "error") { setStatus(st.error, "err"); toast(st.error); showTab("log"); break; }
      if (st.state === "idle") { setStatus(t("Start with your data (stage 1) or open an example.")); break; }
      if (st.elapsed >= 3) setStatus(t("Building the network…") + " " + tf("{s} s", {s: Math.round(st.elapsed)}), "busy");
    }
  } catch (e) { toast(e.message); setStatus(e.message, "err"); }
  S.running = false; $("btn-run").disabled = false;
}

/* ---------------- results ---------------- */
const GROUP_TABLES = ["communities", "structural_holes", "brokers", "group_centrality", "blocks", "block_image", "block_types", "cliques"];
const TABS = [["welcome", "Start"], ["network", "Network"], ["summary", "Summary"], ["nodes", "Nodes"], ["ties", "Ties"],
              ["groups", "Groups"], ["model", "Model"], ["tables", "Tables"], ["evolution", "Over time"], ["files", "Files"], ["log", "Log"]];
function tabAvailable(id) {
  const R = S.result;
  if (["welcome", "log"].includes(id)) return true;
  if (!R) return false;
  if (id === "groups") return R.communities.length > 0 || GROUP_TABLES.some(k => R.tables[k]);
  if (id === "tables") return Object.keys(R.tables).length > 0;
  if (id === "evolution") return !!R.tables.evolution;
  if (id === "model") return !!R.tables.ergm;
  return true;
}
function renderTabs() {
  const cur = document.querySelector("#tabs button.on")?.dataset.tab || "welcome";
  $("tabs").replaceChildren(...TABS.filter(([id]) => tabAvailable(id)).map(([id, label]) =>
    el("button", {type: "button", "data-tab": id, class: id === cur ? "on" : "", text: t(label), onclick: () => showTab(id)})));
}
function showTab(name) {
  if (!tabAvailable(name)) name = "welcome";
  document.querySelectorAll("#tabs button").forEach(b => b.classList.toggle("on", b.dataset.tab === name));
  document.querySelectorAll(".pane").forEach(p => p.classList.toggle("on", p.id === "p-" + name));
  if (name === "network" && S.net) setTimeout(() => S.net.redraw(), 30);
}
function renderResult(relayout = true) {
  const R = S.result; if (!R) return;
  renderTabs();
  const color = $("color-by"), size = $("size-by"), prevC = color.value, prevS = size.value;
  color.replaceChildren(...R.categorical.map(c => el("option", {value: c, text: t("Color:") + " " + statLabel(c)})),
    ...R.numeric.map(c => el("option", {value: "#" + c, text: t("Color:") + " " + statLabel(c) + " " + t("(gradient)")})), el("option", {value: "", text: t("Color: none")}));
  size.replaceChildren(el("option", {value: "", text: t("Size: number of ties")}), ...R.numeric.map(c => el("option", {value: c, text: t("Size:") + " " + statLabel(c)})));
  color.value = [...color.options].some(o => o.value === prevC && prevC) ? prevC : (["community", "hole_role", "type"].find(c => R.categorical.includes(c)) || R.categorical[0] || "");
  size.value = R.numeric.includes(prevS) ? prevS : (["betweenness", "pagerank", "degree"].find(x => R.numeric.includes(x)) || "");
  $("dl-labels").replaceChildren(...R.nodes.map(n => el("option", {value: n.label})));
  const hasStrength = R.edges.some(e => e.attrs.tie_strength), hasBridges = R.edges.some(e => "local_bridge" in e.attrs), prevT = $("tie-style").value;
  $("tie-style").replaceChildren(...[el("option", {value: "weight", text: t("Ties: by weight")}),
    hasStrength ? el("option", {value: "strength", text: t("Ties: strong and weak")}) : null,
    hasBridges ? el("option", {value: "bridges", text: t("Ties: local bridges")}) : null].filter(Boolean));
  $("tie-style").value = [...$("tie-style").options].some(o => o.value === prevT) && prevT !== "weight" ? prevT : (hasStrength ? "strength" : "weight");
  $("tie-style").classList.toggle("hidden", !hasStrength && !hasBridges);
  $("dl-attrs").replaceChildren(...attrSuggestions().map(a => el("option", {value: a})));
  $("weak").value = 0; $("weak-cls").checked = false;
  $("weak-cls-wrap").classList.toggle("hidden", !hasStrength);
  for (const k of ["shape_by", "label_by"]) if (S.style[k] && S.style[k] !== "#size" && !R.categorical.includes(S.style[k])) S.style = TS.clean({...S.style, [k]: ""});
  drawNetwork(relayout); renderStyle(); renderSummary(); renderNodes(); renderTies(); renderGroups(); renderModel(); renderTables(); renderEvolution(); renderFiles();
  $("details").replaceChildren();
  $("nethint").textContent = t("Click a node or a tie to see its details. Ties built from documents show the text that supports them.");
}
const label = id => S.result.nodes.find(n => n.id === id)?.label ?? id;
/* ---------------- network drawing and appearance ---------------- */
const TS = window.TejidoStyle;
const STYLE_UI = [
  ["Quick style", [["preset"]]],
  ["Nodes", [["shape", "select"], ["shape_by", "attr"], ["palette", "select"], ["scale", "select"], ["size_min", "range"], ["size_max", "range"],
             ["border", "range"], ["border_color", "select"], ["node_opacity", "range"], ["shadow", "bool"], ["top_ring", "range"]]],
  ["Labels", [["labels", "select"], ["label_top", "range", s => s.labels === "top"], ["label_by", "attr"], ["label_long", "select"], ["label_size", "range"],
              ["label_halo", "bool"], ["declutter", "bool", s => s.labels === "all" || s.labels === "top"]]],
  ["Ties", [["edge_color", "select"], ["edge_opacity", "range"], ["edge_width", "range"], ["curve", "select"],
            ["arrow_size", "range", () => !!S.result?.directed], ["edge_labels", "bool"]]],
  ["Arrangement and background", [["layout", "select"], ["spacing", "range"], ["label_adjust", "bool", s => s.layout === "force" || s.layout === "compact"],
                                  ["background", "select"], ["halos", "bool"]]],
  ["Image", [["png_scale", "range"], ["png_legend", "bool"], ["png_title", "bool"]]]];
const STYLE_TEXT = {preset: "Look", shape: "Node shape", shape_by: "Shape by", palette: "Palette (groups)", scale: "Scale (numbers)",
  size_min: "Smallest node", size_max: "Largest node", border: "Border", border_color: "Border color", node_opacity: "Node opacity (%)",
  shadow: "Shadow", top_ring: "Ring around the largest", labels: "Show names", label_top: "Nodes with name (%)", label_by: "Name text",
  label_size: "Name size (%)", label_halo: "Halo behind names", label_long: "Long names", declutter: "Hide names that overlap",
  label_adjust: "Move nodes apart so names fit", edge_color: "Tie color", edge_opacity: "Tie opacity (%)", edge_width: "Tie width (%)",
  curve: "Tie shape", arrow_size: "Arrow size", edge_labels: "Show tie weights", layout: "Arrangement", spacing: "Spacing",
  background: "Background", halos: "Shade the groups", png_scale: "Image resolution (×)", png_legend: "Legend in the image", png_title: "Title in the image"};
const STYLE_OPTS = {sober: "Sober (default)", poster: "Poster", print: "Print (black and white)", accessible: "Color-blind friendly", night: "Night",
  dot: "Circle", square: "Square", triangle: "Triangle", diamond: "Diamond", star: "Star", hexagon: "Hexagon", triangleDown: "Inverted triangle",
  tejido: "Tejido", andean: "Andean textile", okabe: "Okabe–Ito (color-blind)", earth: "Earth", pastel: "Pastel", gray: "Grays",
  indigo: "Indigo", viridis: "Viridis", heat: "Heat", diverging: "Indigo–cochineal (diverging)",
  darker: "Darker than the fill", background: "Background color (ring)", ink: "Ink",
  all: "All", top: "Only the largest", hover: "On hover", none: "None",
  neutral: "Gray", source: "Color of the origin", gradient: "Blend of both ends", group: "Group color inside groups",
  straight: "Straight", curved: "Curved", smooth: "Smooth curves",
  force: "Forces", compact: "Compact forces", circle: "Circle", rings: "Rings (largest in the center)", groups: "One circle per group",
  hierarchical: "Levels (hierarchy)", full: "Complete, in one line", wrap: "Complete, in several lines", short: "Shortened", theme: "Like the interface", white: "White", paper: "Paper", dark: "Dark"};
const byFreq = xs => { const c = {}; xs.forEach(x => { c[x] = (c[x] || 0) + 1; }); return Object.keys(c).sort((a, b) => c[b] - c[a]); };
const labelsOn = () => $("labels-on").checked && S.style.labels !== "none";
function loadStyle() { let s = null; try { s = JSON.parse(localStorage.getItem("tejido.style") || "null"); } catch (e) { /* private mode */ } S.style = TS.clean(s); }
function saveStyle() { try { localStorage.setItem("tejido.style", JSON.stringify(TS.diff(S.style))); } catch (e) { /* private mode */ } }
function nodeText(n, st, v) {
  const name = st.label_long === "short" ? TS.shortName(n.label) : n.label;
  if (st.label_by === "#size") return `${name} · ${fmt(v)}`;
  const x = st.label_by ? n.attrs[st.label_by] : null;
  return x == null || x === "" ? name : String(valLabel(x));
}
/* Names that would cover a larger node or its name are hidden, and come back when zooming in; hovering shows any name. */
function relabel() {
  if (!S.net || S.focus != null) return;
  const st = S.style, on = labelsOn(), want = on ? S.named : new Set();
  const show = on && st.declutter ? TS.pickLabels(TS.boxes(S.net, S.order, id => want.has(id), ringRoom), want) : want;
  const upd = S.result.nodes.filter(n => show.has(n.id) !== S.shown.has(n.id)).map(n => ({id: n.id, font: TS.font(show.has(n.id), st, S.col)}));
  S.shown = show; if (upd.length) S.nodesDS.update(upd);
}
const ringRoom = id => S.ring.includes(id) ? 8 : 0;   // the ring around the largest nodes takes room too
const relabelSoon = () => { clearTimeout(S.labelTimer); S.labelTimer = setTimeout(relabel, 120); };
function settle(fit = true) {                  // after the forces stop: make room for the names, fit, choose names
  const st = S.style;
  if (st.label_adjust && (st.layout === "force" || st.layout === "compact") && labelsOn())
    TS.spreadNet(S.net, S.order, TS.mainLabels(S.order, S.named), ringRoom);
  if (fit) fitView(false); else S.net.redraw();
  relabelSoon();
}
const groupName = (attr, k) => /^-?\d+$/.test(k) ? `${statLabel(attr)} ${k}` : String(valLabel(k));
function drawNetwork(relayout = false) {
  const R = S.result; if (!R) return;
  const st = S.style, col = TS.colors(st, getComputedStyle(document.documentElement).getPropertyValue("--panel").trim());
  const cSel = $("color-by").value, num = cSel.startsWith("#"), cAttr = num ? cSel.slice(1) : cSel, sAttr = $("size-by").value;
  const deg = {}; R.edges.forEach(e => { deg[e.from] = (deg[e.from] || 0) + 1; deg[e.to] = (deg[e.to] || 0) + 1; });
  const vals = R.nodes.map(n => sAttr ? (Number(n.attrs[sAttr]) || 0) : (deg[n.id] || 0));
  const pal = TS.palette(st.palette, col.dark), stops = TS.SCALES[st.scale], cat = (n, a) => String(n.attrs[a] ?? "—");
  const gAttr = cAttr && !num ? cAttr : (R.categorical.includes("community") ? "community" : "");
  const gmap = gAttr ? Object.fromEntries(byFreq(R.nodes.map(n => cat(n, gAttr))).map((k, i) => [k, pal[i] || "#9aa3b8"])) : {};
  let lo = 0, hi = 1;
  if (num) { const xs = R.nodes.map(n => Number(n.attrs[cAttr])).filter(Number.isFinite); if (xs.length) { lo = Math.min(...xs); hi = Math.max(...xs); } }
  const colorOf = n => {
    if (num) { const x = Number(n.attrs[cAttr]); return Number.isFinite(x) ? TS.ramp(stops, hi > lo ? (x - lo) / (hi - lo) : 0.5) : "#9aa3b8"; }
    return cAttr ? gmap[cat(n, cAttr)] : pal[0]; };
  const smap = st.shape_by ? TS.shapeMap(R.nodes.map(n => cat(n, st.shape_by))) : null;
  const order = R.nodes.map((n, i) => i).sort((a, b) => vals[b] - vals[a]);
  S.named = new Set(st.labels === "all" ? R.nodes.map(n => n.id)
    : st.labels === "top" ? order.slice(0, Math.max(1, Math.ceil(order.length * st.label_top / 100))).map(i => R.nodes[i].id) : []);
  S.ring = order.slice(0, st.top_ring).map(i => R.nodes[i].id); S.ring.forEach(id => S.named.add(id));
  S.order = [...new Set([...S.ring, ...order.map(i => R.nodes[i].id)])]; S.shown = new Set(labelsOn() ? S.named : []);
  S.col = col; S.base = {};
  const prev = !relayout && S.net ? S.net.getPositions() : null, view = prev ? {position: S.net.getViewPosition(), scale: S.net.getScale()} : null;
  const fixed = prev ? null : TS.layout(R.nodes.map((n, i) => ({id: n.id, value: vals[i], group: gAttr ? cat(n, gAttr) : ""})), st);
  const nodes = R.nodes.map((n, i) => {
    const c = colorOf(n); S.base[n.id] = c;
    const x = {id: n.id, label: nodeText(n, st, vals[i]), value: vals[i], color: TS.nodeColor(c, st, col), font: TS.font(S.shown.has(n.id), st, col)};
    if (st.label_long === "short" && x.label !== n.label) x.title = n.label;
    if (smap) x.shape = smap[cat(n, st.shape_by)];
    const p = (prev && prev[n.id]) || (fixed && fixed[n.id]); if (p) { x.x = p.x; x.y = p.y; }
    return x; });
  const ws = R.edges.map(e => { const w = Number(e.attrs.weight); return Number.isFinite(w) ? w : 1; });
  S.wmin = ws.length ? ws.reduce((a, b) => Math.min(a, b)) : 0; S.wmax = ws.length ? ws.reduce((a, b) => Math.max(a, b)) : 1;
  const ts = $("tie-style").value, wk = st.edge_width / 100, gOf = gAttr ? Object.fromEntries(R.nodes.map(n => [n.id, cat(n, gAttr)])) : {};
  S.ebase = {};
  const edges = R.edges.map((e, i) => {
    const x = {id: i, from: e.from, to: e.to, w: ws[i], cls: e.attrs.tie_strength,
               width: wk * (S.wmax > S.wmin ? 0.6 + 5 * (ws[i] - S.wmin) / (S.wmax - S.wmin) : 1.4)};
    let c = TS.edgeColor(st, col, st.edge_color === "group" && gAttr ? gmap[gOf[e.from]] : S.base[e.from], !!gAttr && gOf[e.from] === gOf[e.to]);
    if (ts === "strength" && e.attrs.tie_strength) {
      if (e.attrs.tie_strength === "strong") { c = st.edge_color === "neutral" ? {color: col.ink, opacity: 0.8} : {...c, opacity: Math.max(0.8, c.opacity)}; x.width = Math.max(x.width, 2.6 * wk); }
      else if (e.attrs.tie_strength === "weak") { x.dashes = [5, 5]; x.width = 1.2 * wk; }
      else if (e.attrs.tie_strength === "unclassified") c = {color: col.neutral, opacity: 0.15};
    } else if (ts === "bridges") {
      if (e.attrs.local_bridge) { c = {color: col.red, opacity: 0.95}; x.width = 3 * wk; } else c = {color: col.neutral, opacity: 0.2};
    }
    if (st.edge_labels) x.label = fmt(ws[i]);
    S.ebase[i] = c; x.color = c; return x;
  });
  S.halos = gAttr ? Object.entries(R.nodes.reduce((g, n) => { const k = cat(n, gAttr); if (k !== "—") (g[k] ||= []).push(n.id); return g; }, {}))
    .sort((a, b) => b[1].length - a[1].length).slice(0, 24).map(([k, ids]) => ({ids, color: gmap[k], label: groupName(gAttr, k)})) : null;
  const focus = relayout ? null : S.focus; S.focus = null;
  S.nodesDS = new vis.DataSet(nodes); S.edgesDS = new vis.DataSet(edges);
  const big = nodes.length > 400, hier = st.layout === "hierarchical" && !prev, still = !!(prev || fixed || hier);
  if (S.net) S.net.destroy();
  $("net").style.background = st.background === "theme" ? "" : col.bg;
  const opts = TS.options(st, col, R.directed, big);
  opts.physics = {...TS.physics(st, big), enabled: !still}; opts.physics.stabilization.fit = false;
  opts.layout = hier ? TS.hierarchical(st, R.directed) : {improvedLayout: !big && !still};
  S.net = new vis.Network($("net"), {nodes: S.nodesDS, edges: S.edgesDS}, opts);
  const respread = S.respread; S.respread = false;
  if (view) { S.net.moveTo(view); S.net.once("afterDrawing", () => { if (respread) settle(false); else relabel(); }); }
  else if (still) S.net.once("afterDrawing", () => { fitView(false); relabelSoon(); });
  S.physics = !still; $("btn-physics").textContent = t(S.physics ? "Pause layout" : "Resume layout");
  if (S.physics) S.net.once("stabilizationIterationsDone", () => { S.net.setOptions({physics: {enabled: false}}); S.physics = false; $("btn-physics").textContent = t("Resume layout"); settle(); });
  S.net.on("click", p => { if (p.nodes.length) showNode(p.nodes[0]); else if (p.edges.length) showEdge(p.edges[0]); else { highlight(null); $("details").replaceChildren(); } });
  S.net.on("hoverNode", p => { if (S.focus == null && labelsOn() && !S.shown.has(p.node)) S.nodesDS.update({id: p.node, font: TS.font(true, S.style, S.col)}); });
  S.net.on("blurNode", p => { if (S.focus == null && !S.shown.has(p.node)) S.nodesDS.update({id: p.node, font: TS.font(false, S.style, S.col)}); });
  for (const ev of ["zoom", "dragEnd", "animationFinished"]) S.net.on(ev, relabelSoon);
  S.net.on("beforeDrawing", ctx => { if (S.style.halos && S.halos) TS.drawHalos(ctx, S.net, S.halos); });
  S.net.on("afterDrawing", ctx => TS.drawRings(ctx, S.net, S.ring, S.col.red));
  weakTies();
  if (focus != null && S.nodesDS.get(focus)) highlight(focus);
  S.legend = [];
  if (cAttr && !num) S.legend.push({title: statLabel(cAttr), items: Object.entries(gmap).slice(0, 16).map(([k, c]) => ({color: c, text: String(valLabel(k))}))});
  if (num) S.legend.push({title: statLabel(cAttr), ramp: stops, lo: fmt(lo), hi: fmt(hi)});
  if (smap) S.legend.push({title: statLabel(st.shape_by), items: Object.entries(smap).slice(0, 7).map(([k, s]) => ({glyph: TS.GLYPH[s], text: String(valLabel(k))}))});
  if (ts === "strength") S.legend.push({title: t("Ties"), items: [{glyph: "━", text: t(S.schema.option_labels.val_strong)}, {glyph: "┄", text: t(S.schema.option_labels.val_weak)}]});
  if (ts === "bridges") S.legend.push({title: t("Ties"), items: [{glyph: "━", color: col.red, text: t("Local bridges")}]});
  if (S.ring.length) S.legend.push({title: "", items: [{glyph: "◯", color: col.red, text: tf("The {n} largest nodes", {n: S.ring.length})}]});
  if (S.legend.length) S.legend.push({title: t("Size"), items: [{text: sAttr ? statLabel(sAttr) : t("number of ties")}]});
  renderLegend();
  if (relayout && R.truncated) toast(tf("Showing the {n} most connected nodes; all nodes are in the saved files.", {n: R.nodes.length.toLocaleString()}), true);
}
function fitView(animation) {                 // fit the network in the area that toolbars and panels leave free
  if (!S.net) return;
  S.net.fit();
  const W = $("net").clientWidth, H = $("net").clientHeight, side = $("stylebox").classList.contains("open") || $("details").querySelector("h3") ? 376 : 0;
  const top = 0, k = Math.min((W - side - 24) / W, (H - top - 12) / H), sc = S.net.getScale() * Math.max(0.3, k), c = S.net.getViewPosition();
  S.net.moveTo({position: {x: c.x + side / 2 / sc, y: c.y - top / 2 / sc}, scale: sc, animation: animation ? {duration: 400} : false});
}
function renderLegend() {
  const lg = $("legend");
  lg.replaceChildren(...S.legend.map(s => el("div", {class: "lrow"}, s.title ? el("b", {text: s.title}) : null,
    ...(s.ramp ? [el("span", {class: "lnum", text: " " + s.lo}), el("i", {class: "ramp", style: `background:linear-gradient(90deg,${s.ramp.join(",")})`}), el("span", {class: "lnum", text: s.hi})] : []),
    ...(s.items || []).map(it => el("span", {class: "litem"}, it.glyph ? el("em", {text: it.glyph, style: it.color ? `color:${it.color}` : undefined})
      : it.color ? el("i", {style: `background:${it.color}`}) : " ", it.text)))));
  lg.classList.toggle("hidden", !S.legend.length);
}
function highlight(id) {
  if (!S.nodesDS) return;
  S.focus = id;
  const near = new Set(id == null ? [] : [id, ...S.net.getConnectedNodes(id)]), st = S.style, col = S.col, on = labelsOn();
  S.nodesDS.update(S.result.nodes.map(n => { const keep = id == null || near.has(n.id);
    return {id: n.id, color: keep ? TS.nodeColor(S.base[n.id], st, col) : TS.dimColor(S.base[n.id], st, col),
            font: TS.font(on && (S.shown.has(n.id) || (id != null && near.has(n.id))), st, col, !keep)}; }));
  S.edgesDS.update(S.edgesDS.get().map(e => ({id: e.id, color: id == null ? S.ebase[e.id] : {...S.ebase[e.id], opacity: e.from === id || e.to === id ? 0.95 : 0.07}})));
  if (id == null) { S.shown = new Set(on ? S.shown : []); relabelSoon(); }
}
function setStyle(next, panel) {
  const prev = S.style; S.style = TS.clean(next); saveStyle();
  if (panel) renderStyle();
  S.relayout = S.relayout || ["layout", "spacing"].some(k => prev[k] !== S.style[k]);
  S.respread = S.respread || ["label_size", "label_long", "label_adjust", "labels", "label_top", "label_by", "size_min", "size_max", "shape", "shape_by"]
    .some(k => prev[k] !== S.style[k]);
  clearTimeout(S.styleTimer);
  S.styleTimer = setTimeout(() => { const r = S.relayout; S.relayout = false; drawNetwork(r); }, S.relayout ? 0 : 90);
}
function toggleStyle(open) {
  const box = $("stylebox"), on = open ?? !box.classList.contains("open");
  box.classList.toggle("open", on); $("btn-style").classList.toggle("on", on); $("btn-style").setAttribute("aria-expanded", String(on));
  if (on) { $("details").replaceChildren(); renderStyle(); }
}
function renderStyle() {
  const box = $("stylebox"); if (!box.classList.contains("open")) return;
  const st = S.style, cats = (S.result?.categorical || []).map(c => [c, statLabel(c)]);
  const attrOpts = k => k === "label_by" ? [["", t("Name")], ["#size", t("Name and size value")], ...cats] : [["", t("Same for all")], ...cats];
  const row = (k, ...ctl) => el("div", {class: "srow"}, el("label", {text: t(STYLE_TEXT[k])}), ...ctl);
  const sel = (opts, cur, on) => el("select", {onchange: e => on(e.target.value)}, opts.map(([o, txt]) => el("option", {value: o, text: txt, selected: o === cur})));
  const parts = [el("div", {class: "shead"}, el("h3", {text: t("Appearance")}),
    el("button", {class: "btn small", type: "button", text: t("Reset"), title: t("Back to the default look"), onclick: () => setStyle({}, true)}),
    el("button", {class: "btn icon", type: "button", title: t("Close"), "aria-label": t("Close"), text: "✕", onclick: () => toggleStyle(false)}))];
  for (const [title, keys] of STYLE_UI) {
    const sec = el("section", {}, el("h4", {text: t(title)}));
    for (const [k, kind, show] of keys) {
      if (show && !show(st)) continue;
      const set = (x, panel) => setStyle({...S.style, [k]: x}, panel);
      if (k === "preset") sec.append(row(k, sel([["", t("Choose…")], ...Object.keys(TS.PRESETS).map(p => [p, t(STYLE_OPTS[p])])], "",
        p => p && setStyle(TS.preset(p, S.style), true))));
      else if (kind === "select") sec.append(row(k, sel(TS.OPTIONS[k].map(o => [o, t(STYLE_OPTS[o])]), st[k], x => set(x, true))));
      else if (kind === "attr") sec.append(row(k, sel(attrOpts(k), st[k], x => set(x, true))));
      else if (kind === "bool") sec.append(row(k, el("input", {type: "checkbox", checked: !!st[k], onchange: e => set(e.target.checked, false)})));
      else {
        const [a, b, s] = TS.RANGES[k], out = el("output", {text: fmt(st[k])});
        sec.append(row(k, el("input", {type: "range", min: a, max: b, step: s, value: st[k], "aria-label": t(STYLE_TEXT[k]),
          oninput: e => { out.textContent = fmt(Number(e.target.value)); set(Number(e.target.value), false); }}), out));
      }
    }
    parts.push(sec);
  }
  parts.push(el("p", {class: "hint", text: t("The look is remembered on this computer and saved with the settings; the interactive page of the results uses it too.")}));
  box.replaceChildren(...parts);
}
function paintLegend(g, W, H, col) {
  const maxW = Math.min(W - 48, 620), lines = [[]], face = "Instrument Sans, system-ui, sans-serif";
  let x = 0;
  const add = (w, draw) => { if (x + w > maxW && lines.at(-1).length) { lines.push([]); x = 0; } lines.at(-1).push({x, w, draw}); x += w; };
  const word = (s, bold) => { g.font = `${bold ? "600 " : ""}12px ${face}`; const w = g.measureText(s).width;
    return [w + 10, (X, Y) => { g.font = `${bold ? "600 " : ""}12px ${face}`; g.fillStyle = col.ink; g.fillText(s, X, Y); }]; };
  S.legend.forEach((s, i) => {
    if (i) { lines.push([]); x = 0; }
    if (s.title) add(...word(s.title, true));
    if (s.ramp) { add(...word(s.lo)); add(90, (X, Y) => { const gr = g.createLinearGradient(X, 0, X + 80, 0);
      s.ramp.forEach((c, j) => gr.addColorStop(j / (s.ramp.length - 1), c)); g.fillStyle = gr; g.fillRect(X, Y - 5, 80, 10); }); add(...word(s.hi)); }
    (s.items || []).forEach(it => { const [w, d] = word(it.text); add(w + 18, (X, Y) => {
      if (it.glyph) { g.font = `13px ${face}`; g.fillStyle = it.color || col.ink; g.fillText(it.glyph, X, Y); }
      else if (it.color) { g.save(); g.translate(X + 5, Y); g.rotate(Math.PI / 4); g.fillStyle = it.color; g.fillRect(-4, -4, 8, 8); g.restore(); }
      d(X + 18, Y); }); });
  });
  const L = lines.filter(l => l.length), lh = 20, bw = Math.max(...L.map(l => l.at(-1).x + l.at(-1).w)) + 20, bh = L.length * lh + 12, x0 = 16, y0 = H - 16 - bh;
  g.fillStyle = TS.alpha(col.bg, 0.92); g.strokeStyle = col.dark ? "#2b3040" : "#dde0e7"; g.lineWidth = 1;
  g.beginPath(); g.roundRect ? g.roundRect(x0, y0, bw, bh, 8) : g.rect(x0, y0, bw, bh); g.fill(); g.stroke();
  g.textBaseline = "middle"; g.textAlign = "left";
  L.forEach((l, i) => l.forEach(tk => tk.draw(x0 + 10 + tk.x, y0 + 6 + lh * (i + 0.5))));
}
function savePNG() {
  if (!S.net) return;
  const c = S.net.canvas, cv = c.frame.canvas, old = c.pixelRatio, k = S.style.png_scale, W = cv.clientWidth, H = cv.clientHeight;
  let url;
  try {
    c.pixelRatio = k; cv.width = Math.round(W * k); cv.height = Math.round(H * k);
    S.net.renderer._redraw();
    const out = el("canvas", {width: cv.width, height: cv.height}), g = out.getContext("2d"), col = S.col;
    g.fillStyle = col.bg; g.fillRect(0, 0, out.width, out.height); g.drawImage(cv, 0, 0); g.scale(k, k);
    if (S.style.png_title) { g.font = `600 20px Instrument Sans, system-ui, sans-serif`; g.fillStyle = col.ink; g.textBaseline = "top"; g.fillText($("project").value.trim() || "Tejido", 18, 16); }
    if (S.style.png_legend && S.legend.length) paintLegend(g, W, H, col);
    url = out.toDataURL("image/png");
  } catch (e) { toast(e.message); } finally { c.pixelRatio = old; c.setSize(); S.net.redraw(); }
  if (!url) return;
  const a = el("a", {href: url, download: ($("project").value.trim() || "tejido").replace(/[\\/:*?"<>|]+/g, "_") + ".png"});
  document.body.append(a); a.click(); a.remove();
  toast(t("Image saved in your downloads folder."), true);
}
function weakTies() {
  if (!S.edgesDS) return;
  const pct = Number($("weak").value), cut = S.wmin + (S.wmax - S.wmin) * pct / 100, hideWeak = $("weak-cls").checked;
  S.edgesDS.update(S.edgesDS.get().map(e => ({id: e.id, hidden: (pct > 0 && e.w < cut) || (hideWeak && e.cls === "weak")})));
}
function kvTable(obj) {
  return el("table", {class: "kv"}, Object.entries(obj).filter(([k]) => !["label", "evidence"].includes(k))
    .map(([k, v]) => el("tr", {}, el("td", {text: statLabel(k)}), el("td", {text: fmt(valLabel(v))}))));
}
const closeDetails = () => el("button", {class: "btn icon close", type: "button", title: t("Close"), "aria-label": t("Close"), text: "✕",
  onclick: () => { $("details").replaceChildren(); if (S.net) { S.net.unselectAll(); highlight(null); } }});
function showNode(id) {
  const n = S.result.nodes.find(x => x.id === id); if (!n) return;
  toggleStyle(false);
  highlight(id);
  const nb = S.result.edges.filter(e => e.from === id || e.to === id)
    .map(e => ({id: e.from === id ? e.to : e.from, w: Number(e.attrs.weight) || 1})).sort((a, b) => b.w - a.w).slice(0, 15);
  $("details").replaceChildren(closeDetails(), el("h3", {text: n.label}), kvTable(n.attrs),
    el("p", {class: "hint", text: tf("Strongest ties ({n} shown)", {n: nb.length})}),
    ...nb.map(x => el("div", {}, el("button", {class: "link", type: "button", text: label(x.id), onclick: () => focusNode(x.id)}), " · " + fmt(x.w))));
}
function showEdge(i) {
  const e = S.result.edges[i]; if (!e) return;
  toggleStyle(false);
  $("details").replaceChildren(closeDetails(), el("h3", {text: `${label(e.from)} ${S.result.directed ? "→" : "—"} ${label(e.to)}`}), kvTable(e.attrs),
    ...(e.attrs.evidence ? [el("div", {class: "evidence", text: e.attrs.evidence})] : []));
}
function focusNode(id) { showTab("network"); if (!S.net) return; S.net.selectNodes([id]); S.net.focus(id, {scale: 1.3, animation: true}); showNode(id); }
const SUMMARY = [
  ["Size and density", ["nodes", "ties", "directed", "density", "average_degree", "degree_sd", "max_degree", "degree_gini", "mean_tie_weight", "isolates"]],
  ["Connectivity", ["components", "largest_component_share", "strong_components", "bridges", "cut_points", "connectedness", "hierarchy", "algebraic_connectivity", "dyads_mutual", "dyads_asymmetric", "dyads_null"]],
  ["Distances", ["diameter", "radius", "average_path_length", "global_efficiency", "distances_note"]],
  ["Cohesion", ["average_clustering", "transitivity", "reciprocity", "degree_assortativity", "max_core", "max_core_nodes", "cliques", "largest_clique"]],
  ["Centralization", ["degree_centralization", "betweenness_centralization", "closeness_centralization"]],
  ["Groups and positions", ["communities", "modularity", "blocks", "blockmodel_method", "blockmodel_equivalence", "blockmodel_r2",
    "blockmodel_errors", "blockmodel_fit", "sbm_icl", "sbm_loglik", "core_size", "core_periphery_fit"]],
  ["Exponential random graph model", k => k.startsWith("ergm_")],
  ["Structural holes and tie strength", ["brokers", "embedded_nodes", "mean_node_constraint", "mean_hole_share", "group_holes", "tie_strength_by",
    "tie_strength_rule", "strong_ties", "intermediate_ties", "weak_ties", "unclassified_ties", "strong_tie_share", "local_bridges", "weak_share_of_local_bridges", "weight_overlap_correlation", "stc_violations"]],
  ["Homophily", k => k === "type_assortativity" || k.startsWith("assortativity_") || k.startsWith("ei_index_")],
  ["Compared with random networks", k => k.endsWith("_z") || k === "small_world_sigma"],
  ["Personal networks and trajectories", ["egos", "mean_network_size", "mean_ego_density", "mean_constraint", "units", "transitions", "mobility_rate"]]];
const ruleText = v => S.lang === "es" ? String(v).replace(/\bweak\b/g, "débil").replace(/\bstrong\b/g, "fuerte") : v;
function renderSummary() {
  const sum = S.result.summary, used = new Set(), box = $("p-summary"); box.replaceChildren();
  const tile = k => { used.add(k); return el("div", {class: "stat", title: S.schema.stat_help[k] ? t(S.schema.stat_help[k]) : undefined},
    el("div", {class: "v", text: fmt(k === "tie_strength_rule" ? ruleText(sum[k]) : k === "blockmodel_method" ? optLabel("bm_" + sum[k])
      : typeof sum[k] === "boolean" ? t(sum[k] ? "Yes" : "No") : typeof sum[k] === "string" ? t(sum[k]) : sum[k])}),
    el("div", {class: "k", text: statLabel(k)})); };
  for (const [title, keys] of SUMMARY) {
    const ks = Object.keys(sum).filter(k => !used.has(k) && (typeof keys === "function" ? keys(k) : keys.includes(k)));
    if (ks.length) box.append(el("h2", {class: "sec", text: t(title)}), el("div", {class: "stats"}, ks.map(tile)));
  }
  const rest = Object.keys(sum).filter(k => !used.has(k));
  if (rest.length) box.append(el("h2", {class: "sec", text: t("Other")}), el("div", {class: "stats"}, rest.map(tile)));
}
function download(name, cols, rows) {
  const q = v => { const s = v == null ? "" : String(v); return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const csv = "\ufeff" + [cols.map(q).join(","), ...rows.map(r => r.map(q).join(","))].join("\n");
  saveBlob(new Blob([csv], {type: "text/csv"}), name + ".csv");
}
function saveBlob(blob, name) {
  const url = URL.createObjectURL(blob), a = el("a", {href: url, download: name});
  document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
}
function grid(key, cols, rows, opts = {}) {
  const sort = S.sorts[key] || (S.sorts[key] = {col: opts.sortCol ?? null, dir: -1});
  let data = rows;
  if (sort.col != null) data = [...rows].sort((a, b) => { const x = a[sort.col], y = b[sort.col];
    return (typeof x === "number" && typeof y === "number" ? x - y : String(x ?? "").localeCompare(String(y ?? ""), undefined, {numeric: true})) * sort.dir; });
  const tb = el("table", {class: "grid"}, el("thead", {}, el("tr", {}, cols.map((c, i) => el("th", {scope: "col", text: statLabel(c) + (sort.col === i ? (sort.dir < 0 ? " ↓" : " ↑") : ""),
    onclick: () => { sort.dir = sort.col === i ? -sort.dir : -1; sort.col = i; opts.redraw(); }})))));
  const body = el("tbody");
  data.slice(0, opts.limit || 500).forEach(r => body.append(el("tr", {}, r.map((v, i) => i === 0 && opts.onFirst
    ? el("td", {}, el("button", {class: "link", type: "button", text: fmt(v), onclick: () => opts.onFirst(r)}))
    : el("td", {class: typeof v === "number" ? "num" : undefined, text: typeof v === "string" && v.length > 120 ? v.slice(0, 117) + "…" : fmt(valLabel(v))})))));
  tb.append(body);
  return el("div", {}, el("div", {class: "tablewrap"}, tb), data.length > (opts.limit || 500) ? el("p", {class: "hint", text: tf("Showing {a} of {b} rows; the saved files have all of them.", {a: opts.limit || 500, b: data.length})}) : null);
}
function nodeRows() {
  const R = S.result, attrs = [...R.categorical.filter(c => c !== "label"), ...R.numeric];
  return [["label", ...attrs], R.nodes.map(n => [n.label, ...attrs.map(a => n.attrs[a] ?? null)]), R.nodes.map(n => n.id)];
}
function renderNodes() {
  const box = $("p-nodes"), [cols, rows0] = nodeRows(), q = (S.nodeFilter || "").toLowerCase();
  const ids = S.result.nodes.map(n => n.id);
  const rows = rows0.map((r, i) => Object.assign(r, {_id: ids[i]})).filter(r => !q || String(r[0]).toLowerCase().includes(q));
  const sortCol = cols.indexOf(["betweenness", "pagerank", "degree"].find(c => cols.includes(c)) ?? "label");
  box.replaceChildren(el("div", {class: "toolbar"},
    el("input", {type: "text", value: S.nodeFilter || "", placeholder: t("Filter nodes…"), oninput: e => { S.nodeFilter = e.target.value; renderNodes(); box.querySelector("input").focus(); }}),
    el("button", {class: "btn small", type: "button", text: t("Download CSV"), onclick: () => download("nodes", cols, rows)}),
    el("span", {class: "hint", text: tf("{n} nodes", {n: rows.length.toLocaleString()})})),
    grid("nodes", cols, rows, {sortCol: sortCol >= 0 ? sortCol : 0, redraw: renderNodes, onFirst: r => focusNode(r._id)}));
}
function renderTies() {
  const R = S.result, keys = [...new Set(R.edges.flatMap(e => Object.keys(e.attrs)))].filter(k => k !== "evidence");
  const cols = ["source", "target", ...keys], rows = R.edges.map((e, i) => Object.assign([label(e.from), label(e.to), ...keys.map(k => e.attrs[k] ?? null)], {_i: i}));
  $("p-ties").replaceChildren(el("div", {class: "toolbar"},
    el("button", {class: "btn small", type: "button", text: t("Download CSV"), onclick: () => download("ties", cols, rows)}),
    el("span", {class: "hint", text: tf("{n} ties", {n: rows.length.toLocaleString()})})),
    grid("ties", cols, rows, {sortCol: cols.indexOf("weight"), redraw: renderTies, onFirst: r => { showTab("network"); showEdge(r._i); }}));
}
function tableBlock(name, redraw) {
  const tb = S.result.tables[name]; if (!tb) return null;
  return el("div", {}, el("h2", {class: "sec", text: optLabel("table_" + name)}),
    S.schema.option_labels["help_" + name] ? el("p", {class: "hint", text: t(S.schema.option_labels["help_" + name])}) : null,
    grid("t-" + name, tb.columns, tb.rows, {redraw}));
}
function renderGroups() {
  const R = S.result, box = $("p-groups"); box.replaceChildren();
  if (R.communities.length) {
    box.append(el("h2", {class: "sec", text: t("Communities")}), ...R.communities.map((c, i) => el("div", {class: "comm"},
      el("b", {text: `${t("Community")} ${i + 1}`}), el("span", {class: "hint", text: " · " + tf("{n} nodes; most connected:", {n: c.size})}), el("br"),
      ...c.members.map(m => el("span", {class: "chip", text: m, tabindex: 0, onclick: () => { const n = R.nodes.find(x => x.label === m); if (n) focusNode(n.id); }})))));
  }
  const bm = blockMatrix(); if (bm) box.append(bm);
  GROUP_TABLES.forEach(k => { const b = tableBlock(k, renderGroups); if (b) box.append(b); });
}
/* Blockmodel: the adjacency matrix with rows and columns ordered by block. */
function blockMatrix() {
  const R = S.result, nodes = R.nodes.filter(n => n.attrs.block != null);
  if (nodes.length < 3 || nodes.length > 1500) return null;
  const deg = {}; R.edges.forEach(e => { deg[e.from] = (deg[e.from] || 0) + 1; deg[e.to] = (deg[e.to] || 0) + 1; });
  const order = [...nodes].sort((a, b) => a.attrs.block - b.attrs.block || (deg[b.id] || 0) - (deg[a.id] || 0));
  const pos = new Map(order.map((n, i) => [n.id, i])), N = order.length, size = Math.min(520, Math.max(260, N * 5)), cell = size / N;
  const dpr = window.devicePixelRatio || 1, css = getComputedStyle(document.documentElement), v = x => css.getPropertyValue(x).trim();
  const cv = el("canvas", {class: "bmatrix", width: Math.round(size * dpr), height: Math.round(size * dpr), style: `width:${size}px;height:${size}px`,
    role: "img", "aria-label": t("Blocks: ordered adjacency matrix")});
  const g = cv.getContext("2d"); g.scale(dpr, dpr);
  g.fillStyle = v("--panel") || "#fff"; g.fillRect(0, 0, size, size);
  g.fillStyle = v("--fg") || "#1b2030";
  const w = Math.max(cell, 1);
  for (const e of R.edges) {
    const i = pos.get(e.from), j = pos.get(e.to); if (i == null || j == null) continue;
    g.fillRect(j * cell, i * cell, w, w); if (!R.directed) g.fillRect(i * cell, j * cell, w, w);
  }
  const counts = {}; order.forEach(n => { counts[n.attrs.block] = (counts[n.attrs.block] || 0) + 1; });
  g.strokeStyle = v("--cochineal") || "#a61e44"; g.lineWidth = 1.2; let acc = 0;
  for (const b of Object.keys(counts).sort((x, y) => x - y)) {
    acc += counts[b]; if (acc >= N) break;
    g.beginPath(); g.moveTo(acc * cell, 0); g.lineTo(acc * cell, size); g.moveTo(0, acc * cell); g.lineTo(size, acc * cell); g.stroke();
  }
  g.strokeStyle = v("--line") || "#ddd"; g.strokeRect(0.5, 0.5, size - 1, size - 1);
  return el("div", {}, el("h2", {class: "sec", text: t("Blocks: ordered adjacency matrix")}),
    el("p", {class: "hint", text: t("Rows and columns are the nodes, ordered by block; a dark cell is a tie (row → column). Dense squares are blocks with many ties; empty ones, blocks without ties.")}), cv);
}
/* ERGM: coefficients with what they mean, and goodness of fit against simulated networks. */
const TERM_HELP = {
  edges: "Baseline: how likely any tie is, like an intercept; usually negative in sparse networks.",
  mutual: "Reciprocity: a tie is more likely when it returns an existing one.",
  triangles: "Closure: ties that close triangles (this term often makes models degenerate; prefer gwesp).",
  ttriple: "Transitivity: ties that close transitive triads.",
  isolates: "Isolated nodes: positive means more isolates than expected.",
  gwesp: "Triadic closure: ties between nodes that share partners (friends of friends), each extra shared partner counting less.",
  gwdegree: "Degree spread: negative means ties concentrate on a few popular nodes; positive, that they spread out.",
  gwidegree: "In-degree spread: negative means that a few nodes receive most ties (popularity).",
  gwodegree: "Out-degree spread: negative means that a few nodes send most ties (activity).",
  nodematch: "Homophily: ties between nodes with the same {a}.",
  nodefactor: "Ties of nodes whose {a} is {l}, compared with the reference category.",
  nodecov: "Nodes with a higher {a} have more ties.",
  absdiff: "Ties between nodes that differ in {a}; negative means that similar values attract.",
  nodeicov: "Nodes with a higher {a} receive more ties.",
  nodeocov: "Nodes with a higher {a} send more ties."};
function termHelp(term) {
  const m = /^([a-z]+)(?:\(([^)]*)\))?(?:\.(.*))?$/i.exec(term) || [], txt = TERM_HELP[m[1]];
  return txt ? tf(txt, {a: m[2] || "", l: m[3] || ""}) : "";
}
function renderModel() {
  const R = S.result, box = $("p-model"); box.replaceChildren();
  const tb = R.tables.ergm; if (!tb) return;
  const sum = R.summary, c = n => tb.columns.indexOf(n), stars = p => p == null ? "" : p < .001 ? " ***" : p < .01 ? " **" : p < .05 ? " *" : "";
  const info = [t(sum.ergm_method || "")];
  if (sum.ergm_iterations) info.push(tf("{n} MCMC rounds", {n: sum.ergm_iterations}));
  if (sum.ergm_converged === true) info.push(t("converged"));
  if (sum.ergm_seconds != null) info.push(tf("{n} seconds", {n: fmt(sum.ergm_seconds)}));
  box.append(el("h2", {class: "sec", text: t("Exponential random graph model (ERGM)")}), el("p", {class: "hint", text: info.join(" · ")}));
  if (sum.ergm_converged === false) box.append(el("p", {class: "warn", text: t("The MCMC estimation did not converge: treat these results as provisional. Try fewer or other terms, or more samples.")}));
  if (sum.ergm_method === "maximum pseudo-likelihood" && tb.rows.some(r => !/^(edges|node|absdiff)/.test(r[c("term")])))
    box.append(el("p", {class: "warn", text: t("With dependence terms (mutual, gwesp, triangles…) pseudo-likelihood standard errors are only approximate; use MCMC estimation for inference.")}));
  const head = ["Term", "Estimate", "Std. error", "Odds ratio", "p", "What it means"];
  box.append(el("div", {class: "tablewrap"}, el("table", {class: "coef"},
    el("thead", {}, el("tr", {}, head.map(h => el("th", {text: t(h)})))),
    el("tbody", {}, tb.rows.map(r => el("tr", {},
      el("td", {}, el("code", {text: r[c("term")]})), el("td", {class: "num", text: fmt(r[c("estimate")]) + stars(r[c("p_value")])}),
      el("td", {class: "num", text: fmt(r[c("std_error")])}), el("td", {class: "num", text: fmt(r[c("odds_ratio")])}),
      el("td", {class: "num", text: r[c("p_value")] == null ? "—" : r[c("p_value")] < .001 ? "< 0.001" : fmt(r[c("p_value")])}),
      el("td", {class: "hint", text: termHelp(r[c("term")])})))))),
    el("p", {class: "hint", text: t("*** p < 0.001 · ** p < 0.01 · * p < 0.05. The odds ratio multiplies the conditional odds of a tie for each unit of the pattern, holding the rest constant.")}));
  const g = R.tables.ergm_gof; if (!g) return;
  const gc = n => g.columns.indexOf(n), groups = {};
  g.rows.forEach(r => (groups[r[gc("statistic")]] ||= []).push(r));
  box.append(el("h2", {class: "sec", text: t("Goodness of fit")}),
    el("p", {class: "hint", text: t("Black: the observed network. Gray band: 95% of the networks simulated from the model; dashed: their mean. Red points fall outside the band: what the model does not reproduce.")}),
    el("div", {class: "gof"}, Object.entries(groups).map(([name, rows]) => gofChart(name, rows, gc))));
}
function gofChart(name, rows, gc) {
  const W = 300, H = 170, L = 36, B = 24, T = 20, Rm = 10, ns = "http://www.w3.org/2000/svg";
  const sv = (tag, attrs) => { const e = document.createElementNS(ns, tag); for (const [k, x] of Object.entries(attrs)) e.setAttribute(k, x); return e; };
  const obs = rows.map(r => r[gc("observed")]), lo = rows.map(r => r[gc("low_2.5")]), hi = rows.map(r => r[gc("high_97.5")]), mu = rows.map(r => r[gc("simulated_mean")]);
  const n = rows.length, ymax = Math.max(1, ...obs, ...hi), X = i => L + (n > 1 ? i * (W - L - Rm) / (n - 1) : (W - L - Rm) / 2), Y = y => T + (H - T - B) * (1 - y / ymax);
  const svg = sv("svg", {viewBox: `0 0 ${W} ${H}`, class: "gofc", role: "img", "aria-label": t(name)});
  const pts = arr => arr.map((y, i) => `${X(i).toFixed(1)},${Y(y).toFixed(1)}`).join(" ");
  svg.append(sv("polygon", {class: "band", points: pts(lo) + " " + pts(hi).split(" ").reverse().join(" ")}),
    sv("polyline", {class: "mean", points: pts(mu)}), sv("polyline", {class: "obs", points: pts(obs)}));
  rows.forEach((r, i) => svg.append(sv("circle", {cx: X(i), cy: Y(obs[i]), r: 2.6, class: r[gc("outside")] ? "out" : "in"})));
  const step = Math.ceil(n / 8);
  rows.forEach((r, i) => { if (i % step === 0 || i === n - 1) { const tx = sv("text", {x: X(i), y: H - 8, class: "ax", "text-anchor": "middle"});
    tx.textContent = r[gc("value")] === "unreachable" ? "∞" : r[gc("value")]; svg.append(tx); } });
  const ym = sv("text", {x: L - 6, y: T + 4, class: "ax", "text-anchor": "end"}); ym.textContent = fmt(Math.round(ymax)); svg.append(ym);
  const ttl = sv("text", {x: L, y: 12, class: "ttl"}); ttl.textContent = t(name); svg.append(ttl);
  svg.append(sv("line", {x1: L, y1: H - B, x2: W - Rm, y2: H - B, class: "axis"}));
  return svg;
}
function renderTables() {
  const R = S.result, names = Object.keys(R.tables), box = $("p-tables");
  if (!names.length) return box.replaceChildren();
  if (!names.includes(S.table)) S.table = names.includes("egos") ? "egos" : names[0];
  const tb = R.tables[S.table];
  box.replaceChildren(el("div", {class: "toolbar"},
    el("select", {onchange: e => { S.table = e.target.value; renderTables(); }}, names.map(n => el("option", {value: n, text: optLabel("table_" + n), selected: n === S.table}))),
    el("button", {class: "btn small", type: "button", text: t("Download CSV"), onclick: () => download(S.table, tb.columns, tb.rows)}),
    el("span", {class: "hint", text: tf("{n} rows", {n: tb.total.toLocaleString()})})),
    ...(S.schema.option_labels["help_" + S.table] ? [el("p", {class: "hint", text: t(S.schema.option_labels["help_" + S.table])})] : []),
    grid("tab-" + S.table, tb.columns, tb.rows, {redraw: renderTables}));
}
function renderEvolution() {
  const tb = S.result.tables.evolution, box = $("p-evolution"); if (!tb) return box.replaceChildren();
  const num = tb.columns.filter((c, i) => c !== "period" && tb.rows.some(r => typeof r[i] === "number"));
  if (!num.includes(S.metric)) S.metric = ["density", "nodes", "ties"].find(m => num.includes(m)) || num[0];
  const ci = tb.columns.indexOf(S.metric), pi = tb.columns.indexOf("period");
  const pts = tb.rows.map(r => [String(r[pi]), r[ci]]).filter(([, y]) => typeof y === "number");
  const W = 820, H = 330, L = 64, Rm = 18, T = 20, B = 46, ys = pts.map(p => p[1]);
  const lo = Math.min(...ys), hi = Math.max(...ys), span = hi - lo || Math.abs(hi) || 1;
  const x = i => L + (pts.length > 1 ? i * (W - L - Rm) / (pts.length - 1) : (W - L - Rm) / 2), y = v => T + (H - T - B) * (1 - (v - lo) / span);
  const ns = "http://www.w3.org/2000/svg", svg = document.createElementNS(ns, "svg");
  const add = (tag, a, txt) => { const e = document.createElementNS(ns, tag); Object.entries(a).forEach(([k, v]) => e.setAttribute(k, v)); if (txt != null) e.textContent = txt; svg.append(e); return e; };
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`); svg.setAttribute("role", "img"); svg.setAttribute("aria-label", statLabel(S.metric));
  [lo, lo + span / 2, lo + span].forEach(v => { add("line", {x1: L, x2: W - Rm, y1: y(v), y2: y(v), stroke: "var(--line)"});
    add("text", {x: L - 8, y: y(v) + 4, "text-anchor": "end", "font-size": 12, fill: "var(--muted)"}, fmt(+v.toFixed(4))); });
  add("polyline", {points: pts.map((p, i) => `${x(i)},${y(p[1])}`).join(" "), fill: "none", stroke: "var(--cochineal)", "stroke-width": 2.5});
  const step = Math.ceil(pts.length / 12);
  pts.forEach((p, i) => { const d = add("rect", {x: x(i) - 5, y: y(p[1]) - 5, width: 10, height: 10, transform: `rotate(45 ${x(i)} ${y(p[1])})`, fill: "var(--indigo)"});
    const ti = document.createElementNS(ns, "title"); ti.textContent = `${p[0]}: ${fmt(p[1])}`; d.append(ti);
    if (i % step === 0) add("text", {x: x(i), y: H - 18, "text-anchor": "middle", "font-size": 12, fill: "var(--muted)"}, p[0]); });
  box.replaceChildren(el("div", {class: "toolbar"}, el("select", {onchange: e => { S.metric = e.target.value; renderEvolution(); }},
    num.map(m => el("option", {value: m, text: statLabel(m), selected: m === S.metric})))),
    el("div", {id: "chart"}, svg), tableBlock("evolution", renderEvolution), tableBlock("node_evolution", renderEvolution));
}
const FILE_KINDS = [[/_run\.json$/, "Run record: version, settings and data fingerprints"], [/_report\.md$/, "Report"], [/\.html$/, "Interactive network view"],
  [/_nodes\.csv$/, "Nodes"], [/_edges\.csv$/, "Ties"], [/_matrix\.csv$/, "Adjacency matrix"], [/\.xlsx$/, "Excel workbook"], [/\.graphml$/, "GraphML (Gephi, Cytoscape, R)"],
  [/\.gexf$/, "GEXF (Gephi)"], [/\.net$/, "Pajek"], [/\.dl$/, "UCINET"], [/\.json$/, "JSON node-link"], [/\.csv$/, "Result table"]];
const fileSize = b => b < 1024 ? `${b} B` : b < 1048576 ? `${(b / 1024).toFixed(1)} KB` : `${(b / 1048576).toFixed(1)} MB`;
function renderFiles() {
  const R = S.result;
  $("p-files").replaceChildren(el("div", {class: "toolbar"},
    el("button", {class: "btn", type: "button", text: t("Open results folder"), disabled: !R.output_dir,
      onclick: () => api("/api/open", {path: R.output_dir}).catch(e => toast(e.message))}),
    el("span", {class: "hint", text: R.output_dir || t("Nothing was saved: choose files in stage 7.")})),
    el("div", {class: "files"}, R.files.map(f => el("a", {href: f.url, target: "_blank", rel: "noopener noreferrer"}, el("span", {text: f.name}),
      el("span", {class: "what", text: t((FILE_KINDS.find(([re]) => re.test(f.name)) || [0, ""])[1])}), el("span", {class: "hint", text: fileSize(f.size)})))));
}

/* ---------------- start page, YAML, language ---------------- */
async function renderWelcome() {
  const ex = S.examples || (S.examples = await api("/api/examples").catch(() => []));
  const lock = new DOMParser().parseFromString('<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M3.5 6V4.5a3.5 3.5 0 0 1 7 0V6M2.5 6h9v6.5h-9z" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>', "image/svg+xml").documentElement;
  $("p-welcome").replaceChildren(el("div", {class: "welcome"},
    el("h1", {text: t("Turn your data into a network")}),
    el("p", {class: "lead", text: t("Follow the stages on the left: choose your data, decide what a tie means, and build the network.")}),
    el("p", {class: "note"}, lock, t("Everything runs on this computer; your files are not uploaded anywhere.")),
    el("h2", {text: t("Examples")}),
    el("p", {class: "sub", text: t("Open one to see how each kind of network is set up.")}),
    el("div", {class: "examples"}, ex.map(x => el("button", {class: "example", type: "button", onclick: () => loadExample(x.name)},
      el("b", {text: optLabel("example_" + x.name)}), el("small", {text: t(x.description)}),
      el("em", {text: t(S.schema.builders[x.builder]?.title || x.builder)})))),
    el("p", {class: "foot", text: t("Workspace (uploads and results):") + " " + S.schema.workspace})));
}
async function loadExample(name) {
  setStatus(t("Loading example…"), "busy");
  try {
    const {config, preview} = await api("/api/example", {name});
    applyConfig(config); S.preview = Object.keys(preview).length ? preview : null;
    openStage("build"); updateLoom(); setTitle();
    setStatus(t("Example loaded. Review the stages and click Build network."));
  } catch (e) { toast(e.message); setStatus(t("Could not load the example.")); }
}
async function exportYaml() {
  const cfg = collectConfig(), problem = validate(cfg);
  if (problem) return toast(problem);
  try {
    const {text} = await api("/api/yaml", {config: cfg});
    saveBlob(new Blob([text], {type: "text/yaml"}), (cfg.project || "config").replace(/[\\/:*?"<>|]+/g, "_") + ".yaml");
    toast(t("Settings saved as YAML."), true);
  } catch (e) { toast(e.message); }
}
async function importYaml(file) {
  try {
    const {config} = await api("/api/parse_yaml", {text: await file.text()});
    applyConfig(config); setTitle(); if (S.inputPath || S.inputType === "worldbank_api") await loadPreview();
    toast(t("Settings loaded."), true);
  } catch (e) { toast(e.message); }
}
function applyStatic() {
  document.documentElement.lang = S.lang;
  document.querySelectorAll("#lang button").forEach(b => b.classList.toggle("on", b.dataset.l === S.lang));
  $("project").setAttribute("aria-label", t("Project name")); $("project").title = t("Project name");
  $("btn-import").textContent = t("Open settings"); $("btn-import").title = t("Load a YAML configuration");
  $("btn-export").textContent = t("Save settings"); $("btn-export").title = t("Save these settings as YAML for the command line");
  $("btn-run").textContent = t("Build network");
  $("search").placeholder = t("Find a node…"); $("weak-label").textContent = t("Hide ties with low weight"); $("weak-cls-label").textContent = t("Hide weak ties");
  $("labels-label").textContent = t("Labels"); $("btn-fit").textContent = t("Fit");
  $("btn-style").textContent = t("Customize"); $("btn-style").title = t("Shapes, colors, names, ties, arrangement and background");
  $("btn-png").textContent = t("Image"); $("btn-png").title = t("Download the network as an image (PNG)");
  $("btn-physics").textContent = t(S.physics && S.net ? "Pause layout" : "Resume layout");
  if (!$("status").textContent || S.idleStatus) { setStatus(t("Start with your data (stage 1) or open an example.")); S.idleStatus = true; }
  $("btn-about").textContent = t("About"); $("foot-owner").title = t("About") + " Tejido";
  $("foot-log").textContent = $("applog-title").textContent = t("Activity log");
  $("foot-local-text").textContent = t("Runs only on this computer");
  $("foot-local").title = t("Everything runs on this computer; your files are not uploaded anywhere.");
  $("foot-license").textContent = t("MIT License");
  const ws = S.schema.workspace, parts = ws.split(/[\\/]/).filter(Boolean);
  $("foot-workspace").textContent = parts.length > 3 ? "…" + ws.slice(ws.length - parts.slice(-2).join("/").length - 1) : ws;
  $("foot-workspace").title = t("Open the workspace folder") + ": " + ws;
  $("btn-run").title = t("Build network") + " (Ctrl+Enter)";
  document.querySelectorAll("[data-close]").forEach(b => { b.title = t("Close"); b.setAttribute("aria-label", t("Close")); });
}
function setTitle() { const p = $("project").value.trim(); document.title = p && p !== "my_network" ? `${p} · Tejido` : "Tejido"; }
/* ---------------- about the program and activity log ---------------- */
function openAbout() {
  const A = S.schema.about, ext = (href, text) => el("a", {href, target: "_blank", rel: "noopener noreferrer", text});
  const row = (k, v) => el("tr", {}, el("td", {text: t(k)}), el("td", {}, v));
  $("about-body").replaceChildren(
    el("p", {class: "lead", text: t("Turns almost any data into a network: direct ties, affiliations, similarity, texts, interactions, personal networks and trajectories.")}),
    el("div", {class: "about-owner"}, el("b", {text: A.author}), el("span", {text: t("Author and owner of the program") + " · " + A.copyright})),
    el("h3", {text: t("How to cite")}), el("div", {class: "cite", text: A.citation}),
    el("div", {class: "dlg-actions"}, el("button", {class: "btn small", type: "button", text: t("Copy citation"),
      onclick: () => navigator.clipboard.writeText(A.citation).then(() => toast(t("Copied."), true), () => toast(t("Select the text and copy it.")))})),
    el("h3", {text: t("License")}),
    el("p", {}, t("Tejido is free software under the MIT License: you may use, copy, modify and share it, keeping the copyright notice. It comes without warranty."), " ",
      ext("/static/LICENSE.txt", t("License text")), " · ", ext("/static/THIRD-PARTY-LICENSES.txt", t("Third-party components")), " · ", ext(A.url, t("Website and source code"))),
    el("h3", {text: t("This installation")}),
    el("table", {class: "about-kv"}, row("Version", A.version), row("Python", A.python), row("System", A.system),
      row("Workspace", A.workspace), row("Activity log", A.log || "—"), row("Largest upload", `${A.max_upload_mb.toLocaleString()} MB`)),
    el("div", {class: "dlg-actions"},
      el("button", {class: "btn small", type: "button", text: t("Open the workspace folder"), onclick: () => api("/api/open", {what: "workspace"}).catch(e => toast(e.message))}),
      el("button", {class: "btn small", type: "button", text: t("Activity log"), onclick: () => { $("about").close(); openLog(); }})),
    el("p", {class: "hint", text: t("To report a problem, include the version, the system and the last lines of the activity log.")}));
  if (!$("about").open) $("about").showModal();
}
async function openLog() {
  const body = $("applog-body"), pre = el("pre", {class: "applog", tabindex: 0});
  const load = async () => {
    try {
      const {text, path} = await api("/api/logs?lines=400");
      where.textContent = path || "";
      pre.replaceChildren(...(text ? text.split("\n").map(l => el("span", {class: / (ERROR|CRITICAL) /.test(l) ? "e" : / WARNING /.test(l) ? "w" : / DEBUG /.test(l) ? "d" : undefined, text: l + "\n"}))
        : [t("Nothing recorded yet.")]));
      pre.scrollTop = pre.scrollHeight;
    } catch (e) { toast(e.message); }
  };
  const where = el("span", {class: "hint"});
  body.replaceChildren(el("p", {class: "lead", text: t("What the program did and what went wrong: sessions, builds, files received, errors and refused requests. The contents of your data are never recorded.")}),
    el("div", {class: "dlg-actions"},
      el("button", {class: "btn small", type: "button", text: t("Refresh"), onclick: load}),
      el("button", {class: "btn small", type: "button", text: t("Copy"), onclick: () => navigator.clipboard.writeText(pre.textContent).then(() => toast(t("Copied."), true), () => toast(t("Select the text and copy it.")))}),
      el("button", {class: "btn small", type: "button", text: t("Open the log folder"), onclick: () => api("/api/open", {what: "logs"}).catch(e => toast(e.message))}), where),
    pre);
  if (!$("applog").open) $("applog").showModal();
  await load();
}
function setLang(l) {
  S.lang = l; try { localStorage.setItem("tejido.lang", l); } catch (e) { /* private mode */ }
  applyStatic(); renderLoom(); renderTabs(); renderWelcome(); if (S.result) renderResult(false); else renderStyle();
  if ($("about").open) openAbout();
}
async function init() {
  try { S.schema = await api("/api/schema"); } catch (e) { $("status").textContent = e.message; return toast("Tejido: " + e.message); }
  let saved = null; try { saved = localStorage.getItem("tejido.lang"); } catch (e) { /* private mode */ }
  S.lang = saved || ((navigator.language || "en").toLowerCase().startsWith("es") ? "es" : "en");
  S.rest = restDefaults(); loadStyle();
  applyStatic(); renderTabs(); renderLoom(); openStage("data"); renderWelcome();
  document.querySelectorAll("#lang button").forEach(b => b.onclick = () => setLang(b.dataset.l));
  $("btn-run").onclick = run; $("btn-export").onclick = exportYaml;
  $("btn-import").onclick = () => $("yaml-file").click();
  $("yaml-file").onchange = e => { if (e.target.files[0]) importYaml(e.target.files[0]); e.target.value = ""; };
  $("color-by").onchange = $("size-by").onchange = $("tie-style").onchange = () => drawNetwork(false);
  $("btn-style").onclick = () => toggleStyle(); $("btn-png").onclick = savePNG;
  $("weak").oninput = weakTies; $("weak-cls").onchange = weakTies;
  $("labels-on").onchange = () => highlight(S.focus ?? null);
  $("btn-fit").onclick = () => fitView(true);
  $("btn-physics").onclick = () => { if (!S.net) return; S.physics = !S.physics; S.net.setOptions({physics: {enabled: S.physics}}); $("btn-physics").textContent = t(S.physics ? "Pause layout" : "Resume layout");
    if (!S.physics) settle(); };
  $("btn-about").onclick = $("foot-owner").onclick = openAbout; $("foot-log").onclick = openLog;
  $("foot-workspace").onclick = () => api("/api/open", {what: "workspace"}).catch(e => toast(e.message));
  $("project").oninput = setTitle;
  document.querySelectorAll("dialog").forEach(d => {
    d.querySelector("[data-close]").onclick = () => d.close();
    d.addEventListener("click", e => { if (e.target === d) d.close(); });          // a click on the backdrop closes it
  });
  document.addEventListener("keydown", e => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter" && !document.querySelector("dialog[open]")) { e.preventDefault(); run(); }
    else if (e.key === "Escape" && !document.querySelector("dialog[open]")) {
      if ($("stylebox").classList.contains("open")) toggleStyle(false);
      else if ($("details").querySelector("h3")) { $("details").replaceChildren(); if (S.net) { S.net.unselectAll(); highlight(null); } }
    }
  });
  window.addEventListener("beforeunload", e => { if (S.running) e.preventDefault(); });
  api("/api/status").then(st => {                       // the page was reloaded while a network was being built, or after it
    if (st.state === "running") { $("log").textContent = ""; follow(); }
    else if (st.state === "done" && !S.result) api("/api/result").then(r => { if (!S.result && !S.running) { S.result = r; renderResult(); } }).catch(() => {});
  }).catch(() => {});
  $("search").onchange = () => { const q = $("search").value.toLowerCase(); const n = S.result?.nodes.find(x => x.label.toLowerCase() === q) || S.result?.nodes.find(x => x.label.toLowerCase().includes(q)); if (n) focusNode(n.id); };
}
init();
