"""Unión de las tablas de un año en una sola base al nivel elegido."""
from __future__ import annotations

import fnmatch

import pandas as pd

from .utils import ConfigError, as_list, log

LEVELS = ["vivienda", "hogar", "persona"]  # de menos a más detallado

AGG = {
    "media": "mean", "suma": "sum", "maximo": "max", "minimo": "min",
    "mediana": "median", "conteo": "count", "primero": "first",
}


def norm_key(s: pd.Series) -> pd.Series:
    """Llaves comparables entre módulos: '005001', 5001.0 y '5001' -> '5001'."""
    num = pd.to_numeric(s, errors="coerce")
    if num.notna().all():
        return num.astype("int64").astype(str)
    return s.astype(str).str.strip().str.lstrip("0").replace("", "0")


def level_of(df: pd.DataFrame, keys: dict) -> str | None:
    for lvl in reversed(LEVELS):
        if all(k in df.columns for k in keys[lvl]):
            return lvl
    return None


def merge_tables(tables: dict[str, pd.DataFrame], cfg: dict) -> pd.DataFrame:
    keys, ucfg = cfg["llaves"], cfg["unir"]
    target = ucfg["nivel"]
    tkeys = keys[target]
    prepared: list[tuple[str, str, pd.DataFrame]] = []

    for name, df in tables.items():
        for old, new in (ucfg.get("renombrar") or {}).items():
            if old in df.columns and new not in df.columns:
                df = df.rename(columns={old: new})
        lvl = level_of(df, keys)
        if lvl is None:
            log.warning(f"  · {name}: no tiene las llaves esperadas; se omite")
            continue
        df = df.copy()
        for k in keys[lvl]:
            df[k] = norm_key(df[k])
        if df.duplicated(keys[lvl]).any():
            log.warning(f"  · {name}: hay varias filas por {lvl} (tabla de detalle); se omite. "
                        "Si la necesitas, agrégala antes o usa otra tabla.")
            continue
        prepared.append((name, lvl, df))

    if not prepared:
        raise ConfigError("No quedó ninguna tabla utilizable para unir en este año.")

    same = [p for p in prepared if p[1] == target]
    if not same:
        raise ConfigError(f"No hay ninguna tabla a nivel {target!r}. Revisa 'datos.modulos' o 'unir.nivel'.")
    if ucfg.get("tabla_base"):
        cand = [p for p in same if fnmatch.fnmatch(p[0], f"*{str(ucfg['tabla_base']).lower()}*")]
        if not cand:
            raise ConfigError(f"Ninguna tabla coincide con 'unir.tabla_base' = {ucfg['tabla_base']!r}. "
                              f"Tablas disponibles: {[p[0] for p in same]}")
        base = cand[0]
    else:
        base = max(same, key=lambda p: len(p[2]))
    log.info(f"  · base: {base[0]} ({len(base[2]):,} filas, nivel {target})")
    out = base[2]

    tidx = LEVELS.index(target)
    for name, lvl, df in prepared:
        if name == base[0]:
            continue
        if LEVELS.index(lvl) > tidx:              # más detallado que el destino
            df = _aggregate(df, keys[target], ucfg.get("agregar") or {}, name)
            if df is None:
                continue
            on = keys[target]
        else:
            on = keys[lvl]
        out = _join(out, df, on, name, ucfg["duplicados"])
    return out


def _aggregate(df, by, spec, name):
    cols = {v: as_list(f) for v, f in spec.items() if v in df.columns}
    if not cols:
        log.info(f"  · {name}: es más detallada que el nivel elegido; se omite "
                 "(usa 'unir.agregar' para resumirla)")
        return None
    pieces = []
    for var, funcs in cols.items():
        s = pd.to_numeric(df[var], errors="coerce")
        for f in funcs:
            if f not in AGG:
                raise ConfigError(f"Función de agregación desconocida {f!r}. Opciones: {list(AGG)}")
            pieces.append(s.groupby([df[k] for k in by]).agg(AGG[f]).rename(f"{var}_{f}"))
    log.info(f"  · {name}: agregada al nivel destino ({', '.join(p.name for p in pieces)})")
    return pd.concat(pieces, axis=1).reset_index()


def _join(left, right, on, name, dup_mode):
    overlap = [c for c in right.columns if c in left.columns and c not in on]
    if overlap:
        if dup_mode == "primero":
            right = right.drop(columns=overlap)
        else:
            right = right.rename(columns={c: f"{c}_{name}" for c in overlap})
    merged = left.merge(right, on=on, how="left", validate="many_to_one")
    log.info(f"  · + {name} ({right.shape[1] - len(on)} variables)")
    return merged
