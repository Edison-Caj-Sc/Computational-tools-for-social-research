# =====================================================================
#  07 · ORDINAL LOGIT (proportional odds)
#  For: ordered categories: Likert scales, trust, satisfaction, education level,
#  subjective social class.
#  Interpretation: OR > 1 → higher probability of being in higher categories.
#  Key assumption: each effect is the same across all cut-points (checked below).
# =====================================================================

# ---------------------------------------------------------------------
# 0. SETTINGS · edit this section only
# ---------------------------------------------------------------------
file           <- NULL
outcome        <- "trust"
order          <- c("none", "little", "some", "a_lot")   # from lowest to highest
predictors     <- c("head_educ", "org_member", "head_sex", "area", "head_age")
factors        <- list(head_sex = "male", area = "urban")
extra_terms    <- NULL
manual_formula <- NULL
focus_variable <- "head_educ"
use_design     <- FALSE
design         <- list(stratum = "stratum", psu = "psu", weight = "weight")
output_dir     <- "results/07_ordinal_logit"

# ---------------------------------------------------------------------
# 1. Preparation
# ---------------------------------------------------------------------
source("utils.R"); install_if_missing()
out     <- prepare_output(output_dir)
formula <- build_formula(outcome, predictors, extra_terms, manual_formula)
y <- all.vars(formula)[1]
data    <- prepare_data(load_data(file), formula_vars(formula), factors,
                        ordered = setNames(list(order), y), extra = design_vars(use_design, design))
dsg <- if (use_design) create_design(data, design) else NULL

header("Outcome distribution")
print(round(prop.table(table(data[[y]])), 3))

# ---------------------------------------------------------------------
# 2. Estimation
# ---------------------------------------------------------------------
header("Model")
model <- if (use_design) svyolr(formula, design = dsg) else MASS::polr(formula, data = data, Hess = TRUE)
print(summary(model))
ct <- coef(summary(model))
is_cut <- rownames(ct) %in% names(model$zeta)
z <- ct[, "t value"]
tab <- data.frame(term = rownames(ct), type = ifelse(is_cut, "cut-point", "coefficient"),
                  estimate = ct[, "Value"], se = ct[, "Std. Error"], z = z, p = 2 * pnorm(-abs(z)))
tab$ci_low  <- tab$estimate - qnorm(.975) * tab$se
tab$ci_high <- tab$estimate + qnorm(.975) * tab$se
tab$or         <- ifelse(is_cut, NA, exp(tab$estimate))
tab$or_ci_low  <- ifelse(is_cut, NA, exp(tab$ci_low))
tab$or_ci_high <- ifelse(is_cut, NA, exp(tab$ci_high))
tab$signif <- stars(tab$p)
rownames(tab) <- NULL
print(round_df(tab, 3)); save_table(tab, "2_coefficients", out)

# ---------------------------------------------------------------------
# 3. Proportional odds assumption
#    A binary logit is fitted at each cut-point (Y > category k). If coefficients change
#    a lot across cut-points, the assumption fails: consider 08_multinomial_logit.R
# ---------------------------------------------------------------------
if (!use_design) {
  header("Proportional odds check (logits by cut-point)")
  lv <- levels(data[[y]])
  cuts <- lapply(seq_len(length(lv) - 1), function(k) {
    d <- data; d$.y_bin <- as.integer(as.integer(d[[y]]) > k)
    coef(glm(update(formula, .y_bin ~ .), data = d, family = binomial()))[-1]
  })
  po <- as.data.frame(do.call(cbind, cuts))
  names(po) <- paste0("above_", lv[-length(lv)])
  po$ordinal <- coef(model)[rownames(po)]
  po$range_across_cuts <- apply(po[, seq_along(cuts)], 1, function(x) diff(range(x)))
  po <- cbind(term = rownames(po), po); rownames(po) <- NULL
  print(round_df(po, 3)); save_table(po, "3_proportional_odds", out)
  cat("If a coefficient changes sign or size markedly across cut-points, the assumption is doubtful.\n")
  fit <- data.frame(n = nobs(model), AIC = AIC(model), BIC = BIC(model),
                    pseudo_r2_mcfadden = 1 - as.numeric(logLik(model) / logLik(update(model, . ~ 1))))
  print(round_df(fit, 3)); save_table(fit, "3_fit", out)
}

# ---------------------------------------------------------------------
# 4. Interpretation: marginal effects on the probability of each category
# ---------------------------------------------------------------------
header("Average marginal effects by category")
ame <- marginal_effects(model, data, dsg)
print(round_df(ame, 4)); save_table(ame, "4_marginal_effects", out)
g <- prediction_plot(model, data, c(focus_variable, "group"), dsg, paste("Probability of each category of", y)) +
  labs(y = "Probability", colour = y, fill = y)
g$data$group <- factor(g$data$group, levels = levels(data[[y]]))   # legend follows the scale order
save_plot(g, "4_predictions", out)
save_text(summary(model), "model_summary", out)
header(paste("Done. Results in", out))
