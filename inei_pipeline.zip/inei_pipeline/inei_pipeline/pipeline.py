"""Orquesta el flujo completo: descargar → leer y unir → armonizar → estandarizar → imputar → exportar."""
from __future__ import annotations

import pandas as pd

from .config import load_config, resolve
from .download import download
from .export import export
from .harmonize import harmonize_year, labels
from .impute import impute_all
from .merge import merge_tables
from .reader import read_year
from .standardize import standardize
from .utils import ConfigError, log


class Pipeline:
    """Uso en Python o notebooks:

        p = Pipeline("config.yaml")
        datos = p.run()              # todo el flujo
        # o paso a paso:
        p.download(); base = p.build(); base = p.standardize(base)
        bases, reporte = p.impute(base); p.export(bases, reporte)
    """

    def __init__(self, config):
        self.cfg = load_config(config)

    def download(self):
        return download(self.cfg)

    def build(self) -> pd.DataFrame:
        """Lee, une y armoniza cada año; luego apila todos los años."""
        cfg, frames = self.cfg, []
        root = resolve(cfg, cfg["datos"]["carpeta"])
        for year in cfg["_anios"]:
            log.info(f"Año {year}")
            tables = read_year(root / str(year), cfg["datos"].get("modulos"), cfg["unir"].get("excluir_tablas"))
            if not tables:
                log.warning(f"  · no hay archivos en {root / str(year)}; se omite el año")
                continue
            df = merge_tables(tables, cfg)
            df["anio"] = year
            for cond in cfg["unir"].get("filtros") or []:
                n = len(df)
                try:
                    df = df.query(str(cond))
                except Exception as e:
                    raise ConfigError(f"Error en el filtro {cond!r} ({year}): {e}") from e
                log.info(f"  · filtro '{cond}': {n:,} -> {len(df):,} filas")
            frames.append(harmonize_year(df, year, cfg))
        if not frames:
            raise ConfigError("No se leyó ningún año. ¿Descargaste los datos o la carpeta es correcta?")
        out = pd.concat(frames, ignore_index=True)
        log.info(f"Base armonizada: {len(out):,} filas × {out.shape[1]} columnas")
        return out

    def standardize(self, df):
        return standardize(df, self.cfg)

    def impute(self, df):
        return impute_all(df, self.cfg)

    def export(self, datasets, report):
        return export(datasets, self.cfg, labels(self.cfg), report)

    def run(self, descargar: bool | None = None):
        if self.cfg["datos"].get("descargar", True) if descargar is None else descargar:
            self.download()
        base = self.build()
        if str(self.cfg["imputar"].get("momento", "despues")).lower() == "antes":
            bases, report = self.impute(base)
            bases = [self.standardize(b) for b in bases]
        else:
            bases, report = self.impute(self.standardize(base))
        folder = self.export(bases, report)
        log.info(f"Listo. Resultados en {folder}")
        return bases[0] if len(bases) == 1 else bases


def run(config, descargar: bool | None = None):
    return Pipeline(config).run(descargar)
