# =====================================================================
#  06 · REGRESIÓN FRACCIONAL (logit cuasibinomial, Papke y Wooldridge)
#  Para: proporciones entre 0 y 1, incluidos 0 y 1 exactos: participación del gasto
#  en alimentos, porcentaje de votos, tasa de asistencia.
#  Interpretación: usa los efectos marginales (cambio en la proporción esperada).
# =====================================================================

# ---------------------------------------------------------------------
# 0. CONFIGURACIÓN · edita solo esta sección
# ---------------------------------------------------------------------
archivo        <- NULL
dependiente    <- "prop_gasto_alim"       # entre 0 y 1 (si está en %, divide entre 100)
escala_100     <- FALSE                   # TRUE si la variable está en porcentaje (0-100)
predictores    <- c("log_ingreso", "educ_jefe", "sexo_jefe", "area", "mieperho")
factores       <- list(sexo_jefe = "hombre", area = "urbano")
terminos_extra <- NULL
formula_manual <- NULL
variable_foco  <- "log_ingreso"
usar_diseno    <- FALSE
diseno         <- list(estrato = "estrato", conglomerado = "conglome", peso = "factor07")
carpeta_salida <- "resultados/06_regresion_fraccional"

# ---------------------------------------------------------------------
# 1. Preparación
# ---------------------------------------------------------------------
source("utilidades.R"); instalar_si_falta()
salida  <- preparar_salida(carpeta_salida)
formula <- construir_formula(dependiente, predictores, terminos_extra, formula_manual)
datos   <- preparar_datos(cargar_datos(archivo), variables_formula(formula), factores,
                          extra = vars_diseno(usar_diseno, diseno))
y <- all.vars(formula)[1]
if (escala_100) datos[[y]] <- datos[[y]] / 100
if (any(datos[[y]] < 0 | datos[[y]] > 1)) stop("La variable dependiente debe estar entre 0 y 1 (usa 'escala_100').")
dis <- if (usar_diseno) crear_diseno(datos, diseno) else NULL

encabezado("Descriptivos")
desc <- data.frame(media = mean(datos[[y]]), mediana = median(datos[[y]]),
                   pct_ceros = 100 * mean(datos[[y]] == 0), pct_unos = 100 * mean(datos[[y]] == 1))
print(redondear(desc, 3)); guardar_tabla(desc, "1_descriptivos", salida)

# ---------------------------------------------------------------------
# 2. Estimación (errores robustos: la cuasiverosimilitud solo exige bien especificada la media)
# ---------------------------------------------------------------------
encabezado("Modelo")
if (usar_diseno) {
  modelo <- svyglm(formula, design = dis, family = quasibinomial())
  vc <- NULL
} else {
  modelo <- glm(formula, data = datos, family = quasibinomial())
  vc <- sandwich::vcovHC(modelo, type = "HC0")
}
coefs <- tabla_coeficientes(modelo, vcov = vc)
print(redondear(coefs, 3)); guardar_tabla(coefs, "2_coeficientes", salida)
cat("Los coeficientes están en escala logit; interpreta su signo y usa los efectos marginales para la magnitud.\n")

# ---------------------------------------------------------------------
# 3. Ajuste
# ---------------------------------------------------------------------
encabezado("Ajuste")
ajuste <- data.frame(n = nrow(datos), correlacion_obs_pred2 = cor(datos[[y]], fitted(modelo))^2,
                     dispersion = summary(modelo)$dispersion)
print(redondear(ajuste, 3)); guardar_tabla(ajuste, "3_ajuste", salida)

# ---------------------------------------------------------------------
# 4. Interpretación
# ---------------------------------------------------------------------
encabezado("Efectos marginales promedio (cambio en la proporción)")
ame <- efectos_marginales(modelo, datos, dis, vcov = if (is.null(vc)) TRUE else vc)
ame$efecto_pp <- 100 * ame$efecto
print(redondear(ame, 4)); guardar_tabla(ame, "4_efectos_marginales", salida)
guardar_grafico(grafico_predicciones(modelo, datos, variable_foco, dis, paste("Proporción esperada de", y)),
                "4_predicciones", salida)
guardar_texto(summary(modelo), "resumen_modelo", salida)
encabezado(paste("Listo. Resultados en", salida))
