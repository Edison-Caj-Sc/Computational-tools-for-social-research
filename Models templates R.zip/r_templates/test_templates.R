# Runs every template on the example data, with and without survey design.
# Useful after editing utils.R. Results go to a temporary folder.
templates <- sort(list.files(pattern = "^0[1-9].*\\.R$"))
tmp <- file.path(tempdir(), "template_tests")
res <- expand.grid(template = templates, design = c(FALSE, TRUE), stringsAsFactors = FALSE)
res$result <- NA_character_
for (i in seq_len(nrow(res))) {
  code <- readLines(res$template[i], encoding = "UTF-8")
  code <- sub("^use_design +<- FALSE", paste("use_design <-", res$design[i]), code)
  code <- sub('^output_dir +<- "results/', paste0('output_dir <- "', tmp, "/", res$design[i], "_"), code)
  r <- tryCatch({
    utils::capture.output(suppressMessages(eval(parse(text = code), envir = new.env())))
    "OK"
  }, error = function(e) paste("ERROR:", conditionMessage(e)))
  res$result[i] <- r
  cat(sprintf("%-28s design=%-5s %s\n", res$template[i], res$design[i], r))
}
if (all(res$result == "OK")) cat("\nAll templates work.\n") else stop("Some templates failed.")
