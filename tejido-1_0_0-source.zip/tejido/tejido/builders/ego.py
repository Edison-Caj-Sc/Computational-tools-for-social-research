"""Personal (egocentric) networks from surveys: each respondent (ego) names contacts (alters).

format: wide  one row per respondent; name-generator columns (alter1, alter2…), alter attributes as
              lists of columns or patterns like "alter{i}_sex", alter–alter ties like "tie_{i}_{j}"
        long  one row per ego–alter pair; alter–alter ties in a second table (alter_ties: {path, …})
positions     position generator (Lin): one column per occupation, prestige scores → extensity,
              upper reachability, range and mean prestige of accessed positions
Per ego it computes size, density, effective size, efficiency and constraint (Burt), composition,
heterogeneity (IQV), homophily and E-I index by attribute → table "egos" and ego node attributes."""
from __future__ import annotations

import itertools
from collections import defaultdict

import networkx as nx
import numpy as np
import pandas as pd

from ..config import resolve
from ..io import read_table
from ..utils import ConfigError, as_list, log, require_columns, slug
from . import register


def _blank(v) -> bool:
    return v is None or (isinstance(v, float) and np.isnan(v)) or str(v).strip() in ("", "nan", "None", "<NA>")


def _expand_cols(spec, n, data, where):
    if isinstance(spec, str) and "{i}" in spec:
        cols = [spec.format(i=i) for i in range(1, n + 1)]
    else:
        cols = as_list(spec)
    require_columns(data, cols, where)
    return cols


def _is_numeric(values: pd.Series) -> bool:
    num = pd.to_numeric(values, errors="coerce")
    return num.notna().sum() >= .9 * values.notna().sum() and num.nunique() > 10


def _collect(data: pd.DataFrame, opts: dict, cfg: dict):
    """→ alters: list of dicts (ego, alter, weight, attrs); ties: set of (ego, alter_a, alter_b, weight)."""
    ego = opts.get("ego")
    if not ego:
        raise ConfigError("ego: set 'ego' (respondent id column)")
    fmt = opts.get("format", "wide")
    attr_spec = opts.get("alter_attributes") or {}
    alters, ties = [], []
    if fmt == "wide":
        cols = as_list(opts.get("alters"))
        if len(cols) == 1 and "*" in cols[0]:
            import fnmatch
            cols = [c for c in data.columns if fnmatch.fnmatch(str(c), cols[0])]
        require_columns(data, [ego] + cols, "ego.alters")
        if not cols:
            raise ConfigError("ego (wide): 'alters' must list the name-generator columns")
        n = len(cols)
        acols = {a: _expand_cols(spec, n, data, f"ego.alter_attributes.{a}") for a, spec in attr_spec.items()}
        wcols = _expand_cols(opts["weights"], n, data, "ego.weights") if opts.get("weights") else None
        tie_pat = opts.get("alter_ties")
        for _, r in data.iterrows():
            e = str(r[ego])
            names = {}
            for i, c in enumerate(cols):
                if _blank(r[c]):
                    continue
                names[i + 1] = str(r[c]).strip()
                alters.append({"ego": e, "alter": names[i + 1],
                               "weight": float(pd.to_numeric(r[wcols[i]], errors="coerce")) if wcols else 1.0,
                               **{a: r[cl[i]] for a, cl in acols.items()}})
            if isinstance(tie_pat, str):
                for i, j in itertools.combinations(sorted(names), 2):
                    col = next((tie_pat.format(i=a, j=b) for a, b in ((i, j), (j, i))
                                if tie_pat.format(i=a, j=b) in data.columns), None)
                    v = pd.to_numeric(r[col], errors="coerce") if col else np.nan
                    if col and v > 0:
                        ties.append((e, names[i], names[j], float(v)))
    elif fmt == "long":
        alter = opts.get("alter")
        attrs = list(attr_spec) if isinstance(attr_spec, dict) else as_list(attr_spec)
        require_columns(data, [ego, alter, opts.get("weight")] + attrs, "ego (long)")
        for _, r in data.iterrows():
            if _blank(r[alter]) or _blank(r[ego]):
                continue
            alters.append({"ego": str(r[ego]), "alter": str(r[alter]).strip(),
                           "weight": float(pd.to_numeric(r[opts["weight"]], errors="coerce")) if opts.get("weight") else 1.0,
                           **{a: r[a] for a in attrs}})
        spec = opts.get("alter_ties")
        if isinstance(spec, dict):
            t = read_table(resolve(cfg, spec["path"]))
            e2, a, b = spec.get("ego", ego), spec.get("alter_a", "alter_a"), spec.get("alter_b", "alter_b")
            require_columns(t, [e2, a, b, spec.get("weight")], "ego.alter_ties")
            for _, r in t.iterrows():
                w = float(pd.to_numeric(r[spec["weight"]], errors="coerce")) if spec.get("weight") else 1.0
                if w > 0:
                    ties.append((str(r[e2]), str(r[a]).strip(), str(r[b]).strip(), w))
    else:
        raise ConfigError("ego: 'format' must be wide or long")
    if not alters:
        raise ConfigError("ego: no alters found (check the alter columns)")
    return alters, ties


def _ego_attrs(data, opts):
    spec = opts.get("ego_attributes") or {}
    if not isinstance(spec, dict):
        spec = {c: c for c in as_list(spec)}
    require_columns(data, [opts["ego"]] + list(spec.values()), "ego.ego_attributes")
    t = data.drop_duplicates(opts["ego"]).set_index(data.drop_duplicates(opts["ego"])[opts["ego"]].astype(str))
    return {a: t[c] for a, c in spec.items()}


def _positions(data, opts):
    spec = opts.get("positions")
    if not spec:
        return None
    cols = as_list(spec.get("columns") or list(spec.get("prestige") or {}))
    require_columns(data, [opts["ego"]] + cols, "ego.positions")
    prestige = {c: float(spec.get("prestige", {}).get(c, np.nan)) for c in cols}
    known = data[cols].apply(pd.to_numeric, errors="coerce").fillna(0) > 0
    rows = {}
    for e, k in zip(data[opts["ego"]].astype(str), known.to_numpy()):
        p = np.array([prestige[c] for c, x in zip(cols, k) if x], dtype=float)
        p = p[~np.isnan(p)]
        rows[e] = {"positions_extensity": int(k.sum()),
                   "positions_upper_reach": float(p.max()) if len(p) else np.nan,
                   "positions_range": float(p.max() - p.min()) if len(p) else np.nan,
                   "positions_mean_prestige": float(p.mean()) if len(p) else np.nan}
    return pd.DataFrame.from_dict(rows, orient="index")


@register("ego", "Personal networks from surveys: size, density, constraint, composition, homophily, positions")
def build(data: pd.DataFrame, opts: dict, cfg: dict):
    alters, ties = _collect(data, opts, cfg)
    A = pd.DataFrame(alters).drop_duplicates(["ego", "alter"])
    attrs = [c for c in A.columns if c not in ("ego", "alter", "weight")]
    kind = {a: "numeric" if _is_numeric(A[a]) else "categorical" for a in attrs}
    cats = {a: sorted(A[a].dropna().astype(str).unique()) for a in attrs if kind[a] == "categorical"}
    ego_vals = _ego_attrs(data, opts)
    has_ties = opts.get("alter_ties") is not None
    shared = bool(opts.get("shared_alters", False))
    aid = (lambda e, a: a) if shared else (lambda e, a: f"{e}::{a}")
    ties_by = defaultdict(list)
    for e, a, b, w in ties:
        ties_by[e].append((a, b, w))

    G = nx.Graph()
    rows = []
    for e, grp in A.groupby("ego", sort=False):
        names = grp["alter"].tolist()
        n = len(names)
        G.add_node(e, label=e, type="ego")
        for d in grp.to_dict("records"):               # keeps column names with spaces or accents
            node = aid(e, d["alter"])
            G.add_node(node, label=d["alter"], type="alter",
                       **{k: (v.item() if hasattr(v, "item") else v) for k, v in d.items() if k in attrs and not _blank(v)})
            G.add_edge(e, node, weight=d["weight"], relation="ego_alter")
        et = [(a, b, w) for a, b, w in ties_by.get(e, []) if a in names and b in names and a != b]
        E = nx.Graph()
        E.add_nodes_from(names)
        E.add_weighted_edges_from(et)
        for a, b, w in et:
            G.add_edge(aid(e, a), aid(e, b), weight=w, relation="alter_alter")
        t = E.number_of_edges()
        m = {"ego": e, "size": n, "mean_tie_strength": round(float(grp["weight"].mean()), 4)}
        if has_ties:
            m.update({"alter_ties": t, "density": round(2 * t / (n * (n - 1)), 4) if n > 1 else np.nan,
                      "alter_components": nx.number_connected_components(E) if n else 0,
                      "alter_isolates": sum(1 for x in E if E.degree(x) == 0),
                      "effective_size": round(n - 2 * t / n, 4) if n else 0})
            m["efficiency"] = round(m["effective_size"] / n, 4) if n else np.nan
            Eg = E.copy()
            Eg.add_weighted_edges_from((e + "\0ego", x, w) for x, w in zip(grp["alter"], grp["weight"]))
            m["constraint"] = round(nx.constraint(Eg, [e + "\0ego"], weight="weight")[e + "\0ego"], 4) if n else np.nan
        for a in attrs:
            vals = grp[a]
            ev = ego_vals.get(a, pd.Series(dtype=object)).get(e) if a in ego_vals else None
            if kind[a] == "numeric":
                x = pd.to_numeric(vals, errors="coerce")
                m[f"mean_{slug(a)}"], m[f"sd_{slug(a)}"] = round(x.mean(), 4), round(x.std(ddof=0), 4)
                if ev is not None and not _blank(ev):
                    m[f"diff_{slug(a)}"] = round(float((x - float(ev)).abs().mean()), 4)
            else:
                s = vals.dropna().astype(str)
                K = len(cats[a])
                p = s.value_counts(normalize=True)
                m[f"iqv_{slug(a)}"] = round((1 - (p ** 2).sum()) / (1 - 1 / K), 4) if K > 1 and len(s) else np.nan
                if K <= 8:
                    for c in cats[a]:
                        m[f"share_{slug(a)}_{slug(c)}"] = round(float(p.get(c, 0)), 4)
                if ev is not None and not _blank(ev) and len(s):
                    same = (s == str(ev)).sum()
                    m[f"same_{slug(a)}"] = round(same / len(s), 4)
                    m[f"ei_{slug(a)}"] = round((len(s) - 2 * same) / len(s), 4)
        rows.append(m)
    egos = pd.DataFrame(rows).set_index("ego")
    pos = _positions(data, opts)
    if pos is not None:
        egos = egos.join(pos, how="outer")
        egos["size"] = egos["size"].fillna(0)
    for a, ser in ego_vals.items():
        for e, v in ser.items():
            if e in G and not _blank(v):
                G.nodes[e][a] = v.item() if hasattr(v, "item") else v
    for e, r in egos.iterrows():
        if e in G:
            G.nodes[e].update({k: (v.item() if hasattr(v, "item") else v) for k, v in r.items() if pd.notna(v)})
    egos = egos.reset_index().rename(columns={"index": "ego"})
    G.graph["tables"] = {"egos": egos}
    G.graph["summary"] = {"egos": len(egos), "mean_network_size": round(float(egos["size"].mean()), 3)}
    if has_ties:
        G.graph["summary"]["mean_ego_density"] = round(float(egos["density"].mean()), 4)
        G.graph["summary"]["mean_constraint"] = round(float(egos["constraint"].mean()), 4)
    log.info(f"ego: {len(egos)} respondents, {len(A):,} alters, {len(ties):,} alter–alter ties")
    return G
